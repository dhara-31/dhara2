/*
package com.si_videoplayer.gautm_videoplayer.Castutils;



import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;

import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import java.io.File;

import io.github.dkbai.tinyhttpd.nanohttpd.webserver.SimpleWebServer;
import kotlin.jvm.internal.Intrinsics;

public class WebService extends IntentService {
    private final String TAG = getClass().getSimpleName();
    Context context;

    public WebService() {
        super("blank");
    }

    @Override
    public void onStart(Intent intent, int startId) {
       // SimpleWebServer.stopServer();
        super.onStart(intent, startId);
        context=this;
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        try {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            Intrinsics.checkExpressionValueIsNotNull(externalStorageDirectory, "Environment.getExternalStorageDirectory()");
            SimpleWebServer.runServer(new String[]{"-h", Utils.findIPAddress(getApplicationContext()), "-p 8036", "-d", externalStorageDirectory.getAbsolutePath()});
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        SimpleWebServer.stopServer();
        super.onDestroy();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        SimpleWebServer.stopServer();
        if (Utils.Companion.getRemoteMediaClient() != null) {
            RemoteMediaClient remoteMediaClient = Utils.Companion.getRemoteMediaClient();
            if (remoteMediaClient == null) {
                Intrinsics.throwNpe();
            }
            remoteMediaClient.stop();
        }
        CastContext castContext = CastContext.getSharedInstance(this);
        Intrinsics.checkExpressionValueIsNotNull(castContext, "CastContext.getSharedInstance(this@WebService)");
        SessionManager mSessionManager = castContext.getSessionManager();
        Intrinsics.checkExpressionValueIsNotNull(mSessionManager, "castContext.sessionManager");
        mSessionManager.endCurrentSession(true);
    }
}
*/
