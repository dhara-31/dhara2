package com.si_videoplayer.gautm_videoplayer.Activity;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.mycl.AppvidDetail;
import com.si_videoplayer.gautm_videoplayer.Floating.DviddecgtmApplication;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;
import com.si_videoplayer.gautm_videoplayer.Castutils.Natviddecgtm2sAll;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_IMG = 123;
    RelativeLayout  relativ_share_mani, relativ_pri_po_mani, relativ_rateus_mani;
    ImageView  img_main_start;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView cardView = findViewById(R.id.c);
        Natviddecgtm2sAll.banerAllSviddecgtmow(admobNativeLarge2, MainActivity.this, cardView);


        relativ_share_mani=findViewById(R.id.relativ_share_mani);
        relativ_pri_po_mani=findViewById(R.id.relativ_pri_po_mani);
        relativ_rateus_mani=findViewById(R.id.relativ_rateus_mani);
        img_main_start=findViewById(R.id.img_main_start);




        img_main_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (UtilsVideo.checkIfPermissions(MainActivity.this, REQ_IMG)) {
                    startImage();
                }
            }
        });

        relativ_share_mani.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "share app");
                    String shareMessage = "\nLet me recommend you this application\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + getPackageName();
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (java.lang.Exception e) {

                }
            }

        });
        relativ_pri_po_mani.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();
                if (appDetail != null) {
                    if (appDetail.getPrivacy().equals("")) {
                        Toast.makeText(MainActivity.this, "Url not found...", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(appDetail.getPrivacy()));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                        try {
                            startActivity(i);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(MainActivity.this, "Unable to open chrome", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Url not found...", Toast.LENGTH_SHORT).show();
                }
            }
        });

        relativ_rateus_mani.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } catch (ActivityNotFoundException e) {

                } catch (Exception e) {

                }
            }
        });



    }

    private void startImage() {
        GoviddecgtmAs.getInstance().showinter(MainActivity.this, new GoviddecgtmAs.AviddetInterface() {
            @Override
            public void abrttall() {
                Intent intent=new Intent(MainActivity.this,ManiVideoPlayerActivity.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        if (
                ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == REQ_IMG) {
                startImage();
            }
        } else {
            if (
                    !ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                            !ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, READ_EXTERNAL_STORAGE)
            ) {
                showPermissionDialog();
            }

        }
    }

    private void showPermissionDialog() {

        Dialog alertDialog = new Dialog(MainActivity.this);

        alertDialog.setContentView(R.layout.permission_dialog_vi_main);

        TextView text_Allow_btn_set_dilog = alertDialog.findViewById(R.id.text_Allow_btn_set_dilog);
        TextView text_cancel_btn_set_dilog = alertDialog.findViewById(R.id.text_cancel_btn_set_dilog);
        text_Allow_btn_set_dilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        });
        text_cancel_btn_set_dilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });


        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(this, ExitVideoPlayerActivity.class));
    }
}