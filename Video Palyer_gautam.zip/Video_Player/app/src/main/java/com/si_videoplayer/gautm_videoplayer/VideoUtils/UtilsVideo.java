package com.si_videoplayer.gautm_videoplayer.VideoUtils;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.EditText;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Activity.MainActivity;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;

import java.io.File;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UtilsVideo {

    private static final int DEFAULT_BUFFER_SIZE = 1 * 1024 * 1024;
    private static MediaFormat videoFormat;
    private static MediaFormat audioFormat;


    public static int hour = 0;
    public static int min = 0;
    public static Date currentTime = Calendar.getInstance().getTime();

    static long kilo = 1024;
    static long mega = kilo * kilo;
    static long giga = mega * kilo;
    static long tera = giga * kilo;

    private static PreferenceUtil preferenceUtil;


    private static long durationUs;
    private static final long SLEEP_TO_WAIT_TRACK_TRANSCODERS = 10;
    private static final long PROGRESS_INTERVAL_STEPS = 10;
    private static volatile boolean canceled;


    public static boolean checkIfPermissions(Context context, int reqImg) {
        final String[] permissions = new String[]{
                WRITE_EXTERNAL_STORAGE,
                READ_EXTERNAL_STORAGE
        };

        if (ContextCompat.checkSelfPermission(context, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(context, READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((Activity) context, permissions, reqImg);
            return false;
        } else {
            return true;
        }
    }    public static boolean checkIf(Context context) {
        final String[] permissions = new String[]{
                WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE
        };

        if (ContextCompat.checkSelfPermission(context, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(context, READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            return false;
        } else {
            return true;
        }
    }

    public static String readableFileSize(long size) {
        String s = "";
        double kb = (double) size / kilo;
        double mb = kb / kilo;
        double gb = mb / kilo;
        double tb = gb / kilo;
        if (size < kilo) {
            s = size + " By";
        } else if (size >= kilo && size < mega) {
            s = String.format("%.2f", kb) + " KB";
        } else if (size >= mega && size < giga) {
            s = String.format("%.2f", mb) + " MB";
        } else if (size >= giga && size < tera) {
            s = String.format("%.2f", gb) + " GB";
        } else if (size >= tera) {
            s = String.format("%.2f", tb) + " TB";
        }
        return s;
    }

    public static String formateMilliSeccond(long milliseconds) {
        String finalTimerString = "";
        String secondsString = "";

        int hours = (int) (milliseconds / (1000 * 60 * 60));
        int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
        if (hours > 0) {
            finalTimerString = hours + ":";
        }
        if (seconds < 10) {
            secondsString = "0" + seconds;
        } else {
            secondsString = "" + seconds;
        }
        finalTimerString = finalTimerString + minutes + ":" + secondsString;
        return finalTimerString;
    }

    public static String convertLongToTime(long time, String format) {

        return new SimpleDateFormat(format, Locale.ENGLISH).format(new Date(time));

    }

    public static String convertSolution(String resolution) {
        if (resolution != null) {
            String str;
            String[] split = resolution.split("[^\\d]+");

            if (split.length >= 2) {
                str = split[1];
            } else {
                if (split.length == 1) {
                    str = split[0];
                }
                return "720P";
            }
            long parseLong = Long.parseLong(str);

            return parseLong < 240 ? "144P" : parseLong < 360 ? "240P" : parseLong < 480 ? "360P" : parseLong < 720 ? "480P" : parseLong < 1080 ? "720P" : parseLong < 1440 ? "1080P" : parseLong < 2160 ? "1440P" : parseLong < 4320 ? "4K" : "8K";

        } else {
            return null;
        }

    }

    public static void renameFile(File file, String newName, String oladname) {
        File dir = file.getParentFile();
        if (dir.exists()) {
            File from = new File(dir, oladname);
            File to = new File(dir, newName);
            if (from.exists())
                from.renameTo(to);
        }

    }

    public static Uri getUriFromVideoPath(Activity activity, String songPath) {
        File file = new File(songPath);
        if (file.exists()) {
            long id = 0;
            String selection = MediaStore.Video.Media.DATA;

            Cursor cursor = activity.getContentResolver().query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, new String[]{MediaStore.Video.Media._ID, MediaStore.Video.Media.DATA},
                    selection + "=?", new String[]{file.getAbsolutePath()}, null
            );

            if (cursor != null) {
                while (cursor.moveToNext()) {

                    int idIndex = cursor.getColumnIndex(MediaStore.Video.Media._ID);

                    id = Long.parseLong(cursor.getString(idIndex));
                    Uri videoUri = ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            id
                    );
                    return videoUri;

                }
            }
        }
        return null;
    }

    public static void playlistdatarenama(Context context, String lod_path, File file_original, String newName) {
        preferenceUtil = new PreferenceUtil(context);
        ArrayList<VideoInfo> list_play = new ArrayList<>();
        Gson gson = new Gson();
        String json1Null00 = gson.toJson(list_play);
        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();

        list_play = gson.fromJson(json00, type00);
        if (list_play == null) {
            list_play = new ArrayList<>();
        }
        for (int i = 0; i < list_play.size(); i++) {

            getdatalisr_rename(context, list_play.get(i).getList_name(), lod_path, file_original, newName);
        }
    }

    private static void getdatalisr_rename(Context context, String list_name, String lod_path, File file_original, String newName) {


        preferenceUtil = new PreferenceUtil(context);
        ArrayList<VideoInfo> list_play = new ArrayList<>();
        Gson gson = new Gson();

        String json1Null11 = gson.toJson(list_play);
        String json11 = preferenceUtil.getString(list_name, json1Null11);
        Type type11 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_play = gson.fromJson(json11, type11);

        for (int i = 0; i < list_play.size(); i++) {

            if (list_play.get(i).getmPath().equals(lod_path)) {

                VideoInfo video_model = list_play.get(i);
                video_model.setmDisplayName(newName);
                video_model.setmPath(file_original.getAbsolutePath());
                String json = gson.toJson(list_play);
                preferenceUtil.putString(list_name, json);

            }
        }

    }

    public static void updateplaylistdatadelete(Context context, String path_delete) {
        preferenceUtil = new PreferenceUtil(context);
        ArrayList<VideoInfo> list_play = new ArrayList<>();
        Gson gson = new Gson();
        String json1Null00 = gson.toJson(list_play);
        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();

        list_play = gson.fromJson(json00, type00);
        if (list_play == null) {
            list_play = new ArrayList<>();
        }
        for (int i = 0; i < list_play.size(); i++) {

            getdatalisr_delete(context, list_play.get(i).getList_name(), path_delete);
        }
    }

    private static void getdatalisr_delete(Context context, String list_name, String path_delete) {
        preferenceUtil = new PreferenceUtil(context);
        ArrayList<VideoInfo> list_play = new ArrayList<>();
        Gson gson = new Gson();

        String json1Null11 = gson.toJson(list_play);
        String json11 = preferenceUtil.getString(list_name, json1Null11);
        Type type11 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_play = gson.fromJson(json11, type11);

        for (int i = 0; i < list_play.size(); i++) {
            if (list_play.get(i).getmPath().equals(path_delete)) {
                list_play.remove(i);
                String json = gson.toJson(list_play);
                preferenceUtil.putString(list_name, json);

            }

        }
    }

    public static void updateTime(int selectedHour, int selectedMinute, EditText et_hours, EditText et_min, TextView et_am_pm) {
        String newMinute = "";
        if (String.valueOf(selectedMinute).length() == 1) {
            newMinute = "0" + selectedMinute;
        } else {
            newMinute = String.valueOf(selectedMinute);
        }
        if (selectedMinute == 0) {
            newMinute = "00";
        }

        if (selectedHour == 0) {
            et_hours.setText("12");
            et_min.setText(newMinute + "");
            et_am_pm.setText("AM");
        } else if (selectedHour == 12) {
            et_hours.setText("12");
            et_min.setText(newMinute + "");
            et_am_pm.setText("PM");
        } else if (selectedHour > 12) {
            if (String.valueOf(selectedHour - 12).length() == 1) {
                et_hours.setText("0" + (selectedHour - 12));
            } else {
                et_hours.setText(selectedHour - 12 + "");
            }
            et_min.setText(newMinute + "");
            et_am_pm.setText("PM");
        } else {
            if (String.valueOf(selectedHour).length() == 1) {
                et_hours.setText("0" + selectedHour);
            } else {
                et_hours.setText("" + selectedHour);
            }
            et_min.setText(newMinute + "");
            et_am_pm.setText("AM");
        }
    }

    public static boolean isTablet(Context context) {
        return context.getResources().getConfiguration().smallestScreenWidthDp >= 720;
    }

    public static float normalizeFontScale(float fontScale, boolean small) {

        float newScale;

        if (fontScale > 1.01f) {
            if (fontScale >= 1.99f) {

                newScale = (small ? 1.15f : 1.2f);
            } else {

                newScale = (small ? 1.0f : 1.1f);
            }
        } else if (fontScale < 0.99f) {
            if (fontScale <= 0.26f) {

                newScale = (small ? 0.65f : 0.8f);
            } else {

                newScale = (small ? 0.75f : 0.9f);
            }
        } else {
            newScale = (small ? 0.85f : 1.0f);
        }
        return newScale;
    }

    public static boolean isVideoHaveAudioTrack(String path) {
        boolean audioTrack = false;

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(path);
        String hasAudioStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO);
        if (hasAudioStr != null && hasAudioStr.equals("yes")) {
            audioTrack = true;
        } else {
            audioTrack = false;
        }
        return audioTrack;
    }

    public static Bitmap getVideoFrame(String videoPath, long frameTime) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(videoPath);
            return retriever.getFrameAtTime(frameTime, MediaMetadataRetriever.OPTION_CLOSEST);
        } catch (IllegalArgumentException ex) {


        } catch (RuntimeException ex) {

        } finally {
            try {
                retriever.release();
            } catch (RuntimeException ex) {
            }
        }
        return null;
    }








}
