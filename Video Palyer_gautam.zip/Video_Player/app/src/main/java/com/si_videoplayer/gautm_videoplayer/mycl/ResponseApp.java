package com.si_videoplayer.gautm_videoplayer.mycl;

import java.util.ArrayList;

public class ResponseApp {
    private ArrayList<DetailAds> adsdetail = new ArrayList<>();
    private AppvidDetail appdetail;

    public ArrayList<DetailAds> getAdsdetail() {
        return adsdetail;
    }

    public void setAdsdetail(ArrayList<DetailAds> adsdetail) {
        this.adsdetail = adsdetail;
    }

    public AppvidDetail getAppdetail() {
        return appdetail;
    }

    public void setAppdetail(AppvidDetail appdetail) {
        this.appdetail = appdetail;
    }

}
