package com.si_videoplayer.gautm_videoplayer.mycl;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.si_videoplayer.gautm_videoplayer.Activity.MainActivity;
import com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity;
import com.si_videoplayer.gautm_videoplayer.Castutils.Natviddecgtm2sAll;
import com.si_videoplayer.gautm_videoplayer.Equalizer.DviddecgtmAppOpen;
import com.si_videoplayer.gautm_videoplayer.Floating.DviddecgtmApplication;
import com.si_videoplayer.gautm_videoplayer.R;

import retrofit2.Call;
import retrofit2.Callback;


public class SplashActivity extends AppCompatActivity {


    public static Handler handlgtDlash;
    public static Runnable runnableSPlgtD;
    CountDownTimer timer;
    int timerScreen = 11000;
    public DviddecgtmApplication mgtDpp = DviddecgtmApplication.getInstance();
    boolean checkResugtDed = true;

    boolean overtimegtDve = false;

    public Dialog dialogtDg;
    public static Boolean apgtDopenD = true;

    public static Boolean valugtDe = false;
    public static Integer valueintgtDD = 0;
    public static Boolean exgtDt = false;

    public static int screenngtDer = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DviddecgtmAppOpen.fividdecgtmag = true;

        setContentView(R.layout.activity_start);

        exgtDt = false;
        valueintgtDD = 0;

        valugtDe = false;
        DviddecgtmApplication.isSplviddecgtmnissh = false;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        DviddecgtmAppOpen.Splasviddecgtmty = SplashActivity.this;


        if (isNetworkAvailable()) {
            try {
                if (dialogtDg != null && dialogtDg.isShowing()) {
                    dialogtDg.dismiss();
                }
            } catch (Exception ignored) {
            }

            getApiValgtDs();
            startgtDve();
        } else {

            if (DviddecgtmAppOpen.appOpviddecgtm == null && DviddecgtmAppOpen.aviddecgtm2 == null) {
                InternetDialogUpdate();
            }
        }
    }


    public void getApiValgtDs() {

        Call<ResponseApp> call = ApiClieviddecgtm.getClient().create(ApiInterfaviddecgtm.class).getAll(getPackageName());

        call.enqueue(new Callback<ResponseApp>() {
            @Override
            public void onResponse(Call<ResponseApp> call, retrofit2.Response<ResponseApp> response) {
                if (response.isSuccessful()) {



                    mgtDpp.setAppDetail(response.body().getAppdetail());
                    mgtDpp.setAdsDetails(response.body().getAdsdetail());


                    if (mgtDpp.getAppDetail() != null && mgtDpp.getAppDetail().getAppscreennumber() != null && !TextUtils.isEmpty(mgtDpp.getAppDetail().getAppscreennumber())) {
                        screenngtDer = Integer.parseInt(mgtDpp.getAppDetail().getAppscreennumber());
                    }
                    if (mgtDpp.getAppDetail().getAdstatus().equalsIgnoreCase("2")) {
                        StartMaigtDeen();
                    } else if (mgtDpp.getAppDetail().getAdstatus().equals("1")) {

                        if (mgtDpp.getAppDetail() != null && mgtDpp.getAppDetail().getAdmobnew() != null && !TextUtils.isEmpty(mgtDpp.getAppDetail().getAdmobnew())) {

                            DviddecgtmAppOpen.AviddecgtmUNIT = mgtDpp.getAppDetail().getAdmobnew();

                            mgtDpp.inividdecgtmo();
                            mgtDpp.splashviddecgtmname = "SplashActivity";

                            DviddecgtmAppOpen.Splasviddecgtmty = SplashActivity.this;

                            DviddecgtmApplication.appOviddecgtmger.fividdecgtmag = true;

                            if (DviddecgtmAppOpen.appOpviddecgtm == null) {
                                DviddecgtmApplication.appOviddecgtmger.getOpeviddecgtms();
                            }

                        } else if (mgtDpp.getAppDetail() != null && mgtDpp.getAppDetail().getAdmob2appopen() != null

                                && !TextUtils.isEmpty(mgtDpp.getAppDetail().getAdmob2appopen())) {

                            DviddecgtmAppOpen.AviddecgtmNIT2 = mgtDpp.getAppDetail().getAdmob2appopen();
                            mgtDpp.inividdecgtmo();

                            mgtDpp.splashviddecgtmname = "SplashActivity";
                            DviddecgtmAppOpen.Splasviddecgtmty = SplashActivity.this;
                            DviddecgtmApplication.appOviddecgtmger.fividdecgtmag = true;

                            if (DviddecgtmAppOpen.aviddecgtm2 == null) {
                                DviddecgtmApplication.appOviddecgtmger.getLoadOpviddecgtm2();
                            }
                        } else {
                            StartMaigtDeen();
                        }
                    }

                } else {
                    StartMaigtDeen();
                }
            }

            @Override
            public void onFailure(Call<ResponseApp> call, Throwable t) {
                StartMaigtDeen();
            }
        });
    }


    public void startgtDve() {

        overtimegtDve = false;
        runnableSPlgtD = new Runnable() {
            @Override
            public void run() {

                overtimegtDve = true;
                DviddecgtmApplication.isSplviddecgtmnissh = true;

                if (isNetworkAvailable()) {
                    try {
                        if (dialogtDg != null && dialogtDg.isShowing()) {
                            dialogtDg.dismiss();
                        }
                    } catch (Exception e) {
                    }

                    if (checkResugtDed) {


                        if (exgtDt == false) {

                            valugtDe = true;

                            DviddecgtmApplication.isSplviddecgtmnissh = true;
                            AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();
                            if (appDetail != null && appDetail.getCounter() != null && !TextUtils.isEmpty(appDetail.getCounter())) {

                                if (Integer.parseInt(appDetail.getCounter()) > 1) {
                                    if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                                        GoviddecgtmAs.getInstance().loadviddecgtm(SplashActivity.this);

                                    } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                                        GoviddecgtmAs.getInstance().loadviddecgtmmmm2(SplashActivity.this);
                                    }
                                } else {
                                    GoviddecgtmAs.getInstance().loadviddecgtm(SplashActivity.this);
                                    GoviddecgtmAs.getInstance().loadviddecgtmmmm2(SplashActivity.this);
                                }
                            }

                            DviddecgtmApplication.appOviddecgtmger.fividdecgtmag = false;

                            try {
                                if (handlgtDlash != null) {
                                    handlgtDlash.removeCallbacks(runnableSPlgtD);
                                }
                            } catch (Exception e) {

                            }

                            Natviddecgtm2sAll.getInstance().loadNaviddecgtmth(SplashActivity.this);



                            if(screenngtDer >= 1)
                            {
                                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                                finish();
                            }
                            else {
                                startActivity(new Intent(SplashActivity.this, ManiVideoPlayerActivity.class));
                                finish();
                            }
                        }

                    }
                } else {
                    DviddecgtmApplication.isSplviddecgtmnissh = true;
                    try {
                        if (dialogtDg != null && dialogtDg.isShowing()) {
                            dialogtDg.dismiss();
                        }
                    } catch (Exception e) {
                    }
                    InternetDialogUpdate();
                }
            }
        };

        try {
            if (handlgtDlash != null) {
                handlgtDlash.removeCallbacks(runnableSPlgtD);
            }
        } catch (Exception e) {

        }


        try {
            if (timer != null) {
                timer.cancel();
            }
        } catch (Exception e) {

        }

        handlgtDlash = new Handler();

        handlgtDlash.postDelayed(runnableSPlgtD, timerScreen);

        timer = new CountDownTimer(timerScreen, 100) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
            }

        }.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        checkResugtDed = false;
    }

    private void StartMaigtDeen() {

        DviddecgtmApplication.appOviddecgtmger.fividdecgtmag = false;

        if(screenngtDer >= 1)
        {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }
        else {
            startActivity(new Intent(SplashActivity.this, ManiVideoPlayerActivity.class));
            finish();
        }

    }


    @Override
    protected void onResume() {
        checkResugtDed = true;
        super.onResume();

    }


    public void InternetDialogUpdate() {
        dialogtDg = new Dialog(this);
        dialogtDg.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialogtDg.requestWindowFeature(1);
        dialogtDg.setContentView(R.layout.net_connection);
        dialogtDg.setCancelable(false);
        RelativeLayout txt_yes = (RelativeLayout) dialogtDg.findViewById(R.id.yes);
        RelativeLayout r_retry = (RelativeLayout) dialogtDg.findViewById(R.id.r_retry);
        TextView txt = (TextView) dialogtDg.findViewById(R.id.txt);
        //  txt.setText("Internet is not working.\n" + "Start your Internet and restart app.");

        try {
            timer.cancel();
            handlgtDlash.removeCallbacks(runnableSPlgtD);
        } catch (Exception e) {

        }

        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                dialogtDg.dismiss();

            }
        });
        r_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    timer.cancel();
                    handlgtDlash.removeCallbacks(runnableSPlgtD);
                } catch (Exception e) {

                }

                if (isNetworkAvailable()) {
                    DviddecgtmApplication.isSplviddecgtmnissh = false;
                    try {
                        if (dialogtDg != null && dialogtDg.isShowing()) {
                            dialogtDg.dismiss();
                        }
                    } catch (Exception e) {
                    }
                    startgtDve();
                    getApiValgtDs();

                } else {
                    Toast.makeText(SplashActivity.this, "Please check your internet connection!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (!isFinishing()) {
            dialogtDg.show();
        }
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            boolean isAvailable = false;
            if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                isAvailable = true;
            }
            return isAvailable;
        } catch (Exception e) {
            return false;
        }

    }


    @Override
    protected void onDestroy() {
        try {
            if (handlgtDlash != null) {
                handlgtDlash.removeCallbacks(runnableSPlgtD);
            }
        } catch (Exception e) {

        }
        try {
            if (timer != null) {
                timer.cancel();
            }
        } catch (Exception e) {
        }
        super.onDestroy();
    }


    @Override
    public void onBackPressed() {
    }
}
