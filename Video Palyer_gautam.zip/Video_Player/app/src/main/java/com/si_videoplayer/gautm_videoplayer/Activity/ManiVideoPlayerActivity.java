package com.si_videoplayer.gautm_videoplayer.Activity;

import static android.os.Build.VERSION.SDK_INT;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.backGroundPlayingList;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.backgroundPosition;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.list_video_data;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.mediaPlayer;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.path_delete;
import static com.si_videoplayer.gautm_videoplayer.Service.NotificationService.foregroundService;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo.checkIf;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Adapter.ViewPagerMainAdapter;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Fragment.HistoryFragment;
import com.si_videoplayer.gautm_videoplayer.Fragment.PlaylistFragment;
import com.si_videoplayer.gautm_videoplayer.Fragment.VideoFragment;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.Service.NotificationService;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.mycl.AppvidDetail;
import com.si_videoplayer.gautm_videoplayer.Floating.DviddecgtmApplication;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;
import com.si_videoplayer.gautm_videoplayer.Model.MoreActivity;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ManiVideoPlayerActivity extends AppCompatActivity {


    private static final int REQ_IMG = 11;
    private ViewPagerMainAdapter viewPagerAdapter;
    private ViewPager viewPager_mani;
    ImageView img_teb_video, img_teb_playl, img_teb_histo;
    ArrayList<VideoInfo> list_all_data = new ArrayList<>();
    VideoFragment videoFragment;
    PlaylistFragment playlistFragment;
    HistoryFragment historyFragment;
    public static ManiVideoPlayerActivity maniVideoPlayerActivity;
    ArrayList<String> list_folder = new ArrayList<>();
    private ArrayList<VideoInfo> list_favo = new ArrayList<>();
    Gson gson;
    private ArrayList<VideoInfo> list_hist = new ArrayList<>();
    public PreferenceUtil preferenceUtil;
    public static ImageView mBtnPlayPause;
    public static ImageView song_thumbnail_img;
    public static ImageView btn_previous, btn_next;
    public static TextView mTxtSong;
    public static TextView mTxtComposer;
    public static RelativeLayout bottom_play_linear;
    ImageView bottom_linear_close_img;
    public static ProgressBar mProgressBar;

    RelativeLayout more_app, priv_pol, rate, share;

    DrawerLayout drawer_layout_id;
    NavigationView navigationview_id;


    int Counter = 0;
    private Dialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mani_video_player);

        maniVideoPlayerActivity = this;
        preferenceUtil = new PreferenceUtil(this);
        gson = new Gson();


        FrameLayout banner = findViewById(R.id.banner);
        GoviddecgtmAs.getInstance().ShowBanner(ManiVideoPlayerActivity.this, banner);

        img_teb_video = findViewById(R.id.img_teb_video);
        img_teb_playl = findViewById(R.id.img_teb_playl);
        img_teb_histo = findViewById(R.id.img_teb_histo);

        viewPager_mani = findViewById(R.id.viewPager_mani);
        bottom_linear_close_img = findViewById(R.id.bottom_linear_close_img);
        bottom_play_linear = findViewById(R.id.bottom_play_linear);
        song_thumbnail_img = findViewById(R.id.song_thumbnail_img);
        mTxtSong = findViewById(R.id.txt_song);
        mTxtComposer = findViewById(R.id.txt_composer);
        mBtnPlayPause = findViewById(R.id.btn_play_pause);
        btn_previous = findViewById(R.id.btn_previous);
        btn_next = findViewById(R.id.btn_next);
        mProgressBar = findViewById(R.id.progress);

        more_app=findViewById(R.id.more_app);
        priv_pol=findViewById(R.id.priv_pol);
        rate=findViewById(R.id.rate);
        share=findViewById(R.id.share);

        drawer_layout_id=findViewById(R.id. drawer_layout_id);
        navigationview_id=findViewById(R.id.navigationview_id);

        more_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             startActivity(new Intent(ManiVideoPlayerActivity.this, MoreActivity.class));
                drawer_layout_id.closeDrawers();
            }
        });
        priv_pol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();
                if (appDetail != null) {
                    if (appDetail.getPrivacy().equals("")) {
                        Toast.makeText(ManiVideoPlayerActivity.this, "Url not found...", Toast.LENGTH_SHORT).show();
                    } else {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(appDetail.getPrivacy()));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                        try {
                            startActivity(i);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(ManiVideoPlayerActivity.this, "Unable to open chrome", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(ManiVideoPlayerActivity.this, "Url not found...", Toast.LENGTH_SHORT).show();
                }

                drawer_layout_id.closeDrawers();
            }
        });
        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer_layout_id.closeDrawers();
                try {
                    String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } catch (ActivityNotFoundException e) {

                } catch (Exception e) {

                }
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer_layout_id.closeDrawers();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey check out this app at: https://play.google.com/store/apps/details?id=" + getPackageName());
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });


        if (isMyServiceRunning(NotificationService.class)) {
            try {
                if (bottom_play_linear != null) {
                    bottom_play_linear.setVisibility(View.VISIBLE);
                    mBtnPlayPause.setImageResource(R.drawable.vi_pause_audio);
                    mTxtSong.setText(backGroundPlayingList.get(backgroundPosition).getmDisplayName());
                    mTxtSong.setSelected(true);
                    if (mediaPlayer!=null){
                        try {
                            mProgressBar.setMax(mediaPlayer.getDuration());
                            mProgressBar.setProgress(mProgressBar.getProgress());
                        }catch (Exception e){}
                    }
                }
            }catch (Exception e){}
        }else {
            try {
                if (bottom_play_linear != null) {
                    bottom_play_linear.setVisibility(View.GONE);
                }
            }catch (Exception e){}

        }
        mTxtSong.setSelected(true);

        if (UtilsVideo.checkIfPermissions(ManiVideoPlayerActivity.this, REQ_IMG)) {
            startImage();
        }

        list_all_data.clear();
        bottom_linear_close_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (isMyServiceRunning(NotificationService.class)) {
                    if (bottom_play_linear != null) {
                        bottom_play_linear.setVisibility(View.GONE);
                    }
                    if (foregroundService!=null){

                        foregroundService.stopNotification();

                    }

                }
            }
        });

        mBtnPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mediaPlayer != null) {
                    if (mediaPlayer.isPlaying()) {

                        Constants.PauseBackgroundVideo(ManiVideoPlayerActivity.this);
                    } else {
                        Constants.PlayBackgroundVideo(ManiVideoPlayerActivity.this);
                    }
                }
            }
        });
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.NextBackgroundVideo(ManiVideoPlayerActivity.this);

            }
        });

        btn_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.PreviousBackgroundVideo(ManiVideoPlayerActivity.this);
            }
        });


        bottom_play_linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                preferenceUtil.putInt(Constants.Current_Position,backgroundPosition);

                if (mediaPlayer!=null){
                    preferenceUtil.putLong(backGroundPlayingList.get(preferenceUtil.getInt(Constants.Current_Position,0)).getmPath(),mediaPlayer.getCurrentPosition());
                }
                if (isMyServiceRunning(NotificationService.class)) {
                    if (bottom_play_linear != null) {
                        bottom_play_linear.setVisibility(View.GONE);
                    }
                    if (foregroundService!=null){
                        foregroundService.stopNotification();
                    }
                }

                Constants.play_pause = true;
                Intent intent = new Intent(ManiVideoPlayerActivity.this, VideoShowActivity.class);


                GoviddecgtmAs.getInstance().showinter(ManiVideoPlayerActivity.this, new GoviddecgtmAs.AviddetInterface() {
                    @Override
                    public void abrttall() {
                        startActivity(intent);
                    }
                });
                Constants.play_pause = false;
                Constants.flip_mrrire = false;
                Constants.Screenmode = false;
                Constants.play_list = false;
                Constants.Icon_equalizer_seek_set = false;
                Constants.islock = false;
                Constants.nigthmode = false;
                Constants.video_speed = 5;
                Constants.timer = false;
                Constants.repeat = "none";


            }
        });

        img_teb_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                img_teb_video.setImageResource(R.drawable.vi_video_teb);
                img_teb_playl.setImageResource(R.drawable.vi_playlist_teb_an);
                img_teb_histo.setImageResource(R.drawable.vi_history_teb_an);
                viewPager_mani.setCurrentItem(0);

            }
        });
        img_teb_playl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img_teb_video.setImageResource(R.drawable.vi_video_teb_an);
                img_teb_playl.setImageResource(R.drawable.vi_playlist_teb_se);
                img_teb_histo.setImageResource(R.drawable.vi_history_teb_an);
                viewPager_mani.setCurrentItem(1);

            }
        });
        img_teb_histo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img_teb_video.setImageResource(R.drawable.vi_video_teb_an);
                img_teb_playl.setImageResource(R.drawable.vi_playlist_teb_an);
                img_teb_histo.setImageResource(R.drawable.vi_history_teb_se);
                viewPager_mani.setCurrentItem(2);

            }
        });
        videoFragment = new VideoFragment(ManiVideoPlayerActivity.this);
        playlistFragment = new PlaylistFragment(ManiVideoPlayerActivity.this);
        historyFragment = new HistoryFragment(ManiVideoPlayerActivity.this);

        viewPagerAdapter = new ViewPagerMainAdapter(getSupportFragmentManager());
        viewPagerAdapter.add(videoFragment);
        viewPagerAdapter.add(playlistFragment);
        viewPagerAdapter.add(historyFragment);
        viewPager_mani.setOffscreenPageLimit(3);
        viewPager_mani.setAdapter(viewPagerAdapter);
        viewPager_mani.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {

                    img_teb_video.setImageResource(R.drawable.vi_video_teb);
                    img_teb_playl.setImageResource(R.drawable.vi_playlist_teb_an);
                    img_teb_histo.setImageResource(R.drawable.vi_history_teb_an);

                } else if (position == 1) {

                    img_teb_video.setImageResource(R.drawable.vi_video_teb_an);
                    img_teb_playl.setImageResource(R.drawable.vi_playlist_teb_se);
                    img_teb_histo.setImageResource(R.drawable.vi_history_teb_an);

                } else if (position == 2) {

                    img_teb_video.setImageResource(R.drawable.vi_video_teb_an);
                    img_teb_playl.setImageResource(R.drawable.vi_playlist_teb_an);
                    img_teb_histo.setImageResource(R.drawable.vi_history_teb_se);

                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        new DataGAT().execute(uri);

    }

    public void updatelist(ArrayList<VideoInfo> list_data_all) {
        list_all_data=new ArrayList<>();
        list_all_data.addAll(list_data_all);
        playlistFragment.listsenddata(list_data_all);
        historyFragment.setlistdata();

    }

    public void updateplaytofav() {
        playlistFragment.updatfav();
        historyFragment.setlistdata();

    }

    public void updatefrg() {
        videoFragment.deletedate();
        playlistFragment.setdateview();

    }

    public void updatehistory() {
        historyFragment.setlistdata();

    }

    public void setdervr() {

        drawer_layout_id.openDrawer(navigationview_id);
    }


    class DataGAT extends AsyncTask<Uri, Void, ArrayList<VideoInfo>> {


        @Override
        protected ArrayList<VideoInfo> doInBackground(Uri... uris) {
            list_all_data=new ArrayList<>();
            list_folder=new ArrayList<>();
            ContentResolver contentResolver = getContentResolver();
            Cursor cursor = contentResolver.query(uris[0], null, null, null, null);
            if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
                do {
                    String artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ARTIST));
                    @SuppressLint("Range") long mDateCreated = cursor.getLong(cursor.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED));
                    @SuppressLint("Range") String mDisplayName = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME));
                    @SuppressLint("Range") long duration = cursor.getLong(cursor.getColumnIndex(MediaStore.Video.Media.DURATION));
                    @SuppressLint("Range") long mId = cursor.getLong(cursor.getColumnIndex(MediaStore.Video.Media._ID));
                    @SuppressLint("Range") String mPath = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DATA));
                    @SuppressLint("Range") String mResolution = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.RESOLUTION));
                    @SuppressLint("Range") long mSize = cursor.getLong(cursor.getColumnIndex(MediaStore.Video.Media.SIZE));
                    @SuppressLint("Range") String mUri = null;  //cursor.getString(cursor.getColumnIndex(String.valueOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI)));
                    @SuppressLint("Range") String mimeType = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE));


                    if (duration >= 1000) {
                        if (new File(mPath).exists() && mSize != 00) {
                            if (list_folder.isEmpty()) {
                                list_folder = new ArrayList<>();
                                list_folder.add(new File(mPath).getParentFile().getName());
                            } else {
                                if (!list_folder.contains(new File(mPath).getParentFile().getName())) {
                                    list_folder.add(new File(mPath).getParentFile().getName());
                                }
                            }

                            list_all_data.add(new VideoInfo(mDateCreated, new File(mPath).getName(), duration, mId, mPath, mResolution, mSize, mUri, mimeType, artist));
                        }
                    }

                } while (cursor.moveToNext());
            }

            return list_all_data;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            list_video_data.clear();
            Constants.list_folder_data.clear();
            dilogshow();
        }

        @Override
        protected void onPostExecute(ArrayList<VideoInfo> videoInfos) {
            super.onPostExecute(videoInfos);


            Collections.sort(videoInfos, new Comparator<VideoInfo>() {
                @Override
                public int compare(VideoInfo o1, VideoInfo o2) {
                    return Integer.valueOf((int) o1.getmDateCreated()).compareTo(Integer.valueOf((int) o2.getmDateCreated()));
                }
            });
            Collections.reverse(videoInfos);
            Constants.list_video_data =new ArrayList<>();
            Constants.list_video_data.addAll(videoInfos);
            Constants.list_folder_data =new ArrayList<>();
            Constants.list_folder_data.addAll(list_folder);
            videoFragment.listsendData(videoInfos, list_folder);
            playlistFragment.listsenddata(videoInfos);



        }
    }

    private void dilogshow() {

    }

    public void listalldataupdatefrg(ArrayList<VideoInfo> list) {
        list_all_data=new ArrayList<>();
        list_all_data.addAll(list);
        videoFragment.listsendData(list, list_folder);
        playlistFragment.updatfav();
        historyFragment.setlistdata();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == 1 && resultCode == RESULT_OK) {
            MediaScannerConnection.scanFile(ManiVideoPlayerActivity.this, new String[]{path_delete}, new String[]{"video/*"}, new MediaScannerConnection.MediaScannerConnectionClient() {
                public void onMediaScannerConnected() {
                }

                public void onScanCompleted(String path, Uri uri) {
                }
            });
            list_favo.clear();
            String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
            Type type = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_favo = gson.fromJson(fove_josn, type);
            if (list_favo == null) {
                list_favo = new ArrayList<>();
            }
            for (int i = 0; i < list_favo.size(); i++) {

                if (list_favo.get(i).getmPath().equals(path_delete)) {
                    list_favo.remove(i);
                    break;
                }
            }
            list_hist.clear();
            String hist_josn = preferenceUtil.getString(Constants.Video_history_List, null);
            Type hist = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_hist = gson.fromJson(hist_josn, hist);
            if (list_hist == null) {
                list_hist = new ArrayList<>();
            }

            for (int i = 0; i < list_hist.size(); i++) {

                if (list_hist.get(i).getmPath().equals(path_delete)) {
                    list_hist.remove(i);
                    break;
                }
            }
            savelisthist(list_hist);
            savelistfavo(list_favo);
            UtilsVideo.updateplaylistdatadelete(this, path_delete);
            videoFragment.deletedate();
            playlistFragment.setdateview();
            historyFragment.setlistdata();

        }
        if (requestCode == 123 ) {

             if (!checkIf(ManiVideoPlayerActivity.this)){

                 alertDialog.show();
             }else {
                 startImage();
             }


        }
    }

    private void savelisthist(ArrayList<VideoInfo> list_hist) {
        String json = gson.toJson(list_hist);
        preferenceUtil.putString(Constants.Video_history_List, json);

    }

    private void savelistfavo(ArrayList<VideoInfo> list_favo) {
        String json = gson.toJson(list_favo);
        preferenceUtil.putString(Constants.Video_favo_List, json);
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    public boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private void startImage() {
        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        new DataGAT().execute(uri);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_IMG) {
            if (SDK_INT >= Build.VERSION_CODES.R) {

                if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ) {


                        startImage();

                } else {

                    if (!ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                        showPermissionDialog();
                    } else {
                        if (UtilsVideo.checkIfPermissions(ManiVideoPlayerActivity.this,REQ_IMG)) {

                            startImage();
                        }

                    }
                }
            } else {

                if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

                        startImage();

                } else {

                    if (!ActivityCompat.shouldShowRequestPermissionRationale(ManiVideoPlayerActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                        showPermissionDialog();
                    } else {

                        if (UtilsVideo.checkIfPermissions(ManiVideoPlayerActivity.this,REQ_IMG)) {
                            startImage();
                        }

                    }

                }

            }
        }


    }


    private void showPermissionDialog() {


        alertDialog = new Dialog(ManiVideoPlayerActivity.this);
        alertDialog.setContentView(R.layout.permission_dialog_vi_main);
        TextView text_Allow_btn_set_dilog = alertDialog.findViewById(R.id.text_Allow_btn_set_dilog);
        TextView text_cancel_btn_set_dilog = alertDialog.findViewById(R.id.text_cancel_btn_set_dilog);
        text_Allow_btn_set_dilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent,123);
            }
        });
        text_cancel_btn_set_dilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        alertDialog.show();


    }


}