package com.si_videoplayer.gautm_videoplayer.VideoUtils;

import android.app.Activity;
import android.app.Dialog;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.si_videoplayer.gautm_videoplayer.R;

import java.io.File;

public class VideotoAudio extends AsyncTask<Boolean, Boolean, Boolean> {
    Activity context;
    File destPath;
    String currentSrcPath;
    Dialog dialog;


    public VideotoAudio(Activity context, File destPath, String currentSrcPath) {
        this.context=context;
        this.destPath=destPath;
        this.currentSrcPath=currentSrcPath;
        dialog = new Dialog(context);
    }


    @Override
    protected Boolean doInBackground(Boolean... booleans) {
        boolean tempBool;
        try {
            new AudioExtractor().genVideoUsingMuxer(currentSrcPath, destPath.getAbsolutePath(), -1, -1, true, false);

            tempBool = true;

        } catch (Exception e) {

            File deleteFile = new File( destPath.getAbsolutePath());

            if (deleteFile.exists()) {
                deleteFile.delete();

                MediaScannerConnection.scanFile(context,
                        new String[]{deleteFile.getAbsolutePath()}, null,
                        new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                            }
                        });
            }

            tempBool = false;


        }

        return tempBool;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog.setCancelable(false);
        View loading_view = LayoutInflater.from(context).inflate(R.layout.open_set_mp3, null);
        dialog.setContentView(loading_view);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();

    }


    @Override
    protected void onPostExecute(Boolean isSuccess) {
        super.onPostExecute(isSuccess);

        dialog.dismiss();
        opendilodset();
    }

    private void opendilodset() {
        Dialog dialog1 =new Dialog(context);
        dialog1.setCancelable(true);
        View loading_view = LayoutInflater.from(context).inflate(R.layout.dilog_file_show, null);
        dialog1.setContentView(loading_view);
        dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        TextView path_text_set=dialog1.findViewById(R.id.path_text_set);
        path_text_set.setText("Path : " + destPath.getAbsolutePath());
        dialog1.show();
    }


}
