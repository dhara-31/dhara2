package com.si_videoplayer.gautm_videoplayer.mycl;


import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;


public interface ApiInterfaviddecgtm {


    @FormUrlEncoded
    @POST("api.php")
    Call<ResponseApp> getAll(@Field("package") String deviceId);

}
