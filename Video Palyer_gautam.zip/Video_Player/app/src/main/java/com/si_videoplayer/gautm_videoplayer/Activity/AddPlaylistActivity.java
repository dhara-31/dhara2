package com.si_videoplayer.gautm_videoplayer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Adapter.MyAdaterplaylist;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class AddPlaylistActivity extends AppCompatActivity {

    TextView text_avtivity_name;
    ImageView img_set_tool_serach;
    ImageView img_no_data;
    RecyclerView recy_add_playlist;
    MyAdaterplaylist myAdaterplaylist;
    ImageView btn_add_data;
    ArrayList<VideoInfo> list=new ArrayList<>();
    private Gson gson;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_playlist);


        FrameLayout banner = findViewById(R.id.banner);
        GoviddecgtmAs.getInstance().ShowBanner(AddPlaylistActivity.this, banner);



        text_avtivity_name=findViewById(R.id.text_avtivity_name);
        img_set_tool_serach=findViewById(R.id.img_set_tool_serach);
        img_no_data=findViewById(R.id.img_no_data);
        text_avtivity_name.setText("All Video");
        text_avtivity_name.setLetterSpacing(0);
        img_set_tool_serach.setVisibility(View.GONE);

        gson=new Gson();

        list.clear();
        String json1Null00 = gson.toJson(list);
        String json00=getIntent().getStringExtra("all_date_show");
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();
        list = gson.fromJson(json00, type00);



        recy_add_playlist=findViewById(R.id.recy_add_playlist);
        btn_add_data=findViewById(R.id.btn_add_data);

        recy_add_playlist.setLayoutManager(new LinearLayoutManager(this));
        myAdaterplaylist=new MyAdaterplaylist(this,list,getIntent().getStringExtra("pf_key_set"),btn_add_data);
        recy_add_playlist.setAdapter(myAdaterplaylist);
        if (myAdaterplaylist.getItemCount()==0){
            img_no_data.setVisibility(View.VISIBLE);
            recy_add_playlist.setVisibility(View.GONE);
            btn_add_data.setVisibility(View.GONE);
        }else {
            img_no_data.setVisibility(View.GONE);
            recy_add_playlist.setVisibility(View.VISIBLE);
        }

        btn_add_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                myAdaterplaylist.savedatelist();

                onBackPressed();

            }
        });


    }
}