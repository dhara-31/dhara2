package com.si_videoplayer.gautm_videoplayer.Castutils;

import android.app.Activity;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.si_videoplayer.gautm_videoplayer.Floating.DviddecgtmApplication;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.mycl.AppvidDetail;

public class Natviddecgtm2sAll {


    public static Integer natviddecgtmount1 = 0;
    public static Integer naviddecgtmCunt2 = 0;

    public static NativeAd natividdecgtm2;
    public static NativeAd natviddecgtm1;

    private static Natviddecgtm2sAll ourInsviddecgtme;

    public static Natviddecgtm2sAll getInstance() {
        if (ourInsviddecgtme == null) {
            ourInsviddecgtme = new Natviddecgtm2sAll();
        }
        return ourInsviddecgtme;
    }

    public static void banerAllSviddecgtmow(FrameLayout f, Activity activity, CardView cardView) {
        try {
            AppvidDetail detailApp = DviddecgtmApplication.getInstance().getAppDetail();
            if (detailApp != null && detailApp.getAdstatus().equals("1")) {

                if (natviddecgtm1 != null) {
                    banershownaviddecgtml(f, activity, cardView);
                    natviddecgtm1 = null;
                    loadNatviddecgtm1(activity);
                } else if (natividdecgtm2 != null) {

                    banershownVideoviddecgtm(f, activity, cardView);
                    natividdecgtm2 = null;
                    loadNatviddecgtm2(activity);

                    if (natviddecgtm1 == null) {
                        natviddecgtmount1++;
                        if (natviddecgtmount1 >= 5) {
                            natviddecgtmount1 = 0;
                            natviddecgtm1 = null;
                            loadNatviddecgtm1(activity);
                        }
                    }

                } else {

                    bannerDeviddecgtmt(activity, f, cardView);

                    if (natividdecgtm2 == null) {
                        naviddecgtmCunt2++;
                        if (naviddecgtmCunt2 >= 5) {
                            naviddecgtmCunt2 = 0;
                            natividdecgtm2 = null;
                            loadNatviddecgtm2(activity);
                        }
                    }

                    if (natviddecgtm1 == null) {
                        natviddecgtmount1++;
                        if (natviddecgtmount1 >= 5) {
                            natviddecgtmount1 = 0;
                            natviddecgtm1 = null;
                            loadNatviddecgtm1(activity);
                        }
                    }


                }

            } else {
                f.setVisibility(View.INVISIBLE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void banershownaviddecgtml(FrameLayout frameLayout, Activity activity, CardView cardView) {
        cardView.setVisibility(View.VISIBLE);
        frameLayout.setVisibility(View.VISIBLE);
        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
        populateNativeviddecgtmView(natviddecgtm1, adView);
        frameLayout.removeAllViews();
        frameLayout.addView(adView);
    }

    public static void banershownVideoviddecgtm(FrameLayout frameLayout, Activity activity, CardView cardView) {
        cardView.setVisibility(View.VISIBLE);
        frameLayout.setVisibility(View.VISIBLE);
        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
        populateNativeviddecgtmView(natividdecgtm2, adView);
        frameLayout.removeAllViews();
        frameLayout.addView(adView);
    }


    public static void bannerDeviddecgtmt(Activity activity, FrameLayout f, CardView cardView) {
        AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();
        if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative());
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    boolean isDestroyed = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }

                    NativeAd banernativeAd_Default1 = null;
                    if (banernativeAd_Default1 != null) {
                        banernativeAd_Default1.destroy();
                    }
                    banernativeAd_Default1 = nativeAd;

                    cardView.setVisibility(View.VISIBLE);
                    f.setVisibility(View.VISIBLE);

                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
                    populateNativeviddecgtmView(banernativeAd_Default1, adView);
                    f.removeAllViews();
                    f.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                            bannerDefaulviddecgtm2(activity, f, cardView);
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            bannerDefaulviddecgtm2(activity, f, cardView);
        }
    }

    public static void bannerDefaulviddecgtm2(Activity activity, FrameLayout f, CardView cardView) {
        AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();
        if (appDetail != null && appDetail.getAdmob2native() != null && !TextUtils.isEmpty(appDetail.getAdmob2native()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmob2native());
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    boolean isDestroyed = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    NativeAd banernativeAd_Default2 = null;

                    if (banernativeAd_Default2 != null) {
                        banernativeAd_Default2.destroy();
                    }
                    banernativeAd_Default2 = nativeAd;

                    cardView.setVisibility(View.VISIBLE);
                    f.setVisibility(View.VISIBLE);

                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
                    populateNativeviddecgtmView(banernativeAd_Default2, adView);
                    f.removeAllViews();
                    f.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                            f.setVisibility(View.INVISIBLE);
                            cardView.setVisibility(View.INVISIBLE);
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            f.setVisibility(View.INVISIBLE);
            cardView.setVisibility(View.INVISIBLE);
        }
    }

    public static void loadNaviddecgtmth(final Activity activity) {
        loadNatviddecgtm1(activity);
        loadNatviddecgtm2(activity);
    }

    public static void populateNativeviddecgtmView(NativeAd nativeAd, NativeAdView adView) {

        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getMediaContent().getVideoController();

        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        } else {
        }
    }


    public static void loadNatviddecgtm1(Activity activity) {
        AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();
        if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative());

            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    if (natviddecgtm1 != null) {
                        natviddecgtm1.destroy();
                    }
                    natviddecgtm1 = null;
                    natviddecgtmount1 = 0;
                    natviddecgtm1 = nativeAd;
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        }
    }


    public static void loadNatviddecgtm2(Activity activity) {

        AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();
        if (appDetail != null && appDetail.getAdmob2native() != null
                && !TextUtils.isEmpty(appDetail.getAdmob2native()) && appDetail.getAdstatus().equals("1")) {

            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmob2native());

            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {

                    if (natividdecgtm2 != null) {
                        natividdecgtm2.destroy();
                    }
                    natividdecgtm2 = null;
                    naviddecgtmCunt2 = 0;
                    natividdecgtm2 = nativeAd;
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());

        } else {

        }
    }

}
