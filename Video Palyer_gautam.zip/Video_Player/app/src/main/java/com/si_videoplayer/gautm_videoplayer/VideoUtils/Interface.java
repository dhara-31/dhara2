package com.si_videoplayer.gautm_videoplayer.VideoUtils;

public interface Interface {

    void image_List(int position);

}
