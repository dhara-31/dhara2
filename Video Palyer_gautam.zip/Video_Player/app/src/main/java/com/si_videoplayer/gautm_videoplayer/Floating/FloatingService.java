package com.si_videoplayer.gautm_videoplayer.Floating;

import static android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
import static com.si_videoplayer.gautm_videoplayer.Activity.VideoShowActivity.list_data;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.PauseBackgroundVideo;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.mediaPlayer;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.PlayerView;
import com.si_videoplayer.gautm_videoplayer.Activity.VideoShowActivity;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.Service.FloatPlayServer;

import java.io.File;
import java.util.ArrayList;

public class FloatingService extends Service implements View.OnClickListener, GestureDetector.OnGestureListener {
    private WindowManager mWindowManager;
    private View mFloatingWidgetView, collapsedView, expandedView;
    private PlayerView playerView;
    private ExoPlayer player;
    private Point szWindow = new Point();
    ImageView btnClosed, btnOpen, btnPlayPause, btn_next_vi, btn_previ_vi, img_mute_set;
    RelativeLayout cvButton, muteview;
    WindowManager.LayoutParams params;
    GestureDetector gestureDetector;
    private static int currentItem;
    private boolean isLeft = true;
    private ArrayList<VideoInfo> videoModels = new ArrayList<>();
    private PreferenceUtil preferenceUtil;
    public Runnable hiderunnable;
    private Handler hidehandler;
    private AudioManager audioManager;
    public static FloatingService floatingService;

    public FloatingService() {
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        getApplicationContext().startService(new Intent(getApplicationContext(), FloatPlayServer.class));
        preferenceUtil = new PreferenceUtil(this);
        currentItem = preferenceUtil.getInt(Constants.Current_Position, 0);
        videoModels=new ArrayList<>();
        videoModels.addAll(list_data);
        this.gestureDetector = new GestureDetector(this, this);
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        getWindowManagerDefaultDisplay();
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 10, 0);
        hidehandler = new Handler();
        addFloatingWidgetView(inflater);
        implementClickListeners();
        implementTouchListenerToFloatingWidgetView();
        intializePlayer(currentItem, preferenceUtil.getLong(videoModels.get(currentItem).getmPath()));

        return START_STICKY;


    }

    @Override
    public void onCreate() {
        super.onCreate();
        floatingService = this;


    }


    public void intializePlayer(int poss, long durese) {


        Uri uri = FileProvider.getUriForFile(FloatingService.this, getPackageName() + ".fileprovider", new File(videoModels.get(poss).getmPath()));
        MediaItem mediaItem = MediaItem.fromUri(uri);
        player.setMediaItem(mediaItem, durese);
        player.prepare();
        if (audioFocus()) {
            player.play();
        }
        player.experimentalSetOffloadSchedulingEnabled(false);
        hidehandler.removeCallbacks(hiderunnable);
        hidehandler.postDelayed(hiderunnable, 4000);


    }

    private void addFloatingWidgetView(LayoutInflater inflater) {
        mFloatingWidgetView = inflater.inflate(R.layout.floating_video_layout, null);


        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_PHONE,
                    FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
        } else {
            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT);
        }


        params.gravity = Gravity.TOP | Gravity.LEFT;

        params.x = 0;
        params.y = 100;

        btnClosed = mFloatingWidgetView.findViewById(R.id.btnClosed);
        btnOpen = mFloatingWidgetView.findViewById(R.id.btnOpen);
        btnPlayPause = mFloatingWidgetView.findViewById(R.id.btnPlayPause);
        cvButton = mFloatingWidgetView.findViewById(R.id.cvButton);
        btn_next_vi = mFloatingWidgetView.findViewById(R.id.btn_next_vi);
        btn_previ_vi = mFloatingWidgetView.findViewById(R.id.btn_previ_vi);
        muteview = mFloatingWidgetView.findViewById(R.id.muteview);
        img_mute_set = mFloatingWidgetView.findViewById(R.id.img_mute_set);
        player = new ExoPlayer.Builder(this).build();

        playerView = mFloatingWidgetView.findViewById(R.id.player);

        playerView.setPlayer(player);
        mWindowManager.addView(mFloatingWidgetView, params);


    }

    private void getWindowManagerDefaultDisplay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2)
            mWindowManager.getDefaultDisplay().getSize(szWindow);
        else {
            int w = mWindowManager.getDefaultDisplay().getWidth();
            int h = mWindowManager.getDefaultDisplay().getHeight();
            szWindow.set(w, h);
        }
    }

    private void implementTouchListenerToFloatingWidgetView() {
        mFloatingWidgetView.findViewById(R.id.root_container).setOnTouchListener(new View.OnTouchListener() {
            long time_start = 0, time_end = 0;
            boolean isLongClick = false;
            boolean inBounded = false;

            double x;
            double y;
            double px;
            double py;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                gestureDetector.onTouchEvent(event);

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        time_start = System.currentTimeMillis();

                        x = params.x;
                        y = params.y;


                        px = event.getRawX();


                        py = event.getRawY();


                        return true;
                    case MotionEvent.ACTION_UP:


                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = (int) ((x + event.getRawX()) - px);
                        params.y = (int) ((y + event.getRawY()) - py);

                        mWindowManager.updateViewLayout(mFloatingWidgetView, params);

                        return true;
                }
                return false;
            }
        });
    }


    private void implementClickListeners() {
        btnClosed.setOnClickListener(this);
        btnOpen.setOnClickListener(this);
        btnPlayPause.setOnClickListener(this);
        btn_previ_vi.setOnClickListener(this);
        btn_next_vi.setOnClickListener(this);
        muteview.setOnClickListener(this);


        player.addListener(new Player.Listener() {

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (isPlaying) {
                    btnPlayPause.setImageResource(R.drawable.vi_pause_view);
                } else {
                    btnPlayPause.setImageResource(R.drawable.vi_play_view);
                }
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {

                if (playbackState == Player.STATE_ENDED) {
                    nextvideo();
                }

            }
        });
        hiderunnable = new Runnable() {
            @Override
            public void run() {
                if (player == null) return;
                if (player.isPlaying()) {

                    setHideButton();

                }
            }
        };


    }

    private void setHideButton() {


        btnPlayPause.setVisibility(View.GONE);
        btnOpen.setVisibility(View.GONE);
        btnClosed.setVisibility(View.GONE);
        btn_next_vi.setVisibility(View.GONE);
        btn_previ_vi.setVisibility(View.GONE);
    }

    private void setShowButton() {

        btnPlayPause.setVisibility(View.VISIBLE);
        btnOpen.setVisibility(View.VISIBLE);
        btnClosed.setVisibility(View.VISIBLE);
        btn_next_vi.setVisibility(View.VISIBLE);
        btn_previ_vi.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnClosed:

                stopSelf();
                Constants.Foltingopen = true;
                break;
            case R.id.btnOpen:
                openPlayer();
                break;
            case R.id.btnPlayPause:
                setPlayPaused();
                break;
            case R.id.btn_next_vi:
                nextvideo();
                break;
            case R.id.btn_previ_vi:
                previVideo();
                break;
            case R.id.muteview:
                muteview();
                break;
        }
    }

    private void muteview() {
        if (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {
            img_mute_set.setImageResource(R.drawable.vi_an_mute_vol);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 10, 0);


        } else {
            img_mute_set.setImageResource(R.drawable.vi_vol_muat);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);


        }
    }

    private void previVideo() {
        currentItem = preferenceUtil.getInt(Constants.Current_Position, 0);
        if (currentItem - 1 >= 0) {
            currentItem--;

            preferenceUtil.putInt(Constants.Current_Position, currentItem);
            Glide.with(FloatingService.this)
                    .asBitmap()
                    .load(list_data.get(currentItem).getmPath())
                    .into(new SimpleTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            player.stop();
                            intializePlayer(currentItem, 0);
                            if (audioFocus()) {
                                player.play();
                            }

                        }
                    });

        }

    }

    private void nextvideo() {
        currentItem = preferenceUtil.getInt(Constants.Current_Position, 0);
        if (currentItem + 1 < list_data.size()) {
            currentItem++;

            preferenceUtil.putInt(Constants.Current_Position, currentItem);
            Glide.with(FloatingService.this)
                    .asBitmap()
                    .load(list_data.get(currentItem).getmPath())
                    .into(new SimpleTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            player.stop();
                            intializePlayer(currentItem, 0);
                            if (audioFocus()) {
                                player.play();
                            }
                        }
                    });
        }
    }

    public void setPlayPaused() {

        if (player.isPlaying()) {
            player.pause();
        } else {
            if (audioFocus()){
                player.play();
            }
        }
    }

    private void openPlayer() {

        stopSelf();
        Constants.Foltingopen = false;
        list_data = new ArrayList<>();
        list_data.addAll(videoModels);
        Constants.position = currentItem;
        Intent intent = new Intent(this, VideoShowActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        preferenceUtil.putLong(videoModels.get(preferenceUtil.getInt(Constants.Current_Position, 0)).getmPath(), player.getCurrentPosition());
        startActivity(intent);
    }


    private void resetPosition(int x_cord_now) {
        if (x_cord_now <= szWindow.x / 2) {
            isLeft = true;
            moveToLeft(x_cord_now);
        } else {
            isLeft = false;
            moveToRight(x_cord_now);
        }

    }


    private void moveToLeft(final int current_x_cord) {
        final int x = szWindow.x - current_x_cord;

        new CountDownTimer(500, 5) {
            WindowManager.LayoutParams mParams = (WindowManager.LayoutParams) mFloatingWidgetView.getLayoutParams();

            public void onTick(long t) {
                long step = (500 - t) / 5;

                mParams.x = 0 - (int) (current_x_cord * current_x_cord * step);


                mWindowManager.updateViewLayout(mFloatingWidgetView, mParams);
            }

            public void onFinish() {
                mParams.x = 0;

                mWindowManager.updateViewLayout(mFloatingWidgetView, mParams);
            }
        }.start();
    }

    private void moveToRight(final int current_x_cord) {

        new CountDownTimer(500, 5) {
            WindowManager.LayoutParams mParams = (WindowManager.LayoutParams) mFloatingWidgetView.getLayoutParams();

            public void onTick(long t) {
                long step = (500 - t) / 5;

                mParams.x = (int) (szWindow.x + (current_x_cord * current_x_cord * step) - mFloatingWidgetView.getWidth());


                mWindowManager.updateViewLayout(mFloatingWidgetView, mParams);
            }

            public void onFinish() {
                mParams.x = szWindow.x - mFloatingWidgetView.getWidth();

                mWindowManager.updateViewLayout(mFloatingWidgetView, mParams);
            }
        }.start();
    }

    private double bounceValue(long step, long scale) {
        double value = scale * Math.exp(-0.055 * step) * Math.cos(0.08 * step);
        return value;
    }


    private int getStatusBarHeight() {
        return (int) Math.ceil(25 * getApplicationContext().getResources().getDisplayMetrics().density);
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        getWindowManagerDefaultDisplay();

        WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) mFloatingWidgetView.getLayoutParams();

        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {


            if (layoutParams.y + (mFloatingWidgetView.getHeight() + getStatusBarHeight()) > szWindow.y) {
                layoutParams.y = szWindow.y - (mFloatingWidgetView.getHeight() + getStatusBarHeight());
                mWindowManager.updateViewLayout(mFloatingWidgetView, layoutParams);
            }

            if (layoutParams.x != 0 && layoutParams.x < szWindow.x) {
                resetPosition(szWindow.x);
            }

        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {

            if (layoutParams.x > szWindow.x) {
                resetPosition(szWindow.x);
            }

        }

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        getApplicationContext().stopService(new Intent(getApplicationContext(),FloatPlayServer.class));
        if (player != null) {

            player.stop();
            player.setVideoSurface(null);
            player.release();
        }
        if (mFloatingWidgetView != null)
            mWindowManager.removeView(mFloatingWidgetView);


    }


    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        if (btnPlayPause.getVisibility() == View.VISIBLE) {
            setHideButton();
        } else {
            setShowButton();
        }
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }


    public boolean audioFocus() {
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        int result = audioManager.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            return true;
        }
        return false;
    }

    public AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {

                    switch (focusChange) {

                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK):
                            if (player != null && player.isPlaying()) {
                                player.pause();
                            }
                            if (mediaPlayer!=null &&mediaPlayer.isPlaying()){
                                PauseBackgroundVideo(floatingService);
                            }
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT):
                            if (player != null && player.isPlaying()) {
                                player.pause();
                            }
                            if (mediaPlayer!=null &&mediaPlayer.isPlaying()){
                                PauseBackgroundVideo(floatingService);
                            }
                            break;

                        case (AudioManager.AUDIOFOCUS_LOSS):
                            if (player != null && player.isPlaying()) {
                                player.pause();
                            }
                            if (mediaPlayer!=null &&mediaPlayer.isPlaying()){
                                PauseBackgroundVideo(floatingService);
                            }


                            break;

                        case (AudioManager.AUDIOFOCUS_GAIN):

                            break;
                        default:
                            break;
                    }
                }
            };


}
