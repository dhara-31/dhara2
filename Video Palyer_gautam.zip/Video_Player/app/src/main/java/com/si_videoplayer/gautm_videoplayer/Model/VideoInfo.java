package com.si_videoplayer.gautm_videoplayer.Model;

public class VideoInfo {

    private long mDateCreated;
    private String mDisplayName;
    private long mDuration;
    private long mId;
    private String mPath;
    private String mResolution;
    private long mSize;
    private String mUri;
    private String mimeType;
    private String artist;
    private String list_name;
    private int post_list;
    private String mCurrentDate;



    public VideoInfo(long mDateCreated, String mDisplayName, long mDuration, long mId, String mPath, String mResolution, long mSize, String mUri, String mimeType, String artist) {
        this.mDateCreated = mDateCreated;
        this.mDisplayName = mDisplayName;
        this.mDuration = mDuration;
        this.mId = mId;
        this.mPath = mPath;
        this.mResolution = mResolution;
        this.mSize = mSize;
        this.mUri = mUri;
        this.mimeType = mimeType;
        this.artist = artist;
    }

    public VideoInfo(long mDateCreated, String mDisplayName, long mDuration, long mId, String mPath, String mResolution, long mSize, String mUri, String mimeType, String artist, String list_name) {
        this.mDateCreated = mDateCreated;
        this.mDisplayName = mDisplayName;
        this.mDuration = mDuration;
        this.mId = mId;
        this.mPath = mPath;
        this.mResolution = mResolution;
        this.mSize = mSize;
        this.mUri = mUri;
        this.mimeType = mimeType;
        this.artist = artist;
        this.list_name = list_name;
    }

    public VideoInfo( String mCurrentDate,long mDateCreated, String mDisplayName, long mDuration, long mId, String mPath, String mResolution, long mSize, String mUri, String mimeType, String artist) {
        this.mDateCreated = mDateCreated;
        this.mDisplayName = mDisplayName;
        this.mDuration = mDuration;
        this.mId = mId;
        this.mPath = mPath;
        this.mResolution = mResolution;
        this.mSize = mSize;
        this.mUri = mUri;
        this.mimeType = mimeType;
        this.artist = artist;
        this.mCurrentDate = mCurrentDate;
    }

    public VideoInfo(String list_name) {
        this.list_name = list_name;

    }

    public String getList_name() {
        return list_name;
    }

    public void setList_name(String list_name) {
        this.list_name = list_name;
    }

    public int getPost_list() {
        return post_list;
    }

    public void setPost_list(int post_list) {
        this.post_list = post_list;
    }

    public long getmDateCreated() {
        return mDateCreated;
    }

    public void setmDateCreated(long mDateCreated) {
        this.mDateCreated = mDateCreated;
    }

    public String getmDisplayName() {
        return mDisplayName;
    }

    public void setmDisplayName(String mDisplayName) {
        this.mDisplayName = mDisplayName;
    }

    public long getmDuration() {
        return mDuration;
    }

    public void setmDuration(long mDuration) {
        this.mDuration = mDuration;
    }

    public long getmId() {
        return mId;
    }

    public void setmId(long mId) {
        this.mId = mId;
    }

    public String getmPath() {
        return mPath;
    }

    public void setmPath(String mPath) {
        this.mPath = mPath;
    }

    public String getmResolution() {
        return mResolution;
    }

    public void setmResolution(String mResolution) {
        this.mResolution = mResolution;
    }

    public long getmSize() {
        return mSize;
    }

    public void setmSize(long mSize) {
        this.mSize = mSize;
    }

    public String getmUri() {
        return mUri;
    }

    public void setmUri(String mUri) {
        this.mUri = mUri;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getmCurrentDate() {
        return mCurrentDate;
    }

    public void setmCurrentDate(String mCurrentDate) {
        this.mCurrentDate = mCurrentDate;
    }
}
