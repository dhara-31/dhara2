package com.si_videoplayer.gautm_videoplayer.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Activity.AddPlaylistActivity;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class MyAdaterplaylist extends RecyclerView.Adapter<MyAdaterplaylist.Dataviewadd> {

    Context context;
    ArrayList<VideoInfo> list;
    ArrayList<VideoInfo> temp_song_size=new ArrayList<>();
    String Sp_key;
    Gson gson;
    PreferenceUtil preferenceUtil;
    ImageView imageView;

    public MyAdaterplaylist(AddPlaylistActivity addPlaylistActivity, ArrayList<VideoInfo> list, String pf_key_set,ImageView imageView) {
        context=addPlaylistActivity;
        this.list=list;
        Sp_key=pf_key_set;
        this.imageView=imageView;
        preferenceUtil=new PreferenceUtil(context);
        gson =new Gson();
        temp_song_size.clear();
        String json1Null11 = gson.toJson(temp_song_size);
        String json11 = preferenceUtil.getString(pf_key_set, json1Null11);
        Type type11 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();
        temp_song_size = gson.fromJson(json11, type11);
        if (temp_song_size==null){
            temp_song_size=new ArrayList<>();
        }
    }

    @NonNull
    @Override
    public Dataviewadd onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       return new Dataviewadd(LayoutInflater.from(context).inflate(R.layout.item_layout_videoall_selelct,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull Dataviewadd holder, @SuppressLint("RecyclerView") int position) {
        if (temp_song_size.size()==0){
            temp_song_size=new ArrayList<>();
        }else {
            for (int a=0;a<temp_song_size.size();a++){
                if (temp_song_size.get(a).getmPath().equals(list.get(position).getmPath())){
                    holder.iv_an_select.setVisibility(View.GONE);
                    holder.iv_select.setVisibility(View.VISIBLE);
                    break;
                }else {
                    holder.iv_an_select.setVisibility(View.VISIBLE);
                    holder.iv_select.setVisibility(View.GONE);
                }
            }
        }

        Glide.with(context).load(list.get(position).getmPath()).apply(new RequestOptions().placeholder(R.drawable.vi_video_place)).thumbnail(0.1f).override(350, 350).transition(new DrawableTransitionOptions().crossFade()).into(holder.iv_thumbnail);

        holder.tv_total_time.setText(UtilsVideo.formateMilliSeccond(list.get(position).getmDuration()));
        holder.tv_video_name.setText(list.get(position).getmDisplayName());
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                holder.tv_video_name.setSelected(true);
            }
        },2000);
        holder.tv_created_day.setText(UtilsVideo.readableFileSize(list.get(position).getmSize()) + "   " + UtilsVideo.convertLongToTime(new File(list.get(position).getmPath()).lastModified(), "dd-MM-yyyy"));
        String convertSolution = UtilsVideo.convertSolution(list.get(position).getmResolution());
        if (TextUtils.isEmpty(convertSolution)) {
            holder.tv_resolution_size.setVisibility(View.GONE);
        } else {
            holder.tv_resolution_size.setVisibility(View.VISIBLE);
            holder.tv_resolution_size.setText(convertSolution);
        }

        holder.tv_total_time.setText(UtilsVideo.formateMilliSeccond(list.get(position).getmDuration()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView.setVisibility(View.VISIBLE);
                if (holder.iv_an_select.getVisibility()==View.VISIBLE){
                    holder.iv_an_select.setVisibility(View.GONE);
                    holder.iv_select.setVisibility(View.VISIBLE);
                    if (temp_song_size.size() == 0) {
                        temp_song_size.add(list.get(position));

                    } else {
                        for (int i = 0; i < temp_song_size.size(); i++) {
                            if (temp_song_size.get(i).getmPath().equals(list.get(position).getmPath())) {
                                temp_song_size.remove(i);
                                break;
                            }
                        }
                        temp_song_size.add(list.get(position));
                    }

                }else {
                    if (holder.iv_select.getVisibility()==View.VISIBLE){

                        holder.iv_an_select.setVisibility(View.VISIBLE);
                        holder.iv_select.setVisibility(View.GONE);
                        for (int i = 0; i < temp_song_size.size(); i++) {
                            if (temp_song_size.get(i).getmPath().equals(list.get(position).getmPath())) {
                                temp_song_size.remove(i);
                                break;
                            }
                        }

                    }
                }
                notifyDataSetChanged();
            }
        });






    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void savedatelist() {

        if (temp_song_size.size()==0){
            Toast.makeText(context, "Update playlist", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Video Added to playlist!  ", Toast.LENGTH_SHORT).show();
        }
        String json = gson.toJson(temp_song_size);
        preferenceUtil.putString(Sp_key,json);


    }

    class  Dataviewadd extends RecyclerView.ViewHolder {

        ImageView iv_thumbnail;
        ImageView iv_an_select,iv_select;
        TextView tv_total_time, tv_video_name, tv_created_day, tv_resolution_size;
        RelativeLayout img_setcl_btn_set;

        public Dataviewadd(@NonNull View itemView) {
            super(itemView);

            iv_thumbnail = itemView.findViewById(R.id.iv_thumbnail);
            iv_an_select = itemView.findViewById(R.id.iv_an_select);
            img_setcl_btn_set = itemView.findViewById(R.id.img_setcl_btn_set);
            iv_select = itemView.findViewById(R.id.iv_select);
            tv_total_time = itemView.findViewById(R.id.tv_total_time);
            tv_video_name = itemView.findViewById(R.id.tv_video_name);
            tv_created_day = itemView.findViewById(R.id.tv_created_day);
            tv_resolution_size = itemView.findViewById(R.id.tv_resolution_size);

        }

    }
}
