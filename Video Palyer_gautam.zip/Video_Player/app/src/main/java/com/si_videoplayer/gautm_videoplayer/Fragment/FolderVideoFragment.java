package com.si_videoplayer.gautm_videoplayer.Fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.si_videoplayer.gautm_videoplayer.Adapter.MyFolderAdpter;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.R;

import java.util.ArrayList;


public class FolderVideoFragment extends Fragment {


    RecyclerView recy_folder;
    ArrayList<String> list_data_all=new ArrayList<>();
    ArrayList<VideoInfo> list=new ArrayList<>();
    MyFolderAdpter myFolderAdpter;
    ImageView img_no_data;
    VideoFragment videoFragment;

    public FolderVideoFragment(){}

    public FolderVideoFragment(VideoFragment videoFragment) {
        this.videoFragment=videoFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_folder_video, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recy_folder=view.findViewById(R.id.recy_folder);
        img_no_data=view.findViewById(R.id.img_no_data);


        recy_folder.setLayoutManager(new GridLayoutManager(getActivity(),1));
        myFolderAdpter=new MyFolderAdpter(getActivity(),list_data_all,list,1);
        recy_folder.setAdapter(myFolderAdpter);
        setadterdata();

    }

    private void setadterdata() {
        if (myFolderAdpter.getItemCount()==0){
            img_no_data.setVisibility(View.VISIBLE);
            recy_folder.setVisibility(View.GONE);
        }else {
            img_no_data.setVisibility(View.GONE);
            recy_folder.setVisibility(View.VISIBLE);
        }
    }

    public void listfoldeupdate(ArrayList<String> list, ArrayList<VideoInfo> videoInfos) {

        list_data_all=list;
        this.list=videoInfos;
        myFolderAdpter.listupdate(list,videoInfos);
        setadterdata();
    }

    public void girdfoldeupdate(int setview) {
        recy_folder.setLayoutManager(new GridLayoutManager(getActivity(),setview));
        myFolderAdpter=new MyFolderAdpter(getActivity(),list_data_all,list,setview);
        recy_folder.setAdapter(myFolderAdpter);
        setadterdata();

    }
}