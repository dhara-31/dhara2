package com.si_videoplayer.gautm_videoplayer.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.Castutils.Natviddecgtm2sAll;

public class ExitVideoPlayerActivity extends AppCompatActivity {

    TextView text_cancel_btn,text_ok_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit_video_player);


        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView cardView = findViewById(R.id.c1);
        Natviddecgtm2sAll.banerAllSviddecgtmow(admobNativeLarge2, ExitVideoPlayerActivity.this, cardView);


        text_cancel_btn=findViewById(R.id.text_cancel_btn);
        text_ok_btn=findViewById(R.id.text_ok_btn);

        text_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        text_ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });
    }
}