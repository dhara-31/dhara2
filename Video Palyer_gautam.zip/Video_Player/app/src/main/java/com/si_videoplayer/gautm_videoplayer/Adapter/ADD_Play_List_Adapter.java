package com.si_videoplayer.gautm_videoplayer.Adapter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Interface;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ADD_Play_List_Adapter extends RecyclerView.Adapter<ADD_Play_List_Adapter.Dataview_list_play> {

    ArrayList<VideoInfo> adp_list;
    ArrayList<VideoInfo> set_list = new ArrayList<>();
    Context context;
    Interface creation_interface;
    PreferenceUtil preferenceUtil;
    private Gson gson;
    int Post;
    ArrayList<VideoInfo> mvideo;
    Dialog alertadd;


    public ADD_Play_List_Adapter(ArrayList<VideoInfo> adp_get_list, FragmentActivity activity, int post, ArrayList<VideoInfo> mvideo, Dialog alertadd, Interface anInterface) {
        adp_list = adp_get_list;
        context = activity;
        creation_interface = anInterface;
        this.Post = post;
        this.mvideo = mvideo;
        this.alertadd = alertadd;
        preferenceUtil = new PreferenceUtil(context);
        gson = new Gson();
    }

    @NonNull
    @Override
    public Dataview_list_play onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Dataview_list_play(LayoutInflater.from(context).inflate(R.layout.set_playlist, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Dataview_list_play holder, @SuppressLint("RecyclerView") int position) {
        set_list = new ArrayList<>();

        List<VideoInfo> arrayListOfNull11 = new ArrayList<>();
        String json1Null11 = gson.toJson(arrayListOfNull11);
        String json11 = preferenceUtil.getString(adp_list.get(position).getList_name(), json1Null11);
        Type type11 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        set_list = gson.fromJson(json11, type11);

        if (set_list.size() == 0) {
            set_list = new ArrayList<>();
        }
        try {
            Glide.with(context).load(set_list.get(set_list.size() - 1).getmPath()).into(holder.song_thumbnail_img);
        } catch (Exception e) {
            Glide.with(context).load(R.drawable.vi_playlistic_frg).into(holder.song_thumbnail_img);
        }

        holder.atp_list_name_txt.setText(adp_list.get(position).getList_name());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                set_list = new ArrayList<>();
                List<VideoInfo> arrayListOfNull11 = new ArrayList<>();
                String json1Null11 = gson.toJson(arrayListOfNull11);
                String json11 = preferenceUtil.getString(adp_list.get(position).getList_name(), json1Null11);
                Type type11 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();
                set_list = gson.fromJson(json11, type11);

                if (set_list.size() == 0) {
                    set_list = new ArrayList<>();
                }

                for (int j = 0; j < set_list.size(); j++) {

                    if (mvideo.get(Post).getmPath().equals(set_list.get(j).getmPath())) {
                        alertadd.dismiss();
                        Toast.makeText(context, "Already added", Toast.LENGTH_SHORT).show();
                        return;

                    }
                }
                set_list.add(new VideoInfo(mvideo.get(Post).getmDateCreated(), mvideo.get(Post).getmDisplayName(), mvideo.get(Post).getmDuration(), mvideo.get(Post).getmId(), mvideo.get(Post).getmPath(), mvideo.get(Post).getmResolution(), mvideo.get(Post).getmSize(), mvideo.get(Post).getmUri(), mvideo.get(Post).getMimeType(), mvideo.get(Post).getArtist(), adp_list.get(position).getList_name()));
                String json = gson.toJson(set_list);
                preferenceUtil.putString(adp_list.get(position).getList_name(), json);
                alertadd.dismiss();
                creation_interface.image_List(position);
                Toast.makeText(context, "Video Added to playlist!", Toast.LENGTH_SHORT).show();


            }
        });
    }

    @Override
    public int getItemCount() {

        return adp_list.size();
    }


    class Dataview_list_play extends RecyclerView.ViewHolder {

        ImageView song_thumbnail_img;
        TextView atp_list_name_txt;

        public Dataview_list_play(@NonNull View itemView) {
            super(itemView);


            song_thumbnail_img = itemView.findViewById(R.id.song_thumbnail_img);
            atp_list_name_txt = itemView.findViewById(R.id.atp_list_name_txt);


        }

    }
}
