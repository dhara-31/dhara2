package com.si_videoplayer.gautm_videoplayer.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.si_videoplayer.gautm_videoplayer.Activity.VideoShowActivity;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MyVideoHistoryAdpter extends RecyclerView.Adapter<MyVideoHistoryAdpter.Daviewhistory>{

    Context context;
    ArrayList<VideoInfo> listdata;
    Date today = new Date();
    SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
    String dateToStr = format.format(today);
    PreferenceUtil preferenceUtil;

    public MyVideoHistoryAdpter(FragmentActivity activity, ArrayList<VideoInfo> list_his) {
        listdata=list_his;
        context=activity;
        preferenceUtil=new PreferenceUtil(activity);
    }

    @NonNull
    @Override
    public Daviewhistory onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Daviewhistory(LayoutInflater.from(context).inflate(R.layout.item_history,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull Daviewhistory holder, @SuppressLint("RecyclerView") int position) {
        VideoInfo historyModel = listdata.get(position);
        if (position != 0) {
            if (listdata.size() != position + 1) {
                if (!historyModel.getmCurrentDate().substring(0, 11).equals(listdata.get(position - 1).getmCurrentDate().substring(0, 11))) {
                    holder.tv_date_history.setVisibility(View.VISIBLE);
                } else {
                    holder.tv_date_history.setVisibility(View.GONE);
                }
            }else{
                holder.tv_date_history.setVisibility(View.GONE);
            }
        } else {
            holder.tv_date_history.setVisibility(View.VISIBLE);
        }

        if (dateToStr.substring(0, 11).equals(historyModel.getmCurrentDate().substring(0, 11))) {
            holder.tv_date_history.setText("Today");
        } else {
            holder.tv_date_history.setText(historyModel.getmCurrentDate().substring(0, 6).replaceAll("-", " "));
        }

        Glide.with(context).load(listdata.get(position).getmPath()).apply(new RequestOptions().placeholder(R.drawable.vi_video_place)).thumbnail(0.1f).override(350, 350).transition(new DrawableTransitionOptions().crossFade()).into(holder.iv_thumbnail);


        holder.tv_total_time.setText(UtilsVideo.formateMilliSeccond(listdata.get(position).getmDuration()));
        holder.tv_video_name.setText(listdata.get(position).getmDisplayName());
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                holder.tv_video_name.setSelected(true);
            }
        },2000);
        holder.tv_created_day.setText(UtilsVideo.readableFileSize(listdata.get(position).getmSize()) + "   " + UtilsVideo.convertLongToTime(new File(listdata.get(position).getmPath()).lastModified(), "dd-MM-yyyy"));
        String convertSolution = UtilsVideo.convertSolution(listdata.get(position).getmResolution());
        if (TextUtils.isEmpty(convertSolution)) {
            holder.tv_resolution_size.setVisibility(View.GONE);
        } else {
            holder.tv_resolution_size.setVisibility(View.VISIBLE);
            holder.tv_resolution_size.setText(convertSolution);
        }
        holder.tv_total_time.setText(UtilsVideo.formateMilliSeccond(listdata.get(position).getmDuration()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Constants.play_pause=true;

                preferenceUtil.putInt(Constants.Current_Position, position);
                VideoShowActivity.list_data=new ArrayList<>();
                VideoShowActivity.list_data.addAll(listdata);




                GoviddecgtmAs.getInstance().showinter((Activity) context, new GoviddecgtmAs.AviddetInterface() {
                    @Override
                    public void abrttall() {
                        Intent intent=new Intent(context,VideoShowActivity.class);
                        context.startActivity(intent);
                    }
                });



            }
        });

    }

    @Override
    public int getItemCount() {
        return listdata.size();
    }

    public void setupdatelist(ArrayList<VideoInfo> list_his) {
        listdata=list_his;
        notifyDataSetChanged();
    }

    class Daviewhistory extends RecyclerView.ViewHolder {

        ImageView iv_thumbnail;

        TextView tv_total_time, tv_video_name, tv_created_day, tv_resolution_size,tv_date_history;

        public Daviewhistory(@NonNull View itemView) {
            super(itemView);

            iv_thumbnail = itemView.findViewById(R.id.iv_thumbnail);
            tv_total_time = itemView.findViewById(R.id.tv_total_time);
            tv_video_name = itemView.findViewById(R.id.tv_video_name);
            tv_created_day = itemView.findViewById(R.id.tv_created_day);
            tv_resolution_size = itemView.findViewById(R.id.tv_resolution_size);
            tv_date_history = itemView.findViewById(R.id.tv_date_history);
        }
    }

    public boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}
