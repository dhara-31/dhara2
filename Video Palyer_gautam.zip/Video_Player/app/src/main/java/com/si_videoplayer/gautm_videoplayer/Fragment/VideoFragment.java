package com.si_videoplayer.gautm_videoplayer.Fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity;
import com.si_videoplayer.gautm_videoplayer.Activity.SerachAvtivity;
import com.si_videoplayer.gautm_videoplayer.Adapter.ViewPagerChiAdapter;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class VideoFragment extends Fragment {
    ImageView img_set_tool_serach;
    ViewPager viewpager_chide;
    ViewPagerChiAdapter viewPagerChiAdapter;
    RelativeLayout all_vi_frg_sel,folder_frg_sel;
    View frg_sel_view,frg_sel_view2;
    AllVideoFragment allVideoFragment;
    FolderVideoFragment folderVideoFragment;
    ImageView img_sroting,img_list_gird;
    ArrayList<VideoInfo> list_srotset=new ArrayList<>();
    private PreferenceUtil preferenceUtil;
    ImageView img_dervr;


    TextView text_avtivity_name;
    boolean grid=false;
    int setview=1;
    ManiVideoPlayerActivity maniVideoPlayerActivity;
    private Gson gson;

   public VideoFragment(){}
    public VideoFragment(ManiVideoPlayerActivity maniVideoPlayerActivity) {
        this.maniVideoPlayerActivity=maniVideoPlayerActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_video, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        text_avtivity_name=view.findViewById(R.id.text_avtivity_name);
        img_set_tool_serach=view.findViewById(R.id.img_set_tool_serach);
        text_avtivity_name.setText("Video Player");

        img_set_tool_serach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gson = new Gson();
                String json = gson.toJson(list_srotset);

                Intent intent=new Intent(getActivity(), SerachAvtivity.class);
                intent.putExtra("Serachlistset",json);
                intent.putExtra("setactivty",11);

                GoviddecgtmAs.getInstance().showinter(getActivity(), new GoviddecgtmAs.AviddetInterface() {
                    @Override
                    public void abrttall() {
                        startActivity(intent);
                    }
                });


            }
        });

        preferenceUtil = new PreferenceUtil(getActivity());
        preferenceUtil.putInt(Constants.KEY_PR_SROT,0);
        viewpager_chide=view.findViewById(R.id.viewpager_chide);
        all_vi_frg_sel=view.findViewById(R.id.all_vi_frg_sel);
        folder_frg_sel=view.findViewById(R.id.folder_frg_sel);
        frg_sel_view=view.findViewById(R.id.frg_sel_view);
        frg_sel_view2=view.findViewById(R.id.frg_sel_view2);
        img_sroting=view.findViewById(R.id.img_sroting);
        img_list_gird=view.findViewById(R.id.img_list_gird);
        img_dervr=view.findViewById(R.id.img_dervr);
        img_dervr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                maniVideoPlayerActivity.setdervr();
            }
        });



        img_sroting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                opendilogset();
            }
        });
        img_list_gird.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (grid==false){
                    grid=true;
                    setview=2;
                    updategird(setview);
                    img_list_gird.setImageResource(R.drawable.vi_list_frg);
                }else {
                    grid=false;
                    setview=1;
                    updategird(setview);
                    img_list_gird.setImageResource(R.drawable.vi_grid_frg);

                }
            }
        });


        all_vi_frg_sel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                frg_sel_view.setVisibility(View.VISIBLE);
                frg_sel_view2.setVisibility(View.GONE);
                img_sroting.setVisibility(View.VISIBLE);
                viewpager_chide.setCurrentItem(0);
            }
        });
        folder_frg_sel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                frg_sel_view.setVisibility(View.GONE);
                frg_sel_view2.setVisibility(View.VISIBLE);
                img_sroting.setVisibility(View.GONE);
                viewpager_chide.setCurrentItem(1);
            }
        });

        allVideoFragment =new AllVideoFragment(this);
        folderVideoFragment=new FolderVideoFragment(this);
        viewPagerChiAdapter = new ViewPagerChiAdapter(getChildFragmentManager());
        viewPagerChiAdapter.add(allVideoFragment);
        viewPagerChiAdapter.add(folderVideoFragment);
        viewpager_chide.setOffscreenPageLimit(2);
        viewpager_chide.setAdapter(viewPagerChiAdapter);
        viewpager_chide.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position==0){
                    frg_sel_view.setVisibility(View.VISIBLE);
                    frg_sel_view2.setVisibility(View.GONE);
                    img_sroting.setVisibility(View.VISIBLE);
                }else if (position==1){
                    frg_sel_view.setVisibility(View.GONE);
                    frg_sel_view2.setVisibility(View.VISIBLE);
                    img_sroting.setVisibility(View.GONE);
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    private void updategird(int setview) {
        allVideoFragment.girdupdate(setview);
        folderVideoFragment.girdfoldeupdate(setview);
    }



    @SuppressLint("ResourceAsColor")
    private void opendilogset() {
        Dialog dialog1 = new Dialog(getActivity());
        dialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog1.setContentView(R.layout.dialog_sort);
        dialog1.setCancelable(true);

        RelativeLayout relativ_srot_date= dialog1.findViewById(R.id.relativ_srot_date);
        RelativeLayout relativ_srot_name= dialog1.findViewById(R.id.relativ_srot_name);
        RelativeLayout relativ_srot_size= dialog1.findViewById(R.id.relativ_srot_size);
        RelativeLayout relativ_srot_time= dialog1.findViewById(R.id.relativ_srot_time);
        ImageView img_1_time= dialog1.findViewById(R.id.img_1_date);
        ImageView img_2_name= dialog1.findViewById(R.id.img_2_name);
        ImageView img_3_size= dialog1.findViewById(R.id.img_3_size);
        ImageView img_4_time= dialog1.findViewById(R.id.img_4_time);
        TextView text_srot_date= dialog1.findViewById(R.id.text_srot_date);
        TextView text_srot_name= dialog1.findViewById(R.id.text_srot_name);
        TextView text_srot_size= dialog1.findViewById(R.id.text_srot_size);
        TextView text_srot_time= dialog1.findViewById(R.id.text_srot_time);
        ImageView  img_dilog_cancel=dialog1.findViewById(R.id.img_dilog_cancel);

        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog1.dismiss();
            }
        });
        int value=preferenceUtil.getInt(Constants.KEY_PR_SROT,0);
        if (value==0){
            setdate1date(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);
        }else if (value==1){
            setdate2name(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);
        }else if (value==2){
            setdata3size(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);
        }else if (value==3){
            setdata4time(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);

        }

        relativ_srot_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setdate1date(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);
                preferenceUtil.putInt(Constants.KEY_PR_SROT,0);
                Collections.sort(list_srotset, new Comparator<VideoInfo>() {
                    @Override
                    public int compare(VideoInfo o1, VideoInfo o2) {
                        return Integer.valueOf((int) o1.getmDateCreated()).compareTo(Integer.valueOf((int) o2.getmDateCreated()));
                    }
                });
                Collections.reverse(list_srotset);
                allVideoFragment.listupdate(list_srotset);
            }

        });
        relativ_srot_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setdate2name(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);
                preferenceUtil.putInt(Constants.KEY_PR_SROT,1);
                Collections.sort(list_srotset, new Comparator<VideoInfo>() {
                    @Override
                    public int compare(VideoInfo o1, VideoInfo o2) {
                        return o1.getmDisplayName().compareToIgnoreCase(o2.getmDisplayName());
                    }
                });

                allVideoFragment.listupdate(list_srotset);
            }

        });
        relativ_srot_size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setdata3size(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);
                preferenceUtil.putInt(Constants.KEY_PR_SROT,2);
                Collections.sort(list_srotset, new Comparator<VideoInfo>() {
                    @Override
                    public int compare(VideoInfo rhs, VideoInfo lhs) {
                        return Long.compare(rhs.getmSize(),lhs.getmSize());
                    }
                });
                allVideoFragment.listupdate(list_srotset);
            }


        });
        relativ_srot_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setdata4time(relativ_srot_date,relativ_srot_name,relativ_srot_size,relativ_srot_time,img_1_time,img_2_name,img_3_size,img_4_time,text_srot_date,text_srot_name,text_srot_size,text_srot_time);
                preferenceUtil.putInt(Constants.KEY_PR_SROT,3);
                Collections.sort(list_srotset, new Comparator<VideoInfo>() {
                    @Override
                    public int compare(VideoInfo o1, VideoInfo o2) {
                        return Integer.valueOf((int) o1.getmDuration()).compareTo(Integer.valueOf((int) o2.getmDuration()));
                    }
                });
                allVideoFragment.listupdate(list_srotset);
            }


        });

        dialog1.show();

    }
    @SuppressLint("ResourceAsColor")
    private void setdata3size(RelativeLayout relativ_srot_date, RelativeLayout relativ_srot_name, RelativeLayout relativ_srot_size, RelativeLayout relativ_srot_time, ImageView img_1_time, ImageView img_2_name, ImageView img_3_size, ImageView img_4_time, TextView text_srot_date, TextView text_srot_name, TextView text_srot_size, TextView text_srot_time) {
        relativ_srot_date.setBackgroundResource(android.R.color.transparent);
        relativ_srot_name.setBackgroundResource(android.R.color.transparent);
        relativ_srot_size.setBackgroundResource(R.drawable.vi_selected_item_bg);
        relativ_srot_time.setBackgroundResource(android.R.color.transparent);
        img_1_time.setImageResource(R.drawable.vi_calander_an);
        img_2_name.setImageResource(R.drawable.vi_name_an);
        img_3_size.setImageResource(R.drawable.vi_size_se);
        img_4_time.setImageResource(R.drawable.vi_time_an);
        text_srot_date.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_name.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_size.setTextColor(ContextCompat.getColor(getActivity(),R.color.black));
        text_srot_time.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));

    }

    @SuppressLint("ResourceAsColor")
    private void setdate1date(RelativeLayout relativ_srot_date, RelativeLayout relativ_srot_name, RelativeLayout relativ_srot_size, RelativeLayout relativ_srot_time, ImageView img_1_time, ImageView img_2_name, ImageView img_3_size, ImageView img_4_time, TextView text_srot_date, TextView text_srot_name, TextView text_srot_size, TextView text_srot_time) {
        relativ_srot_date.setBackgroundResource(R.drawable.vi_selected_item_bg);

        relativ_srot_name.setBackgroundResource(android.R.color.transparent);
        relativ_srot_size.setBackgroundResource(android.R.color.transparent);
        relativ_srot_time.setBackgroundResource(android.R.color.transparent);
        img_1_time.setImageResource(R.drawable.vi_calander_se);
        img_2_name.setImageResource(R.drawable.vi_name_an);
        img_3_size.setImageResource(R.drawable.vi_size_an);
        img_4_time.setImageResource(R.drawable.vi_time_an);
        text_srot_date.setTextColor(ContextCompat.getColor(getActivity(),R.color.black));
        text_srot_name.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_size.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_time.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));

    }
    @SuppressLint("ResourceAsColor")
    private void setdate2name(RelativeLayout relativ_srot_date, RelativeLayout relativ_srot_name, RelativeLayout relativ_srot_size, RelativeLayout relativ_srot_time, ImageView img_1_time, ImageView img_2_name, ImageView img_3_size, ImageView img_4_time, TextView text_srot_date, TextView text_srot_name, TextView text_srot_size, TextView text_srot_time) {
        relativ_srot_date.setBackgroundResource(android.R.color.transparent);
        relativ_srot_name.setBackgroundResource(R.drawable.vi_selected_item_bg);
        relativ_srot_size.setBackgroundResource(android.R.color.transparent);
        relativ_srot_time.setBackgroundResource(android.R.color.transparent);
        img_1_time.setImageResource(R.drawable.vi_calander_an);
        img_2_name.setImageResource(R.drawable.vi_name_se);
        img_3_size.setImageResource(R.drawable.vi_size_an);
        img_4_time.setImageResource(R.drawable.vi_time_an);
        text_srot_date.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_name.setTextColor(ContextCompat.getColor(getActivity(),R.color.black));
        text_srot_size.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_time.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
    }

    @SuppressLint("ResourceAsColor")
    private void setdata4time(RelativeLayout relativ_srot_date, RelativeLayout relativ_srot_name, RelativeLayout relativ_srot_size, RelativeLayout relativ_srot_time, ImageView img_1_time, ImageView img_2_name, ImageView img_3_size, ImageView img_4_time, TextView text_srot_date, TextView text_srot_name, TextView text_srot_size, TextView text_srot_time) {
        relativ_srot_date.setBackgroundResource(android.R.color.transparent);
        relativ_srot_name.setBackgroundResource(android.R.color.transparent);
        relativ_srot_size.setBackgroundResource(android.R.color.transparent);
        relativ_srot_time.setBackgroundResource(R.drawable.vi_selected_item_bg);
        img_1_time.setImageResource(R.drawable.vi_calander_an);
        img_2_name.setImageResource(R.drawable.vi_name_an);
        img_3_size.setImageResource(R.drawable.vi_size_an);
        img_4_time.setImageResource(R.drawable.vi_time_se);
        text_srot_date.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_name.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_size.setTextColor(ContextCompat.getColor(getActivity(),R.color.gary));
        text_srot_time.setTextColor(ContextCompat.getColor(getActivity(),R.color.black));
    }


    public void listsendData(ArrayList<VideoInfo> videoInfos, ArrayList<String> list) {

            list_srotset=new ArrayList<>();
            list_srotset.clear();
            list_srotset.addAll(videoInfos);



            if (allVideoFragment!=null) {
                allVideoFragment.listupdate(videoInfos);
            }
            if (folderVideoFragment!=null) {
                folderVideoFragment.listfoldeupdate(list, videoInfos);
            }


    }

    public void updatelist(ArrayList<VideoInfo> list_data_all) {
        list_srotset=new ArrayList<>();
        list_srotset.addAll(list_data_all);

        maniVideoPlayerActivity.updatelist(list_data_all);
    }

    public void deletedate() {
        allVideoFragment.delete_video_file();
    }

    public void updatefavlist() {
        maniVideoPlayerActivity.updateplaytofav();
    }

    public void updatefrg() {
        maniVideoPlayerActivity.updatefrg();
    }
}