package com.si_videoplayer.gautm_videoplayer.Activity;

import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.play_pause;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.MediaScannerConnection;
import android.media.audiofx.Equalizer;
import android.media.audiofx.PresetReverb;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Display;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.PlayerView;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Equalizer.EqualizerModel;
import com.si_videoplayer.gautm_videoplayer.Equalizer.Settings;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.Service.VideoPlayServer;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

public class OpenWithVideoActivity extends AppCompatActivity implements View.OnTouchListener, GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, ScaleGestureDetector.OnScaleGestureListener {



    private Equalizer mEqualizer;
    private float[] points;
    private SeekBar[] seekBarFinal = new SeekBar[5];
    private int audioSesionId;
    private PlayerView playerView;
    public ExoPlayer player;
    private RelativeLayout toucher, img_bottom_teb, view_set_up_down;
    private GestureDetector gestureDetector;
    private ScaleGestureDetector scaleGestureDetector;
    private boolean e0 = true;
    private boolean m = false;
    private boolean l = false;
    private float scaleFactor = 1.0f;
    private RelativeLayout img_tool_teb, cut_view_next_prev;
    private ImageView img_back_set;
    private TextView txt_video_name;
    private ImageView left_img;
    private ImageView right_img;
    private TextView aspecttext;
    private TextView txt_left_time;
    private TextView txt_right_time;
    private SeekBar video_seek_set;
    private ImageView img_lock_set;
    private ImageView img_unlock_set;
    private ImageView img_play_pause;
    private ImageView img_aspectbtn_set;
    private ImageView img_up_down_mune;
    private ImageView img_equalizer_set;
    private ImageView img_night_set;
    private ImageView img_mute_set;
    private ImageView img_ss_set;
    private ImageView img_speed_set;
    private LinearLayout continuelay;
    private ConstraintLayout bright_view_set, volum_view_set;
    private SeekBar seek_volume, seek_bright;
    private TextView text_bright, txt_volume;
    private ImageView img_volume_set, img_bright_set;
    private boolean layuot_open = false;
    private AudioManager audioManager;
    public boolean g0 = false;
    private boolean isshow;
    private int resizemode = 0;
    private String[] aspectmode = {"Original", "FILL", "ZOOM", "FIXED HEIGHT", "FIXED WIDTH"};
    private int[] resource = {R.drawable.vi_fullscreen_view, R.drawable.vi_baseline_crop_3_2, R.drawable.vi_crop_white, R.drawable.vi_zoom_inside, R.drawable.vi_zoom_original};
    private Handler handler;
    private boolean isdonebyus;


    private RelativeLayout equalizerLayout, relativ_clikr_off;
    private TextView tv_custom, tv_normal, tv_classic, tv_dance, tv_flat, tv_folk, tv_heavy_metal, tv_hip_hop, tv_jazz, tv_pop, tv_rock;
    private ImageView vi_on, vi_off, video_flip, video_roatate_lock;
    private Spinner presetSpinner;
    private RelativeLayout  relativ_nigitset;
    private boolean rotate = false;



    private RelativeLayout speed_mune_set;
    private TextView select_speed_txt;
    private SeekBar seek_speed;
    private TextView text_speed_025;
    private TextView text_speed_050;
    private TextView text_speed_075;
    private TextView text_speed_01;
    private TextView text_speed_125;
    private TextView text_speed_150;
    private TextView text_speed_175;
    private TextView text_speed_02;
    Handler handler_gone;
    Runnable runnable_gone;
    private Runnable runnable;
    private boolean videoswip;


    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_with_video);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setNavigationBarColor(Color.parseColor("#000000"));
            window.setStatusBarColor(Color.parseColor("#000000"));
        }




        OpenWithViewBind();


        handler_gone = new Handler();
        handler = new Handler();

        Display display = ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay();

        int orientation = display.getRotation();

        if (orientation == Surface.ROTATION_90 || orientation == Surface.ROTATION_270) {
            Constants.Screenmode = true;
        } else {
            Constants.Screenmode = false;
        }
        audioManager = (AudioManager) getSystemService("audio");
        gestureDetector = new GestureDetector(this, this);
        scaleGestureDetector = new ScaleGestureDetector(this, this);

        toucher.setOnTouchListener(this);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (player != null) {
                    video_seek_set.setMax((int) player.getDuration());
                    video_seek_set.setProgress((int) player.getCurrentPosition());
                }
            }
        }, 100);
        seek_volume.setMax(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        seek_volume.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        txt_volume.setText(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) + "");
        if (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {
            img_mute_set.setImageResource(R.drawable.evol_on_mute);
            img_volume_set.setImageResource(R.drawable.vi_vol_muat);
        } else {
            img_mute_set.setImageResource(R.drawable.vi_vol_on_set);
            img_volume_set.setImageResource(R.drawable.vi_an_mute_vol);
        }
        img_back_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        img_play_pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (player.isPlaying()) {

                    Constants.play_pause = false;
                    player.pause();
                    handler_gone.removeCallbacks(runnable_gone);
                } else {
                    if (audioFocus()) {
                        player.play();
                        Constants.play_pause = true;
                        handler_gone.removeCallbacks(runnable_gone);
                        handler_gone.postDelayed(runnable_gone, 4000);
                    }

                }

            }
        });
        img_aspectbtn_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resizemode++;
                aspecttext.setVisibility(View.VISIBLE);
                if ((resizemode % 5) != 2) {
                    playerView.setScaleX(1.0f);
                    playerView.setScaleY(1.0f);

                } else {
                    playerView.setScaleX(scaleFactor);
                    playerView.setScaleY(scaleFactor);
                }
                aspecttext.setText(aspectmode[resizemode % 5]);
                img_aspectbtn_set.setImageResource(resource[resizemode % 5]);
                playerView.setResizeMode(resizemode % 5);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        aspecttext.setVisibility(View.GONE);

                    }
                }, 300);
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });
        if (Constants.islock == true) {
            hideSystemUI();
            img_bottom_teb.setVisibility(View.GONE);
            img_tool_teb.setVisibility(View.GONE);
            img_unlock_set.setVisibility(View.VISIBLE);
            volum_view_set.setVisibility(View.GONE);
            bright_view_set.setVisibility(View.GONE);
            img_up_down_mune.setVisibility(View.GONE);
            setmunegone();
            if (Constants.Screenmode == true) {
                img_up_down_mune.setRotation(90);
            } else {
                img_up_down_mune.setRotation(0);
            }

        }
        img_lock_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.islock = true;
                hideSystemUI();

                img_bottom_teb.setVisibility(View.GONE);
                img_tool_teb.setVisibility(View.GONE);
                img_unlock_set.setVisibility(View.VISIBLE);
                volum_view_set.setVisibility(View.GONE);
                bright_view_set.setVisibility(View.GONE);
                img_up_down_mune.setVisibility(View.GONE);
                setmunegone();
                if (Constants.Screenmode == true) {
                    img_up_down_mune.setRotation(90);
                } else {
                    img_up_down_mune.setRotation(0);
                }


            }
        });
        img_unlock_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.islock = false;
                showSystemUI();
                img_bottom_teb.setVisibility(View.VISIBLE);
                img_tool_teb.setVisibility(View.VISIBLE);
                img_unlock_set.setVisibility(View.GONE);
                img_up_down_mune.setVisibility(View.VISIBLE);

                if (Constants.Screenmode == true) {
                    img_up_down_mune.setRotation(90);
                } else {
                    img_up_down_mune.setRotation(0);
                }
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });
        img_up_down_mune.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!layuot_open) {
                    layuot_open = true;


                    if (Constants.Screenmode == true) {

                        img_up_down_mune.setRotation(270);
                        video_flip.setVisibility(View.VISIBLE);
                        video_roatate_lock.setVisibility(View.VISIBLE);


                    } else {
                        img_up_down_mune.setRotation(180);

                        img_equalizer_set.setVisibility(View.VISIBLE);
                        img_night_set.setVisibility(View.VISIBLE);
                        img_mute_set.setVisibility(View.VISIBLE);
                        img_ss_set.setVisibility(View.VISIBLE);
                        img_speed_set.setVisibility(View.VISIBLE);

                        video_flip.setVisibility(View.VISIBLE);
                        video_roatate_lock.setVisibility(View.VISIBLE);

                    }

                } else {
                    layuot_open = false;


                    if (Constants.Screenmode == true) {
                        img_up_down_mune.setRotation(90);
                        video_flip.setVisibility(View.GONE);
                        video_roatate_lock.setVisibility(View.GONE);


                    } else {
                        img_up_down_mune.setRotation(0);
                        img_equalizer_set.setVisibility(View.GONE);
                        img_night_set.setVisibility(View.GONE);
                        img_mute_set.setVisibility(View.GONE);
                        img_ss_set.setVisibility(View.GONE);
                        img_speed_set.setVisibility(View.GONE);

                        video_flip.setVisibility(View.GONE);

                        video_roatate_lock.setVisibility(View.GONE);

                    }

                }
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });


        if (Constants.nigthmode == true) {
            relativ_nigitset.setVisibility(View.VISIBLE);
            img_night_set.setImageResource(R.drawable.vi_night);
        }



        img_night_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Constants.nigthmode == true) {
                    Constants.nigthmode = false;
                    relativ_nigitset.setVisibility(View.GONE);
                    img_night_set.setImageResource(R.drawable.vi_night_set);
                } else {
                    Constants.nigthmode = true;
                    relativ_nigitset.setVisibility(View.VISIBLE);
                    img_night_set.setImageResource(R.drawable.vi_night);
                }
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });

        video_roatate_lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (rotate == true) {
                    rotate(false);
                    rotate = false;
                    video_roatate_lock.setImageResource(R.drawable.vi_rotate_lock_btm);
                } else {
                    rotate(true);
                    rotate = true;
                    video_roatate_lock.setImageResource(R.drawable.vi_erotation_lock);

                }
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });

        if (Constants.flip_mrrire == false) {
            playerView.setScaleX(scaleFactor);
            video_flip.setImageResource(R.drawable.vi_flip_btm);
        } else {

            playerView.setScaleX(-scaleFactor);
            video_flip.setImageResource(R.drawable.vi_eflip_set);
        }
        video_flip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!Constants.flip_mrrire) {
                    Constants.flip_mrrire = true;
                    playerView.setScaleX(-scaleFactor);
                    video_flip.setImageResource(R.drawable.vi_eflip_set);
                } else {
                    Constants.flip_mrrire = false;
                    playerView.setScaleX(scaleFactor);
                    video_flip.setImageResource(R.drawable.vi_flip_btm);
                }
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);

            }
        });

        img_ss_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            Bitmap bitmap = ((TextureView) playerView.getVideoSurfaceView()).getBitmap();
                            bitmapsavemoth(bitmap, "VPS_" + System.currentTimeMillis());
                        } catch (Exception e) {
                        }


                        handler_gone.removeCallbacks(runnable_gone);
                        handler_gone.postDelayed(runnable_gone, 4000);
                    }
                }, 250);
            }
        });


        if (Constants.Speed_bottom == true) {
            speed_mune_set.setVisibility(View.VISIBLE);
        }
        img_speed_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (speed_mune_set.getVisibility() == View.GONE) {
                    speed_mune_set.setVisibility(View.VISIBLE);
                    Constants.Speed_bottom = true;
                }
                speed_dilod_open();
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });
        speed_mune_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                speed_mune_set.setVisibility(View.GONE);
                Constants.Speed_bottom = false;
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });
        float tempbright = getWindow().getAttributes().screenBrightness;
        if (tempbright < 0) tempbright = 0.5f;
        int mybright = (int) (15 * tempbright);
        seek_bright.setMax(seek_volume.getMax());
        seek_bright.setProgress(mybright);
        video_seek_set.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                if (fromUser) {
                    player.seekTo(progress);
                }
                txt_left_time.setText(UtilsVideo.formateMilliSeccond(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                player.pause();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (audioFocus()) {
                    player.play();
                }

                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });
        img_mute_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (seek_volume.getProgress() == 0) {
                    img_mute_set.setImageResource(R.drawable.vi_vol_on_set);
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 7, 0);
                    seek_volume.setProgress(7);

                } else {
                    img_mute_set.setImageResource(R.drawable.evol_on_mute);
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
                    seek_volume.setProgress(0);

                }
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);

            }
        });
        seek_bright.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                text_bright.setText(progress + "");
                if (progress > 5) {
                    img_bright_set.setImageResource(R.drawable.vi_full_brightnss_set);
                } else {
                    img_bright_set.setImageResource(R.drawable.vi_brightness_set);
                }
                float brightness = progress / 25.0f;
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = brightness;
                getWindow().setAttributes(lp);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {


            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);

            }
        });
        seek_volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                txt_volume.setText(progress + "");
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
                if (progress == 0) {
                    img_volume_set.setImageResource(R.drawable.vi_vol_muat);
                    img_mute_set.setImageResource(R.drawable.evol_on_mute);

                } else {
                    img_volume_set.setImageResource(R.drawable.vi_an_mute_vol);
                    img_mute_set.setImageResource(R.drawable.vi_vol_on_set);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });

        if (Constants.Icon_equalizer_seek_set == true) {
            equalizerLayout.setVisibility(View.VISIBLE);
        }

        img_equalizer_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (equalizerLayout.getVisibility() == View.GONE) {
                    equalizerLayout.setVisibility(View.VISIBLE);
                    setmunegone();
                    Constants.Icon_equalizer_seek_set = true;
                    Settings.presetPos = 0;

                    audioSesionId = player.getAudioSessionId();
                    if (Settings.equalizerModel == null) {
                        Settings.equalizerModel = new EqualizerModel();
                        Settings.equalizerModel.setReverbPreset(PresetReverb.PRESET_NONE);
                        Settings.equalizerModel.setBassStrength((short) (1000 / 19));
                    }

                    mEqualizer = new Equalizer(0, audioSesionId);


                    if (Settings.presetPos == 0) {
                        for (short bandIdx = 0; bandIdx < mEqualizer.getNumberOfBands(); bandIdx++) {
                            mEqualizer.setBandLevel(bandIdx, (short) Settings.seekbarpos[bandIdx]);
                        }
                    } else {
                        mEqualizer.usePreset((short) Settings.presetPos);
                    }
                }
                handler_gone.removeCallbacks(runnable_gone);
                handler_gone.postDelayed(runnable_gone, 4000);
            }
        });
        equalizerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.Icon_equalizer_seek_set = false;
                equalizerLayout.setVisibility(View.GONE);
            }
        });

        hideSystemUI();
        img_bottom_teb.setVisibility(View.GONE);
        img_tool_teb.setVisibility(View.GONE);
        img_up_down_mune.setVisibility(View.GONE);

        if (!OpenWithVideoActivity.this.isDestroyed()) {
            if (Intent.ACTION_VIEW.equals(getIntent().getAction())) {
                File file = new File(getRealPathFromURI(getIntent().getData()));
                videoplayersetdata(file);
            }

            instlizevideoeqlizer();
        }
        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (isPlaying) {
                    img_play_pause.setImageResource(R.drawable.vi_pause_view);
                    txt_right_time.setText(UtilsVideo.formateMilliSeccond(player.getDuration()));
                    video_seek_set.setMax((int) player.getDuration());
                    handler.postDelayed(runnable, 1000);
                    newhandrerunble(true);

                } else {
                    img_play_pause.setImageResource(R.drawable.vi_play_view);
                    newhandrerunble(true);
                    handler.removeCallbacks(runnable);

                }
            }


            @Override
            public void onPlaybackStateChanged(int playbackState) {

                if (playbackState == Player.STATE_ENDED) {
                  finish();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {


                switch (error.errorCode) {
                    case ExoPlaybackException.TYPE_SOURCE:

                    case ExoPlaybackException.TYPE_UNEXPECTED:
                        break;

                    case ExoPlaybackException.TYPE_RENDERER:
                        break;
                }

                Toast.makeText(OpenWithVideoActivity.this,   " is not supported", Toast.LENGTH_SHORT).show();

            }
        });


        runnable_gone = new Runnable() {
            @Override
            public void run() {

                hideSystemUI();
                img_bottom_teb.setVisibility(View.GONE);
                img_tool_teb.setVisibility(View.GONE);
                img_up_down_mune.setVisibility(View.GONE);
                cut_view_next_prev.setVisibility(View.GONE);
                bright_view_set.setVisibility(View.GONE);
                volum_view_set.setVisibility(View.GONE);
                left_img.setVisibility(View.GONE);
                right_img.setVisibility(View.GONE);
                setmunegone();

            }
        };
    }

    private String getRealPathFromURI(Uri data) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = getContentResolver().query(data, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void OpenWithViewBind() {
        player = new ExoPlayer.Builder(OpenWithVideoActivity.this).build();
        playerView = findViewById(R.id.player_show);
        playerView.setPlayer(player);
        toucher = findViewById(R.id.toucher);
        img_tool_teb = findViewById(R.id.img_tool_teb);
        img_back_set = findViewById(R.id.img_back_set);
        txt_video_name = findViewById(R.id.txt_video_name);
        aspecttext = findViewById(R.id.aspecttext);
        img_bottom_teb = findViewById(R.id.img_bottom_teb);
        txt_left_time = findViewById(R.id.txt_left_time);
        txt_right_time = findViewById(R.id.txt_right_time);
        video_seek_set = findViewById(R.id.video_seek_set);
        img_lock_set = findViewById(R.id.img_lock_set);
        img_unlock_set = findViewById(R.id.img_unlock_set);

        img_play_pause = findViewById(R.id.img_play_pause);
        img_aspectbtn_set = findViewById(R.id.img_aspectbtn_set);
        img_up_down_mune = findViewById(R.id.img_up_down_mune);
        img_equalizer_set = findViewById(R.id.img_equalizer_set);
        img_night_set = findViewById(R.id.img_night_set);
        img_mute_set = findViewById(R.id.img_mute_set);
        img_ss_set = findViewById(R.id.img_ss_set);
        img_speed_set = findViewById(R.id.img_speed_set);
        view_set_up_down = findViewById(R.id.view_set_up_down);
        bright_view_set = findViewById(R.id.bright_view_set);
        volum_view_set = findViewById(R.id.volum_view_set);
        seek_volume = findViewById(R.id.seek_volume);
        seek_bright = findViewById(R.id.seek_bright);

        text_bright = findViewById(R.id.text_bright);
        txt_volume = findViewById(R.id.txt_volume);

        img_volume_set = findViewById(R.id.img_volume_set);
        img_bright_set = findViewById(R.id.img_bright_set);
        equalizerLayout = findViewById(R.id.equalizerLayout);
        tv_custom = findViewById(R.id.tv_custom);
        tv_normal = findViewById(R.id.tv_normal);
        tv_classic = findViewById(R.id.tv_classic);
        tv_dance = findViewById(R.id.tv_dance);
        tv_flat = findViewById(R.id.tv_flat);
        tv_folk = findViewById(R.id.tv_folk);
        tv_heavy_metal = findViewById(R.id.tv_heavy_metal);
        tv_hip_hop = findViewById(R.id.tv_hip_hop);
        tv_jazz = findViewById(R.id.tv_jazz);
        tv_pop = findViewById(R.id.tv_pop);
        tv_rock = findViewById(R.id.tv_rock);

        vi_on = findViewById(R.id.equa_on_set);
        vi_off = findViewById(R.id.equa_off_set);
        relativ_nigitset = findViewById(R.id.relativ_nigitset);
        video_flip = findViewById(R.id.video_flip);
        video_roatate_lock = findViewById(R.id.video_roatate_lock);
        cut_view_next_prev = findViewById(R.id.cut_view_next_prev);
        left_img = findViewById(R.id.left_img);
        right_img = findViewById(R.id.right_img);




        speed_mune_set = findViewById(R.id.speed_mune_set);
        select_speed_txt = findViewById(R.id.select_speed_txt);
        seek_speed = findViewById(R.id.seek_speed);
        text_speed_025 = findViewById(R.id.text_speed_025);
        text_speed_050 = findViewById(R.id.text_speed_050);
        text_speed_075 = findViewById(R.id.text_speed_075);
        text_speed_01 = findViewById(R.id.text_speed_01);
        text_speed_125 = findViewById(R.id.text_speed_125);
        text_speed_150 = findViewById(R.id.text_speed_150);
        text_speed_175 = findViewById(R.id.text_speed_175);
        text_speed_02 = findViewById(R.id.text_speed_02);
        continuelay = findViewById(R.id.continuelay);
        relativ_clikr_off = findViewById(R.id.relativ_clikr_off);

    }


    private void rotate(boolean b) {

        if (b == true) {

            Display display = ((WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay();
            int orientation = display.getOrientation();

            switch (orientation) {
                case 0:
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                    break;
                case 3:
                case 1:
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE);
                    break;
            }
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        }

    }

    private void speed_dilod_open() {

        seek_speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Constants.video_speed = i;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);
        text_speed_025.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 1;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }
        });
        text_speed_050.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 2;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }
        });
        text_speed_075.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 3;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }
        });
        text_speed_01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 5;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }
        });
        text_speed_125.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 6;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);
            }
        });
        text_speed_150.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 7;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }
        });
        text_speed_175.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 8;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }
        });
        text_speed_02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constants.video_speed = 10;
                setmothdata(seek_speed, select_speed_txt, text_speed_025, text_speed_050, text_speed_075, text_speed_01, text_speed_125, text_speed_150, text_speed_175, text_speed_02);

            }
        });
    }

    private void setmothdata(SeekBar seek_speed, TextView select_speed_txt, TextView text_speed_025, TextView text_speed_050, TextView text_speed_075, TextView text_speed_01, TextView text_speed_125, TextView text_speed_150, TextView text_speed_175, TextView text_speed_02) {
        if (Constants.video_speed == 1) {
            seek_speed.setProgress((int) 1);
            select_speed_txt.setText("0.25x");
            PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
            player.setPlaybackParameters(param);
            text_speed_025.setBackgroundResource(R.drawable.speed_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

        } else if (Constants.video_speed == 2) {
            seek_speed.setProgress((int) 2);
            select_speed_txt.setText("0.50x");
            PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
            player.setPlaybackParameters(param);
            text_speed_025.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

        } else if (Constants.video_speed == 3) {
            seek_speed.setProgress((int) 3);
            select_speed_txt.setText("0.75x");
            text_speed_025.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

        } else if (Constants.video_speed == 4 || Constants.video_speed == 5) {
            seek_speed.setProgress((int) 5);
            select_speed_txt.setText("1x");
            PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
            player.setPlaybackParameters(param);
            text_speed_025.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

        } else if (Constants.video_speed == 6) {
            seek_speed.setProgress((int) 6);
            select_speed_txt.setText("1.25x");
            PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
            player.setPlaybackParameters(param);
            text_speed_025.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

        } else if (Constants.video_speed == 7) {
            seek_speed.setProgress((int) 7);
            select_speed_txt.setText("1.50x");
            PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
            player.setPlaybackParameters(param);
            text_speed_025.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

        } else if (Constants.video_speed == 8) {
            seek_speed.setProgress((int) 8);
            select_speed_txt.setText("1.75x");
            PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
            player.setPlaybackParameters(param);
            text_speed_025.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

        } else if (Constants.video_speed == 9 || Constants.video_speed == 10) {
            seek_speed.setProgress((int) 10);
            select_speed_txt.setText("2x");
            PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
            player.setPlaybackParameters(param);
            text_speed_025.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_050.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_075.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_01.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_125.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_150.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_175.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
            text_speed_02.setBackgroundResource(R.drawable.speed_txt_bg);
        }
    }


    private void setmunegone() {
        layuot_open = false;
        if (Constants.Screenmode == true) {

            img_up_down_mune.setRotation(90);
            video_flip.setVisibility(View.GONE);
            video_roatate_lock.setVisibility(View.GONE);

        } else {
            img_up_down_mune.setRotation(0);
            img_equalizer_set.setVisibility(View.GONE);
            img_night_set.setVisibility(View.GONE);
            img_mute_set.setVisibility(View.GONE);
            img_ss_set.setVisibility(View.GONE);
            img_speed_set.setVisibility(View.GONE);
            video_flip.setVisibility(View.GONE);
            video_roatate_lock.setVisibility(View.GONE);
        }


    }
    private void bitmapsavemoth(Bitmap bitmap, String s) {


        String path1 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/Video ss";
        File dir = new File(path1);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        File file = null;

        if (bitmap != null) {
            try {
                file = new File(dir.getAbsolutePath(), s + ".jpg");
                file.createNewFile();
                OutputStream stream = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                stream.flush();
                stream.close();

                Toast.makeText(OpenWithVideoActivity.this, file.getAbsolutePath() + " " + "Image Save Successfully", Toast.LENGTH_LONG).show();

            } catch (IOException e) {
                e.printStackTrace();

            }
            MediaScannerConnection.scanFile(OpenWithVideoActivity.this, new String[]{dir.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {


                }
            });
        }
    }

    private void hideSystemUI() {
        isshow = false;

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);

    }

    private void showSystemUI() {
        isshow = true;
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        if (continuelay != null) {
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) continuelay.getLayoutParams();
            layoutParams.setMargins(layoutParams.leftMargin, layoutParams.topMargin, layoutParams.rightMargin, getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._90sdp));
            continuelay.setLayoutParams(layoutParams);
        }

    }

    private void instlizevideoeqlizer() {

        mEqualizer = new Equalizer(0, audioSesionId);
        Paint paint = new Paint();
        TextView equalizerHeading = new TextView(OpenWithVideoActivity.this);
        equalizerHeading.setText(R.string.eq);
        equalizerHeading.setTextSize(20);
        equalizerHeading.setGravity(Gravity.CENTER_HORIZONTAL);

        short numberOfFrequencyBands = 5;

        points = new float[numberOfFrequencyBands];

        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];
        final short upperEqualizerBandLevel = mEqualizer.getBandLevelRange()[1];

        for (short i = 0; i < numberOfFrequencyBands; i++) {
            final short equalizerBandIndex = i;
            final TextView frequencyHeaderTextView = new TextView(OpenWithVideoActivity.this);
            frequencyHeaderTextView.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));
            frequencyHeaderTextView.setGravity(Gravity.CENTER_HORIZONTAL);
            frequencyHeaderTextView.setTextColor(Constants.textColor);
            frequencyHeaderTextView.setText((mEqualizer.getCenterFreq(equalizerBandIndex) / 1000) + "Hz");

            LinearLayout seekBarRowLayout = new LinearLayout(OpenWithVideoActivity.this);
            seekBarRowLayout.setOrientation(LinearLayout.VERTICAL);

            TextView lowerEqualizerBandLevelTextView = new TextView(OpenWithVideoActivity.this);
            lowerEqualizerBandLevelTextView.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
            lowerEqualizerBandLevelTextView.setTextColor(Constants.textColor);
            lowerEqualizerBandLevelTextView.setText((lowerEqualizerBandLevel / 100) + "dB");

            TextView upperEqualizerBandLevelTextView = new TextView(OpenWithVideoActivity.this);
            lowerEqualizerBandLevelTextView.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));
            upperEqualizerBandLevelTextView.setTextColor(Constants.textColor);
            upperEqualizerBandLevelTextView.setText((upperEqualizerBandLevel / 100) + "dB");

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            layoutParams.weight = 1;

            SeekBar seekBar = new SeekBar(OpenWithVideoActivity.this);
            TextView textView = new TextView(OpenWithVideoActivity.this);
            switch (i) {
                case 0:
                    seekBar = findViewById(R.id.seekBar1);
                    textView = findViewById(R.id.textView1);
                    break;
                case 1:
                    seekBar = findViewById(R.id.seekBar2);
                    textView = findViewById(R.id.textView2);
                    break;
                case 2:
                    seekBar = findViewById(R.id.seekBar3);
                    textView = findViewById(R.id.textView3);
                    break;
                case 3:
                    seekBar = findViewById(R.id.seekBar4);
                    textView = findViewById(R.id.textView4);
                    break;
                case 4:
                    seekBar = findViewById(R.id.seekBar5);
                    textView = findViewById(R.id.textView5);
                    break;
            }
            seekBarFinal[i] = seekBar;

            seekBar.setId(i);


            seekBar.setMax(upperEqualizerBandLevel - lowerEqualizerBandLevel);
            textView.setText(frequencyHeaderTextView.getText());
            textView.setTextColor(Constants.textColor);
            textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

            if (Settings.isEqualizerReloaded) {
                points[i] = Settings.seekbarpos[i] - lowerEqualizerBandLevel;

                seekBar.setProgress(Settings.seekbarpos[i] - lowerEqualizerBandLevel);
            } else {
                points[i] = mEqualizer.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel;

                seekBar.setProgress(mEqualizer.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel);
                Settings.seekbarpos[i] = mEqualizer.getBandLevel(equalizerBandIndex);
                Settings.isEqualizerReloaded = true;
            }
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    mEqualizer.setBandLevel(equalizerBandIndex, (short) (progress + lowerEqualizerBandLevel));
                    points[seekBar.getId()] = mEqualizer.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel;
                    Settings.seekbarpos[seekBar.getId()] = (progress + lowerEqualizerBandLevel);
                    Settings.equalizerModel.getSeekbarpos()[seekBar.getId()] = (progress + lowerEqualizerBandLevel);

                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                    Settings.presetPos = 0;


                    tv_custom.setBackgroundResource(R.drawable.speed_txt_bg);
                    tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                    tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                    try {
                        if (0 != 0) {
                            mEqualizer.usePreset((short) (0 - 1));
                            Settings.presetPos = 0;
                            short numberOfFreqBands = 5;

                            final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                            for (short i = 0; i < numberOfFreqBands; i++) {
                                seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                                points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                                Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                                Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                            }
                        }
                    } catch (Exception e) {
                        Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });

        }
        if (Constants.Icon_equalizer_seek_set) {
            vi_off.setVisibility(View.GONE);
            vi_on.setVisibility(View.VISIBLE);
            relativ_clikr_off.setVisibility(View.GONE);
            seekBarFinal[0].setEnabled(true);
            seekBarFinal[1].setEnabled(true);
            seekBarFinal[2].setEnabled(true);
            seekBarFinal[3].setEnabled(true);
            seekBarFinal[4].setEnabled(true);

        } else {
            vi_on.setVisibility(View.GONE);
            vi_off.setVisibility(View.VISIBLE);
            relativ_clikr_off.setVisibility(View.VISIBLE);
            seekBarFinal[0].setEnabled(false);
            seekBarFinal[1].setEnabled(false);
            seekBarFinal[2].setEnabled(false);
            seekBarFinal[3].setEnabled(false);
            seekBarFinal[4].setEnabled(false);
        }
        vi_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vi_off.setVisibility(View.GONE);
                vi_on.setVisibility(View.VISIBLE);
                relativ_clikr_off.setVisibility(View.GONE);
                Constants.Icon_equalizer_seek_set = true;
                mEqualizer.setEnabled(true);
                seekBarFinal[0].setEnabled(true);
                seekBarFinal[1].setEnabled(true);
                seekBarFinal[2].setEnabled(true);
                seekBarFinal[3].setEnabled(true);
                seekBarFinal[4].setEnabled(true);
                img_equalizer_set.setImageResource(R.drawable.vi_eequalizer);
            }
        });
        vi_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vi_on.setVisibility(View.GONE);
                vi_off.setVisibility(View.VISIBLE);
                relativ_clikr_off.setVisibility(View.VISIBLE);
                Constants.Icon_equalizer_seek_set = false;
                mEqualizer.setEnabled(false);
                seekBarFinal[0].setEnabled(false);
                seekBarFinal[1].setEnabled(false);
                seekBarFinal[2].setEnabled(false);
                seekBarFinal[3].setEnabled(false);
                seekBarFinal[4].setEnabled(false);
                mEqualizer.setEnabled(false);
                img_equalizer_set.setImageResource(R.drawable.vi_equalizer_set);

            }
        });

        presetSpinner = findViewById(R.id.equalizer_preset_spinner);

        equalizeSound();

        paint.setColor(Constants.textColor);
        paint.setStrokeWidth((float) (1.10 * Settings.ratio));

        Button mEndButton = new Button(OpenWithVideoActivity.this);
        mEndButton.setBackgroundColor(Constants.themeColor);
        mEndButton.setTextColor(Constants.textColor);

    }

    private void equalizeSound() {
        ArrayList<String> equalizerPresetNames = new ArrayList<>();
        ArrayAdapter<String> equalizerPresetSpinnerAdapter = new ArrayAdapter<>(OpenWithVideoActivity.this, R.layout.spinner_item, equalizerPresetNames);
        equalizerPresetSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        equalizerPresetNames.add("Custom");

        for (short i = 0; i < mEqualizer.getNumberOfPresets(); i++) {
            equalizerPresetNames.add(mEqualizer.getPresetName(i));
        }

        presetSpinner.setAdapter(equalizerPresetSpinnerAdapter);
        if (Settings.isEqualizerReloaded && Settings.presetPos != 0) {
            presetSpinner.setSelection(Settings.presetPos);
        }

        switch (Settings.presetPos) {
            case 0:
                tv_custom.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (0 != 0) {
                        mEqualizer.usePreset((short) (0 - 1));
                        Settings.presetPos = 0;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }


                break;
            case 1:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (1 != 0) {
                        mEqualizer.usePreset((short) (1 - 1));
                        Settings.presetPos = 1;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 2:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (2 != 0) {
                        mEqualizer.usePreset((short) (2 - 1));
                        Settings.presetPos = 2;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 3:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (3 != 0) {
                        mEqualizer.usePreset((short) (3 - 1));
                        Settings.presetPos = 3;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }


                break;
            case 4:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (4 != 0) {
                        mEqualizer.usePreset((short) (4 - 1));
                        Settings.presetPos = 4;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 5:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (5 != 0) {
                        mEqualizer.usePreset((short) (5 - 1));
                        Settings.presetPos = 5;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 6:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (6 != 0) {
                        mEqualizer.usePreset((short) (6 - 1));
                        Settings.presetPos = 6;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 7:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (7 != 0) {
                        mEqualizer.usePreset((short) (7 - 1));
                        Settings.presetPos = 7;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 8:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (8 != 0) {
                        mEqualizer.usePreset((short) (8 - 1));
                        Settings.presetPos = 8;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 9:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (9 != 0) {
                        mEqualizer.usePreset((short) (9 - 1));
                        Settings.presetPos = 9;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
            case 10:
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_txt_bg);


                try {
                    if (10 != 0) {
                        mEqualizer.usePreset((short) (10 - 1));
                        Settings.presetPos = 10;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

                break;
        }
        tv_custom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (0 != 0) {
                        mEqualizer.usePreset((short) (0 - 1));
                        Settings.presetPos = 0;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_normal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (1 != 0) {
                        mEqualizer.usePreset((short) (1 - 1));
                        Settings.presetPos = 1;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_classic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (2 != 0) {
                        mEqualizer.usePreset((short) (2 - 1));
                        Settings.presetPos = 2;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_dance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);


                try {
                    if (3 != 0) {
                        mEqualizer.usePreset((short) (3 - 1));
                        Settings.presetPos = 3;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_flat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (4 != 0) {
                        mEqualizer.usePreset((short) (4 - 1));
                        Settings.presetPos = 4;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_folk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (5 != 0) {
                        mEqualizer.usePreset((short) (5 - 1));
                        Settings.presetPos = 5;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_heavy_metal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (6 != 0) {
                        mEqualizer.usePreset((short) (6 - 1));
                        Settings.presetPos = 6;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_hip_hop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (7 != 0) {
                        mEqualizer.usePreset((short) (7 - 1));
                        Settings.presetPos = 7;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_jazz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (8 != 0) {
                        mEqualizer.usePreset((short) (8 - 1));
                        Settings.presetPos = 8;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_stoc_txt_bg);

                try {
                    if (9 != 0) {
                        mEqualizer.usePreset((short) (9 - 1));
                        Settings.presetPos = 9;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        tv_rock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                tv_custom.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_normal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_classic.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_dance.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_flat.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_folk.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_heavy_metal.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_hip_hop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_jazz.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_pop.setBackgroundResource(R.drawable.speed_stoc_txt_bg);
                tv_rock.setBackgroundResource(R.drawable.speed_txt_bg);

                try {
                    if (10 != 0) {
                        mEqualizer.usePreset((short) (10 - 1));
                        Settings.presetPos = 10;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                    presetSpinner.setSelection(Settings.presetPos);
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }
        });

        presetSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (position != 0) {
                        mEqualizer.usePreset((short) (position - 1));
                        Settings.presetPos = position;
                        short numberOfFreqBands = 5;

                        final short lowerEqualizerBandLevel = mEqualizer.getBandLevelRange()[0];

                        for (short i = 0; i < numberOfFreqBands; i++) {
                            seekBarFinal[i].setProgress(mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel);
                            points[i] = mEqualizer.getBandLevel(i) - lowerEqualizerBandLevel;
                            Settings.seekbarpos[i] = mEqualizer.getBandLevel(i);
                            Settings.equalizerModel.getSeekbarpos()[i] = mEqualizer.getBandLevel(i);
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(OpenWithVideoActivity.this, "Error while updating Equalizer", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        g0 = true;
        isshow = false;
        float f = getResources().getDisplayMetrics().widthPixels / 2.0f;
        cut_view_next_prev.setVisibility(View.VISIBLE);
        if (motionEvent.getX() > f) {
            if (motionEvent.getX() > f + 200.0f) {

                player.seekTo(player.getCurrentPosition() + 5000);
                left_img.setVisibility(View.GONE);
                right_img.setVisibility(View.VISIBLE);

            }

        }
        if (motionEvent.getX() < f) {
            if (motionEvent.getX() < f - 200.0f) {

                player.seekTo(player.getCurrentPosition() - 5000);
                left_img.setVisibility(View.VISIBLE);
                right_img.setVisibility(View.GONE);

            }
        }
        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {

        if (g0 == false) {
            if (isshow) {
                hideSystemUI();
                img_bottom_teb.setVisibility(View.INVISIBLE);
                img_tool_teb.setVisibility(View.INVISIBLE);
                img_up_down_mune.setVisibility(View.GONE);
                volum_view_set.setVisibility(View.GONE);
                bright_view_set.setVisibility(View.GONE);
                view_set_up_down.setVisibility(View.GONE);
                setmunegone();


            } else {
                showSystemUI();
                img_play_pause.setVisibility(View.VISIBLE);
                img_bottom_teb.setVisibility(View.VISIBLE);
                view_set_up_down.setVisibility(View.VISIBLE);
                img_tool_teb.setVisibility(View.VISIBLE);
                img_up_down_mune.setVisibility(View.VISIBLE);
                volum_view_set.setVisibility(View.GONE);
                bright_view_set.setVisibility(View.GONE);


            }
        }
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float f, float f2) {
        float width = toucher.getWidth();

        if (e0) {

            if (f2 > 11.0f && motionEvent.getX() > width / 2.0f && !l) {
                m = true;
                bright_view_set.setVisibility(View.GONE);
                img_bottom_teb.setVisibility(View.GONE);
                img_tool_teb.setVisibility(View.GONE);
                view_set_up_down.setVisibility(View.GONE);
                setmunegone();

                audioManager.setStreamVolume(3, audioManager.getStreamVolume(3) + 1, 0);
                seek_volume.setProgress(audioManager.getStreamVolume(3));
                volum_view_set.setVisibility(View.VISIBLE);

                return true;
            }
            float f3 = -f2;
            if (f3 > 11.0f && motionEvent.getX() > width / 2.0f && !this.l) {
                this.m = true;
                bright_view_set.setVisibility(View.GONE);
                img_bottom_teb.setVisibility(View.GONE);
                img_tool_teb.setVisibility(View.GONE);
                view_set_up_down.setVisibility(View.GONE);
                setmunegone();

                audioManager.setStreamVolume(3, audioManager.getStreamVolume(3) - 1, 0);
                seek_volume.setProgress(audioManager.getStreamVolume(3));
                volum_view_set.setVisibility(View.VISIBLE);

                return true;
            } else if (f2 > 11.0f && motionEvent.getX() < width / 2.0f && !l) {
                this.m = true;
                volum_view_set.setVisibility(View.GONE);
                img_bottom_teb.setVisibility(View.GONE);
                img_tool_teb.setVisibility(View.GONE);
                view_set_up_down.setVisibility(View.GONE);
                setmunegone();
                seek_bright.setProgress(seek_bright.getProgress() + 3);
                bright_view_set.setVisibility(View.VISIBLE);

                return true;
            } else {
                if (f3 > 11.0f && motionEvent.getX() < width / 2.0f && !l) {
                    this.m = true;
                    volum_view_set.setVisibility(View.GONE);
                    img_bottom_teb.setVisibility(View.GONE);
                    img_tool_teb.setVisibility(View.GONE);
                    view_set_up_down.setVisibility(View.GONE);
                    setmunegone();
                    seek_bright.setProgress(seek_bright.getProgress() - 3);
                    bright_view_set.setVisibility(View.VISIBLE);

                }

                if (f > 1.0f && !m) {
                    videoswip = true;
                    bright_view_set.setVisibility(View.GONE);
                    volum_view_set.setVisibility(View.GONE);
                    img_tool_teb.setVisibility(View.GONE);
                    view_set_up_down.setVisibility(View.GONE);
                    setmunegone();
                    player.seekTo(player.getCurrentPosition() - 1000);
                    l = true;
                    player.pause();
                    img_play_pause.setImageResource(R.drawable.vi_play_view);
                    img_bottom_teb.setVisibility(View.VISIBLE);


                    return true;
                } else if ((-f) > 1.0f && !m) {
                    videoswip = true;
                    bright_view_set.setVisibility(View.GONE);
                    volum_view_set.setVisibility(View.GONE);
                    img_tool_teb.setVisibility(View.GONE);
                    view_set_up_down.setVisibility(View.GONE);
                    setmunegone();
                    player.seekTo(player.getCurrentPosition() + 1000);
                    l = true;
                    player.pause();
                    img_play_pause.setImageResource(R.drawable.vi_play_view);
                    img_bottom_teb.setVisibility(View.VISIBLE);


                }


            }

        }

        return true;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        scaleFactor *= detector.getScaleFactor();
        if (scaleFactor > 4 || scaleFactor < 0.25) {
            return true;
        } else {
            playerView.setScaleX(scaleFactor);
            playerView.setScaleY(scaleFactor);
            float per = (1000 * scaleFactor) / 4.5f;
            aspecttext.setText((int) per + "%");
        }
        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
        aspecttext.setVisibility(View.VISIBLE);

        scaleFactor = playerView.getScaleX();
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {
        aspecttext.setVisibility(View.GONE);
        scaleFactor = playerView.getScaleX();
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (Constants.islock == true) {
        } else {
            if (motionEvent.getPointerCount() == 1) {
                gestureDetector.onTouchEvent(motionEvent);
            } else {
                scaleGestureDetector.onTouchEvent(motionEvent);
            }
            if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                cut_view_next_prev.setVisibility(View.GONE);
                if (handler_gone != null) {
                    handler_gone.removeCallbacks(runnable_gone);
                    handler_gone.postDelayed(runnable_gone, 4000);
                }


                if (Constants.play_pause == true) {
                    if (!player.isPlaying()) {
                        if (audioFocus()) {
                            player.play();
                            Constants.play_pause = true;
                        }
                    }
                }


            }
            if (motionEvent.getActionMasked() != 1) {
                return true;
            }
            l = false;
            m = false;

        }
        return true;
    }


    @Override
    protected void onPause() {
        super.onPause();
        stopService(new Intent(OpenWithVideoActivity.this, VideoPlayServer.class));
        pausePlayer();

    }

    private void pausePlayer() {
        if (player == null) return;
        player.pause();
        player.setPlayWhenReady(false);
        player.getPlaybackState();

    }

    @Override
    protected void onResume() {
        super.onResume();

        hideSystemUI();
        startService(new Intent(OpenWithVideoActivity.this, VideoPlayServer.class));
        if (player != null) {

            player.prepare();
        }
    }

    @Override
    public void onBackPressed() {

        if (equalizerLayout.getVisibility() == View.VISIBLE) {
            equalizerLayout.setVisibility(View.GONE);
            Constants.Icon_equalizer_seek_set = false;


        } else {
            super.onBackPressed();
            Constants.position = 0;
            Constants.play_pause = false;
            Constants.flip_mrrire = false;
            Constants.Screenmode = false;
            Constants.play_list = false;
            Constants.Icon_equalizer_seek_set = false;
            Constants.islock = false;
            Constants.nigthmode = false;
            Constants.video_speed = 5;
            Constants.timer = false;
            Constants.repeat = "none";
        }
    }

    private void newhandrerunble(boolean b) {
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                if (b == true) {
                    g0 = false;
                    if (player == null) return;
                    if (!isdonebyus) {
                        video_seek_set.setProgress((int) player.getCurrentPosition());
                    }
                }
                handler.postDelayed(this::run, 1000);
            }
        };
        handler.postDelayed(runnable, 1000);


    }


    private void videoplayersetdata(File file) {


        Uri uri = FileProvider.getUriForFile(OpenWithVideoActivity.this, getPackageName() + ".fileprovider",file);
        MediaItem mediaItem = MediaItem.fromUri(uri);

        player.setMediaItem(mediaItem, 0);
        txt_video_name.setText(file.getName());
        player.prepare();
        video_seek_set.setProgress(0);
        txt_left_time.setText(UtilsVideo.formateMilliSeccond(player.getCurrentPosition()));
        video_seek_set.setProgress((int) player.getCurrentPosition());
        video_seek_set.setMax((int) player.getDuration());
        video_seek_set.setProgress((int) player.getCurrentPosition());
        PlaybackParameters param = new PlaybackParameters(0.5f + (Constants.video_speed / 10.0f));
        player.setPlaybackParameters(param);
        video();

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (player != null) {
            player.stop();
            player.setPlayWhenReady(false);
            player.release();

        }
    }

    public void video() {

        if (player != null) {
            if (play_pause == false) {
                if (player.isPlaying()) {
                    player.pause();
                }
            } else {

                if (player.isPlaying()) {
                    player.pause();
                } else {
                    if (audioFocus()) {
                        player.play();
                    }
                }
            }
        }
    }

    public boolean audioFocus() {
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        int result = audioManager.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            return true;
        }
        return false;
    }

    public AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {

                    switch (focusChange) {

                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK):
                            if (player != null && player.isPlaying()) {
                                player.pause();

                            }
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT):
                            if (player != null && player.isPlaying()) {
                                player.pause();


                            }
                            break;

                        case (AudioManager.AUDIOFOCUS_LOSS):
                            if (player != null && player.isPlaying()) {
                                player.pause();


                            }


                            break;

                        case (AudioManager.AUDIOFOCUS_GAIN):

                            break;
                        default:
                            break;
                    }
                }
            };
}