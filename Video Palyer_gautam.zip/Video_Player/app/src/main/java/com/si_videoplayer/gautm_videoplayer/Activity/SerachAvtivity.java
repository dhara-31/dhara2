package com.si_videoplayer.gautm_videoplayer.Activity;

import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.bottom_play_linear;
import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.maniVideoPlayerActivity;

import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.PlayFirstBackgroundVideo;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.backGroundPlayingList;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.backgroundPosition;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.path_delete;
import static com.si_videoplayer.gautm_videoplayer.Service.NotificationService.foregroundService;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Adapter.ADD_Play_List_Adapter;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Interface;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.Adapter.MyAdaterSearch;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.Service.NotificationService;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.VideotoAudio;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;

public class SerachAvtivity extends AppCompatActivity {

    EditText edit_text_set_search;
    ImageView img_close_search;
    Gson gson;
    ArrayList<VideoInfo> search_list = new ArrayList<>();
    ArrayList<VideoInfo> list_favo = new ArrayList<>();
    ArrayList<VideoInfo> list_filte = new ArrayList<>();
    ArrayList<VideoInfo> list_history = new ArrayList<>();
    ArrayList<VideoInfo> atp_get_list = new ArrayList<>();
    RecyclerView recy_search_set;
    MyAdaterSearch myAdaterSearch;
    ImageView img_no_data;
    PreferenceUtil preferenceUtil;
    RelativeLayout img_tool_search, tool_favo_set;
    private File file_for_delete;
    private int delete_pos, filtr_pos;
    private int renamepos;
    private String newName;
    private File file_original;
    private String edit_item_path;
    private String old_file_path;
    private Uri contentUri;
    private ADD_Play_List_Adapter atp_list_adapter;
    private TextView text_avtivity_name;
    private ImageView img_set_tool_serach;
    int activitynubset;
    TextView text_no_data;
    boolean serset = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_serach_avtivity);




        FrameLayout banner = findViewById(R.id.banner);
        GoviddecgtmAs.getInstance().ShowBanner(SerachAvtivity.this, banner);

        preferenceUtil = new PreferenceUtil(this);
        gson = new Gson();


        String json1Null00 = gson.toJson(search_list);
        String json00 = getIntent().getStringExtra("Serachlistset");
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        search_list = gson.fromJson(json00, type00);


        edit_text_set_search = findViewById(R.id.edit_text_set_search);
        img_close_search = findViewById(R.id.img_close_search);
        recy_search_set = findViewById(R.id.recy_search_set);
        img_no_data = findViewById(R.id.img_no_data);
        tool_favo_set = findViewById(R.id.tool_favo_set);
        img_tool_search = findViewById(R.id.img_tool_search);
        text_avtivity_name = findViewById(R.id.text_avtivity_name);
        img_set_tool_serach = findViewById(R.id.img_set_tool_serach);
        text_no_data = findViewById(R.id.text_no_data);
        text_avtivity_name.setLetterSpacing(0);
        img_set_tool_serach.setVisibility(View.GONE);

        int activitynub = getIntent().getIntExtra("setactivty", 11);
        activitynubset = activitynub;
        if (activitynub == 11) {
            img_tool_search.setVisibility(View.VISIBLE);
            tool_favo_set.setVisibility(View.GONE);

        } else {
            img_tool_search.setVisibility(View.GONE);
            tool_favo_set.setVisibility(View.VISIBLE);
            text_avtivity_name.setText("My Favourites");


        }


        recy_search_set.setLayoutManager(new LinearLayoutManager(this));
        myAdaterSearch = new MyAdaterSearch(this, activitynubset, search_list, this::noclick);
        recy_search_set.setAdapter(myAdaterSearch);
        if (activitynub == 22) {
            if (myAdaterSearch.getItemCount() == 0) {
                text_no_data.setVisibility(View.VISIBLE);
                recy_search_set.setVisibility(View.GONE);
            } else {
                text_no_data.setVisibility(View.GONE);
                recy_search_set.setVisibility(View.VISIBLE);
            }
        } else {
            if (myAdaterSearch.getItemCount() == 0) {
                recy_search_set.setVisibility(View.GONE);
                img_no_data.setVisibility(View.VISIBLE);

            } else {
                img_no_data.setVisibility(View.GONE);
                recy_search_set.setVisibility(View.VISIBLE);

            }
        }


        img_close_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                img_close_search.setImageResource(R.drawable.vi_close_sear);
                edit_text_set_search.setText("");
                edit_text_set_search.clearFocus();
                serset = false;
                setAptpter("");
            }
        });

        edit_text_set_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String sd = String.valueOf(editable).trim();
                if (sd.length() == 0) {
                    serset = false;
                } else {
                    setAptpter(sd);
                    serset = true;
                }

            }
        });

    }

    public void noclick(String s, int list_pos, ArrayList<VideoInfo> list_filter) {

        list_filte = list_filter;
        filtr_pos = list_pos;
        int aa = 0;
        for (int a = 0; a < search_list.size(); a++) {
            if (search_list.get(a).getmPath().equals(s)) {
                aa = a;

            }
        }
        final BottomSheetDialog bsd = new BottomSheetDialog(this);
        bsd.setContentView(R.layout.bottom_sheet_dialog_main);
        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }
        ImageView iv_thumbnail = bsd.findViewById(R.id.iv_thumbnail);


        Glide.with(this).load(search_list.get(aa).getmPath()).into(iv_thumbnail);


        TextView tv_total_time = bsd.findViewById(R.id.tv_total_time);
        TextView tv_video_name = bsd.findViewById(R.id.tv_video_name);
        TextView tv_created_day = bsd.findViewById(R.id.tv_created_day);
        TextView tv_resolution_size = bsd.findViewById(R.id.tv_resolution_size);


        tv_total_time.setText(UtilsVideo.formateMilliSeccond(search_list.get(aa).getmDuration()));
        tv_video_name.setText(search_list.get(aa).getmDisplayName());
        tv_created_day.setText(UtilsVideo.readableFileSize(search_list.get(aa).getmSize()) + "   " + UtilsVideo.convertLongToTime(new File(search_list.get(aa).getmPath()).lastModified(), "dd-MM-yyyy"));
        String convertSolution = UtilsVideo.convertSolution(search_list.get(aa).getmResolution());
        if (TextUtils.isEmpty(convertSolution)) {
            tv_resolution_size.setVisibility(View.GONE);
        } else {
            tv_resolution_size.setVisibility(View.VISIBLE);
            tv_resolution_size.setText(convertSolution);
        }
        tv_total_time.setText(UtilsVideo.formateMilliSeccond(search_list.get(aa).getmDuration()));

        RelativeLayout relativ_play_as_audio = bsd.findViewById(R.id.relativ_play_as_audio);
        RelativeLayout relativ_Add_to_fat = bsd.findViewById(R.id.relativ_Add_to_fat);
        RelativeLayout relativ_convert_mp3 = bsd.findViewById(R.id.relativ_convert_mp3);
        RelativeLayout relativ_add_to_platlist = bsd.findViewById(R.id.relativ_add_to_platlist);
        RelativeLayout relativ_properties = bsd.findViewById(R.id.relativ_properties);
        RelativeLayout relativ_share = bsd.findViewById(R.id.relativ_share);
        RelativeLayout relativ_rename = bsd.findViewById(R.id.relativ_rename);
        RelativeLayout relativ_delete = bsd.findViewById(R.id.relativ_delete);

        ImageView img_anselect = bsd.findViewById(R.id.img_anselect);
        ImageView img_select = bsd.findViewById(R.id.img_select);
        int finalAa = aa;

        if (list_favo.size() == 0) {
            list_favo = new ArrayList<>();
            img_anselect.setVisibility(View.VISIBLE);
            img_select.setVisibility(View.GONE);
        } else {
            for (int i = 0; i < list_favo.size(); i++) {
                if (list_favo.get(i).getmPath().equals(s)) {

                    img_anselect.setVisibility(View.GONE);
                    img_select.setVisibility(View.VISIBLE);
                    break;
                } else {
                    img_anselect.setVisibility(View.VISIBLE);
                    img_select.setVisibility(View.GONE);
                }
            }
        }
        relativ_play_as_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isMyServiceRunning(NotificationService.class)) {
                    if (foregroundService != null) {
                        foregroundService.stopNotification();
                    }
                }
                backgroundPosition = finalAa;
                backGroundPlayingList = new ArrayList<>();
                backGroundPlayingList.addAll(search_list);
                if (bottom_play_linear != null) {
                    bottom_play_linear.setVisibility(View.VISIBLE);
                }
                PlayFirstBackgroundVideo(SerachAvtivity.this);
                Intent intent = new Intent(SerachAvtivity.this, NotificationService.class);
                intent.setAction(Constants.ACTION.STARTFOREGROUND_ACTION);
                startService(intent);
                bsd.dismiss();

            }
        });
        relativ_Add_to_fat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (img_anselect.getVisibility() == View.VISIBLE) {

                    img_anselect.setVisibility(View.GONE);
                    img_select.setVisibility(View.VISIBLE);

                    if (list_favo.size() == 0) {
                        list_favo.add(search_list.get(finalAa));

                    } else {
                        for (int i = 0; i < list_favo.size(); i++) {
                            if (list_favo.get(i).getmPath().equals(search_list.get(finalAa).getmPath())) {
                                list_favo.remove(i);
                                break;
                            }
                        }
                        list_favo.add(search_list.get(finalAa));
                    }

                    savelistfavo(list_favo);
                } else {
                    if (img_select.getVisibility() == View.VISIBLE) {
                        img_anselect.setVisibility(View.VISIBLE);
                        img_select.setVisibility(View.GONE);

                        for (int i = 0; i < list_favo.size(); i++) {
                            if (list_favo.get(i).getmPath().equals(search_list.get(finalAa).getmPath())) {
                                list_favo.remove(i);
                                break;
                            }
                        }
                        savelistfavo(list_favo);
                    }
                }

                bsd.dismiss();
            }
        });
        relativ_convert_mp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String filename = search_list.get(finalAa).getmDisplayName();
                String result = filename.substring(0, filename.lastIndexOf("."));
                File filecerr = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/convatmp3/");

                if (!filecerr.exists()) {
                    filecerr.mkdirs();
                }
                File file_save_status = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/convatmp3/" + result + ".mp3");
                if (UtilsVideo.isVideoHaveAudioTrack(search_list.get(finalAa).getmPath())) {
                    new VideotoAudio(SerachAvtivity.this, file_save_status, search_list.get(finalAa).getmPath()).execute();
                } else {
                    Toast.makeText(SerachAvtivity.this, "This video does not have any audio!", Toast.LENGTH_SHORT).show();
                }


                bsd.dismiss();
            }
        });
        relativ_add_to_platlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_playlist(finalAa);
                bsd.dismiss();
            }
        });


        relativ_properties.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_pro(finalAa);
                bsd.dismiss();
            }
        });
        relativ_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                File file = new File(search_list.get(finalAa).getmPath());
                Uri picUri = FileProvider.getUriForFile(SerachAvtivity.this, getPackageName() + ".fileprovider", file.getAbsoluteFile());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_STREAM, picUri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                intent.setType("video/*");
                startActivity(Intent.createChooser(intent, "Share Via"));

                bsd.dismiss();
            }
        });

        relativ_rename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_rename(finalAa);
                bsd.dismiss();
            }
        });

        relativ_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_delete(finalAa);
                bsd.dismiss();
            }
        });

        bsd.show();

    }

    private void open_dialog_playlist(int pos) {
        ArrayList<VideoInfo> atp_get_list1 = new ArrayList<>();
        String json1Null00 = gson.toJson(atp_get_list);
        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();

        atp_get_list1 = gson.fromJson(json00, type00);
        if (atp_get_list1.size() == 0) {
            atp_get_list1 = new ArrayList<>();
        }
        Dialog alertadd = new Dialog(this);
        View mView = LayoutInflater.from(this).inflate(R.layout.dialog_play_list, null);
        alertadd.setContentView(mView);
        alertadd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        RecyclerView atp_list_recycler = (RecyclerView) mView.findViewById(R.id.atp_list_recycler);
        ImageView atp_list_add_img = (ImageView) mView.findViewById(R.id.atp_list_add_img);
        ArrayList<VideoInfo> finalAtp_get_list = atp_get_list1;
        atp_list_add_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_atp_dialogue(atp_list_recycler, pos, alertadd, finalAtp_get_list);
                alertadd.dismiss();
            }
        });
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        atp_list_recycler.setLayoutManager(layoutManager);
        atp_list_adapter = new ADD_Play_List_Adapter(atp_get_list1, this, pos, search_list, alertadd, new Interface() {
            @Override
            public void image_List(int position) {

                maniVideoPlayerActivity.listalldataupdatefrg(search_list);

            }
        });
        atp_list_recycler.setAdapter(atp_list_adapter);

        alertadd.show();


    }

    private void open_atp_dialogue(RecyclerView atp_list_recycler, int pos, Dialog alertadd, ArrayList<VideoInfo> finalAtp_get_list) {
        final Dialog alert_creat = new Dialog(this);

        View mView = LayoutInflater.from(this).inflate(R.layout.creat_play_list, null);

        EditText playList_name_et = (EditText) mView.findViewById(R.id.edt_text_data);
        ImageView cancel_txt = (ImageView) mView.findViewById(R.id.img_dilog_cancel);
        ImageView add_txt = (ImageView) mView.findViewById(R.id.img_create);

        alert_creat.setContentView(mView);
        alert_creat.setCanceledOnTouchOutside(false);
        alert_creat.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        cancel_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alert_creat.dismiss();
            }
        });
        add_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> temp = new ArrayList<>();
                String name_list = playList_name_et.getText().toString().trim();
                if (name_list.length() == 0) {
                } else {
                    for (int i = 0; i < finalAtp_get_list.size(); i++) {
                        temp.add(finalAtp_get_list.get(i).getList_name());
                    }
                    if (!temp.contains(name_list)) {
                        finalAtp_get_list.add(0, new VideoInfo(name_list));
                    }
                    LinearLayoutManager layoutManager = new LinearLayoutManager(SerachAvtivity.this, LinearLayoutManager.HORIZONTAL, true);
                    atp_list_recycler.setLayoutManager(layoutManager);

                    atp_list_adapter = new ADD_Play_List_Adapter(finalAtp_get_list, SerachAvtivity.this, pos, search_list, alertadd, new Interface() {
                        @Override
                        public void image_List(int position) {

                            maniVideoPlayerActivity.listalldataupdatefrg(search_list);

                        }
                    });
                    atp_list_recycler.setAdapter(atp_list_adapter);
                    String json111 = gson.toJson(finalAtp_get_list);
                    preferenceUtil.putString(Constants.Add_play_List, json111);
                    alert_creat.dismiss();
                    open_dialog_playlist(pos);

                }
            }
        });

        alert_creat.show();
    }

    private void open_dialog_rename(int pos) {
        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }


        list_history.clear();
        String his_josn = preferenceUtil.getString(Constants.Video_history_List, null);
        Type type_his = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_history = gson.fromJson(his_josn, type_his);
        if (list_history == null) {
            list_history = new ArrayList<>();
        }

        renamepos = pos;

        Dialog dialogrename = new Dialog(this);
        dialogrename.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View vi2 = LayoutInflater.from(this).inflate(R.layout.dialog_rename, null);
        dialogrename.setContentView(vi2);
        dialogrename.setCancelable(false);

        ImageView img_dilog_cancel = vi2.findViewById(R.id.img_dilog_cancel);
        RelativeLayout img_rename = vi2.findViewById(R.id.img_rename);
        EditText edt_text_data = vi2.findViewById(R.id.edt_text_data);

        String video_old_name = search_list.get(pos).getmDisplayName();

        video_old_name = video_old_name.substring(0, video_old_name.lastIndexOf("."));
        edt_text_data.setText(video_old_name);

        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogrename.dismiss();
            }
        });
        img_rename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                renamepos = pos;
                newName = edt_text_data.getText().toString().trim();
                newName = newName.replace(".mp4", "");

                String aaaa = search_list.get(pos).getmPath();
                file_original = new File(aaaa);
                if (newName.isEmpty() || newName.trim().equals("")) {

                    edt_text_data.setError("Enter any Name!");

                } else {

                    boolean checkFileName = false;

                    for (int i = 0; i < search_list.size(); i++) {

                        if (search_list.get(i).getmDisplayName().replace(".mp4", "").equals(newName.trim().replace(" .mp4", ".mp4"))) {

                            checkFileName = true;

                        }
                    }

                    if (checkFileName) {


                        Toast.makeText(SerachAvtivity.this, "File Name Already Exists!", Toast.LENGTH_SHORT).show();

                        return;

                    } else {
                        edit_item_path = search_list.get(pos).getmPath();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            old_file_path = search_list.get(pos).getmPath();

                            ArrayList<Uri> uris = new ArrayList<>();

                            try {
                                contentUri = UtilsVideo.getUriFromVideoPath(SerachAvtivity.this, search_list.get(pos).getmPath());
                            } catch (Throwable throwable) {
                                throwable.printStackTrace();
                            }
                            if (contentUri != null) {
                                uris.add(contentUri);
                            }


                            if (uris.size() > 0) {

                                IntentSender intentSender;
                                if (Build.VERSION.SDK_INT >= 30) {
                                    PendingIntent pendingIntent = MediaStore.createWriteRequest(getContentResolver(), (Collection) uris);
                                    intentSender = pendingIntent.getIntentSender();
                                } else {
                                    intentSender = null;
                                }

                                if (intentSender != null) {

                                    intentSenderLauncherRename.launch((new IntentSenderRequest.Builder(intentSender)).build());
                                }
                            }

                        } else {
                            newName = newName + ".mp4";
                            File new_path = new File(new File(edit_item_path).getParentFile(), newName);
                            UtilsVideo.playlistdatarenama(SerachAvtivity.this, search_list.get(pos).getmPath(), new_path, newName);
                            UtilsVideo.renameFile(new_path, newName.trim().replace(" .mp4", ".mp4"), search_list.get(pos).getmDisplayName());
                            MediaScannerConnection.scanFile(SerachAvtivity.this, new String[]{file_original.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                public void onScanCompleted(String path, Uri uri) {
                                }
                            });

                            MediaScannerConnection.scanFile(SerachAvtivity.this, new String[]{new_path.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                public void onScanCompleted(String path, Uri uri) {
                                }
                            });

                            for (int i = 0; i < list_favo.size(); i++) {

                                if (list_favo.get(i).getmPath().equals(search_list.get(pos).getmPath())) {
                                    list_favo.get(i).setmDisplayName(newName);
                                    list_favo.get(i).setmPath(new_path.getAbsolutePath());
                                    break;
                                }
                            }

                            for (int a = 0; a < list_history.size(); a++) {
                                if (list_history.get(a).getmPath().equals(search_list.get(pos).getmPath())) {
                                    list_history.get(a).setmDisplayName(newName);
                                    list_history.get(a).setmPath(new_path.getAbsolutePath());
                                    break;
                                }
                            }

                            savelistfavo(list_favo);
                            savehistory(list_history);
                            search_list.get(pos).setmDisplayName(newName);
                            search_list.get(pos).setmPath(new_path.getAbsolutePath());
                         /*   list_filte.get(filtr_pos).setmDisplayName(newName);
                            list_filte.get(filtr_pos).setmPath(new_path.getAbsolutePath());*/
                            myAdaterSearch.filterList(list_filte);

                           /* if (serset == true) {*/
                                setAptpter(edit_text_set_search.getText().toString().trim());
                         /*   }else {
                                setAptpter(" " );
                            }*/
                            maniVideoPlayerActivity.new DataGAT().execute(MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                        }

                    }
                    dialogrename.dismiss();

                }
            }
        });


        dialogrename.show();
    }

    private void open_dialog_pro(int pos) {
        Dialog dialog1 = new Dialog(this);
        dialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View vi2 = LayoutInflater.from(this).inflate(R.layout.dialog_propertioes, null);
        dialog1.setContentView(vi2);
        dialog1.setCancelable(false);

        TextView video_info_title_txt = (TextView) dialog1.findViewById(R.id.video_info_title_txt);
        TextView video_info_location_txt = (TextView) dialog1.findViewById(R.id.video_info_location_txt);
        TextView video_info_size_txt = (TextView) dialog1.findViewById(R.id.video_info_size_txt);
        TextView video_info_format_txt = (TextView) dialog1.findViewById(R.id.video_info_format_txt);
        TextView video_info_duration_txt = (TextView) dialog1.findViewById(R.id.video_info_duration_txt);
        TextView video_info_resolution_txt = (TextView) dialog1.findViewById(R.id.video_info_resolution_txt);
        TextView video_info_date_txt = (TextView) dialog1.findViewById(R.id.video_info_date_txt);
        ImageView img_dilog_cancel = (ImageView) dialog1.findViewById(R.id.img_dilog_cancel);

        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog1.dismiss();
            }
        });

        video_info_title_txt.setSelected(true);
        video_info_location_txt.setSelected(true);
        video_info_title_txt.setText(search_list.get(pos).getmDisplayName());
        video_info_location_txt.setText(search_list.get(pos).getmPath());
        video_info_size_txt.setText(UtilsVideo.readableFileSize(search_list.get(pos).getmSize()));
        video_info_format_txt.setText(search_list.get(pos).getMimeType());
        video_info_duration_txt.setText(UtilsVideo.formateMilliSeccond(search_list.get(pos).getmDuration()));
        video_info_resolution_txt.setText(UtilsVideo.convertSolution(search_list.get(pos).getmResolution()));
        video_info_date_txt.setText(UtilsVideo.convertLongToTime(new File(search_list.get(pos).getmPath()).lastModified(), "dd-MM-yyyy"));


        dialog1.show();
    }

    private void setAptpter(String text) {


        if (text.trim().length() == 0) {
            img_close_search.setImageResource(R.drawable.vi_close_sear);
        } else {
            img_close_search.setImageResource(R.drawable.vi_close_txt_get);
        }

        ArrayList<VideoInfo> filteredlist = new ArrayList<>();

        for (VideoInfo item : search_list) {

            if (text != null) {
                if (item.getmDisplayName().toLowerCase().contains(text)) {
                    filteredlist.add(item);

                }
            }
        }
        recy_search_set.setVisibility(View.VISIBLE);
        myAdaterSearch.filterList(filteredlist);
        if (!filteredlist.isEmpty()) {
            recy_search_set.setVisibility(View.VISIBLE);
            img_no_data.setVisibility(View.GONE);

        } else {
            img_no_data.setVisibility(View.VISIBLE);
            recy_search_set.setVisibility(View.GONE);

        }

    }

    private void open_dialog_delete(int pos) {
        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }

        list_history.clear();
        String histo_josn = preferenceUtil.getString(Constants.Video_history_List, null);
        Type histo = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_history = gson.fromJson(histo_josn, histo);
        if (list_history == null) {
            list_history = new ArrayList<>();
        }

        Dialog dialogDelete = new Dialog(this);
        dialogDelete.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View vi2 = LayoutInflater.from(this).inflate(R.layout.dialog_delete, null);
        dialogDelete.setContentView(vi2);
        dialogDelete.setCancelable(false);

        ImageView img_dilog_cancel = dialogDelete.findViewById(R.id.img_dilog_cancel);
        ImageView img_delete = dialogDelete.findViewById(R.id.img_delete);
        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogDelete.dismiss();
            }
        });

        img_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                ArrayList<Uri> fichiers = new ArrayList<>();
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Long.valueOf(search_list.get(pos).getmId()));
                file_for_delete = new File(search_list.get(pos).getmPath());
                path_delete = file_for_delete.getAbsolutePath();
                delete_pos = pos;
                fichiers.add(contentUri);


                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {


                    PendingIntent demande = MediaStore.createDeleteRequest(getContentResolver(), fichiers);
                    try {
                        startIntentSenderForResult(demande.getIntentSender(), 1, new Intent(), 0, 0, 0);
                    } catch (IntentSender.SendIntentException e) {

                    }

                } else {
                    file_for_delete.delete();

                    UtilsVideo.updateplaylistdatadelete(SerachAvtivity.this, file_for_delete.getAbsolutePath());
                    search_list.remove(pos);
                   /* list_filte.remove(filtr_pos);*/

                    myAdaterSearch.filterList(list_filte);

                    /*if (myAdaterSearch.getItemCount() == 0) {
                        text_no_data.setVisibility(View.VISIBLE);
                        recy_search_set.setVisibility(View.GONE);
                    } else {
                        text_no_data.setVisibility(View.GONE);
                        recy_search_set.setVisibility(View.GONE);
                    }

                    if (myAdaterSearch.getItemCount() == 0) {
                        text_no_data.setVisibility(View.VISIBLE);
                        recy_search_set.setVisibility(View.GONE);
                    } else {
                        text_no_data.setVisibility(View.GONE);
                        recy_search_set.setVisibility(View.GONE);
                    }*/
                    for (int i = 0; i < list_favo.size(); i++) {

                        if (list_favo.get(i).getmPath().equals(search_list.get(pos).getmPath())) {
                            list_favo.remove(i);
                            break;
                        }
                    }
                    for (int i = 0; i < list_history.size(); i++) {

                        if (list_history.get(i).getmPath().equals(search_list.get(pos).getmPath())) {
                            list_history.remove(i);
                            break;
                        }
                    }
                    if (serset == true) {
                        setAptpter(edit_text_set_search.getText().toString().trim());
                    }

                    savelistfavo(list_favo);
                    savehistory(list_history);
                    maniVideoPlayerActivity.new DataGAT().execute(MediaStore.Video.Media.EXTERNAL_CONTENT_URI);

                    MediaScannerConnection.scanFile(SerachAvtivity.this, new String[]{file_for_delete.getAbsolutePath()}, new String[]{"video/*"}, new MediaScannerConnection.MediaScannerConnectionClient() {
                        public void onMediaScannerConnected() {
                        }

                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });

                    Toast.makeText(SerachAvtivity.this, "Video Deleted!", Toast.LENGTH_SHORT).show();

                }

                dialogDelete.dismiss();
            }
        });

        dialogDelete.show();


    }

    private void savehistory(ArrayList<VideoInfo> list_history) {
        String json = gson.toJson(list_history);
        preferenceUtil.putString(Constants.Video_history_List, json);
    }

    private void savelistfavo(ArrayList<VideoInfo> list_favo) {
        gson = new Gson();
        String json = gson.toJson(list_favo);
        preferenceUtil.putString(Constants.Video_favo_List, json);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == 1 && resultCode == RESULT_OK) {

            MediaScannerConnection.scanFile(SerachAvtivity.this, new String[]{path_delete}, new String[]{"video/*"}, new MediaScannerConnection.MediaScannerConnectionClient() {
                public void onMediaScannerConnected() {
                }

                public void onScanCompleted(String path, Uri uri) {
                }
            });
            list_favo.clear();
            String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
            Type type = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_favo = gson.fromJson(fove_josn, type);
            if (list_favo == null) {
                list_favo = new ArrayList<>();
            }
            for (int i = 0; i < list_favo.size(); i++) {

                if (list_favo.get(i).getmPath().equals(path_delete)) {
                    list_favo.remove(i);
                    break;
                }
            }
            list_history.clear();
            String hist_josn = preferenceUtil.getString(Constants.Video_history_List, null);
            Type hist = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_history = gson.fromJson(hist_josn, hist);
            if (list_history == null) {
                list_history = new ArrayList<>();
            }

            for (int i = 0; i < list_history.size(); i++) {

                if (list_history.get(i).getmPath().equals(path_delete)) {
                    list_history.remove(i);
                    break;
                }
            }
            for (int i = 0; i < search_list.size(); i++) {
                if (search_list.get(i).getmPath().equals(search_list.get(delete_pos).getmPath())) {
                    search_list.remove(i);
                }
            }

            savehistory(list_history);
            savelistfavo(list_favo);
            UtilsVideo.updateplaylistdatadelete(this, path_delete);

           /* list_filte.remove(filtr_pos);*/
            myAdaterSearch.filterList(list_filte);
            maniVideoPlayerActivity.new DataGAT().execute(MediaStore.Video.Media.EXTERNAL_CONTENT_URI);

        /*    if (serset == true) {*/

                setAptpter(edit_text_set_search.getText().toString().trim());
           /* }else {
                setAptpter(" "  );
            }*/

        }
    }

    public final ActivityResultLauncher<IntentSenderRequest> intentSenderLauncherRename = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {

            if (Build.VERSION.SDK_INT >= 30) {

                newName = newName + ".mp4";

                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                    getContentResolver().update(UtilsVideo.getUriFromVideoPath(this, old_file_path), contentValues, null);
                }
                MediaScannerConnection.scanFile(SerachAvtivity.this, new String[]{search_list.get(renamepos).getmPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });


                File new_path = new File(new File(edit_item_path).getParentFile(), newName);

                MediaScannerConnection.scanFile(SerachAvtivity.this, new String[]{new_path.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {

                    }
                });
                for (int i = 0; i < list_favo.size(); i++) {

                    if (list_favo.get(i).getmPath().equals(edit_item_path)) {
                        list_favo.get(i).setmDisplayName(newName);
                        list_favo.get(i).setmPath(new_path.getAbsolutePath());
                        break;
                    }
                }

                for (int a = 0; a < list_history.size(); a++) {
                    if (list_history.get(a).getmPath().equals(search_list.get(renamepos).getmPath())) {
                        list_history.get(a).setmDisplayName(newName);
                        list_history.get(a).setmPath(new_path.getAbsolutePath());
                        break;
                    }
                }

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        UtilsVideo.playlistdatarenama(SerachAvtivity.this, edit_item_path, new_path, newName);
                        savelistfavo(list_favo);
                        savehistory(list_history);
                        VideoInfo video_model = search_list.get(renamepos);
                        video_model.setmDisplayName(newName);
                        video_model.setmPath(new_path.getAbsolutePath());
                       /* list_filte.get(filtr_pos).setmDisplayName(newName);
                        list_filte.get(filtr_pos).setmPath(new_path.getAbsolutePath());*/
                    /*    if (!list_filte.isEmpty()) {*/
                            myAdaterSearch.filterList(list_filte);
                      /*  }*/
                      /*  if (serset == true) {*/
                            setAptpter(edit_text_set_search.getText().toString().trim());
                      /*  }else {
                            setAptpter(" "  );
                        }*/
                        maniVideoPlayerActivity.new DataGAT().execute(MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                    }
                }, 100);
            }

        }
    });

    public boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

}