package com.si_videoplayer.gautm_videoplayer.Activity;


import static com.google.android.exoplayer2.upstream.cache.CacheDataSink.DEFAULT_BUFFER_SIZE;
import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.maniVideoPlayerActivity;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.audioFocus;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.media.AudioManager;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarChangeListener;
import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;


import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.PlayerView;
import com.si_videoplayer.gautm_videoplayer.R;

import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;


import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;

public class VideoCutActivity extends AppCompatActivity {


    ImageView img_back_btn_cut;
    TextView text_video_name;
    private PlayerView playerView;
    private ExoPlayer player;
    String path_get = null;
    ImageView playpausebutton;
    CrystalRangeSeekbar rangeSeekbar2;
    TextView text_rgirt, text_laft;
    private Handler handler;
    private Runnable hiderunnable;
    private boolean video_end = false;
    ImageView img_cut_set;
    long start_du = 0;
    long end_du = 0;
    String name = null;
    boolean isVideoCutRunning = false;
    String setpath;


    public static VideoCutActivity context;
    private Dialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_cut);

        context = this;

        path_get = getIntent().getStringExtra("video_path_send");
        name = getIntent().getStringExtra("video_name_send");

        FrameLayout banner = findViewById(R.id.banner);
        GoviddecgtmAs.getInstance().ShowBanner(VideoCutActivity.this, banner);

        img_back_btn_cut = findViewById(R.id.img_back_btn_cut);
        text_video_name = findViewById(R.id.text_video_name);
        player = new ExoPlayer.Builder(this).build();
        playerView = findViewById(R.id.player_at);
        playerView.setPlayer(player);
        playpausebutton = findViewById(R.id.playpausebutton);

        text_laft = findViewById(R.id.text_laft);
        text_rgirt = findViewById(R.id.text_rgirt);
        rangeSeekbar2 = (CrystalRangeSeekbar) findViewById(R.id.rangeSeekbar2);
        img_cut_set = findViewById(R.id.img_btn_cutvideo);


        instlizevideo(path_get);
        rangeSeekbar2.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
            @Override
            public void valueChanged(Number minValue, Number maxValue) {
                player.pause();
                video_end = false;
                player.seekTo((Long) minValue);
                start_du = (long) minValue;
                end_du = (long) maxValue;
                text_rgirt.setText(UtilsVideo.formateMilliSeccond((Long) maxValue));
                text_laft.setText(UtilsVideo.formateMilliSeccond((Long) minValue));
            }
        });

        img_back_btn_cut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        text_video_name.setText(name);
        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (isPlaying) {
                    playpausebutton.setImageResource(R.drawable.vi_pause_view_cut);

                } else {
                    playpausebutton.setImageResource(R.drawable.vi_play_view_cut);


                }
            }
        });

        handler = new Handler();
        hiderunnable = new Runnable() {
            @Override
            public void run() {
                if ((long) player.getCurrentPosition() >= (long) rangeSeekbar2.getSelectedMaxValue()) {

                    if (player.isPlaying()) {
                        player.pause();
                        video_end = true;
                        handler.removeCallbacks(hiderunnable);
                    }
                }
                handler.postDelayed(hiderunnable, 1000);
            }
        };


        playpausebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (audioFocus(VideoCutActivity.this)) {
                    if (player.isPlaying()) {
                        player.pause();

                    } else {

                        player.play();
                        handler.postDelayed(hiderunnable, 1000);
                        if (video_end == true) {
                            player.seekTo((Long) rangeSeekbar2.getSelectedMinValue());
                        }
                        video_end = false;
                    }


                }
            }
        });
        img_cut_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!isVideoCutRunning) {
                    isVideoCutRunning = true;

                    if (player.isPlaying()) {
                        player.pause();
                        video_end = false;
                    }
                    File file = new File(path_get);
                    String path1 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/Video Cut";
                    File dir = new File(path1);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }

                    setpath = path1 + "/Cut_" + System.currentTimeMillis() + name;

                    new DataCut(setpath, path_get, start_du, end_du).execute();

                }
            }
        });


    }

    private void instlizevideo(String path_get) {
        Uri uri = Uri.parse(path_get);
        MediaItem mediaItem = MediaItem.fromUri(uri);
        player.setMediaItem(mediaItem, 0);
        player.prepare();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                video_end = false;
                rangeSeekbar2.setMaxValue((int) player.getDuration());
                rangeSeekbar2.setMinValue(0);
                rangeSeekbar2.setMinStartValue(10);
                text_rgirt.setText(UtilsVideo.formateMilliSeccond(player.getDuration()));
                text_laft.setText("00:00");
            }
        }, 1000);


    }

    @Override
    protected void onPause() {
        super.onPause();
        pausePlayer();

    }

    private void pausePlayer() {
        if (player == null) return;
        player.setPlayWhenReady(false);
        player.getPlaybackState();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.stop();
            player.setPlayWhenReady(false);
            player.release();
        }
    }


    public AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {

                    switch (focusChange) {

                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK):
                            if (player != null && player.isPlaying()) {
                                player.pause();

                            }
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT):
                            if (player != null && player.isPlaying()) {
                                player.pause();


                            }
                            break;

                        case (AudioManager.AUDIOFOCUS_LOSS):
                            if (player != null && player.isPlaying()) {
                                player.pause();
                            }


                            break;

                        case (AudioManager.AUDIOFOCUS_GAIN):

                            break;
                        default:
                            break;
                    }
                }
            };

    @SuppressLint({"NewApi", "WrongConstant"})
    public void genVideoUsingMuxer(String srcPath, String dstPath, long startMs, long endMs, boolean useAudio, boolean useVideo) throws IOException {
        MediaExtractor extractor = new MediaExtractor();
        extractor.setDataSource(srcPath);
        int trackCount = extractor.getTrackCount();
        MediaMuxer muxer = new MediaMuxer(dstPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        HashMap<Integer, Integer> indexMap = new HashMap<Integer, Integer>(trackCount);
        int bufferSize = -1;


        for (int i = 0; i < trackCount; i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            int videoTrack = -1;
            boolean selectCurrentTrack = false;
            if (mime.startsWith("audio/") && useAudio) {

                selectCurrentTrack = true;
                videoTrack = i;

            } else if (mime.startsWith("video/") && useVideo) {
                selectCurrentTrack = true;
                videoTrack = i;
            }

            if (selectCurrentTrack) {

                extractor.selectTrack(videoTrack);
                int dstIndex = muxer.addTrack(format);
                indexMap.put(videoTrack, dstIndex);
                if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    int newSize = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE);
                    bufferSize = newSize > bufferSize ? newSize : bufferSize;
                }
            }

        }

        if (bufferSize < 0) {
            bufferSize = DEFAULT_BUFFER_SIZE;
        }
        MediaMetadataRetriever retrieverSrc = new MediaMetadataRetriever();
        retrieverSrc.setDataSource(srcPath);
        String degreesString = retrieverSrc.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
        if (degreesString != null) {
            int degrees = Integer.parseInt(degreesString);
            if (degrees >= 0) {
                muxer.setOrientationHint(degrees);
            }
        }
        if (startMs > 0) {
            extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
        }

        int offset = 0;
        int trackIndex = -1;
        ByteBuffer dstBuf = ByteBuffer.allocate(bufferSize);

        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
        muxer.start();

        while (true) {
            bufferInfo.offset = offset;
            bufferInfo.size = extractor.readSampleData(dstBuf, offset);
            bufferInfo.presentationTimeUs = extractor.getSampleTime();

            if (bufferInfo.size < 0) {

                bufferInfo.size = 0;
                break;
            } else {

                if (endMs > 0 && bufferInfo.presentationTimeUs > (endMs * 1000)) {

                    break;
                } else {
                    bufferInfo.flags = extractor.getSampleFlags();
                    trackIndex = extractor.getSampleTrackIndex();

                    muxer.writeSampleData(indexMap.get(trackIndex), dstBuf, bufferInfo);
                    extractor.advance();
                }
            }
        }
        muxer.stop();
        muxer.release();
        MediaScannerConnection.scanFile(context, new String[]{dstPath}, null, new MediaScannerConnection.OnScanCompletedListener() {
            public void onScanCompleted(String path, Uri uri) {

            }
        });
        Toast.makeText(context, "" + dstPath, Toast.LENGTH_SHORT).show();
        return;
    }

    class DataCut extends AsyncTask<Boolean, Boolean, Boolean> {

        String destPath;
        String currentSrcPath;
        long start;
        long end;

        public DataCut(String destPath, String currentSrcPath, long start, long end) {

            this.destPath = destPath;
            this.currentSrcPath = currentSrcPath;
            this.start = start;
            this.end = end;
            dialog = new Dialog(context);
        }

        @Override
        protected Boolean doInBackground(Boolean... booleans) {

            try {
                genVideoUsingMuxer(currentSrcPath, destPath, start, end, true, true);

            } catch (Exception e) {
            }

            return false;
        }

        @Override
        protected void onPostExecute(Boolean isSuccess) {
            super.onPostExecute(isSuccess);
            MediaScannerConnection.scanFile(VideoCutActivity.this, new String[]{destPath}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {

                    Uri uri1 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    maniVideoPlayerActivity.new DataGAT().execute(uri1);
                }
            });
            isVideoCutRunning = false;
            if (dialog != null) {
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
            }

            opendilodset(destPath);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            dialog.setCancelable(false);
            View loading_view = LayoutInflater.from(context).inflate(R.layout.open_set_mp3, null);
            dialog.setContentView(loading_view);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.show();

        }
    }

    private void opendilodset(String destPath) {
        Dialog dialog1 = new Dialog(context);
        dialog1.setCancelable(true);
        View loading_view = LayoutInflater.from(context).inflate(R.layout.dilog_file_show, null);
        dialog1.setContentView(loading_view);
        dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        TextView path_text_set = dialog1.findViewById(R.id.path_text_set);
        path_text_set.setText("Path : " + destPath);
        dialog1.show();
    }
}