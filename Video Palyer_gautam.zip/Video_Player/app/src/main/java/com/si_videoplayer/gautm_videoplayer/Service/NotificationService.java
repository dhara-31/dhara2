package com.si_videoplayer.gautm_videoplayer.Service;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.view.View;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;

import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.bottom_play_linear;
import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.mProgressBar;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.*;
import static com.si_videoplayer.gautm_videoplayer.Service.BackgroundPlayServer.mediaSession;


import com.si_videoplayer.gautm_videoplayer.Activity.VideoShowActivity;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.NotificationDismissedReceiver;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;

public class NotificationService extends Service implements AudioManager.OnAudioFocusChangeListener {

    public static final String CHANNEL_ID = "ServiceChannel";

    public static NotificationManager notificationManager;
    public static boolean songIsPlaying = true;
    public static NotificationService foregroundService = null;
    public Binder musicBind;
    NotificationManager manager;
    Notification notification;
    PreferenceUtil preferenceUtil;
    private AudioManager audioManager;

    public void stopNotification() {
        getApplicationContext().stopService(new Intent(getApplicationContext(),VideoPlayServer.class));
        try {
            if (mediaPlayer!=null){
                mediaPlayer.stop();
            }
            stopSelf();
            if (bottom_play_linear != null) {
                bottom_play_linear.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (notificationManager != null) {
                notificationManager.cancelAll();
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        foregroundService = this;
        return musicBind;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        musicBind = new MusicBinder();
        preferenceUtil = new PreferenceUtil(this);


    }

    @Override
    public boolean onUnbind(Intent intent) {
        return false;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        foregroundService = this;

        try {
            switch (intent.getAction()) {
                case ACTION.STARTFOREGROUND_ACTION:
                    showNotification();
                    break;
                case ACTION.STOPFOREGROUND_ACTION:

                    break;
                case "START_ACTIVITY":
                    updateNotificationBigView("START_ACTIVITY");
                    break;
                case ACTION.PAUSE_ACTION:
                    updateNotificationBigView("Pause");
                    break;
                case ACTION.PREV_ACTION:
                    updateNotificationBigView("Pre");
                    break;
                case ACTION.PLAY_ACTION:
                    updateNotificationBigView("Play");
                    break;
                case ACTION.NEXT_ACTION:
                    updateNotificationBigView("Next");
                    break;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return START_NOT_STICKY;
    }

    public void audioFocus() {
        try {
            int result = audioManager.requestAudioFocus(NotificationService.this, AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN);
        } catch (Exception e) {

        }

    }

    private void updateNotificationBigView(String next_pre) {
        try {
            audioManager.requestAudioFocus(NotificationService.this,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN);
        } catch (Exception e) {

        }


        switch (next_pre) {
            case "Next": {
                try {
                    NextBackgroundVideo(foregroundService);

                } catch (Exception e) {

                }

                break;
            }
            case "Pre": {

                try {
                    PreviousBackgroundVideo(foregroundService);

                } catch (Exception e) {

                }

                break;
            }
            case "Pause": {

                PauseBackgroundVideo(foregroundService);

                break;
            }
            case "Play": {

                PlayBackgroundVideo(foregroundService);

                break;
            }
        }
    }

    int plying;
    public void showNotification() {

        try {
            long when = System.currentTimeMillis();

            try {
                if (!isMyServiceRunning(foregroundService, BackgroundPlayServer.class)) {
                    startService(new Intent(this, BackgroundPlayServer.class));
                //  MediaPlayer  mediaPlayer= MediaPlayer.create(getApplicationContext(), R.raw.silent_sound);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            VideoShowActivity.list_data=new ArrayList<>();
            VideoShowActivity.list_data.addAll(backGroundPlayingList);
            createNotificationChannel();
            Intent intent;
            intent = new Intent(this, VideoShowActivity.class);

            TaskStackBuilder stackBuilder = TaskStackBuilder.create(foregroundService);
            stackBuilder.addNextIntentWithParentStack(intent);
            play_pause=true;
            PendingIntent pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);


            Intent nextIntent = new Intent(this, NotificationService.class);
            nextIntent.setAction(ACTION.NEXT_ACTION);
            PendingIntent NextIntent = PendingIntent.getService(this, 0, nextIntent, (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ? PendingIntent.FLAG_MUTABLE : 0);

            Intent previousIntent = new Intent(this, NotificationService.class);
            previousIntent.setAction(ACTION.PREV_ACTION);
            PendingIntent previousPendingIntent = PendingIntent.getService(this, 0, previousIntent, (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ? PendingIntent.FLAG_MUTABLE : 0);

            Intent MoreIntent = new Intent(this, NotificationService.class);
            MoreIntent.setAction(ACTION.PAUSE_ACTION);
            PendingIntent more_Intent = PendingIntent.getService(this, 0, MoreIntent, (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ? PendingIntent.FLAG_MUTABLE : 0);

            Intent LessIntent = new Intent(this, NotificationService.class);
            LessIntent.setAction(ACTION.PLAY_ACTION);
            PendingIntent less_Intent = PendingIntent.getService(this, 0, LessIntent, (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ? PendingIntent.FLAG_MUTABLE : 0);

            Intent intent_slide = new Intent(this, NotificationDismissedReceiver.class);
            intent_slide.putExtra("notificationId", NOTIFICATION_ID.FOREGROUND_SERVICE);
            PendingIntent pendingIntent_slide = PendingIntent.getBroadcast(this.getApplicationContext(), 0, intent_slide, (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) ? PendingIntent.FLAG_MUTABLE : 0);

            String musicTitle, musicArtist;

            mediaSession.setMetadata(new MediaMetadataCompat.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, backGroundPlayingList.get(backgroundPosition).getmDisplayName())
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, backGroundPlayingList.get(backgroundPosition).getArtist())
                    .putLong(MediaMetadataCompat.METADATA_KEY_DURATION,mediaPlayer.getDuration())
                    .build());
            musicTitle = backGroundPlayingList.get(backgroundPosition).getmDisplayName();
            musicArtist = backGroundPlayingList.get(backgroundPosition).getArtist();

            int play;
            PendingIntent play_intent;


            if (!mediaPlayer.isPlaying()) {
                play = R.drawable.play;
                play_intent = less_Intent;
            } else {
                play = R.drawable.pause;
                play_intent = more_Intent;
            }


            if (songIsPlaying) {
                plying = PlaybackStateCompat.STATE_PLAYING;
            } else {
                plying = PlaybackStateCompat.STATE_PAUSED;
            }

            mediaSession.setPlaybackState(
                    new PlaybackStateCompat.Builder()
                            .setState(plying, mediaPlayer.getCurrentPosition(), 1.0f)
                            .setActions(PlaybackStateCompat.ACTION_PLAY |
                                    PlaybackStateCompat.ACTION_PAUSE |
                                    PlaybackStateCompat.ACTION_SKIP_TO_NEXT |
                                    PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS |
                                    PlaybackStateCompat.ACTION_SEEK_TO)
                            .build());


            mediaSession.setCallback(new MediaSessionCompat.Callback() {

                @Override
                public void onSeekTo(long pos) {
                    super.onSeekTo(pos);
                    if (mediaPlayer!=null){
                        mediaPlayer.seekTo((int) pos);
                    }
                    if (mProgressBar!=null){
                        mProgressBar.setProgress(mediaPlayer.getCurrentPosition());
                    }
                    if (songIsPlaying) {
                        plying = PlaybackStateCompat.STATE_PLAYING;
                    } else {
                        plying = PlaybackStateCompat.STATE_PAUSED;
                    }

                    mediaSession.setPlaybackState(new PlaybackStateCompat.Builder().setState(plying, mediaPlayer.getCurrentPosition(), 1.0f)
                            .setActions(PlaybackStateCompat.ACTION_SEEK_TO)
                                    .build()
                    );


                }

                @Override
                public void onPause() {
                    super.onPause();
                    PauseBackgroundVideo(foregroundService);
                }


                @Override
                public boolean onMediaButtonEvent(Intent mediaButtonEvent) {



                    return super.onMediaButtonEvent(mediaButtonEvent);

                }

                @Override
                public void onPlay() {
                    super.onPlay();
                   PlayBackgroundVideo(foregroundService);
                }
            });


            notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle(musicTitle)
                    .setContentText(musicArtist)
                    .setLargeIcon(UtilsVideo.getVideoFrame(backGroundPlayingList.get(backgroundPosition).getmPath(), 1000))
                    .setSmallIcon(R.drawable.vi_logo_round_start)
                    .setDeleteIntent(pendingIntent_slide)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(false)
                    .setPriority(Notification.PRIORITY_MAX)
                    .addAction(R.drawable.app_previous, "Previous", previousPendingIntent)
                    .addAction(play, "Play", play_intent)
                    .addAction(R.drawable.next, "Next", NextIntent)
                    .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                            .setShowActionsInCompactView(0, 1, 2)
                            .setMediaSession(mediaSession.getSessionToken()))
                    .setWhen(when)
                    .setNotificationSilent()
                    .build();


            if (notificationManager == null) {
                notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            }

            if (mediaPlayer.isPlaying()) {
                startForeground(NOTIFICATION_ID.FOREGROUND_SERVICE, notification);
            } else {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mediaPlayer.isPlaying()) {
                            startForeground(NOTIFICATION_ID.FOREGROUND_SERVICE, notification);
                        } else {
                            stopSelf();
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    notificationManager.notify(NOTIFICATION_ID.FOREGROUND_SERVICE, notification);
                                }
                            }, 500);
                        }
                    }
                }, 1000);

            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }




    private void createNotificationChannel() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                if (manager == null) {
                    NotificationChannel serviceChannel = new NotificationChannel(
                            CHANNEL_ID, "Foreground Service Channel",   NotificationManager.IMPORTANCE_DEFAULT
                    );
                    manager = getSystemService(NotificationManager.class);
                    manager.createNotificationChannel(serviceChannel);

                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        try {
            if (mediaPlayer != null) {
                if (!mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                    mediaPlayer.release();


                    try {
                        stopSelf();
                    } catch (Exception e) {

                        e.printStackTrace();
                    }
                    try {
                        if (notificationManager != null) {
                            notificationManager.cancelAll();

                        }
                    } catch (Exception e) {

                        e.printStackTrace();
                    }


                }
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getApplicationContext().startService(new Intent(getApplicationContext(), BackgroundPlayServer.class));
    }

    @Override
    public void onAudioFocusChange(int i) {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {

                    PauseBackgroundVideo(foregroundService);
                    songIsPlaying = false;
                    showNotification();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class MusicBinder extends Binder {
        public NotificationService getService() {
            return NotificationService.this;
        }
    }
}
