package com.si_videoplayer.gautm_videoplayer.Activity;

import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.list_noti;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.remoteMediaClient;
import static com.si_videoplayer.gautm_videoplayer.Castutils.Utils.mCastSession;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.datatransport.BuildConfig;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaTrack;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.CastStateListener;
import com.google.android.gms.cast.framework.IntroductoryOverlay;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.common.images.WebImage;
import com.si_videoplayer.gautm_videoplayer.Adapter.MyAdapterlist;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import com.si_videoplayer.gautm_videoplayer.Castutils.Utils;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;


import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

public class CastvideoActivity extends AppCompatActivity {

    ImageView btnPause, img_an_set_munt, btnPlay, img_back_set, img_load_set_video, video_next, video_previous, img_mune;
    @org.jetbrains.annotations.Nullable
    private static String deviceIpAddress;
    private IntroductoryOverlay mIntroductoryOverlay;
    SeekBar seekBar;
    TextView text_title_tool;
    RelativeLayout relative_list;
    ConstraintLayout recy_volum_view;
    TextView txt_volume;
    SeekBar seek_volume;


    @NotNull
    public static final Companion Companion = new Companion(null);
    private Handler handler;
    Runnable runnable;
    RecyclerView recy_cast_list;
    private MyAdapterlist myAdapterlist;
    private PreferenceUtil preferenceUtil;
    public int cast_pot = 0;
    Handler handler_seek_vol;
    Runnable runnable_seel_vol;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_castvideo);

        Constants.activityset = this;
        preferenceUtil = new PreferenceUtil(this);


        FrameLayout banner = findViewById(R.id.banner);
        GoviddecgtmAs.getInstance().ShowBanner(CastvideoActivity.this, banner);


        cast_pot = preferenceUtil.getInt(Constants.Current_Position, 0);
        btnPause = findViewById(R.id.btnPause);
        btnPlay = findViewById(R.id.btnPlay);
        img_back_set = findViewById(R.id.img_back_set);
        seekBar = findViewById(R.id.videoSeek);
        img_an_set_munt = findViewById(R.id.img_an_set_munt);
        text_title_tool = findViewById(R.id.text_title_tool);
        img_load_set_video = findViewById(R.id.img_load_set_video);
        video_next = findViewById(R.id.video_next);
        video_previous = findViewById(R.id.video_previous);
        img_mune = findViewById(R.id.img_mune);
        relative_list = findViewById(R.id.relative_list);
        recy_cast_list = findViewById(R.id.recy_cast_list);


        recy_volum_view = findViewById(R.id.recy_volum_view);
        txt_volume = findViewById(R.id.txt_volume);
        seek_volume = findViewById(R.id.seek_volume);

        handler_seek_vol = new Handler();
        runnable_seel_vol = new Runnable() {
            @Override
            public void run() {
                recy_volum_view.setVisibility(View.GONE);
            }
        };


        img_back_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        img_mune.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recy_volum_view.setVisibility(View.GONE);
                if (relative_list.getVisibility() == View.GONE) {
                    relative_list.setVisibility(View.VISIBLE);
                    setlistdata(cast_pot);
                }
            }
        });
        relative_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relative_list.setVisibility(View.GONE);
            }
        });

        //SimpleWebServer.init(this, BuildConfig.DEBUG);
        Utils.Companion.setUpCastListener(this);
        Constants.mCastContext = CastContext.getSharedInstance(this);
        Constants.mCastContext.addCastStateListener(new CastStateListener() {
            @Override
            public final void onCastStateChanged(int state) {
                if (state != 1) {
                    showIntroductoryOverlay();
                }
            }
        });
        CastContext castContext = Constants.mCastContext;
        castContext.getSessionManager().addSessionManagerListener(Utils.Companion.getMSessionManagerListener(), CastSession.class);

        video_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (cast_pot + 1 < Constants.list_noti.size()) {
                    cast_pot++;
                    playVideo();
                }

            }
        });
        video_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cast_pot - 1 >= 0) {
                    cast_pot--;
                    playVideo();

                }
            }
        });

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Utils.Companion.getRemoteMediaClient() != null) {

                    RemoteMediaClient remoteMediaClient = Utils.Companion.getRemoteMediaClient();

                    if (remoteMediaClient == null) {
                        Intrinsics.throwNpe();
                    }

                    btnPlay.setVisibility(View.GONE);
                    btnPause.setVisibility(View.VISIBLE);

                    if (remoteMediaClient.getMediaInfo() == null) {
                        playVideo();
                        return;
                    }

                    Integer valueOf = remoteMediaClient != null ? Integer.valueOf((int) remoteMediaClient.getApproximateStreamPosition()) : null;
                    if (valueOf == null) {
                        Intrinsics.throwNpe();
                    }
                    if (valueOf.intValue() == 0) {
                        playVideo();
                        return;
                    }
                    RemoteMediaClient remoteMediaClient3 = Utils.Companion.getRemoteMediaClient();
                    if (remoteMediaClient3 == null) {
                        Intrinsics.throwNpe();
                    }
                    remoteMediaClient3.play();


                    return;
                }

            }
        });

        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnPlay.setVisibility(View.VISIBLE);
                btnPause.setVisibility(View.GONE);
                if (Utils.Companion.getRemoteMediaClient() != null) {
                    RemoteMediaClient remoteMediaClient = Utils.Companion.getRemoteMediaClient();

                    if (remoteMediaClient == null) {
                        Intrinsics.throwNpe();
                    }
                    remoteMediaClient.pause();

                    return;
                }
            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    RemoteMediaClient remoteMediaClient2 = Utils.Companion.getMCastSession().getRemoteMediaClient();
                    if (remoteMediaClient2 != null) {
                        remoteMediaClient2.seek(progress);

                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                handler_seek_vol.postDelayed(runnable_seel_vol, 2000);
            }
        });
        if (mCastSession != null) {
            int aa = (int) (mCastSession.getVolume() * 100);
            if (aa == 0) {
                img_an_set_munt.setImageResource(R.drawable.vi_vol_muat);
            } else {
                img_an_set_munt.setImageResource(R.drawable.vi_an_mute_vol);
            }
        }


        img_an_set_munt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (recy_volum_view.getVisibility() == View.GONE) {
                    recy_volum_view.setVisibility(View.VISIBLE);
                    int aa = (int) (mCastSession.getVolume() * 100);

                    seek_volume.setMax(100);
                    seek_volume.setProgress(aa);
                    txt_volume.setText(aa + "");

                } else {
                    recy_volum_view.setVisibility(View.GONE);
                }
            }
        });

        seek_volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txt_volume.setText(i + "");
                double d = Double.parseDouble(String.valueOf(i));
                double aa = d / 100;
                try {
                    mCastSession.setVolume(aa);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (i == 0) {
                    img_an_set_munt.setImageResource(R.drawable.vi_vol_muat);
                } else {
                    img_an_set_munt.setImageResource(R.drawable.vi_an_mute_vol);
                }


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {


            }
        });
        playVideo();


    }

    private void setlistdata(int cast_pot) {
        recy_cast_list.setLayoutManager(new LinearLayoutManager(this));
        myAdapterlist = new MyAdapterlist(CastvideoActivity.this, Constants.list_noti, cast_pot, this::onclickBottom);
        recy_cast_list.scrollToPosition(cast_pot);
        recy_cast_list.setAdapter(myAdapterlist);
    }

    private void onclickBottom(int i, TextView textView) {
        cast_pot = i;
        textView.setTextColor(Color.BLUE);
        myAdapterlist.update(i);
        playVideo();
    }

    private void startHandelForSeek() {
        seekBar.setMax(Integer.parseInt(String.valueOf(Constants.list_noti.get(cast_pot).getmDuration())));
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {


                RemoteMediaClient remoteMediaClient2 = Utils.Companion.getMCastSession().getRemoteMediaClient();
                if (remoteMediaClient2 != null) {


                    if (remoteMediaClient2.isPlaying()) {

                        btnPlay.setVisibility(View.GONE);
                        btnPause.setVisibility(View.VISIBLE);

                    } else {
                        btnPlay.setVisibility(View.VISIBLE);
                        btnPause.setVisibility(View.GONE);
                    }

                    seekBar.setProgress((int) remoteMediaClient2.getApproximateStreamPosition());
                    if (remoteMediaClient2.getApproximateStreamPosition() >= 1) {
                        if (remoteMediaClient2.getApproximateStreamPosition() + 1500 >= remoteMediaClient2.getStreamDuration()) {
                            video_next.performClick();
                        }
                    }

                }


                handler.postDelayed(runnable, 1000);

            }
        };
        handler.postDelayed(runnable, 1000);

    }

    public final void showIntroductoryOverlay() {
        IntroductoryOverlay introductoryOverlay = this.mIntroductoryOverlay;
        if (introductoryOverlay != null) {
            introductoryOverlay.remove();
        }

    }

    public static final class Companion {
        @org.jetbrains.annotations.Nullable
        public final String getDeviceIpAddress() {
            return deviceIpAddress;
        }

        public final void setDeviceIpAddress(@org.jetbrains.annotations.Nullable String var1) {
            deviceIpAddress = var1;
        }

        private Companion() {
        }


        public Companion(DefaultConstructorMarker constructor_marker) {
            this();
        }
    }

    public final void playVideo() {
        if (Build.VERSION.SDK_INT >= 23 && this.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            this.requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 112);
        } else {

            Context var10001 = this.getApplicationContext();
            Intrinsics.checkExpressionValueIsNotNull(var10001, "applicationContext");
            deviceIpAddress = Utils.findIPAddress(getApplicationContext());
            if (deviceIpAddress == null) {
                Toast.makeText(this.getApplicationContext(), (CharSequence) "Connect to a wifi device or hotspot", Toast.LENGTH_LONG).show();
            } else {
              //  this.startService(new Intent((Context) this, WebService.class));
                RemoteMediaClient remoteMediaClientc = Utils.Companion.getRemoteMediaClient();
                if ((remoteMediaClientc != null ? remoteMediaClientc.getMediaInfo() : null) == null) {
                    Utils.Companion companion2 = Utils.Companion;
                    RemoteMediaClient remoteMediaClient2 = Utils.Companion.getMCastSession().getRemoteMediaClient();
                    if (remoteMediaClient2 != null) {
                        companion2.setRemoteMediaClient(remoteMediaClient2);
                    } else {
                        return;
                    }
                }

                if (mCastSession != null) {
                    RemoteMediaClient var4 = Utils.Companion.getRemoteMediaClient();

                    if (var4 != null) {


                        final RemoteMediaClient remoteMediaClient = var4;
                        remoteMediaClient.registerCallback((RemoteMediaClient.Callback) (new RemoteMediaClient.Callback() {
                            public void onStatusUpdated() {
                                remoteMediaClient.unregisterCallback((RemoteMediaClient.Callback) this);
                                startHandelForSeek();


                            }
                        }));

                        if (list_noti.size() != 0) {
                            remoteMediaClient.load((new MediaLoadRequestData.Builder()).setMediaInfo(this.buildMediaInfo()).setAutoplay(true).setCurrentTime(0L).build());
                        }

                        return;
                    }
                }

            }
        }
    }

    private final MediaInfo buildMediaInfo() {

        String path = Constants.list_noti.get(cast_pot).getmPath();
        Glide.with(getApplicationContext()).load(path).into(img_load_set_video);
        String subPath = path.replace("/storage/emulated/0/", "");
        text_title_tool.setText(Constants.list_noti.get(cast_pot).getmDisplayName());
        text_title_tool.setSelected(true);
        StringBuilder var10000 = (new StringBuilder()).append("http://").append(deviceIpAddress).append(":8036/");

        String sampleVideoStream = var10000.append(subPath).toString();
        var10000 = (new StringBuilder()).append("http://").append(deviceIpAddress).append(":8036/");
        String sampleVideoSubtitle = var10000.append("").toString();
        MediaMetadata movieMetadata = new MediaMetadata(1);

        if (movieMetadata != null) {
            movieMetadata.putString(MediaMetadata.KEY_TITLE, Constants.list_noti.get(cast_pot).getmDisplayName());
        }
        if (movieMetadata != null) {
            movieMetadata.putString(MediaMetadata.KEY_SUBTITLE, "");
        }
        String testImageUrl1 = "https://www.itgeared.com/wp-content/uploads/how-to-cast-instagram-to-tv.jpg";
        String testImageUrl2 = "https://www.itgeared.com/wp-content/uploads/how-to-cast-instagram-to-tv.jpg";
        movieMetadata.addImage(new WebImage(Uri.parse(testImageUrl1)));
        movieMetadata.addImage(new WebImage(Uri.parse(testImageUrl2)));
        MediaTrack mediaTrack = (new com.google.android.gms.cast.MediaTrack.Builder(1L, 1)).setName("English").setSubtype(1).setContentId(sampleVideoSubtitle).setLanguage("en-US").build();
        return (new com.google.android.gms.cast.MediaInfo.Builder(sampleVideoStream)).setStreamType(1).setContentType("videos/mp4").setMetadata(movieMetadata).setStreamDuration(Long.parseLong(String.valueOf(Constants.list_noti.get(cast_pot).getmDuration()))).setMediaTracks(CollectionsKt.listOf(mediaTrack)).build();
    }

    @Override
    public void onBackPressed() {
        opendilogset();

    }

    private void opendilogset() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.dialog_cast_disconnect);
        dialog.setCancelable(true);

        ImageView img_disconnect = dialog.findViewById(R.id.img_disconnect);
        TextView text_cast_tv_name = dialog.findViewById(R.id.text_cast_tv_name);

        text_cast_tv_name.setText(Constants.cast_name);
        img_disconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCastSession.getRemoteMediaClient() != null) {
                    mCastSession.getRemoteMediaClient().stop();
                    CastContext.getSharedInstance(CastvideoActivity.this).getSessionManager().endCurrentSession(true);
                    finish();
                }
            }
        });
        dialog.show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacks(runnable);
        }
        if (remoteMediaClient != null) {
            remoteMediaClient.stop();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (mCastSession != null) {

                try {
                    if (mCastSession.getVolume() <= 0.99) {
                        recy_volum_view.setVisibility(View.VISIBLE);
                        mCastSession.setVolume(mCastSession.getVolume() + 0.10);
                        int aa = (int) ((mCastSession.getVolume() + 0.05) * 100);
                        seek_volume.setProgress(aa);
                        handler_seek_vol.postDelayed(runnable_seel_vol, 2000);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (mCastSession != null) {

                try {
                    if (mCastSession.getVolume() != 0.00) {
                        recy_volum_view.setVisibility(View.VISIBLE);
                        mCastSession.setVolume(mCastSession.getVolume() - 0.10);
                        int aa = (int) ((mCastSession.getVolume() - 0.05) * 100);
                        seek_volume.setProgress(aa);
                        handler_seek_vol.postDelayed(runnable_seel_vol, 2000);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return true;
        }

        return super.onKeyUp(keyCode, event);
    }
}