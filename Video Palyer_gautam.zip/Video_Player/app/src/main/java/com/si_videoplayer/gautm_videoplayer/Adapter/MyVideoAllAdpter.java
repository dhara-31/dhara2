package com.si_videoplayer.gautm_videoplayer.Adapter;

import static com.si_videoplayer.gautm_videoplayer.Floating.FloatingService.floatingService;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.si_videoplayer.gautm_videoplayer.Activity.VideoShowActivity;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.io.File;
import java.util.ArrayList;

public class MyVideoAllAdpter extends RecyclerView.Adapter<MyVideoAllAdpter.DataviewAllDate> {

    ArrayList<VideoInfo> list_data_aa;
    Context context;
    int viewsetgrid;
    PreferenceUtil preferenceUtil;
    ClickaMoreIcon clickaMoreIcon;

    public MyVideoAllAdpter(FragmentActivity activity, ArrayList<VideoInfo> list_data_all,int viewset, ClickaMoreIcon clickaMoreIcon) {
        context=activity;
        list_data_aa=list_data_all;
        viewsetgrid=viewset;
        this.clickaMoreIcon=clickaMoreIcon;
        preferenceUtil=new PreferenceUtil(context);
    }

    @NonNull
    @Override
    public DataviewAllDate onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewsetgrid == 1) {
            return new DataviewAllDate(LayoutInflater.from(context).inflate(R.layout.item_layout_videoall, parent, false));
        } else {
            return new DataviewAllDate(LayoutInflater.from(context).inflate(R.layout.item_layout_videoall_2, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull DataviewAllDate holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(context).load(list_data_aa.get(position).getmPath()).apply(new RequestOptions().placeholder(R.drawable.vi_video_place)).thumbnail(0.1f).override(350, 350).transition(new DrawableTransitionOptions().crossFade()).into(holder.iv_thumbnail);

        holder.tv_total_time.setText(UtilsVideo.formateMilliSeccond(list_data_aa.get(position).getmDuration()));
        holder.tv_video_name.setText(list_data_aa.get(position).getmDisplayName());
        holder.tv_created_day.setText(UtilsVideo.readableFileSize(list_data_aa.get(position).getmSize()) +" | "+ UtilsVideo.convertLongToTime(new File(list_data_aa.get(position).getmPath()).lastModified(), "dd-MM-yyyy"));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                holder.tv_video_name.setSelected(true);
                holder.tv_created_day.setSelected(true);
            }
        },2000);

        String convertSolution = UtilsVideo.convertSolution(list_data_aa.get(position).getmResolution());
        if (TextUtils.isEmpty(convertSolution)) {
            holder.tv_resolution_size.setVisibility(View.GONE);
        } else {
            holder.tv_resolution_size.setVisibility(View.VISIBLE);
            holder.tv_resolution_size.setText(convertSolution);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (floatingService!=null){
                    floatingService.stopSelf();
                }
                Constants.play_pause=true;

                preferenceUtil.putInt(Constants.Current_Position, position);
                VideoShowActivity.list_data=new ArrayList<>();
                VideoShowActivity.list_data.addAll(list_data_aa);





                GoviddecgtmAs.getInstance().showinter((Activity) context, new GoviddecgtmAs.AviddetInterface() {
                    @Override
                    public void abrttall() {
                        Intent intent=new Intent(context,VideoShowActivity.class);
                        context.startActivity(intent);
                    }
                });


            }
        });
        holder.iv_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                clickaMoreIcon.itemclickpospass(list_data_aa.get(position).getmPath(),position);

            }
        });
    }

    @Override
    public int getItemCount() {
        return list_data_aa.size();
    }

    public void updatelist(ArrayList<VideoInfo> videoInfos) {
        list_data_aa=new ArrayList<>();

        list_data_aa.addAll(videoInfos);
        Constants.list_video_data=new ArrayList<>();
        Constants.list_video_data.clear();
        Constants.list_video_data.addAll(videoInfos);
        notifyDataSetChanged();
    }

    public interface  ClickaMoreIcon{
        void itemclickpospass(String path,int pos );
    }

    class  DataviewAllDate extends RecyclerView.ViewHolder {
        ImageView iv_thumbnail;
        ImageView  iv_more;
        TextView tv_total_time, tv_video_name, tv_created_day, tv_resolution_size;

        public DataviewAllDate(@NonNull View itemView) {

            super(itemView);

            iv_thumbnail = itemView.findViewById(R.id.iv_thumbnail);
            iv_more = itemView.findViewById(R.id.iv_more);
            tv_total_time = itemView.findViewById(R.id.tv_total_time);
            tv_video_name = itemView.findViewById(R.id.tv_video_name);
            tv_created_day = itemView.findViewById(R.id.tv_created_day);
            tv_resolution_size = itemView.findViewById(R.id.tv_resolution_size);
            tv_video_name.setSelected(false);
        }
    }
}
