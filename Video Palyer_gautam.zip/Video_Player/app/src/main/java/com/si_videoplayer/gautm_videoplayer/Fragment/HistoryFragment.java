package com.si_videoplayer.gautm_videoplayer.Fragment;

import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.maniVideoPlayerActivity;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity;
import com.si_videoplayer.gautm_videoplayer.Adapter.MyVideoHistoryAdpter;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import java.lang.reflect.Type;
import java.util.ArrayList;


public class HistoryFragment extends Fragment {

    private  ManiVideoPlayerActivity context;
    TextView text_avtivity_name;
    ImageView img_set_tool_serach,img_no_data;
    private PreferenceUtil preferenceUtil;
    RecyclerView recy_history;
    MyVideoHistoryAdpter myVideoHistoryAdpter;
    ArrayList<VideoInfo> list_his=new ArrayList<>();
    TextView text_list_clear;
    private Gson gson;

    public HistoryFragment(){}

    public HistoryFragment(ManiVideoPlayerActivity maniVideoPlayerActivity) {
        context=maniVideoPlayerActivity;
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        text_avtivity_name=view.findViewById(R.id.text_avtivity_name);
        img_set_tool_serach=view.findViewById(R.id.img_set_tool_serach);
        img_no_data=view.findViewById(R.id.img_no_data);
        text_list_clear=view.findViewById(R.id.text_list_clear);

        text_avtivity_name.setText("History");
        img_set_tool_serach.setVisibility(View.GONE);
        preferenceUtil=new PreferenceUtil(getActivity());
        gson=new Gson();
        recy_history=view.findViewById(R.id.recy_history);
        recy_history.setLayoutManager(new GridLayoutManager(getActivity(),1));
        myVideoHistoryAdpter=new MyVideoHistoryAdpter(getActivity(),list_his);
        recy_history.setAdapter(myVideoHistoryAdpter);
       updateset();
        setlistdata();

        text_list_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String json = gson.toJson(list_his=new ArrayList<>());
                preferenceUtil.putString(Constants.Video_history_List, json);
                if(maniVideoPlayerActivity!=null){
                    maniVideoPlayerActivity.updatehistory();
                }

            }
        });

    }

    private void updateset() {
        if (myVideoHistoryAdpter.getItemCount()==0){
            recy_history.setVisibility(View.GONE);
            text_list_clear.setVisibility(View.GONE);
            img_no_data.setVisibility(View.VISIBLE);
        }else {
            recy_history.setVisibility(View.VISIBLE);
            text_list_clear.setVisibility(View.VISIBLE);
            img_no_data.setVisibility(View.GONE);
        }
    }

    public void setlistdata() {
        String history_josn = preferenceUtil.getString(Constants.Video_history_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {}.getType();
        list_his = gson.fromJson(history_josn, type);
        if (list_his == null) {
            list_his = new ArrayList<>();
        }
        myVideoHistoryAdpter.setupdatelist(list_his);
        updateset();
    }
}