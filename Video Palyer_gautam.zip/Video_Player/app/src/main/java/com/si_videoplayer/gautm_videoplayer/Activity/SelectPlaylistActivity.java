package com.si_videoplayer.gautm_videoplayer.Activity;

import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.bottom_play_linear;
import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.maniVideoPlayerActivity;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.PlayFirstBackgroundVideo;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.backGroundPlayingList;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.backgroundPosition;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.path_delete;
import static com.si_videoplayer.gautm_videoplayer.Service.NotificationService.foregroundService;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Adapter.ADD_Play_List_Adapter;
import com.si_videoplayer.gautm_videoplayer.Adapter.MyAdaterSelectplaylist;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Interface;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.Service.NotificationService;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.VideotoAudio;
import com.si_videoplayer.gautm_videoplayer.Castutils.Natviddecgtm2sAll;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;

public class SelectPlaylistActivity extends AppCompatActivity {

    private TextView text_avtivity_name;
    private ImageView img_set_tool_serach, img_no_data;
    RecyclerView recy_select_playlist;
    MyAdaterSelectplaylist myAdaterSelectplaylist;
    ArrayList<VideoInfo> list_data = new ArrayList<>();
    ArrayList<VideoInfo> list_data_all = new ArrayList<>();
    PreferenceUtil preferenceUtil;
    Gson gson = new Gson();

    TextView text_delete_playlist;
    private ArrayList<VideoInfo> list_favo = new ArrayList<>();
    private File file_for_delete;
    private int delete_pos;
    private int renamepos;
    private String newName;
    private File file_original;
    private String edit_item_path;
    private String old_file_path;
    public Uri contentUri;
    private File to;
    private ArrayList<VideoInfo> atp_get_list = new ArrayList<>();
    private ArrayList<VideoInfo> list_hist = new ArrayList<>();
    private ADD_Play_List_Adapter atp_list_adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_playlist);


        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView cardView = findViewById(R.id.c);
        Natviddecgtm2sAll.banerAllSviddecgtmow(admobNativeLarge2, SelectPlaylistActivity.this, cardView);

        text_delete_playlist = findViewById(R.id.text_delete_playlist);

        preferenceUtil = new PreferenceUtil(this);
        gson = new Gson();
        int aa = getIntent().getIntExtra("datashow", 0);
        text_avtivity_name = findViewById(R.id.text_avtivity_name);
        img_set_tool_serach = findViewById(R.id.img_set_tool_serach);
        img_no_data = findViewById(R.id.img_no_data);
        if (aa == 22) {

            text_delete_playlist.setVisibility(View.GONE);

            text_avtivity_name.setText(getIntent().getStringExtra("folder_name"));

            list_data_all.clear();
            String json = getIntent().getStringExtra("data_all_folder_asasas");
            Type type = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_data_all = gson.fromJson(json, type);
            list_data = getdatafolder(list_data_all, getIntent().getStringExtra("folder_name"));

        } else {
            text_delete_playlist.setVisibility(View.VISIBLE);
            text_avtivity_name.setText(getIntent().getStringExtra("pf_keyaa"));
            list_data_all.clear();
            String json00 = getIntent().getStringExtra("all_date_showaa");
            Type type00 = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_data_all = gson.fromJson(json00, type00);

            list_data.clear();
            String json1Null11 = gson.toJson(list_data);
            String json11 = preferenceUtil.getString(getIntent().getStringExtra("pf_keyaa"), json1Null11);
            Type type11 = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_data = gson.fromJson(json11, type11);

        }


        text_delete_playlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog alertadd11 = new Dialog(SelectPlaylistActivity.this);
                alertadd11.setContentView(R.layout.dialog_delete);
                alertadd11.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertadd11.setCancelable(false);
                ImageView img_delete = alertadd11.findViewById(R.id.img_delete);
                ImageView img_dilog_cancel = alertadd11.findViewById(R.id.img_dilog_cancel);
                TextView text_conta = alertadd11.findViewById(R.id.text_conta);
                text_conta.setText("Delete Video playlist.");

                img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertadd11.dismiss();
                    }
                });


                img_delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String playlistname = text_avtivity_name.getText().toString().trim();
                        gson = new Gson();
                        String json = gson.toJson(list_data = new ArrayList<>());
                        preferenceUtil.putString(playlistname, json);

                        ArrayList<VideoInfo> list_play = new ArrayList<>();
                        String json1Null00 = gson.toJson(list_play);
                        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
                        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {
                        }.getType();
                        list_play = gson.fromJson(json00, type00);
                        for (int aa = 0; aa < list_play.size(); aa++) {

                            if (list_play.get(aa).getList_name().equals(playlistname)) {
                                list_play.remove(aa);
                                break;
                            }
                        }

                        String json1 = gson.toJson(list_play);
                        preferenceUtil.putString(Constants.Add_play_List, json1);
                        if (maniVideoPlayerActivity != null) {
                            if (maniVideoPlayerActivity.playlistFragment != null) {
                                maniVideoPlayerActivity.playlistFragment.setdateview();
                            }
                        }

                        Toast.makeText(SelectPlaylistActivity.this, "Delete playlist!", Toast.LENGTH_SHORT).show();
                        
                        onBackPressed();
                        alertadd11.dismiss();

                    }
                });
                alertadd11.show();

            }
        });

        text_avtivity_name.setLetterSpacing(0);
        img_set_tool_serach.setVisibility(View.GONE);
        recy_select_playlist = findViewById(R.id.recy_select_playlist);


        recy_select_playlist.setLayoutManager(new LinearLayoutManager(this));
        myAdaterSelectplaylist = new MyAdaterSelectplaylist(this, list_data, aa, this::clickmune);
        recy_select_playlist.setAdapter(myAdaterSelectplaylist);
        setdataApdpter();
    }

    private void setdataApdpter() {
        if (myAdaterSelectplaylist.getItemCount() == 0) {
            img_no_data.setVisibility(View.VISIBLE);
            recy_select_playlist.setVisibility(View.GONE);
        } else {
            img_no_data.setVisibility(View.GONE);
            recy_select_playlist.setVisibility(View.VISIBLE);
        }
    }


    private ArrayList<VideoInfo> getdatafolder(ArrayList<VideoInfo> list_set_all, String data_list) {
        ArrayList<VideoInfo> list = new ArrayList<>();
        for (VideoInfo videoInfo : list_set_all) {
            if (new File(videoInfo.getmPath()).getParentFile().getName().equals(data_list)) {
                list.add(videoInfo);
            }
        }
        return list;
    }

    private void clickmune(String s, int pos, int selectact) {
        if (selectact == 22) {
            manibottomsheet(s, pos);
        } else {
            playlistsheets(s, pos);
        }

    }

    private void playlistsheets(String s, int pos) {
        BottomSheetDialog bosdilog = new BottomSheetDialog(this);
        bosdilog.setContentView(R.layout.bottom_sheet_dialog_select);
        ImageView iv_thumbnail = bosdilog.findViewById(R.id.iv_thumbnail);
        Glide.with(this).load(list_data.get(pos).getmPath()).into(iv_thumbnail);
        TextView tv_total_time = bosdilog.findViewById(R.id.tv_total_time);
        TextView tv_video_name = bosdilog.findViewById(R.id.tv_video_name);
        TextView tv_created_day = bosdilog.findViewById(R.id.tv_created_day);
        TextView tv_resolution_size = bosdilog.findViewById(R.id.tv_resolution_size);
        tv_total_time.setText(UtilsVideo.formateMilliSeccond(list_data.get(pos).getmDuration()));
        tv_video_name.setText(list_data.get(pos).getmDisplayName());
        tv_created_day.setText(UtilsVideo.readableFileSize(list_data.get(pos).getmSize()) + "   " + UtilsVideo.convertLongToTime(new File(list_data.get(pos).getmPath()).lastModified(), "dd-MM-yyyy"));
        String convertSolution = UtilsVideo.convertSolution(list_data.get(pos).getmResolution());
        if (TextUtils.isEmpty(convertSolution)) {
            tv_resolution_size.setVisibility(View.GONE);
        } else {
            tv_resolution_size.setVisibility(View.VISIBLE);
            tv_resolution_size.setText(convertSolution);
        }
        tv_total_time.setText(UtilsVideo.formateMilliSeccond(list_data.get(pos).getmDuration()));


        RelativeLayout relativ_properties = bosdilog.findViewById(R.id.relativ_properties);
        RelativeLayout relativ_share = bosdilog.findViewById(R.id.relativ_share);
        RelativeLayout relativ_add_to_platlist = bosdilog.findViewById(R.id.relativ_add_to_platlist);
        RelativeLayout relativ_delete = bosdilog.findViewById(R.id.relativ_delete);

        relativ_properties.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_pro(pos);
                bosdilog.dismiss();
            }
        });
        relativ_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File file = new File(list_data.get(pos).getmPath());
                Uri picUri = FileProvider.getUriForFile(SelectPlaylistActivity.this, SelectPlaylistActivity.this.getPackageName() + ".fileprovider", file.getAbsoluteFile());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_STREAM, picUri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                intent.setType("video/*");
                startActivity(Intent.createChooser(intent, "Share Via"));
                bosdilog.dismiss();

            }
        });
        relativ_add_to_platlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remove_playlist(pos);
                bosdilog.dismiss();

            }
        });
        relativ_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_delete(pos);
                bosdilog.dismiss();
            }
        });

        bosdilog.show();
    }

    private void manibottomsheet(String s, int pos) {
        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }


        BottomSheetDialog bosdilog = new BottomSheetDialog(this);
        bosdilog.setContentView(R.layout.bottom_sheet_dialog_main);
        ImageView iv_thumbnail = bosdilog.findViewById(R.id.iv_thumbnail);
        Glide.with(this).load(list_data.get(pos).getmPath()).into(iv_thumbnail);
        TextView tv_total_time = bosdilog.findViewById(R.id.tv_total_time);
        TextView tv_video_name = bosdilog.findViewById(R.id.tv_video_name);
        TextView tv_created_day = bosdilog.findViewById(R.id.tv_created_day);
        TextView tv_resolution_size = bosdilog.findViewById(R.id.tv_resolution_size);
        tv_total_time.setText(UtilsVideo.formateMilliSeccond(list_data.get(pos).getmDuration()));
        tv_video_name.setText(list_data.get(pos).getmDisplayName());
        tv_created_day.setText(UtilsVideo.readableFileSize(list_data.get(pos).getmSize()) + "   " + UtilsVideo.convertLongToTime(new File(list_data.get(pos).getmPath()).lastModified(), "dd-MM-yyyy"));
        String convertSolution = UtilsVideo.convertSolution(list_data.get(pos).getmResolution());
        if (TextUtils.isEmpty(convertSolution)) {
            tv_resolution_size.setVisibility(View.GONE);
        } else {
            tv_resolution_size.setVisibility(View.VISIBLE);
            tv_resolution_size.setText(convertSolution);
        }
        tv_total_time.setText(UtilsVideo.formateMilliSeccond(list_data.get(pos).getmDuration()));
        RelativeLayout relativ_play_as_audio = bosdilog.findViewById(R.id.relativ_play_as_audio);
        RelativeLayout relativ_Add_to_fat = bosdilog.findViewById(R.id.relativ_Add_to_fat);
        RelativeLayout relativ_convert_mp3 = bosdilog.findViewById(R.id.relativ_convert_mp3);
        RelativeLayout relativ_add_to_platlist = bosdilog.findViewById(R.id.relativ_add_to_platlist);
        RelativeLayout relativ_properties = bosdilog.findViewById(R.id.relativ_properties);
        RelativeLayout relativ_share = bosdilog.findViewById(R.id.relativ_share);
        RelativeLayout relativ_rename = bosdilog.findViewById(R.id.relativ_rename);
        RelativeLayout relativ_delete = bosdilog.findViewById(R.id.relativ_delete);

        ImageView img_anselect = bosdilog.findViewById(R.id.img_anselect);
        ImageView img_select = bosdilog.findViewById(R.id.img_select);

        if (list_favo.size() == 0) {
            list_favo = new ArrayList<>();
            img_anselect.setVisibility(View.VISIBLE);
            img_select.setVisibility(View.GONE);
        } else {
            for (int i = 0; i < list_favo.size(); i++) {

                if (list_favo.get(i).getmPath().equals(s)) {

                    img_anselect.setVisibility(View.GONE);
                    img_select.setVisibility(View.VISIBLE);
                    break;
                } else {
                    img_anselect.setVisibility(View.VISIBLE);
                    img_select.setVisibility(View.GONE);
                }
            }
        }
        relativ_play_as_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isMyServiceRunning(NotificationService.class)) {
                    if (foregroundService != null) {
                        foregroundService.stopNotification();
                    }
                    ;
                }
                backgroundPosition = pos;
                backGroundPlayingList = new ArrayList<>();
                backGroundPlayingList.addAll(list_data);
                if (bottom_play_linear != null) {
                    bottom_play_linear.setVisibility(View.VISIBLE);
                }
                PlayFirstBackgroundVideo(SelectPlaylistActivity.this);
                Intent intent = new Intent(SelectPlaylistActivity.this, NotificationService.class);
                intent.setAction(Constants.ACTION.STARTFOREGROUND_ACTION);
                startService(intent);


                bosdilog.dismiss();
            }
        });

        relativ_Add_to_fat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (img_anselect.getVisibility() == View.VISIBLE) {

                    img_anselect.setVisibility(View.GONE);
                    img_select.setVisibility(View.VISIBLE);

                    if (list_favo.size() == 0) {
                        list_favo.add(list_data.get(pos));

                    } else {
                        for (int i = 0; i < list_favo.size(); i++) {
                            if (list_favo.get(i).getmPath().equals(list_data.get(pos).getmPath())) {
                                list_favo.remove(i);
                                break;
                            }
                        }
                        list_favo.add(list_data.get(pos));
                    }

                    savelistfavo(list_favo);
                } else {
                    if (img_select.getVisibility() == View.VISIBLE) {
                        img_anselect.setVisibility(View.VISIBLE);
                        img_select.setVisibility(View.GONE);

                        for (int i = 0; i < list_favo.size(); i++) {
                            if (list_favo.get(i).getmPath().equals(list_data.get(pos).getmPath())) {
                                list_favo.remove(i);
                                break;
                            }
                        }
                        savelistfavo(list_favo);
                    }
                }

                bosdilog.dismiss();
            }
        });
        relativ_convert_mp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String filename = list_data_all.get(pos).getmDisplayName();
                String result = filename.substring(0, filename.lastIndexOf("."));
                File filecerr = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/convatmp3/");
                if (!filecerr.exists()) {
                    filecerr.mkdirs();
                }
                File file_save_status = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/convatmp3/" + result + ".mp3");
                if (UtilsVideo.isVideoHaveAudioTrack(list_data_all.get(pos).getmPath())) {
                    new VideotoAudio(SelectPlaylistActivity.this, file_save_status, list_data_all.get(pos).getmPath()).execute();
                } else {
                    Toast.makeText(SelectPlaylistActivity.this, "This video does not have any audio!", Toast.LENGTH_SHORT).show();
                }


                bosdilog.dismiss();
            }
        });
        relativ_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File file = new File(list_data.get(pos).getmPath());
                Uri picUri = FileProvider.getUriForFile(SelectPlaylistActivity.this, SelectPlaylistActivity.this.getPackageName() + ".fileprovider", file.getAbsoluteFile());
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_STREAM, picUri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                intent.setType("video/*");
                startActivity(Intent.createChooser(intent, "Share Via"));
                bosdilog.dismiss();

            }
        });
        relativ_properties.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_pro(pos);
                bosdilog.dismiss();
            }
        });
        relativ_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_delete_folder(pos);
                bosdilog.dismiss();
            }
        });
        relativ_rename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_rename_folder(pos);
                bosdilog.dismiss();
            }
        });
        relativ_add_to_platlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_dialog_playlist_folder(pos);
                bosdilog.dismiss();
            }
        });


        bosdilog.show();
    }

    private void open_dialog_playlist_folder(int pos) {
        ArrayList<VideoInfo> atp_get_list1 = new ArrayList<>();
        String json1Null00 = gson.toJson(atp_get_list);
        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();

        atp_get_list1 = gson.fromJson(json00, type00);
        if (atp_get_list1.size() == 0) {
            atp_get_list1 = new ArrayList<>();
        }
        Dialog alertadd = new Dialog(this);
        View mView = LayoutInflater.from(this).inflate(R.layout.dialog_play_list, null);
        alertadd.setContentView(mView);
        alertadd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        RecyclerView atp_list_recycler = (RecyclerView) mView.findViewById(R.id.atp_list_recycler);
        ImageView atp_list_add_img = (ImageView) mView.findViewById(R.id.atp_list_add_img);
        ArrayList<VideoInfo> finalAtp_get_list = atp_get_list1;
        atp_list_add_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_atp_dialogue(atp_list_recycler, pos, alertadd, finalAtp_get_list);
                alertadd.dismiss();
            }
        });
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        atp_list_recycler.setLayoutManager(layoutManager);
        atp_list_adapter = new ADD_Play_List_Adapter(atp_get_list1, this, pos, list_data_all, alertadd, new Interface() {
            @Override
            public void image_List(int position) {

            }
        });
        atp_list_recycler.setAdapter(atp_list_adapter);

        alertadd.show();
    }

    private void open_atp_dialogue(RecyclerView atp_list_recycler, int pos, Dialog alertadd, ArrayList<VideoInfo> finalAtp_get_list) {

        final Dialog alert_creat = new Dialog(this);

        View mView = LayoutInflater.from(this).inflate(R.layout.creat_play_list, null);

        EditText playList_name_et = (EditText) mView.findViewById(R.id.edt_text_data);
        ImageView cancel_txt = (ImageView) mView.findViewById(R.id.img_dilog_cancel);
        ImageView add_txt = (ImageView) mView.findViewById(R.id.img_create);

        alert_creat.setContentView(mView);
        alert_creat.setCanceledOnTouchOutside(false);
        alert_creat.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        cancel_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alert_creat.dismiss();
            }
        });
        add_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> temp = new ArrayList<>();
                String name_list = playList_name_et.getText().toString().trim();
                if (name_list.length() == 0) {
                } else {
                    for (int i = 0; i < finalAtp_get_list.size(); i++) {
                        temp.add(finalAtp_get_list.get(i).getList_name());
                    }
                    if (!temp.contains(name_list)) {
                        finalAtp_get_list.add(0, new VideoInfo(name_list));
                    }
                    LinearLayoutManager layoutManager = new LinearLayoutManager(SelectPlaylistActivity.this, LinearLayoutManager.HORIZONTAL, true);
                    atp_list_recycler.setLayoutManager(layoutManager);

                    atp_list_adapter = new ADD_Play_List_Adapter(finalAtp_get_list, SelectPlaylistActivity.this, pos, list_data, alertadd, new Interface() {
                        @Override
                        public void image_List(int position) {

                        }
                    });
                    atp_list_recycler.setAdapter(atp_list_adapter);
                    String json111 = gson.toJson(finalAtp_get_list);
                    preferenceUtil.putString(Constants.Add_play_List, json111);
                    alert_creat.dismiss();
                    open_dialog_playlist_folder(pos);

                }
            }
        });

        alert_creat.show();
    }

    private void open_dialog_rename_folder(int pos) {
        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }
        loadlisty();
        renamepos = pos;
        Dialog dialogrename = new Dialog(this);
        dialogrename.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View vi2 = LayoutInflater.from(this).inflate(R.layout.dialog_rename, null);
        dialogrename.setContentView(vi2);
        dialogrename.setCancelable(false);

        ImageView img_dilog_cancel = vi2.findViewById(R.id.img_dilog_cancel);
        RelativeLayout img_rename = vi2.findViewById(R.id.img_rename);
        EditText edt_text_data = vi2.findViewById(R.id.edt_text_data);

        String video_old_name = list_data.get(pos).getmDisplayName();

        video_old_name = video_old_name.substring(0, video_old_name.lastIndexOf("."));
        edt_text_data.setText(video_old_name);

        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogrename.dismiss();
            }
        });
        img_rename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                renamepos = pos;
                newName = edt_text_data.getText().toString().trim();
                newName = newName.replace(".mp4", "");

                String aaaa = list_data.get(pos).getmPath();
                file_original = new File(aaaa);
                if (newName.isEmpty() || newName.trim().equals("")) {

                    edt_text_data.setError("Enter any Name!");

                } else {

                    boolean checkFileName = false;

                    for (int i = 0; i < list_data.size(); i++) {

                        if (list_data.get(i).getmDisplayName().replace(".mp4", "").equals(newName.trim().replace(" .mp4", ".mp4"))) {

                            checkFileName = true;

                        }
                    }

                    if (checkFileName) {


                        Toast.makeText(SelectPlaylistActivity.this, "File Name Already Exists!", Toast.LENGTH_SHORT).show();

                        return;

                    } else {
                        edit_item_path = list_data.get(pos).getmPath();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            old_file_path = list_data.get(pos).getmPath();

                            ArrayList<Uri> uris = new ArrayList<>();

                            try {
                                contentUri = UtilsVideo.getUriFromVideoPath(SelectPlaylistActivity.this, list_data.get(pos).getmPath());
                            } catch (Throwable throwable) {
                                throwable.printStackTrace();
                            }
                            if (contentUri != null) {
                                uris.add(contentUri);
                            }


                            if (uris.size() > 0) {

                                IntentSender intentSender;
                                if (Build.VERSION.SDK_INT >= 30) {
                                    PendingIntent pendingIntent = MediaStore.createWriteRequest(getContentResolver(), (Collection) uris);
                                    intentSender = pendingIntent.getIntentSender();
                                } else {
                                    intentSender = null;
                                }

                                if (intentSender != null) {

                                    intentSenderLauncherRename.launch((new IntentSenderRequest.Builder(intentSender)).build());
                                }
                            }

                        } else {
                            newName = newName + ".mp4";
                            File new_path = new File(new File(edit_item_path).getParentFile(), newName);
                            UtilsVideo.playlistdatarenama(SelectPlaylistActivity.this, list_data.get(pos).getmPath(), new_path, newName);
                            UtilsVideo.renameFile(new_path, newName.trim().replace(" .mp4", ".mp4"), list_data.get(pos).getmDisplayName());

                            MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{file_original.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                public void onScanCompleted(String path, Uri uri) {
                                }
                            });

                            MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{new_path.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                public void onScanCompleted(String path, Uri uri) {
                                }
                            });

                            for (int i = 0; i < list_favo.size(); i++) {

                                if (list_favo.get(i).getmPath().equals(list_data.get(renamepos).getmPath())) {
                                    list_favo.get(i).setmDisplayName(newName);
                                    list_favo.get(i).setmPath(new_path.getAbsolutePath());
                                    break;
                                }
                            }


                            for (int i = 0; i < list_data_all.size(); i++) {
                                if (list_data_all.get(i).getmPath().equals(list_data.get(renamepos).getmPath())) {
                                    list_data_all.get(i).setmDisplayName(newName);
                                    list_data_all.get(i).setmPath(new_path.getAbsolutePath());
                                }

                            }
                            for (int i = 0; i < list_hist.size(); i++) {
                                if (list_hist.get(i).getmPath().equals(list_data.get(renamepos).getmPath())) {
                                    list_hist.get(i).setmDisplayName(newName);
                                    list_hist.get(i).setmPath(new_path.getAbsolutePath());
                                }

                            }
                            savelistfavo(list_favo);
                            savelistdata(list_data);
                            savelisthist(list_hist);
                            list_data.get(renamepos).setmPath(file_original.getAbsolutePath());
                            list_data.get(renamepos).setmDisplayName(newName);

                            Toast.makeText(SelectPlaylistActivity.this, "Video Rename!", Toast.LENGTH_SHORT).show();
                            if (maniVideoPlayerActivity != null) {

                            }
                            myAdaterSelectplaylist.updatelist(list_data);
                            setdataApdpter();

                        }

                    }
                    dialogrename.dismiss();

                }
            }
        });


        dialogrename.show();
    }

    private void open_dialog_delete_folder(int pos) {

        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }

        loadlisty();
        Dialog dialogDelete1 = new Dialog(this);
        dialogDelete1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View vi2 = LayoutInflater.from(this).inflate(R.layout.dialog_delete, null);
        dialogDelete1.setContentView(vi2);
        dialogDelete1.setCancelable(false);

        ImageView img_dilog_cancel = dialogDelete1.findViewById(R.id.img_dilog_cancel);
        ImageView img_delete = dialogDelete1.findViewById(R.id.img_delete);
        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogDelete1.dismiss();
            }
        });
        img_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ArrayList<Uri> fichiers = new ArrayList<>();

                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Long.valueOf(list_data.get(pos).getmId()));
                file_for_delete = new File(list_data.get(pos).getmPath());
                path_delete = file_for_delete.getAbsolutePath();
                delete_pos = pos;
                fichiers.add(contentUri);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                    PendingIntent demande = MediaStore.createDeleteRequest(getContentResolver(), fichiers);

                    try {
                        startIntentSenderForResult(demande.getIntentSender(), 2, new Intent(), 0, 0, 0);
                    } catch (IntentSender.SendIntentException e) {

                    }

                } else {
                    file_for_delete.delete();


                    for (int i = 0; i < list_data_all.size(); i++) {
                        if (list_data_all.get(i).getmPath().equals(list_data.get(pos).getmPath())) {
                            list_data_all.remove(i);
                            break;
                        }
                    }

                    for (int i = 0; i < list_favo.size(); i++) {

                        if (list_favo.get(i).getmPath().equals(list_data.get(pos).getmPath())) {
                            list_favo.remove(i);
                            break;
                        }
                    }
                    for (int i = 0; i < list_hist.size(); i++) {
                        if (list_hist.get(i).getmPath().equals(list_data.get(pos).getmPath())) {
                            list_hist.remove(i);
                            break;
                        }
                    }
                    list_data.remove(pos);
                    savelisthist(list_hist);
                    savelistfavo(list_favo);
                    setdataApdpter();
                    MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{file_for_delete.getAbsolutePath()}, new String[]{"video/*"}, new MediaScannerConnection.MediaScannerConnectionClient() {
                        public void onMediaScannerConnected() {
                        }

                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });

                    Toast.makeText(SelectPlaylistActivity.this, "Video Deleted!", Toast.LENGTH_SHORT).show();
                    if (maniVideoPlayerActivity != null) {
                        maniVideoPlayerActivity.listalldataupdatefrg(list_data_all);
                    }
                    myAdaterSelectplaylist.updatelist(list_data);
                    savelistdata(list_data);
                }


                dialogDelete1.dismiss();
            }
        });
        dialogDelete1.show();
    }

    private void remove_playlist(int pos) {
        String json1Null11 = gson.toJson(list_data);
        String json11 = preferenceUtil.getString(getIntent().getStringExtra("pf_keyaa"), json1Null11);
        Type type11 = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_data = gson.fromJson(json11, type11);
        list_data.remove(pos);
        savelistdata(list_data);
        myAdaterSelectplaylist.updatelist(list_data);
        setdataApdpter();
    }

    private void open_dialog_delete(int pos) {


        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }
        loadlisty();

//        list_data.clear();
//        String json1Null11 = gson.toJson(list_data);
//        String json11 = preferenceUtil.getString(getIntent().getStringExtra("pf_keyaa"), json1Null11);
//        Type type11 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();
//        list_data = gson.fromJson(json11, type11);


        Dialog dialogDelete = new Dialog(this);
        dialogDelete.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View vi2 = LayoutInflater.from(this).inflate(R.layout.dialog_delete, null);
        dialogDelete.setContentView(vi2);
        dialogDelete.setCancelable(false);

        ImageView img_dilog_cancel = vi2.findViewById(R.id.img_dilog_cancel);
        ImageView img_delete = vi2.findViewById(R.id.img_delete);
        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogDelete.dismiss();
            }
        });

        img_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                ArrayList<Uri> fichiers = new ArrayList<>();
                Uri contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, Long.valueOf(list_data.get(pos).getmId()));
                file_for_delete = new File(list_data.get(pos).getmPath());
                path_delete = file_for_delete.getAbsolutePath();
                delete_pos = pos;
                fichiers.add(contentUri);


                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                    PendingIntent demande = MediaStore.createDeleteRequest(getContentResolver(), fichiers);
                    try {
                        SelectPlaylistActivity.this.startIntentSenderForResult(demande.getIntentSender(), 1, new Intent(), 0, 0, 0);
                    } catch (IntentSender.SendIntentException e) {

                    }

                } else {
                    file_for_delete.delete();


                    for (int i = 0; i < list_data_all.size(); i++) {
                        if (list_data_all.get(i).getmPath().equals(list_data.get(pos).getmPath())) {
                            list_data_all.remove(i);
                            break;
                        }
                    }

                    for (int i = 0; i < list_hist.size(); i++) {

                        if (list_hist.get(i).getmPath().equals(list_data.get(pos).getmPath())) {
                            list_hist.remove(i);
                            break;
                        }
                    }
                    list_data.remove(pos);
                    savelisthist(list_hist);
                    savelistfavo(list_favo);
                    MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{file_for_delete.getAbsolutePath()}, new String[]{"video/*"}, new MediaScannerConnection.MediaScannerConnectionClient() {
                        public void onMediaScannerConnected() {
                        }

                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });

                    Toast.makeText(SelectPlaylistActivity.this, "Video Deleted!", Toast.LENGTH_SHORT).show();
                    if (maniVideoPlayerActivity != null) {
                        maniVideoPlayerActivity.listalldataupdatefrg(list_data_all);
                    }
                    myAdaterSelectplaylist.updatelist(list_data);
                    savelistdata(list_data);
                }


                dialogDelete.dismiss();
            }
        });

        dialogDelete.show();

    }

    private void savelistdata(ArrayList<VideoInfo> list_data) {
        gson = new Gson();
        String json = gson.toJson(list_data);
        preferenceUtil.putString(getIntent().getStringExtra("pf_keyaa"), json);
    }

    private void savelistfavo(ArrayList<VideoInfo> list_favo) {
        gson = new Gson();
        String json = gson.toJson(list_favo);
        preferenceUtil.putString(Constants.Video_favo_List, json);


    }

    private void open_dialog_pro(int pos) {
        Dialog dialog1 = new Dialog(this);
        dialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View vi2 = LayoutInflater.from(this).inflate(R.layout.dialog_propertioes, null);
        dialog1.setContentView(vi2);
        dialog1.setCancelable(false);

        TextView video_info_title_txt = (TextView) dialog1.findViewById(R.id.video_info_title_txt);
        TextView video_info_location_txt = (TextView) dialog1.findViewById(R.id.video_info_location_txt);
        TextView video_info_size_txt = (TextView) dialog1.findViewById(R.id.video_info_size_txt);
        TextView video_info_format_txt = (TextView) dialog1.findViewById(R.id.video_info_format_txt);
        TextView video_info_duration_txt = (TextView) dialog1.findViewById(R.id.video_info_duration_txt);
        TextView video_info_resolution_txt = (TextView) dialog1.findViewById(R.id.video_info_resolution_txt);
        TextView video_info_date_txt = (TextView) dialog1.findViewById(R.id.video_info_date_txt);
        ImageView img_dilog_cancel = (ImageView) dialog1.findViewById(R.id.img_dilog_cancel);

        img_dilog_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog1.dismiss();
            }
        });

        video_info_title_txt.setSelected(true);
        video_info_location_txt.setSelected(true);
        video_info_title_txt.setText(list_data.get(pos).getmDisplayName());
        video_info_location_txt.setText(list_data.get(pos).getmPath());
        video_info_size_txt.setText(UtilsVideo.readableFileSize(list_data.get(pos).getmSize()));
        video_info_format_txt.setText(list_data.get(pos).getMimeType());
        video_info_duration_txt.setText(UtilsVideo.formateMilliSeccond(list_data.get(pos).getmDuration()));
        video_info_resolution_txt.setText(UtilsVideo.convertSolution(list_data.get(pos).getmResolution()));
        video_info_date_txt.setText(UtilsVideo.convertLongToTime(new File(list_data.get(pos).getmPath()).lastModified(), "dd-MM-yyyy"));


        dialog1.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {

            list_favo.clear();
            String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
            Type type = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_favo = gson.fromJson(fove_josn, type);
            if (list_favo == null) {
                list_favo = new ArrayList<>();
            }
            list_data.clear();
            String json1Null11 = gson.toJson(list_data);
            String json11 = preferenceUtil.getString(getIntent().getStringExtra("pf_keyaa"), json1Null11);
            Type type11 = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_data = gson.fromJson(json11, type11);

            for (int i = 0; i < list_data_all.size(); i++) {
                if (list_data_all.get(i).getmPath().equals(list_data.get(delete_pos).getmPath())) {
                    list_data_all.remove(i);
                    break;
                }
            }
            for (int i = 0; i < list_favo.size(); i++) {

                if (list_favo.get(i).getmPath().equals(list_data.get(delete_pos).getmPath())) {
                    list_favo.remove(i);
                    break;
                }
            }
            for (int i = 0; i < list_hist.size(); i++) {

                if (list_hist.get(i).getmPath().equals(list_data.get(delete_pos).getmPath())) {
                    list_hist.remove(i);
                    break;
                }
            }

            savelisthist(list_hist);
            savelistfavo(list_favo);
            if (maniVideoPlayerActivity != null) {
                maniVideoPlayerActivity.listalldataupdatefrg(list_data_all);
            }
            MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{path_delete}, new String[]{"video/*"}, new MediaScannerConnection.MediaScannerConnectionClient() {
                public void onMediaScannerConnected() {

                }

                public void onScanCompleted(String path, Uri uri) {

                }
            });
            list_data.remove(delete_pos);
            myAdaterSelectplaylist.updatelist(list_data);
            setdataApdpter();
            savelistdata(list_data);


        } else if (requestCode == 2 && resultCode == RESULT_OK) {
            list_favo.clear();
            String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
            Type type = new TypeToken<ArrayList<VideoInfo>>() {
            }.getType();
            list_favo = gson.fromJson(fove_josn, type);
            if (list_favo == null) {
                list_favo = new ArrayList<>();
            }

            for (int i = 0; i < list_favo.size(); i++) {

                if (list_favo.get(i).getmPath().equals(list_data.get(delete_pos).getmPath())) {
                    list_favo.remove(i);
                    break;
                }
            }
            for (int i = 0; i < list_hist.size(); i++) {

                if (list_hist.get(i).getmPath().equals(list_data.get(delete_pos).getmPath())) {

                    list_hist.remove(i);
                    break;
                }
            }

            savelisthist(list_hist);
            savelistfavo(list_favo);
            for (int i = 0; i < list_data_all.size(); i++) {
                if (list_data_all.get(i).getmPath().equals(list_data.get(delete_pos).getmPath())) {
                    list_data_all.remove(i);
                }
            }
            list_data.remove(delete_pos);
            myAdaterSelectplaylist.updatelist(list_data);
            setdataApdpter();
            if (maniVideoPlayerActivity != null) {
                maniVideoPlayerActivity.listalldataupdatefrg(list_data_all);
            }
            MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{path_delete}, new String[]{"video/*"}, new MediaScannerConnection.MediaScannerConnectionClient() {
                public void onMediaScannerConnected() {

                }

                public void onScanCompleted(String path, Uri uri) {

                }
            });

        }
    }


    public void loadlisty() {
        list_hist.clear();
        String hist_josn = preferenceUtil.getString(Constants.Video_history_List, null);
        Type hist = new TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_hist = gson.fromJson(hist_josn, hist);
        if (list_hist == null) {
            list_hist = new ArrayList<>();
        }
    }

    private void savelisthist(ArrayList<VideoInfo> list_hist) {
        String json = gson.toJson(list_hist);
        preferenceUtil.putString(Constants.Video_history_List, json);


    }

    public final ActivityResultLauncher<IntentSenderRequest> intentSenderLauncherRename = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {

            if (Build.VERSION.SDK_INT >= 30) {

                newName = newName + ".mp4";

                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                    getContentResolver().update(UtilsVideo.getUriFromVideoPath(SelectPlaylistActivity.this, old_file_path), contentValues, null);
                }
                MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{list_data_all.get(renamepos).getmPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });


                File new_path = new File(new File(edit_item_path).getParentFile(), newName);

                MediaScannerConnection.scanFile(SelectPlaylistActivity.this, new String[]{new_path.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {


                    }
                });

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        for (int i = 0; i < list_hist.size(); i++) {

                            if (list_hist.get(i).getmPath().equals(list_data.get(renamepos).getmPath())) {

                                list_hist.get(i).setmDisplayName(newName);
                                list_hist.get(i).setmPath(new_path.getAbsolutePath());
                            }

                        }

                        for (int i = 0; i < list_favo.size(); i++) {

                            if (list_favo.get(i).getmPath().equals(list_data.get(renamepos).getmPath())) {
                                list_favo.get(i).setmDisplayName(newName);
                                list_favo.get(i).setmPath(new_path.getAbsolutePath());
                                break;
                            }
                        }
                        for (int i = 0; i < list_data_all.size(); i++) {
                            if (list_data_all.get(i).getmPath().equals(list_data.get(renamepos).getmPath())) {
                                list_data_all.get(i).setmDisplayName(newName);
                                list_data_all.get(i).setmPath(new_path.getAbsolutePath());
                            }

                        }
                        savelistfavo(list_favo);
                        savelistdata(list_data);
                        savelisthist(list_hist);
                        UtilsVideo.playlistdatarenama(SelectPlaylistActivity.this, edit_item_path, new_path, newName);
                        VideoInfo video_model = list_data.get(renamepos);
                        video_model.setmDisplayName(newName);
                        video_model.setmPath(new_path.getAbsolutePath());
                       /* list_data.get(renamepos).setmPath(file_original.getAbsolutePath());
                        list_data.get(renamepos).setmDisplayName(newName);*/
                        if (maniVideoPlayerActivity != null) {
                            maniVideoPlayerActivity.listalldataupdatefrg(list_data_all);
                        }
                        myAdaterSelectplaylist.updatelist(list_data);
                        setdataApdpter();


                    }
                }, 100);
            }

        }
    });

    public boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}