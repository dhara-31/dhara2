package com.si_videoplayer.gautm_videoplayer.mycl;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.si_videoplayer.gautm_videoplayer.Floating.DviddecgtmApplication;


public class GoviddecgtmAs {


    private AviddetInterface calviddecgtmck;
    public static Integer counviddecgtmall = 0;
    public InterstitialAd mInterstitialAviddecgtm1;
    private static GoviddecgtmAs ourInstance;
    private InterstitialAd mInviddecgtmter2;
    public static Integer countviddecgtmnter = 0;
    public static Integer countmInterstitialAd_D2 = 0;
    private long mLastClickTime1 = 0;
    private AdView AdVieviddecgtmner;

    private AdSize getAviddecgtmze(Activity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }


    @SuppressLint("MissingPermission")
    public void ShowBanner(Activity activity, FrameLayout banner) {
        AppvidDetail detailApp = DviddecgtmApplication.getInstance().getAppDetail();
        if (detailApp != null && detailApp.getAdmobbanner() != null && !TextUtils.isEmpty(detailApp.getAdmobbanner()) && detailApp.getAdstatus().equalsIgnoreCase("1")) {
            AdVieviddecgtmner = new AdView(activity);
            AdVieviddecgtmner.setAdSize(getAviddecgtmze(activity));
            AdVieviddecgtmner.setAdUnitId(detailApp.getAdmobbanner());
            AdRequest adRequest = new AdRequest.Builder().build();
            AdVieviddecgtmner.loadAd(adRequest);

            AdVieviddecgtmner.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    banner.addView(AdVieviddecgtmner);
                    super.onAdLoaded();
                }

                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    loaviddecgtmnner2(activity, banner);
                }
            });

        } else {
            loaviddecgtmnner2(activity, banner);
        }
    }

    public void loaviddecgtmnner2(Activity activity, FrameLayout banner) {
        AppvidDetail detailApp = DviddecgtmApplication.getInstance().getAppDetail();
        if (detailApp != null && detailApp.getAdmob2banner() != null && !TextUtils.isEmpty(detailApp.getAdmob2banner())
                && detailApp.getAdstatus().equalsIgnoreCase("1")) {
            AdView AdViewBanner2 = new AdView(activity);
            AdViewBanner2.setAdSize(getAviddecgtmze(activity));
            AdViewBanner2.setAdUnitId(detailApp.getAdmob2banner());
            AdRequest adRequest = new AdRequest.Builder().build();
            AdViewBanner2.loadAd(adRequest);
            AdViewBanner2.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {

                    banner.addView(AdViewBanner2);
                    super.onAdLoaded();
                }

                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    banner.setVisibility(View.INVISIBLE);

                }
            });
        } else {
            banner.setVisibility(View.INVISIBLE);
        }
    }

    public interface AviddetInterface {
        void abrttall();
    }

    public static GoviddecgtmAs getInstance() {
        if (ourInstance == null) {
            ourInstance = new GoviddecgtmAs();
        }
        return ourInstance;
    }

    public void showinter(Activity context, AviddetInterface _myCallback) {

        if (SystemClock.elapsedRealtime() - mLastClickTime1 < 700) {
            return;
        }

        mLastClickTime1 = SystemClock.elapsedRealtime();
        this.calviddecgtmck = _myCallback;

        try {

            counviddecgtmall = counviddecgtmall + 1;
            AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();

            if (appDetail != null) {

                this.calviddecgtmck = _myCallback;

                if (SplashActivity.valueintgtDD == 0) {
                    if (mInterstitialAviddecgtm1 != null) {
                        mInterstitialAviddecgtm1.show(context);
                        counviddecgtmall = 0;
                        SplashActivity.valueintgtDD = 1;
                    } else if (mInviddecgtmter2 != null) {
                        mInviddecgtmter2.show(context);
                        counviddecgtmall = 0;
                        SplashActivity.valueintgtDD = 1;
                    } else {

                        if (mInviddecgtmter2 == null) {
                            if (mInterstitialAviddecgtm1 == null) {
                                countmInterstitialAd_D2++;
                                if (countmInterstitialAd_D2 >= 2) {
                                    SplashActivity.valueintgtDD = 1;
                                    countmInterstitialAd_D2 = 0;
                                    mInviddecgtmter2 = null;

                                    if (DviddecgtmApplication.c().interviddecgtme != 2) {
                                        loadviddecgtmmmm2(context);
                                    }
                                }
                            }
                        }

                        if (calviddecgtmck != null) {
                            calviddecgtmck.abrttall();
                            calviddecgtmck = null;
                        }
                    }

                } else {

                    if (DviddecgtmApplication.c().interviddecgtme == 2) {
                        if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                            if (mInterstitialAviddecgtm1 == null) {
                                loadviddecgtm(context);
                            }
                        } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                            if (mInviddecgtmter2 == null) {
                                loadviddecgtmmmm2(context);
                            }
                        }
                        DviddecgtmApplication.c().interviddecgtme = 1;
                    }


                    if (appDetail.getCounter() != null && Integer.parseInt(appDetail.getCounter()) <= 1) {
                        counviddecgtmall = Integer.parseInt(appDetail.getCounter()) + 2;
                    }


                    if (counviddecgtmall >= Integer.parseInt(appDetail.getCounter())) {

                        if (mInterstitialAviddecgtm1 != null) {
                            mInterstitialAviddecgtm1.show(context);
                            counviddecgtmall = 0;
                        } else if (mInviddecgtmter2 != null) {
                            counviddecgtmall = 0;
                            mInviddecgtmter2.show(context);
                            countmInterstitialAd_D2 = 0;

                            if (mInterstitialAviddecgtm1 == null) {
                                countviddecgtmnter++;
                                if (countviddecgtmnter >= 5) {
                                    countviddecgtmnter = 0;
                                    mInterstitialAviddecgtm1 = null;
                                    loadviddecgtm(context);
                                }
                            }
                        } else {

                            if (calviddecgtmck != null) {
                                calviddecgtmck.abrttall();
                                calviddecgtmck = null;
                            }

                            if (mInterstitialAviddecgtm1 == null) {
                                countviddecgtmnter++;
                                if (countviddecgtmnter >= 5) {
                                    countviddecgtmnter = 0;
                                    mInterstitialAviddecgtm1 = null;
                                    loadviddecgtm(context);
                                }
                            }

                            if (mInviddecgtmter2 == null) {
                                countmInterstitialAd_D2++;
                                if (countmInterstitialAd_D2 >= 5) {
                                    countmInterstitialAd_D2 = 0;
                                    mInviddecgtmter2 = null;
                                    loadviddecgtmmmm2(context);
                                }
                            }
                        }

                    } else {
                        if (calviddecgtmck != null) {
                            calviddecgtmck.abrttall();
                            calviddecgtmck = null;
                        }
                    }
                }

            } else {

                if (calviddecgtmck != null) {
                    calviddecgtmck.abrttall();
                    calviddecgtmck = null;
                }
            }
        } catch (Exception e) {
            if (calviddecgtmck != null) {
                calviddecgtmck.abrttall();
                calviddecgtmck = null;
            }
        }
    }

    public void loadviddecgtm(final Activity context) {
        AdRequest adRequest = new AdRequest.Builder().build();
        AppvidDetail detailApp = DviddecgtmApplication.getInstance().getAppDetail();
        if (detailApp != null) {
            if (detailApp != null && detailApp.getAdstatus().equalsIgnoreCase("1") && detailApp.getAdmobinter() != null && !TextUtils.isEmpty(detailApp.getAdmobinter())) {
                InterstitialAd.load(context, detailApp.getAdmobinter(), adRequest, new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAviddecgtm1 = interstitialAd;
                        countviddecgtmnter = 0;

                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {

                                mInterstitialAviddecgtm1 = null;
                                loadviddecgtm(context);
                                if (calviddecgtmck != null) {
                                    calviddecgtmck.abrttall();
                                    calviddecgtmck = null;
                                }
                                SplashActivity.apgtDopenD = true;
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                mInterstitialAviddecgtm1 = null;
                                SplashActivity.apgtDopenD = true;
                                if (calviddecgtmck != null) {
                                    calviddecgtmck.abrttall();
                                    calviddecgtmck = null;
                                }
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                countviddecgtmnter = 0;
                                SplashActivity.apgtDopenD = false;
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        mInterstitialAviddecgtm1 = null;
                    }
                });
            }
        }
    }

    public void loadviddecgtmmmm2(final Activity context) {
        AdRequest adRequest = new AdRequest.Builder().build();
        AppvidDetail detailApp = DviddecgtmApplication.getInstance().getAppDetail();

        if (detailApp != null) {
            if (detailApp != null && detailApp.getAdstatus().equalsIgnoreCase("1") && detailApp.getAdmob2interstitial() != null && !TextUtils.isEmpty(detailApp.getAdmob2interstitial())) {

                InterstitialAd.load(context, detailApp.getAdmob2interstitial(), adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                mInviddecgtmter2 = interstitialAd;
                                countmInterstitialAd_D2 = 0;

                                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {


                                        mInviddecgtmter2 = null;
                                        loadviddecgtmmmm2(context);

                                        if (calviddecgtmck != null) {
                                            calviddecgtmck.abrttall();
                                            calviddecgtmck = null;
                                        }
                                        SplashActivity.apgtDopenD = true;
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                                        mInviddecgtmter2 = null;
                                        SplashActivity.apgtDopenD = true;
                                        if (calviddecgtmck != null) {
                                            calviddecgtmck.abrttall();
                                            calviddecgtmck = null;
                                        }
                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {
                                        countmInterstitialAd_D2 = 0;
                                        SplashActivity.apgtDopenD = false;
                                    }
                                });
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                mInviddecgtmter2 = null;
                            }
                        });
            }

        }
    }


}
