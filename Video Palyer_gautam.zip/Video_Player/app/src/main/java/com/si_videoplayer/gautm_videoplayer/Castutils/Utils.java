package com.si_videoplayer.gautm_videoplayer.Castutils;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.widget.Toast;

import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import kotlin.TypeCastException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

public class Utils {
    private static long currentPosition;
    private static long duration;
    private static Handler handler;
    private static boolean isConnected;
    public static CastSession mCastSession;
    public static SessionManagerListener<CastSession> mSessionManagerListener;
    private static Toast mToast;
    private static int position;
    private static RemoteMediaClient remoteMediaClient;
    private static Runnable runnable;
    private static boolean sb_user;
    public static final Companion Companion = new Companion(null);
    private static String context = "Image";
    private static String videoName = "";
    private static String new_path = "";

    public static String findIPAddress(Context context) {
        Intrinsics.checkParameterIsNotNull(context, "context");
        Object systemService = context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (systemService != null) {
            WifiManager wifiManager = (WifiManager) systemService;
            try {
                if (wifiManager.getConnectionInfo() == null) {
                    return null;
                }
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                ByteBuffer order = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
                Intrinsics.checkExpressionValueIsNotNull(wifiInfo, "wifiInfo");
                InetAddress byAddress = InetAddress.getByAddress(order.putInt(wifiInfo.getIpAddress()).array());
                Intrinsics.checkExpressionValueIsNotNull(byAddress, "InetAddress.getByAddress…y()\n                    )");
                return byAddress.getHostAddress();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        } else {
            throw new TypeCastException("null cannot be cast to non-null type android.net.wifi.WifiManager");
        }
    }


    public static final class Companion {
        private Companion() {
        }

        public  Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }

        public final boolean isConnected() {
            return Utils.isConnected;
        }

        public final void setConnected(boolean z) {
            Utils.isConnected = z;
        }

        public final long getDuration() {
            return Utils.duration;
        }

        public final void setDuration(long j) {
            Utils.duration = j;
        }

        public final String getContext() {
            return Utils.context;
        }

        public final void setContext(String str) {
            Intrinsics.checkParameterIsNotNull(str, "<set-?>");
            Utils.context = str;
        }

        public final String getVideoName() {
            return Utils.videoName;
        }

        public final void setVideoName(String str) {
            Intrinsics.checkParameterIsNotNull(str, "<set-?>");
            Utils.videoName = str;
        }

        public final String getNew_path() {
            return Utils.new_path;
        }

        public final void setNew_path(String str) {
            Intrinsics.checkParameterIsNotNull(str, "<set-?>");
            Utils.new_path = str;
        }

        public final boolean getSb_user() {
            return Utils.sb_user;
        }

        public final void setSb_user(boolean z) {
            Utils.sb_user = z;
        }

        public final Runnable getRunnable() {
            return Utils.runnable;
        }

        public final void setRunnable(Runnable runnable) {
            Utils.runnable = runnable;
        }

        public final Handler getHandler() {
            return Utils.handler;
        }

        public final void setHandler(Handler handler) {
            Utils.handler = handler;
        }

        public final Toast getMToast() {
            return Utils.mToast;
        }

        public final void setMToast(Toast toast) {
            Utils.mToast = toast;
        }

        public final int getPosition() {
            return Utils.position;
        }

        public final void setPosition(int i) {
            Utils.position = i;
        }

        public final long getCurrentPosition() {
            return Utils.currentPosition;
        }

        public final void setCurrentPosition(long j) {
            Utils.currentPosition = j;
        }

        public final RemoteMediaClient getRemoteMediaClient() {
            return Utils.remoteMediaClient;
        }

        public final void setRemoteMediaClient(RemoteMediaClient remoteMediaClient) {
            Utils.remoteMediaClient = remoteMediaClient;
        }

        public final CastSession getMCastSession() {
            CastSession castSession = Utils.mCastSession;
            if (castSession == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mCastSession");
            }
            return castSession;
        }

        public final void setMCastSession(CastSession castSession) {
            Intrinsics.checkParameterIsNotNull(castSession, "<set-?>");
            Utils.mCastSession = castSession;
        }

        public final SessionManagerListener<CastSession> getMSessionManagerListener() {
            SessionManagerListener<CastSession> sessionManagerListener = Utils.mSessionManagerListener;
            if (sessionManagerListener == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mSessionManagerListener");
            }
            return sessionManagerListener;
        }

        public final void setMSessionManagerListener(SessionManagerListener<CastSession> sessionManagerListener) {
            Intrinsics.checkParameterIsNotNull(sessionManagerListener, "<set-?>");
            Utils.mSessionManagerListener = sessionManagerListener;
        }

        public final void setUpCastListener(Context context) {
            Intrinsics.checkParameterIsNotNull(context, "context");
            setMSessionManagerListener(new CompanionsetUpCastListener(context));
        }

    }
}
