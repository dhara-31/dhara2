package com.si_videoplayer.gautm_videoplayer.Adapter;

import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.alertDialog;
import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.remoteMediaClient;
import static com.si_videoplayer.gautm_videoplayer.Castutils.Utils.mCastSession;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.mediarouter.app.MediaRouteButton;
import androidx.mediarouter.media.MediaRouter;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;

import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.MYRoutr;
import com.si_videoplayer.gautm_videoplayer.R;


import java.util.ArrayList;


public class MyAdaterCastlist extends RecyclerView.Adapter<MyAdaterCastlist.Dataview> {

    ArrayList<MYRoutr> list;
    Context context;

    public MyAdaterCastlist(Context videoShowActivity, ArrayList<MYRoutr> list) {
        context = videoShowActivity;
        this.list = list;

    }

    public void updatelist(ArrayList<MYRoutr> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Dataview onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Dataview(LayoutInflater.from(context).inflate(R.layout.item_set_cast, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Dataview holder, @SuppressLint("RecyclerView") int position) {
        final MYRoutr chromecastListModel = this.list.get(position);

        CastButtonFactory.setUpMediaRouteButton(this.context, holder.mrb_media_route);


        if (chromecastListModel != null) {
            holder.txt_name.setText(chromecastListModel.getRoute().getName());
        }
        if (chromecastListModel != null) {

            if (chromecastListModel.getRoute().getConnectionState() != MediaRouter.RouteInfo.CONNECTION_STATE_CONNECTED) {
                holder.txt_conn_status.setText("Connect");
            } else if (mCastSession != null) {
                if (mCastSession.isConnected()) {
                    holder.txt_conn_status.setText("Connected");
                } else if (mCastSession.isConnecting()) {
                    holder.txt_conn_status.setText("Connecting");
                }
            }

        }
        if (chromecastListModel.getRoute().isConnecting()) {
            holder.txt_conn_status.setText("Connecting");
        }

        holder.relative_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.txt_conn_status.getText().equals("Connect")) {

                    alertDialog.setCancelable(false);
                    if (Constants.mediaRouter != null) {
                        Constants.mediaRouter.selectRoute(chromecastListModel.getRoute());
                        holder.mrb_media_route.setVisibility(View.VISIBLE);

                    }
                    Constants.cast_name=chromecastListModel.getRoute().getName();
                    holder.txt_conn_status.setText("Connecting");
                    return;
                }else {
                    alertDialog.setCancelable(true);
                }

                if (remoteMediaClient != null) {
                    remoteMediaClient.stop();

                }
                CastContext.getSharedInstance(context).getSessionManager().endCurrentSession(true);
                holder.txt_conn_status.setText("Connect");

            }
        });


    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    class Dataview extends RecyclerView.ViewHolder {


        TextView txt_name, txt_conn_status;
        MediaRouteButton mrb_media_route;
        RelativeLayout relative_item;

        public Dataview(@NonNull View itemView) {
            super(itemView);

            txt_name = itemView.findViewById(R.id.txt_name);
            txt_conn_status = itemView.findViewById(R.id.txt_conn_status);
            mrb_media_route = itemView.findViewById(R.id.mrb_media_route);
            relative_item = itemView.findViewById(R.id.relative_item);
        }
    }

}
