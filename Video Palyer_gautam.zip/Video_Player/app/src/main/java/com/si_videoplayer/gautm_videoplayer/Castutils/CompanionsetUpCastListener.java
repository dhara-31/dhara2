package com.si_videoplayer.gautm_videoplayer.Castutils;

import static com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants.alertDialog;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.si_videoplayer.gautm_videoplayer.Activity.CastvideoActivity;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;

import kotlin.jvm.internal.Intrinsics;

public class CompanionsetUpCastListener implements SessionManagerListener<CastSession> {


    final Context context;
    static int count=0;

    public CompanionsetUpCastListener(Context captured_local_variable$0) {
        this.context = captured_local_variable$0;
    }

    public void onSessionStarted(CastSession session, String p1) {
        Intrinsics.checkParameterIsNotNull(session, "session");
        Intrinsics.checkParameterIsNotNull(p1, "p1");
        onApplicationConnected(session);
    }

    public void onSessionResumeFailed(CastSession p0, int p1) {
        Toast mToast;
        Intrinsics.checkParameterIsNotNull(p0, "p0");
        onApplicationDisconnected();
        if (!(Utils.Companion.getMToast() == null || (mToast = Utils.Companion.getMToast()) == null)) {
            mToast.cancel();
        }

        Utils.Companion.setMToast(Toast.makeText(this.context, "Failed to Connect Please Try Again", Toast.LENGTH_LONG));
        Toast mToast2 = Utils.Companion.getMToast();
        if (mToast2 != null) {
            mToast2.show();
        }
    }

    public void onSessionEnded(CastSession p0, int p1) {
        Toast mToast;
        Intrinsics.checkParameterIsNotNull(p0, "p0");
        onApplicationDisconnected();
        if (!(Utils.Companion.getMToast() == null || (mToast = Utils.Companion.getMToast()) == null)) {
            mToast.cancel();
        }



        Utils.Companion.setMToast(Toast.makeText(this.context, "Disconnected", Toast.LENGTH_LONG));

        if (Constants.activityset!=null){
            Constants.activityset.finish();
            count=0;
        }
        Toast mToast2 = Utils.Companion.getMToast();
        if (mToast2 != null) {
            mToast2.show();
        }
    }

    public void onSessionResumed(CastSession session, boolean p1) {
        Intrinsics.checkParameterIsNotNull(session, "session");
        onApplicationConnected(session);
    }

    public void onSessionStartFailed(CastSession p0, int p1) {
        Toast mToast;
        Intrinsics.checkParameterIsNotNull(p0, "p0");
        onApplicationDisconnected();
        if (!(Utils.Companion.getMToast() == null || (mToast = Utils.Companion.getMToast()) == null)) {
            mToast.cancel();
        }
        alertDialog.setCancelable(true);
        Utils.Companion.setMToast(Toast.makeText(this.context, "Failed to Connect Please Try Again", Toast.LENGTH_LONG));
        Toast mToast2 = Utils.Companion.getMToast();
        if (mToast2 != null) {
            mToast2.show();
        }
    }

    public void onSessionSuspended(CastSession p0, int p1) {
        Intrinsics.checkParameterIsNotNull(p0, "p0");
    }

    public void onSessionStarting(CastSession p0) {
        Intrinsics.checkParameterIsNotNull(p0, "p0");
    }

    public void onSessionResuming(CastSession p0, String p1) {
        Intrinsics.checkParameterIsNotNull(p0, "p0");
        Intrinsics.checkParameterIsNotNull(p1, "p1");
    }

    public void onSessionEnding(CastSession p0) {
        Intrinsics.checkParameterIsNotNull(p0, "p0");
    }

    private final void onApplicationConnected(CastSession castSession) {
        Toast mToast;
        Toast mToast2;
        Utils.Companion.setConnected(true);

        if (castSession != null) {
            Utils.Companion.setMCastSession(castSession);
            if (!(Utils.Companion.getMToast() == null || (mToast2 = Utils.Companion.getMToast()) == null)) {
                mToast2.cancel();
            }
            if (count==0){
                count++;
                Intent intent = new Intent(context, CastvideoActivity.class);
                context.startActivity(intent);
            }
            if (Constants.myAdaterCastlist2 != null) {
                Constants.myAdaterCastlist2.notifyDataSetChanged();
            }
            if (Constants.alertDialog!=null){
                if (Constants.alertDialog.isShowing()){
                    Constants.alertDialog.dismiss();
                }
            }

            ActivityCompat.invalidateOptionsMenu((Activity) this.context);
            return;
        }
        if (Utils.Companion.getRemoteMediaClient() != null) {
            RemoteMediaClient remoteMediaClient = Utils.Companion.getRemoteMediaClient();
            if (remoteMediaClient == null) {
                Intrinsics.throwNpe();
            }
            remoteMediaClient.stop();
        }
        CastContext castContext = CastContext.getSharedInstance(this.context);
        Intrinsics.checkExpressionValueIsNotNull(castContext, "CastContext.getSharedInstance(context)");
        SessionManager mSessionManager = castContext.getSessionManager();
        Intrinsics.checkExpressionValueIsNotNull(mSessionManager, "castContext.sessionManager");
        mSessionManager.endCurrentSession(true);
        if (!(Utils.Companion.getMToast() == null || (mToast = Utils.Companion.getMToast()) == null)) {
            mToast.cancel();
        }
        alertDialog.setCancelable(true);
        Utils.Companion.setMToast(Toast.makeText(this.context, "Failed to Connect Please Try Again", Toast.LENGTH_LONG));
        Toast mToast4 = Utils.Companion.getMToast();
        if (mToast4 != null) {
            mToast4.show();
        }
    }

    private final void onApplicationDisconnected() {
        Utils.Companion.setConnected(false);
        ActivityCompat.invalidateOptionsMenu((Activity) this.context);
        if (Constants.myAdaterCastlist2 != null) {
            Constants.myAdaterCastlist2.notifyDataSetChanged();
        }
    }
}
