

package com.si_videoplayer.gautm_videoplayer.Floating;

import android.app.Activity;
import android.app.Application;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.mycl.AppvidDetail;
import com.si_videoplayer.gautm_videoplayer.mycl.DetailAds;
import com.si_videoplayer.gautm_videoplayer.Equalizer.DviddecgtmAppOpen;

import java.util.ArrayList;

public class DviddecgtmApplication extends Application implements Application.ActivityLifecycleCallbacks {


    public static boolean isSplviddecgtmnissh = false;

    public static String splashviddecgtmname = "SplashActivity";

    public Integer opviddecgtmlue = 0;

    public Integer interviddecgtme = 0;

    private static DviddecgtmApplication ourInstaviddecgtme;

    public SharedPreferences prefeviddecgtmces;

    public static DviddecgtmApplication getInstance() {
        return ourInstaviddecgtme;
    }

    public static final String MyPREFERENCES = "MyAdsPrefs";
    private static final String PREF_APP_DETAILS = "app_details", PREF_ADS_DETAILS = "ads_details";

    private ArrayList<DetailAds> detailAds;

    public static DviddecgtmAppOpen appOviddecgtmger;

    public static DviddecgtmApplication c() {
        return ourInstaviddecgtme;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ourInstaviddecgtme = this;
        registerActivityLifecycleCallbacks(this);

        prefeviddecgtmces = getApplicationContext().getSharedPreferences(MyPREFERENCES, MODE_PRIVATE);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
    }


    public void inividdecgtmo() {
        appOviddecgtmger = new DviddecgtmAppOpen(this);
    }


    public AppvidDetail getAppDetail() {
        return new Gson().fromJson(prefeviddecgtmces.getString(PREF_APP_DETAILS, ""), AppvidDetail.class);
    }

    public void setAppDetail(AppvidDetail appDetail) {
        prefeviddecgtmces.edit().putString(PREF_APP_DETAILS, new Gson().toJson(appDetail)).apply();
    }

    public ArrayList<DetailAds> getAdsDetails() {
        return new Gson().fromJson(prefeviddecgtmces.getString(PREF_ADS_DETAILS, ""), new TypeToken<ArrayList<DetailAds>>() {
        }.getType());
    }

    public void setAdsDetails(ArrayList<DetailAds> adsDetails) {
        this.detailAds = adsDetails;
        prefeviddecgtmces.edit().putString(PREF_ADS_DETAILS, new Gson().toJson(adsDetails)).apply();
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {

        try {


            if (activity != null && !activity.toString().contains("SplashActivity")) {
                if (appOviddecgtmger == null) {
                    appOviddecgtmger = new DviddecgtmAppOpen(this);
                    opviddecgtmlue = 2;
                    interviddecgtme = 2;
                }
            }
        } catch (Exception e) {

        }
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {

    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {

    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {

    }
}
