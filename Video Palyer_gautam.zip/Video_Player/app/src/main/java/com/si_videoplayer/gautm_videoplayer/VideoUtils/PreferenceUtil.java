package com.si_videoplayer.gautm_videoplayer.VideoUtils;

import android.content.Context;
import android.content.SharedPreferences;

import com.si_videoplayer.gautm_videoplayer.R;

public class PreferenceUtil {

    private final SharedPreferences SP;
    public Context context;


    public PreferenceUtil(Context mContext) {
        context = mContext;
        SP = mContext.getSharedPreferences(mContext.getResources().getString(R.string.app_name), Context.MODE_MULTI_PROCESS);
    }

    public Context getContext() {
        return this.context;
    }

    public SharedPreferences.Editor getEditor() {
        return SP.edit();
    }

    public void putString(String key, String value) {
        getEditor().putString(key, value).commit();
    }

    public String getString(String key, String defValue) {
        return SP.getString(key, defValue);
    }

    public void putInt(String key, int value) {
        getEditor().putInt(key, value).commit();
    }

    public int getInt(String key, int defValue) {
        return SP.getInt(key, defValue);
    }
    public void putLong(String key, long value) {
        getEditor().putLong(key, value).commit();
    }

    public long getLong(String key) {
        return SP.getLong(key, 0l);
    }

    public void putBoolean(String key, boolean value) {
        getEditor().putBoolean(key, value).commit();
    }

    public boolean getBoolean(String key, boolean defValue) {
        return SP.getBoolean(key, defValue);
    }
}
