package com.si_videoplayer.gautm_videoplayer.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MyVideoplaylistAdpter  extends RecyclerView.Adapter<MyVideoplaylistAdpter.Dataplay_list>{

    Context context;
    ArrayList<VideoInfo> list_play;
    private Gson gson;
    PreferenceUtil preferenceUtil;
    private ArrayList<VideoInfo> temp_song_size=new ArrayList<>();
    Click_add click_add;

    public MyVideoplaylistAdpter(FragmentActivity activity, ArrayList<VideoInfo> list_play,Click_add click_add) {
        context=activity;
        this.list_play=list_play;
        preferenceUtil=new PreferenceUtil(context);
        gson=new Gson();
        this.click_add=click_add;
    }

    @NonNull
    @Override
    public Dataplay_list onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Dataplay_list(LayoutInflater.from(context).inflate(R.layout.play_list_view,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull Dataplay_list holder, @SuppressLint("RecyclerView") int position) {
        temp_song_size.clear();
        String json1Null11 = gson.toJson(temp_song_size);
        String json11 = preferenceUtil.getString(list_play.get(position).getList_name(), json1Null11);
        Type type11 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();
        temp_song_size = gson.fromJson(json11, type11);
        try {
            Glide.with(context).load(temp_song_size.get(temp_song_size.size()-1).getmPath()).apply(new RequestOptions().placeholder(R.drawable.vi_playlist_thu)).thumbnail(0.1f).override(350, 350).transition(new DrawableTransitionOptions().crossFade()).into(holder.song_thumbnail_img);
        }catch (Exception e){
            Glide.with(context).load(R.drawable.vi_playlistic_frg).into(holder.song_thumbnail_img);
        }
        String json = gson.toJson(temp_song_size);
        preferenceUtil.putString(list_play.get(position).getList_name(),json);

        holder.atp_song_size_txt.setText(String.valueOf(temp_song_size.size()) + " " + "Video");
        holder.atp_song_size_txt.setSelected(true);
        holder.atp_name_txt.setText(list_play.get(position).getList_name());
        holder.img_add_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                click_add.Datasetto_add(list_play.get(position).getList_name(),true);
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                click_add.Datasetto_add(list_play.get(position).getList_name(),false);

            }
        });


    }

    @Override
    public int getItemCount() {
        return list_play.size();
    }

    public void updatelist(ArrayList<VideoInfo> list_play) {
        this.list_play=list_play;
        notifyDataSetChanged();
    }
    public interface Click_add{
        void Datasetto_add(String name,boolean select);
    }

    class Dataplay_list extends RecyclerView.ViewHolder {


        ImageView song_thumbnail_img,img_add_video;
        TextView atp_name_txt, atp_song_size_txt;

        public Dataplay_list(@NonNull View itemView) {
            super(itemView);

            song_thumbnail_img = itemView.findViewById(R.id.song_thumbnail_img);
            atp_name_txt = itemView.findViewById(R.id.atp_name_txt);
            atp_song_size_txt = itemView.findViewById(R.id.atp_song_size_txt);
            img_add_video = itemView.findViewById(R.id.img_add_video);
        }
    }
}
