package com.si_videoplayer.gautm_videoplayer.Adapter;

import static com.si_videoplayer.gautm_videoplayer.Floating.FloatingService.floatingService;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.si_videoplayer.gautm_videoplayer.Activity.SelectPlaylistActivity;
import com.si_videoplayer.gautm_videoplayer.Activity.VideoShowActivity;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;

import com.si_videoplayer.gautm_videoplayer.VideoUtils.UtilsVideo;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.io.File;
import java.util.ArrayList;

public class MyAdaterSelectplaylist extends RecyclerView.Adapter<MyAdaterSelectplaylist.Dataviewset>{

    Context context;
    ArrayList<VideoInfo> list_select;
    ClickDatamune clickDatamune;
    int selectact;
    PreferenceUtil preferenceUtil;

    public MyAdaterSelectplaylist(SelectPlaylistActivity selectPlaylistActivity, ArrayList<VideoInfo> list_data, int aa, ClickDatamune clickDatamune) {
        context=selectPlaylistActivity;
        list_select=list_data;
        this.clickDatamune=clickDatamune;
        this.selectact=aa;
        preferenceUtil=new PreferenceUtil(context);
    }

    @NonNull
    @Override
    public Dataviewset onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Dataviewset(LayoutInflater.from(context).inflate(R.layout.item_layout_videoall,parent,false));

    }

    @Override
    public void onBindViewHolder(@NonNull Dataviewset holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(context).load(list_select.get(position).getmPath()).apply(new RequestOptions().placeholder(R.drawable.vi_video_place)).thumbnail(0.1f).override(350, 350).transition(new DrawableTransitionOptions().crossFade()).into(holder.iv_thumbnail);

        holder.tv_total_time.setText(UtilsVideo.formateMilliSeccond(list_select.get(position).getmDuration()));
        holder.tv_video_name.setText(list_select.get(position).getmDisplayName());
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                holder.tv_video_name.setSelected(true);
            }
        },2000);
        holder.tv_created_day.setText(UtilsVideo.readableFileSize(list_select.get(position).getmSize()) + "   " + UtilsVideo.convertLongToTime(new File(list_select.get(position).getmPath()).lastModified(), "dd-MM-yyyy"));
        String convertSolution = UtilsVideo.convertSolution(list_select.get(position).getmResolution());
        if (TextUtils.isEmpty(convertSolution)) {
            holder.tv_resolution_size.setVisibility(View.GONE);
        } else {
            holder.tv_resolution_size.setVisibility(View.VISIBLE);
            holder.tv_resolution_size.setText(convertSolution);
        }
        holder.tv_total_time.setText(UtilsVideo.formateMilliSeccond(list_select.get(position).getmDuration()));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (floatingService!=null){
                    floatingService.stopSelf();
                }
                Constants.play_pause=true;

                preferenceUtil.putInt(Constants.Current_Position, position);
                VideoShowActivity.list_data=new ArrayList<>();
                VideoShowActivity.list_data.addAll(list_select);



                GoviddecgtmAs.getInstance().showinter((Activity) context, new GoviddecgtmAs.AviddetInterface() {
                    @Override
                    public void abrttall() {

                        Intent intent=new Intent(context,VideoShowActivity.class);
                        context.startActivity(intent);
                    }
                });


            }
        });
        holder.iv_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                clickDatamune.itemclickpos(list_select.get(position).getmPath(),position,selectact);

            }
        });
    }

    @Override
    public int getItemCount() {
        return list_select.size();
    }

    public void updatelist(ArrayList<VideoInfo> list_data) {
        list_select=list_data;
        notifyDataSetChanged();
    }

    public interface ClickDatamune{
        void itemclickpos(String s,int pos,int selectatc);
    }

    class  Dataviewset extends RecyclerView.ViewHolder {

        ImageView iv_thumbnail;
        ImageView iv_more;
        TextView tv_total_time, tv_video_name, tv_created_day, tv_resolution_size;

        public Dataviewset(@NonNull View itemView) {
            super(itemView);

            iv_thumbnail = itemView.findViewById(R.id.iv_thumbnail);
            iv_more = itemView.findViewById(R.id.iv_more);
            tv_total_time = itemView.findViewById(R.id.tv_total_time);
            tv_video_name = itemView.findViewById(R.id.tv_video_name);
            tv_created_day = itemView.findViewById(R.id.tv_created_day);
            tv_resolution_size = itemView.findViewById(R.id.tv_resolution_size);
        }
    }

    public boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

}
