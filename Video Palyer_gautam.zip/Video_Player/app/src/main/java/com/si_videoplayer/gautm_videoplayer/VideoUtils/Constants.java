package com.si_videoplayer.gautm_videoplayer.VideoUtils;


import static android.content.Context.AUDIO_SERVICE;
import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.mBtnPlayPause;
import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.mProgressBar;
import static com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity.mTxtSong;
import static com.si_videoplayer.gautm_videoplayer.Service.NotificationService.foregroundService;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;

import android.net.Uri;
import android.os.Handler;
import android.view.View;

import android.widget.RelativeLayout;

import androidx.core.content.FileProvider;
import androidx.mediarouter.media.MediaRouteSelector;
import androidx.mediarouter.media.MediaRouter;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.cast.CastMediaControlIntent;
import com.google.android.gms.cast.framework.CastContext;

import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import com.si_videoplayer.gautm_videoplayer.Adapter.MyAdaterCastlist;
import com.si_videoplayer.gautm_videoplayer.Model.MYRoutr;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.Service.NotificationService;
import com.si_videoplayer.gautm_videoplayer.Castutils.Utils;


import java.io.File;
import java.util.ArrayList;


public class Constants {
    public static final String KEY_PR_SROT = "sroting";
    public static final String Add_play_List = "play_list";
    public static final String Video_history_List = "history";
    public static final String Video_favo_List = "favourite";
    public static final String Current_Position = "currnr_posset";
    public static String path_delete;
    public static int position = -1;
    public static boolean play_pause = true;
    public static int video_speed = 5;
    public static final int REQUEST_CODE = 12112;
    public static int textColor = Color.BLACK;
    public static int themeColor = Color.BLACK;
    public static boolean Icon_equalizer_seek_set = false;
    public static ArrayList<String> list_folder_data = new ArrayList<>();
    public static ArrayList<VideoInfo> list_video_data = new ArrayList<>();
    public static boolean flip_mrrire = false;
    public static boolean play_list = false;
    public static String repeat = "none";
    public static boolean islock = false;
    public static boolean nigthmode = false;
    public static boolean Screenmode = false;
    public static ArrayList<VideoInfo> list_noti = new ArrayList<>();

    public static String cast_name;

    public static ArrayList<MYRoutr> list = new ArrayList<>();
    public static MediaRouter mediaRouter;
    public static RemoteMediaClient remoteMediaClient;
    public static CastContext mCastContext;
    public static Dialog alertDialog;
    public static MyAdaterCastlist myAdaterCastlist2;
    public static ArrayList<MYRoutr> chromecastLists = new ArrayList<>();
    public static ArrayList<MYRoutr> tempChromecastLists = new ArrayList<>();
    public static boolean videoactivityopen=false;
    public static boolean Foltingopen=false;
    public static boolean time_set_check=false;

    static ArrayList<String> testList = new ArrayList<>();
    public static MediaRouter.Callback callback;
    public static RelativeLayout relativ_recy_set;
    public static RelativeLayout relativ_shearch;
    public static Activity activityset;
    public static boolean timer = false;
    public static boolean timer_set_ok = false;

    public static boolean Speed_bottom = false;
    public static ArrayList<VideoInfo> backGroundPlayingList = new ArrayList<>();
    public static MediaPlayer mediaPlayer = new MediaPlayer();
    public static int backgroundPosition = 0;
    static PreferenceUtil preferenceUtil;
    private static boolean aset;
    private static AudioManager audioManager;

    public static void PlayFirstBackgroundVideo(Context context) {
        preferenceUtil = new PreferenceUtil(context);

        preferenceUtil.putInt(Constants.Current_Position,backgroundPosition);
        Uri videouri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", new File(backGroundPlayingList.get(backgroundPosition).getmPath()));
        if (mTxtSong != null) {
            mTxtSong.setText(backGroundPlayingList.get(backgroundPosition).getmDisplayName());
        }
        try {
            if (mediaPlayer != null) {
                mediaPlayer.pause();
                mediaPlayer.reset();
                mediaPlayer.release();
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(context, videouri);
            mediaPlayer.prepare();

            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                try {
                    mediaPlayer.seekTo((int) preferenceUtil.getLong(backGroundPlayingList.get(backgroundPosition).getmPath()));

                    if (mBtnPlayPause!=null) {
                        mBtnPlayPause.setImageResource(R.drawable.vi_pause_audio);
                    }

                    if (audioFocus(context)){
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    mediaPlayer.start();
                                }catch (Exception e){}
                            }
                        },100);
                    }
                    setpro(context);
                    updateNotification(context);
                }catch ( Exception e){}

                }
            });

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    NextBackgroundVideo(context);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void PlayBackgroundVideo(Context context) {

        mBtnPlayPause.setImageResource(R.drawable.vi_pause_audio);
        if (mediaPlayer != null) {
            if (!mediaPlayer.isPlaying()) {
                if (audioFocus(context)){
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                mediaPlayer.start();
                            }catch (Exception e){}

                        }
                    },100);
                }
                setpro(context);
            }
        }
        updateNotification(context);
    }

    public static void PauseBackgroundVideo(Context context) {

        preferenceUtil.putLong( backGroundPlayingList.get(preferenceUtil.getInt(Current_Position,0)).getmPath(),mediaPlayer.getCurrentPosition());
        mBtnPlayPause.setImageResource(R.drawable.vi_play_as_audio);
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                   mediaPlayer.pause();
            }
        }
        updateNotification(context);

    }

    public static void PreviousBackgroundVideo(Context context) {
        preferenceUtil = new PreferenceUtil(context);
        if (backgroundPosition != 0) {
            backgroundPosition--;

            preferenceUtil.putInt(Current_Position,backgroundPosition);
            Uri videouri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", new File(backGroundPlayingList.get(backgroundPosition).getmPath()));
            if (mTxtSong != null) {
                mTxtSong.setText(backGroundPlayingList.get(backgroundPosition).getmDisplayName());
            }
            try {
                if (mediaPlayer != null) {
                    mediaPlayer.pause();
                    mediaPlayer.reset();
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, videouri);
                mediaPlayer.prepare();

                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        try {
                            mediaPlayer.seekTo(0);
                            if (audioFocus(context)){
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            mediaPlayer.start();
                                        }catch (Exception e){}
                                    }
                                },100);
                            }
                            setpro(context);
                            if (mBtnPlayPause!=null) {
                                mBtnPlayPause.setImageResource(R.drawable.vi_pause_audio);
                            }
                            updateNotification(context);
                        }catch (Exception e){}


                    }
                });
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        NextBackgroundVideo(context);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public static void NextBackgroundVideo(Context context) {
        preferenceUtil = new PreferenceUtil(context);
        if (backgroundPosition < backGroundPlayingList.size() - 1) {
            backgroundPosition++;

            preferenceUtil.putInt(Constants.Current_Position,backgroundPosition);
            Uri videouri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", new File(backGroundPlayingList.get(backgroundPosition).getmPath()));
            if (mTxtSong != null) {
                mTxtSong.setText(backGroundPlayingList.get(backgroundPosition).getmDisplayName());
            }
            try {
                if (mediaPlayer != null) {
                    mediaPlayer.pause();
                    mediaPlayer.reset();
                    mediaPlayer.release();
                }

                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(context, videouri);
                mediaPlayer.prepare();

                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mediaPlayer) {
                        try {
                            mediaPlayer.seekTo(0);

                            if (audioFocus(context)){
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            mediaPlayer.start();
                                        }catch (Exception e){}

                                    }
                                },100);
                            }
                            setpro(context);
                            if (mBtnPlayPause!=null) {
                                mBtnPlayPause.setImageResource(R.drawable.vi_pause_audio);
                            }
                            updateNotification(context);
                        }catch (Exception e){}

                    }
                });
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        NextBackgroundVideo(context);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else {
            if (foregroundService!=null){
                foregroundService.stopNotification();
            }

        }

    }

    public static void setpro(Context context) {
        if (mProgressBar != null) {
            mProgressBar.setMax(mediaPlayer.getDuration());
        }
         aset = false;
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {

                if (aset==false) {
                    if (mProgressBar != null) {

                        mProgressBar.setProgress(mediaPlayer.getCurrentPosition());
                    }
                    handler.postDelayed(this::run, 1000);
                }else {
                    handler.removeCallbacks(this::run);
                }

            }
        };
        handler.postDelayed(runnable, 1000);

    }


    public static void updateNotification(Context context) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isMyServiceRunning(context, NotificationService.class)) {

                    Intent startIntent = new Intent(context, NotificationService.class);
                    startIntent.setAction(ACTION.STARTFOREGROUND_ACTION);
                    context.startService(startIntent);
                } else {
                    if (foregroundService != null)
                        foregroundService.showNotification();
                    else {
                        Intent startIntent = new Intent(context, NotificationService.class);
                        startIntent.setAction(ACTION.STARTFOREGROUND_ACTION);
                        context.startService(startIntent);
                    }
                }
            }
        }, 250);


    }


    public static void showDialog(Context context) {
        wifiConnected(context);
        alertDialog = new Dialog(context);
        alertDialog.setContentView(R.layout.dialog_cast);

        RecyclerView rv_device_list2 = (RecyclerView) alertDialog.findViewById(R.id.recy_cast);
        relativ_recy_set = alertDialog.findViewById(R.id.relativ_recy_set);
        relativ_shearch = alertDialog.findViewById(R.id.relativ_shearch);

        rv_device_list2.setLayoutManager(new GridLayoutManager(context, 1));
        MyAdaterCastlist myAdaterCastlist = new MyAdaterCastlist(context, chromecastLists);
        myAdaterCastlist2 = myAdaterCastlist;
        rv_device_list2.setAdapter(myAdaterCastlist);
        if (myAdaterCastlist.getItemCount() == 0) {
            relativ_shearch.setVisibility(View.VISIBLE);
            relativ_recy_set.setVisibility(View.GONE);
        } else {
            relativ_shearch.setVisibility(View.GONE);
            relativ_recy_set.setVisibility(View.VISIBLE);
        }
        startSearchForDevicesAndCast(context);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
    }

    private static void wifiConnected(Context context) {
        if (!((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getNetworkInfo(1).isConnected()) {
            chromecastLists = new ArrayList<>();
            try {
                if (Utils.Companion.getMCastSession() != null && Utils.Companion.getMCastSession().isConnected()) {
                    if (Utils.Companion.getRemoteMediaClient() != null) {
                        Utils.Companion.getRemoteMediaClient().stop();
                    }
                    CastContext.getSharedInstance(context).getSessionManager().endCurrentSession(true);
                    Utils.Companion.setConnected(false);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void startSearchForDevicesAndCast(Context context) {
        mediaRouter = null;
        MediaRouter instance = MediaRouter.getInstance(context);
        mediaRouter = instance;
        instance.getRoutes();
        MediaRouteSelector selector = new MediaRouteSelector.Builder().addControlCategory(CastMediaControlIntent.categoryForCast("C0868879")).build();

        if (callback != null) {
            mediaRouter.removeCallback(callback);
        }

        callback = new MediaRouter.Callback() {
            @Override
            public void onRouteAdded(MediaRouter router, MediaRouter.RouteInfo route) {
                super.onRouteAdded(router, route);
            }

            @Override
            public void onRouteChanged(MediaRouter router, MediaRouter.RouteInfo route) {
                super.onRouteChanged(router, route);
                MYRoutr chromecastListModel = new MYRoutr();
                chromecastListModel.setRoute(route);
                chromecastListModel.setMediaRouter(router);
                chromecastLists.add(chromecastListModel);
                for (int pos = 0; pos < chromecastLists.size(); pos++) {
                    String name = route.getName();
                    if (!testList.contains(name)) {
                        testList.add(name);
                        tempChromecastLists.add(new MYRoutr(router, route));
                    }
                }
                chromecastLists = new ArrayList<>(tempChromecastLists);
                if (myAdaterCastlist2 != null) {
                    myAdaterCastlist2.updatelist(chromecastLists);
                    myAdaterCastlist2.notifyDataSetChanged();
                }

                if (chromecastLists.size() == 0) {
                    relativ_shearch.setVisibility(View.VISIBLE);
                    relativ_recy_set.setVisibility(View.GONE);
                } else {
                    relativ_shearch.setVisibility(View.GONE);
                    relativ_recy_set.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onRouteSelected(MediaRouter router, MediaRouter.RouteInfo route) {
                super.onRouteSelected(router, route);
            }
        };

        mediaRouter.addCallback(selector, callback, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN);
        if (chromecastLists.size() == 0) {
            relativ_shearch.setVisibility(View.VISIBLE);
            relativ_recy_set.setVisibility(View.GONE);
        } else {
            relativ_shearch.setVisibility(View.GONE);
            relativ_recy_set.setVisibility(View.VISIBLE);
        }
    }


    public static boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }


    public interface ACTION {
        String PREV_ACTION = "action.prev";
        String PLAY_ACTION = "action.play";
        String NEXT_ACTION = "action.next";
        String STARTFOREGROUND_ACTION = "action.startforeground";
        String STOPFOREGROUND_ACTION = "action.stopforeground";
        String PAUSE_ACTION = "action.closeaction";

    }

    public interface NOTIFICATION_ID {
        int FOREGROUND_SERVICE = 101;
    }

    public static boolean audioFocus(Context context) {
        audioManager = (AudioManager) context.getSystemService(AUDIO_SERVICE);
        int result = audioManager.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            return true;
        }
        return false;
    }

    public static AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {

                    switch (focusChange) {

                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK):
                            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                                if (foregroundService!=null){
                                    PauseBackgroundVideo(foregroundService);
                                }


                            }
                            break;
                        case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT):
                            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                                if (foregroundService!=null){
                                    PauseBackgroundVideo(foregroundService);
                                }

                            }
                            break;

                        case (AudioManager.AUDIOFOCUS_LOSS):
                            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                                if (foregroundService!=null){
                                    PauseBackgroundVideo(foregroundService);
                                }
                            }


                            break;

                        case (AudioManager.AUDIOFOCUS_GAIN):

                            break;
                        default:
                            break;
                    }
                }
            };

}
