package com.si_videoplayer.gautm_videoplayer.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.si_videoplayer.gautm_videoplayer.Activity.SelectPlaylistActivity;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.io.File;
import java.util.ArrayList;

public class MyFolderAdpter  extends  RecyclerView.Adapter<MyFolderAdpter.DateviewFolder>{

    int viewset;
    Context context;
    ArrayList<String> videopath;
    ArrayList<VideoInfo> list_datafolder;
    Gson gson;

    public MyFolderAdpter(FragmentActivity activity, ArrayList<String> list_data_all, ArrayList<VideoInfo> list, int setview) {
        context=activity;
        videopath=list_data_all;
        viewset=setview;
        list_datafolder=list;
        gson=new Gson();
    }

    @NonNull
    @Override
    public DateviewFolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewset==1){
            return new DateviewFolder(LayoutInflater.from(context).inflate(R.layout.item_folder, parent, false));
        }else {
            return new DateviewFolder(LayoutInflater.from(context).inflate(R.layout.item_folder_2, parent, false));
        }
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull DateviewFolder holder, int position) {
        holder.item_folder_name.setText(videopath.get(position));
        holder.item_folder_total_video.setText(getvideocunter(videopath.get(position))+" Video");
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gson = new Gson();
                String json = gson.toJson(list_datafolder);
                Intent intent=new Intent(context, SelectPlaylistActivity.class);
                intent.putExtra("datashow",22);
                intent.putExtra("folder_name",videopath.get(position));
                intent.putExtra("data_all_folder_asasas",json);



                GoviddecgtmAs.getInstance().showinter((Activity) context, new GoviddecgtmAs.AviddetInterface() {
                    @Override
                    public void abrttall() {

                        context.startActivity(intent);

                                           }
                });



            }
        });
    }

    private int getvideocunter(String s) {
        int aa=0;
        for (int i = 0; i < list_datafolder.size(); i++) {

            if (s.equals(new File(list_datafolder.get(i).getmPath()).getParentFile().getName())){
                aa++;
            }

        }

        return aa;
    }


    @Override
    public int getItemCount() {
        return videopath.size();
    }

    public void listupdate(ArrayList<String> list, ArrayList<VideoInfo> videoInfos) {
        videopath=list;
        list_datafolder=videoInfos;
        notifyDataSetChanged();
    }

    class  DateviewFolder extends RecyclerView.ViewHolder {

        TextView item_folder_name, item_folder_total_video;
        ImageView img_folder;

        public DateviewFolder(@NonNull View itemView) {
            super(itemView);

            img_folder = itemView.findViewById(R.id.img_folder);
            item_folder_name = itemView.findViewById(R.id.item_folder_name);
            item_folder_total_video = itemView.findViewById(R.id.item_folder_total_video);
        }
    }
}
