package com.si_videoplayer.gautm_videoplayer.Equalizer;

import static androidx.lifecycle.Lifecycle.Event.ON_START;

import static com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.screenngtDer;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.si_videoplayer.gautm_videoplayer.Activity.MainActivity;
import com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity;
import com.si_videoplayer.gautm_videoplayer.Floating.DviddecgtmApplication;
import com.si_videoplayer.gautm_videoplayer.mycl.AppvidDetail;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;
import com.si_videoplayer.gautm_videoplayer.Castutils.Natviddecgtm2sAll;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class DviddecgtmAppOpen implements LifecycleObserver, Application.ActivityLifecycleCallbacks {

    public static String AviddecgtmUNIT = "";
    public static String AviddecgtmNIT2 = "";

    public static boolean doNotDisplviddecgtmay = false;
    private static boolean isShowinviddecgtm = false;

    private final DviddecgtmApplication myApplication;
    public static boolean fividdecgtmag = false;

    public static AppOpenAd appOpviddecgtm = null;

    public static AppOpenAd aviddecgtm2 = null;
    private Activity ruuningActivity;

    public static Activity Splasviddecgtmty;
    private AppOpenAd.AppOpenAdLoadCallback loadCallback;

    private long loadTimeLite = 0;
    private Integer faividdecgtmnt = 0;


    public DviddecgtmAppOpen(DviddecgtmApplication myApplication) {
        this.myApplication = myApplication;
        this.myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }


    public void getLoadOpviddecgtm2() {

        if (isAdAvailable2()) {
            return;
        }

        if (!doNotDisplviddecgtmay) {
            loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {
                    super.onAdLoaded(aviddecgtm2);

                    DviddecgtmAppOpen.this.aviddecgtm2 = ad;

                    DviddecgtmAppOpen.this.loadTimeLite = (new Date()).getTime();

                    if (fividdecgtmag) {

                        if (!DviddecgtmApplication.isSplviddecgtmnissh) {
                            showAdIfAvailable();

                            DviddecgtmApplication.isSplviddecgtmnissh = true;


                            AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();

                            if (appDetail != null && appDetail.getCounter() != null && !TextUtils.isEmpty(appDetail.getCounter())) {

                                if (Integer.parseInt(appDetail.getCounter()) > 1) {

                                    if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                                        GoviddecgtmAs.getInstance().loadviddecgtm(Splasviddecgtmty);
                                    } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                                        GoviddecgtmAs.getInstance().loadviddecgtmmmm2(Splasviddecgtmty);
                                    }
                                } else {
                                    GoviddecgtmAs.getInstance().loadviddecgtm(Splasviddecgtmty);
                                    GoviddecgtmAs.getInstance().loadviddecgtmmmm2(Splasviddecgtmty);
                                }
                            }

                            Natviddecgtm2sAll.getInstance().loadNaviddecgtmth(Splasviddecgtmty);
                        }
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);

                }
            };
            AdRequest request = getAdRequest();
            AppOpenAd.load(myApplication, AviddecgtmNIT2, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

        } else {
            doNotDisplviddecgtmay = false;
        }
    }


    public void getOpeviddecgtms() {

        if (isAdAvailable()) {
            return;
        }

        if (!doNotDisplviddecgtmay) {
            loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {




                    super.onAdLoaded(appOpviddecgtm);
                    faividdecgtmnt = 0;
                    DviddecgtmAppOpen.this.appOpviddecgtm = ad;
                    DviddecgtmAppOpen.this.loadTimeLite = (new Date()).getTime();

                    if (fividdecgtmag) {
                        if (!DviddecgtmApplication.isSplviddecgtmnissh) {

                            showAdIfAvailable();
                            DviddecgtmApplication.isSplviddecgtmnissh = true;

                            AppvidDetail appDetail = DviddecgtmApplication.getInstance().getAppDetail();

                            if (appDetail != null && appDetail.getCounter() != null && !TextUtils.isEmpty(appDetail.getCounter())) {
                                if (Integer.parseInt(appDetail.getCounter()) > 1) {
                                    if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                                        GoviddecgtmAs.getInstance().loadviddecgtm(Splasviddecgtmty);
                                    } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                                        GoviddecgtmAs.getInstance().loadviddecgtmmmm2(Splasviddecgtmty);
                                    }
                                } else {
                                    GoviddecgtmAs.getInstance().loadviddecgtm(Splasviddecgtmty);
                                    GoviddecgtmAs.getInstance().loadviddecgtmmmm2(Splasviddecgtmty);
                                }
                            }
                            Natviddecgtm2sAll.getInstance().loadNaviddecgtmth(Splasviddecgtmty);


                        }
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);

                    DviddecgtmAppOpen.AviddecgtmNIT2 = myApplication.getAppDetail().getAdmob2appopen();
                    if (appOpviddecgtm == null) {
                        myApplication.splashviddecgtmname = "SplashActivity";

                        if (aviddecgtm2 == null) {
                            if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmob2appopen() != null
                                    && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmob2appopen())) {
                                getLoadOpviddecgtm2();
                            }
                        }
                    }
                }
            };
            AdRequest request = getAdRequest();

            AppOpenAd.load(myApplication, AviddecgtmUNIT, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

        } else {
            doNotDisplviddecgtmay = false;
        }
    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }


    private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
        long dateDifference = (new Date()).getTime() - this.loadTimeLite;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * numHours));
    }

    public boolean isAdAvailable() {
        return appOpviddecgtm != null && wasLoadTimeLessThanNHoursAgo(4);
    }

    public boolean isAdAvailable2() {
        return aviddecgtm2 != null && wasLoadTimeLessThanNHoursAgo(4);
    }


    public void showAdIfAvailable() {

        if (!doNotDisplviddecgtmay) {
            if (!isShowinviddecgtm && isAdAvailable()) {
                if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.apgtDopenD == true) {

                    isShowinviddecgtm = true;
                    FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            DviddecgtmAppOpen.this.appOpviddecgtm = null;

                            isShowinviddecgtm = false;

                            if (fividdecgtmag) {


                                fividdecgtmag = false;
                                if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe == false) {
                                    com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe = true;
                                    openNextScreenPhoto();

                                    try {
                                        if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.handlgtDlash != null) {
                                            com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.handlgtDlash.removeCallbacks(com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.runnableSPlgtD);
                                        }
                                    } catch (Exception e) {
                                    }

                                }
                            }

                            if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmobnew() != null
                                    && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmobnew())) {
                                getOpeviddecgtms();
                            }

                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(AdError adError) {
                            isShowinviddecgtm = false;
                            if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe == false) {
                                com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe = true;
                                openNextScreenPhoto();
                            }
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                            isShowinviddecgtm = true;
                        }
                    };


                    appOpviddecgtm.setFullScreenContentCallback(fullScreenContentCallback);
                    appOpviddecgtm.show(ruuningActivity);
                }
            } else if (!isShowinviddecgtm && isAdAvailable2()) {

                if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.apgtDopenD == true) {

                    isShowinviddecgtm = true;
                    FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            DviddecgtmAppOpen.this.aviddecgtm2 = null;

                            isShowinviddecgtm = false;

                            if (fividdecgtmag) {
                                fividdecgtmag = false;

                                if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe == false) {
                                    com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe = true;
                                    openNextScreenPhoto();

                                    try {
                                        if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.handlgtDlash != null) {
                                            com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.handlgtDlash.removeCallbacks(com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.runnableSPlgtD);
                                        }
                                    } catch (Exception e) {
                                    }
                                }
                            }

                            if (appOpviddecgtm == null) {

                                if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmobnew() != null
                                        && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmobnew())) {
                                } else {
                                    if (aviddecgtm2 == null) {
                                        if (!fividdecgtmag) {
                                            if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmob2appopen() != null && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmob2appopen())) {
                                                getLoadOpviddecgtm2();
                                            }
                                        }
                                    }
                                }

                                faividdecgtmnt++;
                                if (faividdecgtmnt > 0) {
                                    faividdecgtmnt = 0;
                                    if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmobnew() != null
                                            && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmobnew())) {
                                        DviddecgtmAppOpen.this.aviddecgtm2 = null;
                                        getOpeviddecgtms();
                                    }

                                }
                            }
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(AdError adError) {
                            if (com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe == false) {
                                com.si_videoplayer.gautm_videoplayer.mycl.SplashActivity.valugtDe = true;
                                openNextScreenPhoto();
                            }

                        }

                        @Override
                        public void onAdShowedFullScreenContent() {

                            isShowinviddecgtm = true;
                        }
                    };
                    aviddecgtm2.setFullScreenContentCallback(fullScreenContentCallback);
                    aviddecgtm2.show(ruuningActivity);
                }
            } else {

                faividdecgtmnt++;
                if (appOpviddecgtm == null && aviddecgtm2 == null) {

                    if (DviddecgtmApplication.getInstance().opviddecgtmlue == 2) {
                        if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmobnew() != null
                                && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmobnew())) {

                            DviddecgtmAppOpen.AviddecgtmUNIT = myApplication.getAppDetail().getAdmobnew();
                            getOpeviddecgtms();
                            faividdecgtmnt = 0;
                            DviddecgtmApplication.getInstance().opviddecgtmlue = 1;
                        } else if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmob2appopen() != null
                                && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmob2appopen())) {
                            DviddecgtmAppOpen.AviddecgtmNIT2 = myApplication.getAppDetail().getAdmob2appopen();
                            getLoadOpviddecgtm2();
                            faividdecgtmnt = 0;
                            DviddecgtmApplication.getInstance().opviddecgtmlue = 1;
                        }


                    } else {

                        if (faividdecgtmnt > 3) {
                            if (myApplication.getAppDetail() != null && myApplication.getAppDetail().getAdmobnew() != null
                                    && !TextUtils.isEmpty(myApplication.getAppDetail().getAdmobnew())) {

                                getOpeviddecgtms();
                                faividdecgtmnt = 0;
                            }
                        }
                    }


                }
            }
        } else {
            doNotDisplviddecgtmay = false;
        }
    }

    private void openNextScreenPhoto() {
        fividdecgtmag = false;
        if (internetConnectionAvailable(1500) && isNetworkAvailable()) {
            Splasviddecgtmty = null;

            if (ruuningActivity != null) {

                if(screenngtDer >= 1)
                {
                    ruuningActivity.startActivity(new Intent(ruuningActivity, MainActivity.class));
                    ruuningActivity.finish();
                }
                else {
                    ruuningActivity.startActivity(new Intent(ruuningActivity, ManiVideoPlayerActivity.class));
                    ruuningActivity.finish();
                }


            }

        } else {
            if (Splasviddecgtmty != null) {

                if(screenngtDer >= 1)
                {
                    Splasviddecgtmty.startActivity(new Intent(Splasviddecgtmty, MainActivity.class));
                    Splasviddecgtmty.finish();
                }
                else {
                    Splasviddecgtmty.startActivity(new Intent(Splasviddecgtmty, ManiVideoPlayerActivity.class));
                    Splasviddecgtmty.finish();
                }


            }
        }
    }


    private boolean isNetworkAvailable() {
        ConnectivityManager manager = (ConnectivityManager) myApplication.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        boolean isAvailable = false;
        if (networkInfo != null && networkInfo.isConnected()) {
            isAvailable = true;
        }
        return isAvailable;
    }


    private boolean internetConnectionAvailable(int timeOut) {
        InetAddress inetAddress = null;
        try {
            Future<InetAddress> future = Executors.newSingleThreadExecutor().submit(new Callable<InetAddress>() {
                @Override
                public InetAddress call() {
                    try {
                        return InetAddress.getByName("google.com");
                    } catch (UnknownHostException e) {
                        return null;
                    }
                }
            });
            inetAddress = future.get(timeOut, TimeUnit.MILLISECONDS);
            future.cancel(true);
        } catch (InterruptedException e) {
        } catch (ExecutionException e) {
        } catch (TimeoutException e) {
        }
        return inetAddress != null && !inetAddress.equals("");
    }

    @OnLifecycleEvent(ON_START)
    public void onStart() {
        showAdIfAvailable();
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle bundle) {
        if (activity.toString().contains(DviddecgtmApplication.splashviddecgtmname)) {
            ruuningActivity = activity;
        } else {
            isShowinviddecgtm = false;
        }
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        if (!activity.toString().contains(DviddecgtmApplication.splashviddecgtmname)) {
            ruuningActivity = activity;
        }
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle bundle) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        ruuningActivity = null;
    }
}
