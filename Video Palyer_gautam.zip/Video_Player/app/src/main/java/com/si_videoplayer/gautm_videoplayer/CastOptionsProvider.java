package com.si_videoplayer.gautm_videoplayer;

import android.content.Context;

import com.google.android.gms.cast.framework.CastOptions;
import com.google.android.gms.cast.framework.OptionsProvider;

import com.google.android.gms.cast.framework.media.CastMediaOptions;
import com.google.android.gms.cast.framework.media.NotificationOptions;
import com.si_videoplayer.gautm_videoplayer.Activity.CastvideoActivity;


import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

import kotlin.jvm.internal.Intrinsics;


public class CastOptionsProvider implements OptionsProvider {
    @NotNull
    public CastOptions getCastOptions(@org.jetbrains.annotations.Nullable Context context) {
        NotificationOptions notificationOptions = (new NotificationOptions.Builder()).setTargetActivityClassName(CastvideoActivity.class.getName()).build();
        CastMediaOptions mediaOptions = (new com.google.android.gms.cast.framework.media.CastMediaOptions.Builder()).setNotificationOptions(notificationOptions).setExpandedControllerActivityClassName(CastvideoActivity.class.getName()).build();
        CastOptions var10000 = (new com.google.android.gms.cast.framework.CastOptions.Builder()).setReceiverApplicationId("CC1AD845").setCastMediaOptions(mediaOptions).build();
        Intrinsics.checkExpressionValueIsNotNull(var10000, "CastOptions.Builder()\n  …ons)\n            .build()");
        return var10000;
    }

    @org.jetbrains.annotations.Nullable
    public List getAdditionalSessionProviders(@Nullable Context p0) {
        return null;
    }
}
