package com.si_videoplayer.gautm_videoplayer.Model;

import androidx.mediarouter.media.MediaRouter;

public class MYRoutr {


    MediaRouter mediaRouter;
    MediaRouter.RouteInfo route;

    public MYRoutr() {

    }

    public MYRoutr(MediaRouter mediaRouter, MediaRouter.RouteInfo route) {
        this.mediaRouter = mediaRouter;
        this.route = route;
    }

    public MediaRouter getMediaRouter() {
        return mediaRouter;
    }

    public void setMediaRouter(MediaRouter mediaRouter) {
        this.mediaRouter = mediaRouter;
    }

    public MediaRouter.RouteInfo getRoute() {
        return route;
    }

    public void setRoute(MediaRouter.RouteInfo route) {
        this.route = route;
    }
}
