package com.si_videoplayer.gautm_videoplayer.Fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.si_videoplayer.gautm_videoplayer.Activity.AddPlaylistActivity;
import com.si_videoplayer.gautm_videoplayer.Activity.ManiVideoPlayerActivity;
import com.si_videoplayer.gautm_videoplayer.Activity.SelectPlaylistActivity;
import com.si_videoplayer.gautm_videoplayer.Activity.SerachAvtivity;
import com.si_videoplayer.gautm_videoplayer.Adapter.MyVideoplaylistAdpter;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.Constants;
import com.si_videoplayer.gautm_videoplayer.Model.VideoInfo;
import com.si_videoplayer.gautm_videoplayer.VideoUtils.PreferenceUtil;
import com.si_videoplayer.gautm_videoplayer.R;
import com.si_videoplayer.gautm_videoplayer.mycl.GoviddecgtmAs;

import java.lang.reflect.Type;
import java.util.ArrayList;


public class PlaylistFragment extends Fragment {

    TextView text_avtivity_name;
    ImageView img_set_tool_serach;
    RecyclerView recy_playlist;
    MyVideoplaylistAdpter myVideoplaylistAdpter;
    ArrayList<VideoInfo> list_play=new ArrayList<>();
    ArrayList<VideoInfo> list_favo=new ArrayList<>();
    ArrayList<VideoInfo> list_all_data=new ArrayList<>();

    RelativeLayout relativ_favourites;
    TextView text_list_size_set;
    ImageView imd_play_list_caraet;
    private PreferenceUtil preferenceUtil;
    private Gson gson;
    boolean add1time=false;
    ManiVideoPlayerActivity context;

    public PlaylistFragment(){}

    public PlaylistFragment(ManiVideoPlayerActivity maniVideoPlayerActivity) {
        context=maniVideoPlayerActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_playlist, container, false);



    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        text_avtivity_name=view.findViewById(R.id.text_avtivity_name);
        img_set_tool_serach=view.findViewById(R.id.img_set_tool_serach);
        text_avtivity_name.setText("Playlist");
        img_set_tool_serach.setVisibility(View.GONE);
        preferenceUtil=new PreferenceUtil(getActivity());
        gson=new Gson();

        list_favo.clear();
        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type1 =new TypeToken<ArrayList<VideoInfo>>(){}.getType();
        list_favo = gson.fromJson(fove_josn, type1);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }

        String json1Null00 = gson.toJson(list_play);
        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();

        list_play = gson.fromJson(json00, type00);
        if (list_play==null){
            list_play=new ArrayList<>();
        }

        recy_playlist=view.findViewById(R.id.recy_playlist);
        relativ_favourites=view.findViewById(R.id.relativ_favourites);
        text_list_size_set=view.findViewById(R.id.text_list_size_set);
        imd_play_list_caraet=view.findViewById(R.id.imd_play_list_caraet);
        text_list_size_set.setText(list_favo.size()+" Video");
        relativ_favourites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gson = new Gson();
                String json = gson.toJson(list_favo);

                GoviddecgtmAs.getInstance().showinter(getActivity(), new GoviddecgtmAs.AviddetInterface() {
                    @Override
                    public void abrttall() {
                        Intent intent=new Intent(getActivity(), SerachAvtivity.class);
                        intent.putExtra("Serachlistset",json);
                        intent.putExtra("setactivty",22);
                        startActivity(intent);
                    }
                });


            }
        });

        recy_playlist.setLayoutManager(new GridLayoutManager(getActivity(),1));
        myVideoplaylistAdpter=new MyVideoplaylistAdpter(getActivity(),list_play,this::clickset);
        recy_playlist.setAdapter(myVideoplaylistAdpter);

        imd_play_list_caraet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                opendilogset();
            }
        });
    }



    private void opendilogset() {
        final Dialog alert_creat = new Dialog(getActivity());

        View mView = LayoutInflater.from(getActivity()).inflate(R.layout.creat_play_list, null);

        EditText playList_name_et = (EditText) mView.findViewById(R.id.edt_text_data);
        ImageView cancel_txt = (ImageView) mView.findViewById(R.id.img_dilog_cancel);
        ImageView add_txt = (ImageView) mView.findViewById(R.id.img_create);

        alert_creat.setContentView(mView);
        alert_creat.setCanceledOnTouchOutside(false);
        alert_creat.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        cancel_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alert_creat.dismiss();
            }
        });
        add_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> temp=new ArrayList<>();
                String list_name=playList_name_et.getText().toString().trim();
                if (list_name.length()==0){
                    playList_name_et.setError("Enter text");
                } else {

                    VideoInfo myModel = new VideoInfo(playList_name_et.getText().toString());
                    if (list_play==null){
                        list_play=new ArrayList<>();
                    }
                    if (list_play.size()==0){
                        add1time=true;
                        list_play.add(0, myModel);
                        myVideoplaylistAdpter.updatelist(list_play);
                        String json111 = gson.toJson(list_play);
                        preferenceUtil.putString(Constants.Add_play_List, json111);
                        alert_creat.dismiss();

                    }else {
                        add1time=false;
                        for (int i = 0; i < list_play.size(); i++) {
                            temp.add(list_play.get(i).getList_name());

                        }
                    }
                    if (!add1time){
                        if (!temp.contains(list_name)){
                            list_play.add(0, myModel);
                            myVideoplaylistAdpter.updatelist(list_play);
                            String json111 = gson.toJson(list_play);
                            preferenceUtil.putString(Constants.Add_play_List, json111);
                            alert_creat.dismiss();
                        }else {
                            playList_name_et.setError("Already playlist name");
                        }
                    }



                }
            }
        });

        alert_creat.show();
    }

    public void updatfav() {

        String fove_josn = preferenceUtil.getString(Constants.Video_favo_List, null);
        Type type = new com.google.common.reflect.TypeToken<ArrayList<VideoInfo>>() {
        }.getType();
        list_favo = gson.fromJson(fove_josn, type);
        if (list_favo == null) {
            list_favo = new ArrayList<>();
        }

        text_list_size_set.setText(list_favo.size()+" Video");

        String json1Null00 = gson.toJson(list_play);
        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();

        list_play = gson.fromJson(json00, type00);
        if (list_play==null){
            list_play=new ArrayList<>();
        }
        if (myVideoplaylistAdpter!=null){
            myVideoplaylistAdpter.updatelist(list_play);
        }


    }

    public void setdateview() {

        String json1Null00 = gson.toJson(list_play);
        String json00 = preferenceUtil.getString(Constants.Add_play_List, json1Null00);
        Type type00 = new TypeToken<ArrayList<VideoInfo>>() {}.getType();

        list_play = gson.fromJson(json00, type00);
        if (list_play==null){
            list_play=new ArrayList<>();
        }
        if (myVideoplaylistAdpter!=null){
            myVideoplaylistAdpter.updatelist(list_play);
        }

    }



    public void listsenddata(ArrayList<VideoInfo> videoInfos) {
        list_all_data=new ArrayList<>();
        list_all_data.addAll(videoInfos);
    }

    private void clickset(String s,boolean setdate) {

        gson = new Gson();
        String json = gson.toJson(list_all_data);

        if (setdate){
            Intent intent=new Intent(getActivity(), AddPlaylistActivity.class);
            intent.putExtra("pf_key_set",s);
            intent.putExtra("all_date_show",json);



            GoviddecgtmAs.getInstance().showinter((Activity) context, new GoviddecgtmAs.AviddetInterface() {
                @Override
                public void abrttall() {
                    startActivity(intent);
                }
            });



        }else {
            Intent intent=new Intent(getActivity(), SelectPlaylistActivity.class);
            intent.putExtra("datashow",11);
            intent.putExtra("pf_keyaa",s);
            intent.putExtra("all_date_showaa",json);

            GoviddecgtmAs.getInstance().showinter((Activity) context, new GoviddecgtmAs.AviddetInterface() {
                @Override
                public void abrttall() {
                    startActivity(intent);
                }
            });

        }



    }

    @Override
    public void onResume() {
        super.onResume();
        updatfav();
    }
}