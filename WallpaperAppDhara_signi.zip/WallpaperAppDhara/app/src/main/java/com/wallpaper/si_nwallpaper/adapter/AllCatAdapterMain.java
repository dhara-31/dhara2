package com.wallpaper.si_nwallpaper.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.activity.GetAllCatwiseActivity;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.List;


public class AllCatAdapterMain extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity activity;
    public List<AllCat.Datum> list;
    public Integer selected;
    TinyDB t;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView catname;
        RecyclerView rec;
        ImageView playall;

        public MyViewHolder(View view) {
            super(view);
            rec = (RecyclerView) view.findViewById(R.id.rec);
            this.catname = (TextView) view.findViewById(R.id.close);
            playall = (ImageView) view.findViewById(R.id.playall);
        }
    }

    public AllCatAdapterMain(List<AllCat.Datum> list2, Activity activity2, Integer selct) {
        this.list = list2;
        this.activity = activity2;
        selected = selct;
        t = new TinyDB(activity);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.allcatadapter, viewGroup, false));
    }


    @SuppressLint("WrongConstant")
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        final String str = this.list.get(i).getCategory();
        MyViewHolder myViewHolder = (MyViewHolder) viewHolder;
        myViewHolder.setIsRecyclable(false);
        String output = str.substring(0, 1).toUpperCase() + str.substring(1);
        myViewHolder.catname.setText(output);

        List<AllCat.Wallpaper> data = list.get(i).getWallpaper();
        AllSubCatAdapter wallpapersAdapter;

        if (selected == 1) {
            wallpapersAdapter = new AllSubCatAdapter(data, activity, t.getListInt("chhose").get(i), "1");
        } else {
            wallpapersAdapter = new AllSubCatAdapter(data, activity, i, "12");
        }

        LinearLayoutManager gridLayoutManager = new LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false);
        myViewHolder.rec.setLayoutManager(gridLayoutManager);
        myViewHolder.rec.setHasFixedSize(true);
        myViewHolder.rec.setItemAnimator(new DefaultItemAnimator());
        myViewHolder.rec.setAdapter(wallpapersAdapter);
        myViewHolder.playall.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                    @Override
                    public void adsCall() {
                        Intent i2 = new Intent(activity, GetAllCatwiseActivity.class);
                        i2.putExtra("str", str);
                        // TODO: 09-05-2022 change for 3 act
                        if (selected == 1) {
                            i2.putExtra("current", t.getListInt("chhose").get(i));
                        } else {
                            i2.putExtra("current", i);
                        }
                        activity.startActivity(i2);
                    }
                });
            }
        });

    }


    @Override
    public int getItemCount() {
        return list.size();
    }
}
