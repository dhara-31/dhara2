package com.wallpaper.si_nwallpaper.database;

import java.io.Serializable;

public class PlayList implements Serializable {

    private String alarm_Name;

    private String colorname;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;

    public String getPath() {
        return alarm_Name;
    }

    public void setPath(String alarm_Name) {
        this.alarm_Name = alarm_Name;
    }

    public String getColorname() {
        return colorname;
    }

    public void setCatogory(String colorname) {
        this.colorname = colorname;
    }


}

