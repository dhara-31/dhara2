package com.wallpaper.si_nwallpaper.apidata;


import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.sleect.WallPaper;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface ApiInterfaceSub {


    @FormUrlEncoded
    @POST("index.php")
    Call<WallPaper> getAll(@Header("Authorization") String auth,
                           @Header("key") String userkey, @Field("packagename") String pkg, @Field("category") String cat);


    @FormUrlEncoded
    @POST("index.php")
    Call<AllCat> getAllCat(@Header("Authorization") String auth, @Header("key") String userkey, @Field("packagename") String pkg);

}
