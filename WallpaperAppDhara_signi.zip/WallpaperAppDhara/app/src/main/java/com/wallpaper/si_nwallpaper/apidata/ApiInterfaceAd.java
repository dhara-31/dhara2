package com.wallpaper.si_nwallpaper.apidata;


import com.wallpaper.si_nwallpaper.sleect.ExampleClass;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterfaceAd {


    @FormUrlEncoded
    @POST("encryption.php")
    Call<ExampleClass> getAll(@Field("packagename")String pkg , @Field("category")String cat , @Field("username")String uname , @Field("password")String pass);

}
