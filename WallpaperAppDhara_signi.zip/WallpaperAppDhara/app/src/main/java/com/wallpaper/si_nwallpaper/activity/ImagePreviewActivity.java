package com.wallpaper.si_nwallpaper.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.FavAdapter;
import com.wallpaper.si_nwallpaper.adapter.FavPagerAdpater;
import com.wallpaper.si_nwallpaper.adapter.GalleryAdapter;
import com.wallpaper.si_nwallpaper.adapter.GalleryPagerAdpater;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;
import com.wallpaper.si_nwallpaper.sleect.WallPaper;
import com.wallpaper.si_nwallpaper.database.Alarm;
import com.wallpaper.si_nwallpaper.database.DBHelper;
import com.wallpaper.si_nwallpaper.database.DBplaylist;
import com.wallpaper.si_nwallpaper.database.PlayList;
import com.wallpaper.si_nwallpaper.other.Constant;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class ImagePreviewActivity extends AppCompatActivity {

    ViewPager mViewPager;

    File sdImageMainDirectory;
    ArrayList<WallPaper.Datum> a;
    private String current = "";
    ArrayList<String> gallery;
    private DBHelper mydb;
    ImageView fav;
    ImageView addplaylist;
    ArrayList<Alarm> favList;
    TextView number;
    LinearLayout premin;
    LinearLayout free;
    TinyDB t;
    DBplaylist p;

    ImageView addplay;
    ArrayList<String> galp;

    ImageView imageView1, imageView2, imageView3;
    RelativeLayout bottom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagepreview);

        addplay = findViewById(R.id.abc);


        imageView1 = (ImageView) findViewById(R.id.i1);
        imageView2 = (ImageView) findViewById(R.id.i2);
        imageView3 = (ImageView) findViewById(R.id.i3);
        bottom = findViewById(R.id.bottom);

        ImageView drw = findViewById(R.id.drw);

        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        p = new DBplaylist(this);

        number = findViewById(R.id.number);
        free = findViewById(R.id.free);

        premin = findViewById(R.id.premin);
        LinearLayout llcoin = findViewById(R.id.llcoin);
        llcoin.setVisibility(View.GONE);

        premin.setVisibility(View.GONE);
        free.setVisibility(View.VISIBLE);
        number.setVisibility(View.GONE);



        mydb = new DBHelper(this);
        fav = findViewById(R.id.fav);
        fav.setVisibility(View.GONE);
        Integer position = getIntent().getIntExtra("str", 0);
        current = getIntent().getStringExtra("current");
        t = new TinyDB(ImagePreviewActivity.this);

        addplaylist = findViewById(R.id.addplaylist);
        addplaylist.setVisibility(View.GONE);




        if (current.equals("gallery")) {

            addplay.setVisibility(View.VISIBLE);

            gallery = t.getListString("gallery");

            mViewPager = (ViewPager) findViewById(R.id.viewpager);

            GalleryPagerAdpater galleryPagerAdpater = new GalleryPagerAdpater(ImagePreviewActivity.this, gallery, current);
            mViewPager.setAdapter(galleryPagerAdpater);
            mViewPager.setCurrentItem(position);

            if (gallery.size() > position + 1) {
                Glide.with(this).load(gallery.get(position + 1)).into(imageView1);
            }

            if (gallery.size() > position + 2) {
                Glide.with(this).load(gallery.get(position + 2)).into(imageView2);
            }

            if (gallery.size() > position + 3) {
                Glide.with(this).load(gallery.get(position + 3)).into(imageView3);
            }

            imageView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (gallery.size() > mViewPager.getCurrentItem() + 1) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                    }
                }
            });


            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (gallery.size() > mViewPager.getCurrentItem() + 2) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 2);
                    }
                }
            });

            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (gallery.size() > mViewPager.getCurrentItem() + 3) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 3);
                    }
                }
            });


            ArrayList<PlayList> pList = p.getAllPlayList();
            int index7 = getIndexplaylist(gallery.get(mViewPager.getCurrentItem()), pList);
            if (index7 == -1) {
                addplay.setImageResource(R.drawable.add_play);
            } else {
                addplay.setImageResource(R.drawable.minus);
            }


            addplay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // TODO: 13-05-2022 p
                    ArrayList<PlayList> pList = p.getAllPlayList();
                    int index7 = getIndexplaylist(gallery.get(mViewPager.getCurrentItem()), pList);
                    if (index7 == -1) {
                        addplay.setImageResource(R.drawable.minus);

                        Dialog dialog = new Dialog(ImagePreviewActivity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));


                        dialog.requestWindowFeature(1);
                        dialog.setContentView(R.layout.added);


                        ImageView aad = dialog.findViewById(R.id.aad);
                        aad.startAnimation(AnimationUtils.loadAnimation(ImagePreviewActivity.this, R.anim.pulse));


                        dialog.setCancelable(true);
                        if (!isFinishing()) {
                            dialog.show();
                        }


                        p.insertPlaylist(gallery.get(mViewPager.getCurrentItem()), gallery.get(mViewPager.getCurrentItem()));

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (dialog != null) {
                                    dialog.dismiss();
                                }
                            }
                        }, 2000);

                    } else {
                        p.deleteFav(index7);
                        addplay.setImageResource(R.drawable.add_play);

                        Dialog dialog = new Dialog(ImagePreviewActivity.this);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                        dialog.requestWindowFeature(1);
                        dialog.setContentView(R.layout.added);

                        ImageView aad = dialog.findViewById(R.id.aad);
                        aad.setImageResource(R.drawable.w_removed);

                        aad.startAnimation(AnimationUtils.loadAnimation(ImagePreviewActivity.this, R.anim.pulse));

                        dialog.setCancelable(true);
                        if (!isFinishing()) {
                            dialog.show();
                        }


                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (dialog != null) {
                                    dialog.dismiss();
                                }
                            }
                        }, 2000);

                    }
                }
            });


        }

        else if (current.equals("fav")) {


            addplay.setVisibility(View.GONE);
            mViewPager = (ViewPager) findViewById(R.id.viewpager);
            favList = mydb.getAllFav();
            FavPagerAdpater galleryPagerAdpater2 = new FavPagerAdpater(ImagePreviewActivity.this, favList);
            mViewPager.setAdapter(galleryPagerAdpater2);
            mViewPager.setCurrentItem(position);


            if (favList.size() > position + 1) {
                Glide.with(this).load(favList.get(position + 1).getPath()).into(imageView1);
            }

            if (favList.size() > position + 2) {
                Glide.with(this).load(favList.get(position + 2).getPath()).into(imageView2);
            }


            if (favList.size() > position + 3) {
                Glide.with(this).load(favList.get(position + 3).getPath()).into(imageView3);
            }

            imageView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (favList.size() > mViewPager.getCurrentItem() + 1) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                    }
                }
            });

            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (favList.size() > mViewPager.getCurrentItem() + 2) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 2);
                    }
                }
            });

            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (favList.size() > mViewPager.getCurrentItem() + 3) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 3);
                    }
                }
            });




        }

        else if (current.equals("galp")) {
            addplay.setVisibility(View.GONE);
            ArrayList<String> galp = t.getListString("glist");
            mViewPager = (ViewPager) findViewById(R.id.viewpager);
            addplaylist.setVisibility(View.GONE);
            GalleryPagerAdpater galleryPagerAdpater = new GalleryPagerAdpater(ImagePreviewActivity.this, galp, current);
            mViewPager.setAdapter(galleryPagerAdpater);
            mViewPager.setCurrentItem(position);


            if (galp.size() > position + 1) {
                Glide.with(this).load(galp.get(position + 1)).into(imageView1);
            }

            if (galp.size() > position + 2) {
                Glide.with(this).load(galp.get(position + 2)).into(imageView2);
            }


            if (galp.size() > position + 3) {
                Glide.with(this).load(galp.get(position + 3)).into(imageView3);
            }

            imageView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (galp.size() > mViewPager.getCurrentItem() + 1) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                    }
                }
            });

            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (galp.size() > mViewPager.getCurrentItem() + 2) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 2);
                    }
                }
            });

            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (galp.size() > mViewPager.getCurrentItem() + 3) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 3);
                    }
                }
            });


        }

        else if (current.equals("fp")) {

            addplay.setVisibility(View.VISIBLE);

            ArrayList<String> b = new ArrayList<>();
            ArrayList<PlayList> pList = p.getAllPlayList();
            for (PlayList a : pList) {
                b.add(a.getPath());
            }

            galp = b;

            if (galp.size() > position + 1) {
                Glide.with(this).load(galp.get(position + 1)).into(imageView1);
            }

            if (galp.size() > position + 2) {
                Glide.with(this).load(galp.get(position + 2)).into(imageView2);
            }


            if (galp.size() > position + 3) {
                Glide.with(this).load(galp.get(position + 3)).into(imageView3);
            }

            imageView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (galp.size() > mViewPager.getCurrentItem() + 1) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                    }
                }
            });

            imageView2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (galp.size() > mViewPager.getCurrentItem() + 2) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 2);
                    }
                }
            });

            imageView3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (galp.size() > mViewPager.getCurrentItem() + 3) {
                        mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 3);
                    }
                }
            });


            addplaylist.setVisibility(View.GONE);
            mViewPager = (ViewPager) findViewById(R.id.viewpager);
            GalleryPagerAdpater galleryPagerAdpater = new GalleryPagerAdpater(ImagePreviewActivity.this, galp, current);
            mViewPager.setAdapter(galleryPagerAdpater);
            mViewPager.setCurrentItem(position);

            pList = p.getAllPlayList();
            int index7 = getIndexplaylist(galp.get(mViewPager.getCurrentItem()), pList);
            if (index7 == -1) {
                addplay.setImageResource(View.GONE);

            } else {
                addplay.setVisibility(View.VISIBLE);
                addplay.setImageResource(R.drawable.minus);
            }




            addplay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    ArrayList<PlayList> pList = p.getAllPlayList();
                    int index7 = getIndexplaylist(galp.get(mViewPager.getCurrentItem()), pList);
                    p.deleteFav(index7);
                    addplay.setVisibility(View.GONE);

                    Dialog dialog = new Dialog(ImagePreviewActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                    dialog.requestWindowFeature(1);
                    dialog.setContentView(R.layout.added);

                    ImageView aad = dialog.findViewById(R.id.aad);
                    aad.setImageResource(R.drawable.w_removed);
                    aad.startAnimation(AnimationUtils.loadAnimation(ImagePreviewActivity.this, R.anim.pulse));

                    dialog.setCancelable(true);

                    if (!isFinishing()) {
                        dialog.show();
                    }

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (dialog != null) {
                                dialog.dismiss();
                            }
                        }
                    }, 2000);

                }
            });
        }








        DBplaylist playListdb = new DBplaylist(ImagePreviewActivity.this);
        RecyclerView recy = findViewById(R.id.recy);
        TinyDB t = new TinyDB(ImagePreviewActivity.this);

        ArrayList<String> b = new ArrayList<>();
        GalleryAdapter wallpapersAdapter = null;


        if (current.equals("gallery")) {
            b = t.getListString("gallery");
            wallpapersAdapter = new GalleryAdapter(b, ImagePreviewActivity.this, 5);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(ImagePreviewActivity.this, 3);
            recy.setLayoutManager(gridLayoutManager);
            recy.setHasFixedSize(true);
            recy.setItemAnimator(new DefaultItemAnimator());
            recy.setAdapter(wallpapersAdapter);
        } else if (current.equals("galp")) {


            b = t.getListString("glist");
            wallpapersAdapter = new GalleryAdapter(b, ImagePreviewActivity.this, 7);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(ImagePreviewActivity.this, 3);
            recy.setLayoutManager(gridLayoutManager);
            recy.setHasFixedSize(true);
            recy.setItemAnimator(new DefaultItemAnimator());
            recy.setAdapter(wallpapersAdapter);

        } else if (current.equals("fp")) {



            b = new ArrayList<>();
            ArrayList<PlayList> pList = playListdb.getAllPlayList();

            for (PlayList a : pList) {
                b.add(a.getPath());
            }

            wallpapersAdapter = new GalleryAdapter(b, ImagePreviewActivity.this, 8);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(ImagePreviewActivity.this, 3);
            recy.setLayoutManager(gridLayoutManager);
            recy.setHasFixedSize(true);
            recy.setItemAnimator(new DefaultItemAnimator());
            recy.setAdapter(wallpapersAdapter);

        } else if (current.equals("fav")) {
            DBHelper db = new DBHelper(ImagePreviewActivity.this);
            ArrayList<Alarm> favList = db.getAllFav();
            GridLayoutManager gridLayoutManager = new GridLayoutManager(ImagePreviewActivity.this, 3);
            FavAdapter wallpapersAdapter1 = new FavAdapter(favList, ImagePreviewActivity.this, 4);
            recy.setLayoutManager(gridLayoutManager);
            recy.setHasFixedSize(true);
            recy.setItemAnimator(new DefaultItemAnimator());
            recy.setAdapter(wallpapersAdapter1);

        } else {
            wallpapersAdapter = new GalleryAdapter(b, ImagePreviewActivity.this, 3);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(ImagePreviewActivity.this, 3);
            recy.setLayoutManager(gridLayoutManager);
            recy.setHasFixedSize(true);
            recy.setItemAnimator(new DefaultItemAnimator());
            recy.setAdapter(wallpapersAdapter);
        }


        addplaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (current.equals("gallery")) {

                    ArrayList<String> b = t.getListString("glist");
                    b.add(gallery.get(mViewPager.getCurrentItem()));
                    t.putListString("glist", b);

                    ArrayList<String> b3 = t.getListString("allplaylist");
                    b3.add(gallery.get(mViewPager.getCurrentItem()));
                    t.putListString("allplaylist", b3);
                    addplaylist.setVisibility(View.GONE);
                } else if (current.equals("fav")) {
                    ArrayList<String> b1 = t.getListString("flist");
                    b1.add(favList.get(mViewPager.getCurrentItem()).getPath());
                    t.putListString("flist", b1);
                    addplaylist.setVisibility(View.GONE);

                    ArrayList<String> b3 = t.getListString("allplaylist");
                    b3.add(favList.get(mViewPager.getCurrentItem()).getPath());
                    t.putListString("allplaylist", b3);
                }
            }
        });

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {


                if (WallApplication.getInstance().isNetworkAvailable()) {
                } else {
                    InternetDialgWall();
                }


                if (current.equals("fp")) {
                    ArrayList<PlayList> pList = p.getAllPlayList();
                    int index7 = getIndexplaylist(galp.get(mViewPager.getCurrentItem()), pList);
                    if (index7 == -1) {
                        addplay.setVisibility(View.GONE);
                    } else {
                        addplay.setImageResource(R.drawable.minus);
                        addplay.setVisibility(View.VISIBLE);
                    }
                }

                if (current.equals("gallery")) {

                    if (gallery.size() > position + 1) {
                        Glide.with(ImagePreviewActivity.this).load(gallery.get(position + 1)).into(imageView1);
                    }

                    if (gallery.size() > position + 2) {
                        Glide.with(ImagePreviewActivity.this).load(gallery.get(position + 2)).into(imageView2);
                    }

                    if (gallery.size() > position + 3) {
                        Glide.with(ImagePreviewActivity.this).load(gallery.get(position + 3)).into(imageView3);
                    }


                    ArrayList<PlayList> pList = p.getAllPlayList();
                    int index7 = getIndexplaylist(gallery.get(mViewPager.getCurrentItem()), pList);

                    if (index7 == -1) {

                        addplay.setImageResource(R.drawable.add_play);
                    } else {
                        addplay.setImageResource(R.drawable.minus);
                        addplay.setVisibility(View.VISIBLE);
                    }


                } else if (current.equals("fav")) {

                    if (favList.size() > position + 1) {
                        Glide.with(ImagePreviewActivity.this).load(favList.get(position + 1).getPath()).into(imageView1);
                    }

                    if (favList.size() > position + 2) {
                        Glide.with(ImagePreviewActivity.this).load(favList.get(position + 2).getPath()).into(imageView2);
                    }

                    if (favList.size() > position + 3) {
                        Glide.with(ImagePreviewActivity.this).load(favList.get(position + 3).getPath()).into(imageView3);
                    }

                } else if (current.equals("galp")) {

                    if (galp.size() > position + 1) {
                        Glide.with(ImagePreviewActivity.this).load(galp.get(position + 1)).into(imageView1);
                    }

                    if (galp.size() > position + 2) {
                        Glide.with(ImagePreviewActivity.this).load(galp.get(position + 2)).into(imageView2);
                    }


                    if (galp.size() > position + 3) {
                        Glide.with(ImagePreviewActivity.this).load(galp.get(position + 3)).into(imageView3);
                    }
                } else if (current.equals("fp")) {

                    if (galp.size() > position + 1) {
                        Glide.with(ImagePreviewActivity.this).load(galp.get(position + 1)).into(imageView1);
                    }

                    if (galp.size() > position + 2) {
                        Glide.with(ImagePreviewActivity.this).load(galp.get(position + 2)).into(imageView2);
                    }


                    if (galp.size() > position + 3) {
                        Glide.with(ImagePreviewActivity.this).load(galp.get(position + 3)).into(imageView3);
                    }


                    ArrayList<PlayList> pList = p.getAllPlayList();
                    int index7 = getIndexplaylist(galp.get(mViewPager.getCurrentItem()), pList);
                    if (index7 == -1) {
                        addplay.setVisibility(View.GONE);
                    } else {
                        addplay.setImageResource(R.drawable.minus);
                        addplay.setVisibility(View.VISIBLE);
                    }
                }

            }


            @Override
            public void onPageScrollStateChanged(int state) {
            }

        });


        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ArrayList<Alarm> favList = mydb.getAllFav();
                int index = getIndex(a.get(mViewPager.getCurrentItem()).getOriginal(), favList);
                if (index == -1) {
                    fav.setImageResource(R.drawable.fav_a);
                    mydb.insertContact(a.get(mViewPager.getCurrentItem()).getOriginal(), current);
                } else {
                    mydb.deleteFav(index);
                    fav.setImageResource(R.drawable.fav_d);
                }

            }
        });

        ImageView lock = findViewById(R.id.lock);
        lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Downloadimage();
            }
        });
    }


    public void InternetDialgWall() {
        Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.net_connection);
        dialog.setCancelable(false);
        RelativeLayout txt_yes = (RelativeLayout) dialog.findViewById(R.id.yes);
        RelativeLayout r_retry = (RelativeLayout) dialog.findViewById(R.id.r_retry);
        TextView txt = (TextView) dialog.findViewById(R.id.txt);
        txt.setText("Internet is not working.\n" + "Start your Internet and restart app.");


        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });

        r_retry.setVisibility(View.GONE);


        dialog.show();

    }

    public static int getNavigationHeight(Activity activity) {

        int navigationBarHeight = 0;
        int resourceId = activity.getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        if (resourceId > 0) {
            navigationBarHeight = activity.getResources().getDimensionPixelSize(resourceId);
        }
        if (!hasSoftKeys(activity.getWindowManager())) return 0;
        return navigationBarHeight;
    }


    public static boolean hasSoftKeys(WindowManager windowManager) {
        Display d = windowManager.getDefaultDisplay();

        DisplayMetrics realDisplayMetrics = new DisplayMetrics();
        d.getRealMetrics(realDisplayMetrics);

        int realHeight = realDisplayMetrics.heightPixels;
        int realWidth = realDisplayMetrics.widthPixels;

        DisplayMetrics displayMetrics = new DisplayMetrics();
        d.getMetrics(displayMetrics);

        int displayHeight = displayMetrics.heightPixels;
        int displayWidth = displayMetrics.widthPixels;

        return (realWidth - displayWidth) > 0 || (realHeight - displayHeight) > 0;
    }


    private int getIndexplaylist(String rawPath, ArrayList<PlayList> list) {
        int i = 0;

        while (i < list.size()) {
            if (list.get(i).getPath().equals(rawPath)) {

                return list.get(i).getId();
            }
            i++;
        }
        return -1;
    }

    private int getIndex(String rawPath, ArrayList<Alarm> list) {
        int i = 0;
        while (i < list.size()) {
            if (list.get(i).getPath().equals(rawPath)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    void Downloadimage() {


        if (current.equals("gallery")) {
            try {
                Uri uri = FileProvider.getUriForFile(ImagePreviewActivity.this, getPackageName() + ".provider", new File(gallery.get(mViewPager.getCurrentItem())));
                Bitmap bitmap = null;
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Bitmap b = null;
                if (bitmap != null) {
                    b = cropBitmapFromCenterAndScreenSize(bitmap);
                }

                WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                Display display = getWindowManager().getDefaultDisplay();
                Point size = new Point();
                display.getSize(size);
                int width = size.x;
                int height = size.y;

                manager.setWallpaperOffsetSteps(1, 1);
                manager.suggestDesiredDimensions(width, height);

                try {
                    if (b != null) {
                        manager.setBitmap(b);
                        Toast.makeText(ImagePreviewActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (current.equals("fav")) {
            Constant.getInstance().showprogress(this);
            DownloadFile downloadFile = new DownloadFile();
            downloadFile.execute(favList.get(mViewPager.getCurrentItem()).getPath(), favList.get(mViewPager.getCurrentItem()).getCatopgoty().toString());

        } else if (current.equals("galp")) {
            Uri uri = FileProvider.getUriForFile(ImagePreviewActivity.this, getPackageName() + ".provider", new File(t.getListString("glist").get(mViewPager.getCurrentItem())));


            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Bitmap b = null;
            if (bitmap != null) {
                b = cropBitmapFromCenterAndScreenSize(bitmap);
            }

            WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
            Display display = getWindowManager().getDefaultDisplay();
            Point size = new Point();
            display.getSize(size);
            int width = size.x;
            int height = size.y;

            manager.setWallpaperOffsetSteps(1, 1);
            manager.suggestDesiredDimensions(width, height);

            try {
                if (b != null) {
                    manager.setBitmap(b);
                    Toast.makeText(ImagePreviewActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        } else if (current.equals("fp")) {

            File root = null;
            int currentapiVersion = Build.VERSION.SDK_INT;

            if (currentapiVersion >= 30) {
                root = new File(getExternalFilesDir("") + File.separator + "Wallpaper" + File.separator);
            } else {
                root = new File(Environment.getExternalStorageDirectory() + File.separator + "Wallpaper" + File.separator);
            }

            root.mkdirs();

            sdImageMainDirectory = new File(root, "play" + mViewPager.getCurrentItem() + ".jpg");
            if (sdImageMainDirectory.exists()) {
                try {
                    Uri uri = FileProvider.getUriForFile(ImagePreviewActivity.this, getPackageName() + ".provider", new File(sdImageMainDirectory.getAbsolutePath()));


                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Bitmap b = null;
                    if (bitmap != null) {
                        b = cropBitmapFromCenterAndScreenSize(bitmap);
                    }

                    WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                    Display display = getWindowManager().getDefaultDisplay();
                    Point size = new Point();
                    display.getSize(size);
                    int width = size.x;
                    int height = size.y;

                    manager.setWallpaperOffsetSteps(1, 1);
                    manager.suggestDesiredDimensions(width, height);

                    try {
                        if (b != null) {
                            manager.setBitmap(b);
                            Toast.makeText(ImagePreviewActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                Constant.getInstance().showprogress(this);
                DownloadFile downloadFile = new DownloadFile();
                downloadFile.execute(galp.get(mViewPager.getCurrentItem()), "play" + mViewPager.getCurrentItem());
            }

        }
    }
    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(ImagePreviewActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });
    }
    private Bitmap cropBitmapFromCenterAndScreenSize(Bitmap bitmap) {

        int screenWidth, screenHeight;
        float bitmap_width = bitmap.getWidth(), bitmap_height = bitmap.getHeight();

        Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();

        screenWidth = display.getWidth();
        screenHeight = display.getHeight();

        float bitmap_ratio = (float) (bitmap_width / bitmap_height);

        float screen_ratio = (float) (screenWidth / screenHeight);

        int bitmapNewWidth, bitmapNewHeight;

        if (screen_ratio > bitmap_ratio) {
            bitmapNewWidth = (int) screenWidth;
            bitmapNewHeight = (int) (bitmapNewWidth / bitmap_ratio);
        } else {
            bitmapNewHeight = (int) screenHeight;
            bitmapNewWidth = (int) (bitmapNewHeight * bitmap_ratio);
        }

        bitmap = Bitmap.createScaledBitmap(bitmap, bitmapNewWidth, bitmapNewHeight, true);

        int bitmapGapX, bitmapGapY;
        bitmapGapX = (int) ((bitmapNewWidth - screenWidth) / 2.0f);
        bitmapGapY = (int) ((bitmapNewHeight - screenHeight) / 2.0f);


        bitmap = Bitmap.createBitmap(bitmap, bitmapGapX, bitmapGapY, screenWidth, screenHeight);
        return bitmap;
    }


    private class DownloadFile extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... sUrl) {
            try {
                URL url = new URL(sUrl[0]);
                URLConnection connection = url.openConnection();
                connection.connect();
                int fileLength = connection.getContentLength();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
                String currentDateandTime = sdf.format(new Date());

                InputStream input = new BufferedInputStream(url.openStream());
                File root = null;
                int currentapiVersion = Build.VERSION.SDK_INT;

                if (currentapiVersion >= 30) {
                    root = new File(getExternalFilesDir("") + File.separator + "Wallpaper" + File.separator);
                } else {
                    root = new File(Environment.getExternalStorageDirectory() + File.separator + "Wallpaper" + File.separator);
                }

                root.mkdirs();
                sdImageMainDirectory = new File(root, sUrl[1] + ".jpg");

                FileOutputStream output = new FileOutputStream(sdImageMainDirectory);

                byte data[] = new byte[1024];
                long total = 0;
                int count;

                while ((count = input.read(data)) != -1) {
                    total += count;
                    publishProgress("" + (int) ((total * 100) / fileLength));
                    output.write(data, 0, count);
                }

                output.flush();
                output.close();
                input.close();

            } catch (Exception e) {

            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            Constant.getInstance().text.setText(String.valueOf(Integer.parseInt(values[0])) + " %");
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Constant.getInstance().hideprogress();
            try {

                mViewPager.getAdapter().notifyDataSetChanged();

                MediaScannerConnection.scanFile(ImagePreviewActivity.this,
                        new String[]{sdImageMainDirectory.getAbsolutePath()}, null,
                        new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                            }
                        });


                Uri uri = FileProvider.getUriForFile(ImagePreviewActivity.this, getPackageName() + ".provider", new File(sdImageMainDirectory.getAbsolutePath()));

                Bitmap bitmap = null;

                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Bitmap b = null;
                if (bitmap != null) {
                    b = cropBitmapFromCenterAndScreenSize(bitmap);
                }

                WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                Display display = getWindowManager().getDefaultDisplay();
                Point size = new Point();

                display.getSize(size);
                int width = size.x;
                int height = size.y;

                manager.setWallpaperOffsetSteps(1, 1);
                manager.suggestDesiredDimensions(width, height);

                try {
                    if (b != null) {
                        manager.setBitmap(b);
                        Toast.makeText(ImagePreviewActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {

                e.printStackTrace();
            }
        }
    }

}