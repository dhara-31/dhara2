package com.wallpaper.si_nwallpaper.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.activity.FavSelectedActivity;
import com.wallpaper.si_nwallpaper.activity.ImagePreviewActivity;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.database.Alarm;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;
import java.util.List;


public class FavAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity activity;
    public List<Alarm> list;
    public Integer selected;

    private Boolean g = true;


    public class MyViewHolder extends RecyclerView.ViewHolder {

        View bg;
        ImageView imageView;
        ImageView lock;
        public View parent;
        public TextView title;

        public MyViewHolder(View view) {
            super(view);
            this.parent = view;
            this.title = (TextView) view.findViewById(R.id.title);
            this.lock = (ImageView) view.findViewById(R.id.lock);
            this.bg = view.findViewById(R.id.bg);
            this.imageView = (ImageView) view.findViewById(R.id.close);
        }
    }

    public FavAdapter(List<Alarm> list2, Activity activity2, Integer selct) {
        this.list = list2;
        this.activity = activity2;
        selected = selct;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        if (selected == 1) {
            return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.wallpaper_view_item_collection, viewGroup, false));
        }
        return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.gallery_adapter, viewGroup, false));
    }


    @SuppressLint("WrongConstant")
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int position) {

        final String str = this.list.get(position).getPath();
        MyViewHolder myViewHolder = (MyViewHolder) viewHolder;
        Glide.with(activity).load(str).into(myViewHolder.imageView);

        TinyDB t = new TinyDB(activity);
        myViewHolder.imageView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (g == true) {
                    FavSelectedActivity.FavsremoveWall.add(list.get(position));
                    myViewHolder.lock.setVisibility(View.VISIBLE);
                    g = false;
                }
                return true;
            }
        });


        if (selected == 3) {
            if (FavSelectedActivity.FavsremoveWall.contains(list.get(position))) {
                myViewHolder.lock.setVisibility(View.VISIBLE);
            } else {
                myViewHolder.lock.setVisibility(View.GONE);
            }
        }

        myViewHolder.imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (selected == 2) {

                } else if (selected == 3) {
                    if (g == true) {

                        GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                            @Override
                            public void adsCall() {
                                Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                                i2.putExtra("str", position);
                                i2.putExtra("current", "fav");
                                activity.startActivity(i2);
                            }
                        });
                    } else {

                        if (FavSelectedActivity.FavsremoveWall.contains(list.get(position))) {
                            ArrayList<Alarm> favList1 = FavSelectedActivity.FavsremoveWall;

                            for (int j = 0; j < favList1.size(); j++) {
                                if (favList1.get(j).getPath().equals(list.get(position).getPath())) {
                                    favList1.remove(j);
                                }
                            }

                            FavSelectedActivity.FavsremoveWall = favList1;
                            myViewHolder.lock.setVisibility(View.GONE);

                        } else {

                            FavSelectedActivity.FavsremoveWall.add(list.get(position));
                            myViewHolder.lock.setVisibility(View.VISIBLE);
                            g = false;
                        }
                    }

                } else if (selected == 4) {

                    Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                    i2.putExtra("str", position);
                    i2.putExtra("current", "fav");
                    activity.startActivity(i2);
                    activity.finish();

                }


                else if (selected == 1) {
                    GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                        @Override
                        public void adsCall() {
                            Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                            i2.putExtra("str", position);
                            i2.putExtra("current", "fav");
                            activity.startActivity(i2);
                        }
                    });

                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return list.size();
    }
}
