package com.wallpaper.si_nwallpaper.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.database.Alarm;

import java.util.ArrayList;
import java.util.Objects;

public class FavPagerAdpater extends PagerAdapter {

    Activity context;
    ArrayList<Alarm> images;
    LayoutInflater mLayoutInflater;

    public FavPagerAdpater(Activity context, ArrayList<Alarm> images) {
        this.context = context;
        this.images = images;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return images.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == ((LinearLayout) object);
    }

    @SuppressLint("ClickableViewAccessibility")
    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        View itemView = mLayoutInflater.inflate(R.layout.item, container, false);
        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageViewMain);
        ImageView imageView1 = (ImageView) itemView.findViewById(R.id.i1);
        ImageView imageView2 = (ImageView) itemView.findViewById(R.id.i2);
        ImageView imageView3 = (ImageView) itemView.findViewById(R.id.i3);

        RelativeLayout bottom = itemView.findViewById(R.id.bottom);
        Glide.with(context).load(images.get(position).getPath()).into(imageView);

        if (images.size() > position + 1) {
            Glide.with(context).load(images.get(position + 1).getPath()).into(imageView1);
        } else {
            imageView1.setVisibility(View.GONE);
        }

        if (images.size() > position + 2) {
            Glide.with(context).load(images.get(position + 2).getPath()).into(imageView2);
        } else {
            imageView2.setVisibility(View.GONE);

        }

        if (images.size() > position + 3) {
            Glide.with(context).load(images.get(position + 3).getPath()).into(imageView3);
        } else {
            imageView3.setVisibility(View.GONE);
        }

        Objects.requireNonNull(container).addView(itemView);


        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }
}

