package com.wallpaper.si_nwallpaper.adsclass;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;


public class ActivityExit extends AppCompatActivity {

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.exitdialog);

        ImageView no = (ImageView) findViewById(R.id.no);
        ImageView yes = (ImageView) findViewById(R.id.yes);

        FrameLayout f = findViewById(R.id.frame1);
        CardView c = findViewById(R.id.c);
        NativeAdsAllWallP.getInstance().nativeAdShowAllwall(f, ActivityExit.this, c);


        yes.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                finishAndRemoveTask();
                finishAffinity();
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SplashActivity.exit = true;
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(ActivityExit.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });
    }


}
