package com.wallpaper.si_nwallpaper.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adsclass.ActivityExit;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.other.Constant;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class StartActivty extends AppCompatActivity {

    ImageView explore;

    private static final int PERMISSION_REQUEST_CODE = 200;
    TinyDB t;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);


        FrameLayout f = findViewById(R.id.frame1);
        CardView c = findViewById(R.id.c);
        NativeAdsAllWallP.getInstance().nativeAdShowAllwall(f, StartActivty.this, c);


        t = new TinyDB(StartActivty.this);


        explore = findViewById(R.id.explore);


        if (t.getBoolean("start") == false) {

            String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
            DatabaseReference reference = FirebaseDatabase.getInstance("https://wallpaperapp-e7e13-default-rtdb.firebaseio.com/").getReference().child("wallCoinsData");
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    Boolean a = false;

                    for (DataSnapshot dataSnap : dataSnapshot.getChildren()) {
                        String object = dataSnap.getKey().toString();
                        if (android_id.equals(object)) {
                            a = true;
                            Constant.coinget = Integer.parseInt(dataSnap.getValue().toString());
                            break;
                        }
                    }

                    if (a == true) {

                    } else {
                        reference.child(android_id).setValue(0);
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });

        }

        explore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (askPermissions()){
                    GAdsWallPaperWp.getInstance().showInterWallpaper(StartActivty.this, new GAdsWallPaperWp.AdsInterface() {
                        @Override
                        public void adsCall() {
                            if (t.getBoolean("start") == false) {
                                startActivity(new Intent(StartActivty.this, ChooseCatogory.class));
                            } else {
                                startActivity(new Intent(StartActivty.this, SelectCatActivity.class));
                            }
                        }
                    });
                }

            }
        });


    }
    boolean askPermissions() {
        String[] strArr = new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE};

        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        if ((ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED) &&
                (ContextCompat.checkSelfPermission(
                        this,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED)
        ) {
            return true;
        }
        ActivityCompat.requestPermissions(this, strArr, PERMISSION_REQUEST_CODE);
        return false;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted && cameraAccepted) {

                        GAdsWallPaperWp.getInstance().showInterWallpaper(StartActivty.this, new GAdsWallPaperWp.AdsInterface() {
                            @Override
                            public void adsCall() {
                                if (t.getBoolean("start") == false) {
                                    startActivity(new Intent(StartActivty.this, ChooseCatogory.class));
                                } else {
                                    startActivity(new Intent(StartActivty.this, SelectCatActivity.class));
                                }
                            }
                        });

                    } else {

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(WRITE_EXTERNAL_STORAGE)) {

                                final Dialog dialog = new Dialog(StartActivty.this);
                                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                dialog.setCancelable(false);
                                dialog.setContentView(R.layout.backgrounddd);

                                TextView txt = dialog.findViewById(R.id.txt);
                                txt.setText("Unable to open this Application. Go to Settings > Permission");

                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                                TextView mDialogNo = dialog.findViewById(R.id.no);

                                mDialogNo.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog.dismiss();
                                    }
                                });

                                TextView mDialogOk = dialog.findViewById(R.id.yes);
                                mDialogOk.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent intent = new Intent();
                                        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                        Uri uri = Uri.fromParts("package", getPackageName(), null);
                                        intent.setData(uri);
                                        startActivity(intent);
                                        dialog.dismiss();
                                    }
                                });

                                dialog.show();

                                return;
                            }
                        }
                    }
                }


                break;
        }
    }


    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(StartActivty.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                startActivity(new Intent(StartActivty.this, ActivityExit.class));
            }
        });
    }
}
