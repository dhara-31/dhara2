package com.wallpaper.si_nwallpaper.apidata;

import android.app.Activity;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;

public class NativeAdsAllWallP {


    public static Integer nativeCountwall = 0;
    public static Integer nativecCunt2wallpapee = 0;
    public static NativeAd nativeAd2;

    public static NativeAd nativeAd_wall1;
    public static NativeAd nativeDefaultwll;
    private static NativeAdsAllWallP ourInstance;

    public static NativeAdsAllWallP getInstance() {
        if (ourInstance == null) {
            ourInstance = new NativeAdsAllWallP();
        }
        return ourInstance;
    }


    public static void banerAllShowWallpaper(FrameLayout f, Activity activity, CardView cardView) {

        AppDetailWp detailApp = WallApplication.getInstance().getAppDetailVWallStatic();
        f.setVisibility(View.INVISIBLE);
        if (detailApp != null && detailApp.getAdstatus().equals("1")) {

            if (nativeAd_wall1 != null) {
                banershownativewithbaner(f, activity, cardView);
                nativeAd_wall1 = null;
                loadNative1_wallpaper(activity);
            } else if (nativeAd2 != null) {

                banershownativewithbaner2(f, activity, cardView);
                nativeAd2 = null;
                loadNative2_Wallpaper(activity);

                if (nativeAd_wall1 == null) {
                    nativeCountwall++;
                    if (nativeCountwall >= 5) {
                        nativeCountwall = 0;
                        nativeAd_wall1 = null;
                        loadNative1_wallpaper(activity);
                    }
                }

            } else {

                bannerDefaultballlwall(activity, f, cardView);

                if (nativeAd2 == null) {
                    nativecCunt2wallpapee++;
                    if (nativecCunt2wallpapee >= 5) {
                        nativecCunt2wallpapee = 0;
                        nativeAd2 = null;
                        loadNative2_Wallpaper(activity);
                    }
                }

                if (nativeAd_wall1 == null) {
                    nativeCountwall++;
                    if (nativeCountwall >= 5) {
                        nativeCountwall = 0;
                        nativeAd_wall1 = null;
                        loadNative1_wallpaper(activity);
                    }
                }
            }

        } else {
            f.setVisibility(View.INVISIBLE);
        }
    }


    public static void banershownativewithbaner(FrameLayout frameLayout, Activity activity, CardView cardView) {
        cardView.setVisibility(View.VISIBLE);
        frameLayout.setVisibility(View.VISIBLE);
        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
        populateNativeAdView_Banerad(nativeAd_wall1, adView);
        frameLayout.removeAllViews();
        frameLayout.addView(adView);
    }

    public static void banershownativewithbaner2(FrameLayout frameLayout, Activity activity, CardView cardView) {
        cardView.setVisibility(View.VISIBLE);
        frameLayout.setVisibility(View.VISIBLE);
        NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
        populateNativeAdView_Banerad(nativeAd2, adView);
        frameLayout.removeAllViews();
        frameLayout.addView(adView);
    }


    public static void bannerDefaultballlwall(Activity activity, FrameLayout f, CardView cardView) {
        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
        if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative());
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    boolean isDestroyed = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    NativeAd banernativeAd_Default1 = null;

                    if (banernativeAd_Default1 != null) {
                        banernativeAd_Default1.destroy();
                    }
                    banernativeAd_Default1 = nativeAd;

                    cardView.setVisibility(View.VISIBLE);
                    f.setVisibility(View.VISIBLE);

                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
                    populateNativeAdView_Banerad(banernativeAd_Default1, adView);
                    f.removeAllViews();
                    f.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                            bannerDefault2(activity, f, cardView);
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            bannerDefault2(activity, f, cardView);
        }
    }


    public static void bannerDefault2(Activity activity, FrameLayout f, CardView cardView) {
        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
        if (appDetail != null && appDetail.getAdmob2native() != null && !TextUtils.isEmpty(appDetail.getAdmob2native()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmob2native());
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    boolean isDestroyed = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    NativeAd banernativeAd_Default2 = null;

                    if (banernativeAd_Default2 != null) {
                        banernativeAd_Default2.destroy();
                    }
                    banernativeAd_Default2 = nativeAd;
                    cardView.setVisibility(View.VISIBLE);
                    f.setVisibility(View.VISIBLE);


                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.custom_native_banner, null);
                    populateNativeAdView_Banerad(banernativeAd_Default2, adView);
                    f.removeAllViews();
                    f.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                            f.setVisibility(View.INVISIBLE);
                            cardView.setVisibility(View.INVISIBLE);
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            f.setVisibility(View.INVISIBLE);
            cardView.setVisibility(View.INVISIBLE);
        }
    }


    public static void nativeAdShowAllwall(FrameLayout f, Activity activity, CardView cardView) {
        f.setVisibility(View.INVISIBLE);
        AppDetailWp detailApp = WallApplication.getInstance().getAppDetailVWallStatic();
        if (detailApp != null && detailApp.getAdstatus().equals("1")) {
            if (nativeAd_wall1 != null) {
                showNAtive1(f, activity, cardView);
                nativeAd_wall1 = null;
                loadNative1_wallpaper(activity);
            } else if (nativeAd2 != null) {

                showNative2(f, activity, cardView);
                nativeAd2 = null;
                loadNative2_Wallpaper(activity);

                if (nativeAd_wall1 == null) {
                    nativeCountwall++;
                    if (nativeCountwall >= 5) {
                        nativeCountwall = 0;
                        nativeAd_wall1 = null;
                        loadNative1_wallpaper(activity);
                    }
                }
            } else {
                loadDefaultNative(f, activity, cardView);


                if (nativeAd2 == null) {
                    nativecCunt2wallpapee++;
                    if (nativecCunt2wallpapee >= 5) {
                        nativecCunt2wallpapee = 0;
                        nativeAd2 = null;
                        loadNative2_Wallpaper(activity);
                    }
                }
                if (nativeAd_wall1 == null) {
                    nativeCountwall++;
                    if (nativeCountwall >= 5) {
                        nativeCountwall = 0;
                        nativeAd_wall1 = null;
                        loadNative1_wallpaper(activity);
                    }
                }
            }

        } else {
            f.setVisibility(View.INVISIBLE);
        }
    }

    public static void loadNativeNormalVideoWall(final Activity activity) {
        loadNative1_wallpaper(activity);
        loadNative2_Wallpaper(activity);
    }


    public static void showNAtive1(FrameLayout frameLayout, Activity activity, CardView cardView) {
        try {
            cardView.setVisibility(View.VISIBLE);
            frameLayout.setVisibility(View.VISIBLE);

            NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_large, null);
            populateNativeAdViewWallppaer(nativeAd_wall1, adView);
            frameLayout.removeAllViews();
            frameLayout.addView(adView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showNative2(FrameLayout frameLayout, Activity activity, CardView cardView) {
        try {
            cardView.setVisibility(View.VISIBLE);
            frameLayout.setVisibility(View.VISIBLE);

            NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_large, null);
            populateNativeAdViewWallppaer(nativeAd2, adView);
            frameLayout.removeAllViews();
            frameLayout.addView(adView);
        } catch (Exception e) {
        }
    }

    public static void loadDefaultNative(FrameLayout f, Activity activity, CardView cardView) {
        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
        if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative());
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    boolean isDestroyed = false;

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }
                    cardView.setVisibility(View.VISIBLE);
                    f.setVisibility(View.VISIBLE);
                    if (nativeDefaultwll != null) {
                        nativeDefaultwll.destroy();
                    }

                    nativeDefaultwll = nativeAd;

                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_large, null);
                    populateNativeAdViewWallppaer(nativeDefaultwll, adView);
                    f.removeAllViews();
                    f.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    loadDefaultNative2(f, activity, cardView);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            loadDefaultNative2(f, activity, cardView);
        }
    }


    public static void populateNativeAdView_Banerad(NativeAd nativeAd, NativeAdView adView) {

        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }
        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getMediaContent().getVideoController();

        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        } else {
        }
    }


    public static void loadDefaultNative2(FrameLayout f, Activity activity, CardView cardView) {
        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
        if (appDetail != null && appDetail.getAdmob2native() != null && !TextUtils.isEmpty(appDetail.getAdmob2native()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmob2native());
            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    boolean isDestroyed = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }

                    cardView.setVisibility(View.VISIBLE);
                    f.setVisibility(View.VISIBLE);

                    if (nativeDefaultwll != null) {
                        nativeDefaultwll.destroy();
                    }
                    nativeDefaultwll = nativeAd;

                    NativeAdView adView = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_large, null);
                    populateNativeAdViewWallppaer(nativeDefaultwll, adView);
                    f.removeAllViews();
                    f.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    cardView.setVisibility(View.INVISIBLE);
                    f.setVisibility(View.INVISIBLE);
                }
            }).build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            f.setVisibility(View.INVISIBLE);
            cardView.setVisibility(View.INVISIBLE);
        }
    }


    public static void loadNative1_wallpaper(Activity activity) {
        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
        if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative());

            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {
                    if (nativeAd_wall1 != null) {
                        nativeAd_wall1.destroy();
                    }
                    nativeAd_wall1 = null;
                    nativeCountwall = 0;
                    nativeAd_wall1 = nativeAd;
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        }
    }


    public static void loadNative2_Wallpaper(Activity activity) {

        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
        if (appDetail != null && appDetail.getAdmob2native() != null
                && !TextUtils.isEmpty(appDetail.getAdmob2native()) && appDetail.getAdstatus().equals("1")) {

            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmob2native());

            builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(NativeAd nativeAd) {

                    if (nativeAd2 != null) {
                        nativeAd2.destroy();
                    }
                    nativeAd2 = null;
                    nativecCunt2wallpapee = 0;
                    nativeAd2 = nativeAd;
                }
            });

            AdLoader adLoader = builder.withAdListener(
                    new AdListener() {
                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                        }
                    })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());

        } else {

        }
    }


    private static void populateNativeAdViewWallppaer(NativeAd nativeAd, NativeAdView adView) {
        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));


        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());

        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getMediaContent().getVideoController();

        if (vc.hasVideoContent()) {

            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        } else {
        }
    }
}
