package com.wallpaper.si_nwallpaper.activity;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.GalleryAdapter;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.database.DBplaylist;
import com.wallpaper.si_nwallpaper.database.PlayList;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;

public class PlayListActivity extends AppCompatActivity {


    RecyclerView gallery;
    DBplaylist playListdb;
    TextView ndata;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.playlist);

        TinyDB t = new TinyDB(PlayListActivity.this);
        gallery = findViewById(R.id.gallery);

        ndata = findViewById(R.id.ndata);

        playListdb = new DBplaylist(this);


        if (WallApplication.getInstance().isNetworkAvailable()) {

        } else {
            InternetDialgWall();
        }


        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView c1 = findViewById(R.id.c);
        NativeAdsAllWallP.banerAllShowWallpaper(admobNativeLarge2, PlayListActivity.this, c1);

        ImageView drw = findViewById(R.id.drw);
        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              onBackPressed();
            }
        });


        ArrayList<String> b = new ArrayList<>();

        ArrayList<PlayList> pList = playListdb.getAllPlayList();

        for (PlayList a : pList) {
            b.add(a.getPath());
        }


        if (b.size() != 0) {
            ndata.setVisibility(View.GONE);
            gallery.setVisibility(View.VISIBLE);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(PlayListActivity.this, 3);
            GalleryAdapter wallpapersAdapter = new GalleryAdapter(b, PlayListActivity.this, 9);
            gallery.setLayoutManager(gridLayoutManager);
            gallery.setHasFixedSize(true);
            gallery.setItemAnimator(new DefaultItemAnimator());
            gallery.setAdapter(wallpapersAdapter);

        } else {
            ndata.setVisibility(View.VISIBLE);
            gallery.setVisibility(View.GONE);
        }

    }


    public void InternetDialgWall() {
        Dialog dialog = new Dialog(PlayListActivity.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.net_connection);
        dialog.setCancelable(false);
        RelativeLayout txt_yes = (RelativeLayout) dialog.findViewById(R.id.yes);
        RelativeLayout r_retry = (RelativeLayout) dialog.findViewById(R.id.r_retry);
        TextView txt = (TextView) dialog.findViewById(R.id.txt);
        txt.setText("Internet is not working.\n" + "Start your Internet and restart app.");


        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });

        r_retry.setVisibility(View.GONE);


        dialog.show();

    }


    @Override
    protected void onResume() {
        super.onResume();

        ArrayList<String> b = new ArrayList<>();
        ArrayList<PlayList> pList = playListdb.getAllPlayList();
        for (PlayList a : pList) {
            b.add(a.getPath());
        }
        if (b.size() != 0) {
            ndata.setVisibility(View.GONE);
            gallery.setVisibility(View.VISIBLE);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(PlayListActivity.this, 3);
            GalleryAdapter wallpapersAdapter = new GalleryAdapter(b, PlayListActivity.this, 9);
            gallery.setLayoutManager(gridLayoutManager);
            gallery.setHasFixedSize(true);
            gallery.setItemAnimator(new DefaultItemAnimator());
            gallery.setAdapter(wallpapersAdapter);
        } else {
            ndata.setVisibility(View.VISIBLE);
            gallery.setVisibility(View.GONE);
        }
    }


    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(PlayListActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });

    }
}
