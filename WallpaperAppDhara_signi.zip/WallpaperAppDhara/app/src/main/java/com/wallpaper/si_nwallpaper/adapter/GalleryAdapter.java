package com.wallpaper.si_nwallpaper.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.activity.GalleryActivity;
import com.wallpaper.si_nwallpaper.activity.GallerySelectedActivity;
import com.wallpaper.si_nwallpaper.activity.ImagePreviewActivity;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;
import java.util.List;



public class GalleryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity activity;
    public List<String> list;
    public Integer selected;

    public Boolean g = true;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        View bg;
        ImageView imageView;
        ImageView lock;
        public View parent;
        public TextView title;

        public MyViewHolder(View view) {
            super(view);
            this.parent = view;
            this.title = (TextView) view.findViewById(R.id.title);
            this.lock = (ImageView) view.findViewById(R.id.lock);
            this.bg = view.findViewById(R.id.bg);
            this.imageView = (ImageView) view.findViewById(R.id.close);
        }
    }

    public GalleryAdapter(List<String> list2, Activity activity2, Integer selct) {
        this.list = list2;
        this.activity = activity2;
        selected = selct;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (selected == 1 || selected == 10) {
            return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.wallpaper_view_item_collection, viewGroup, false));
        }

        return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.gallery_adapter, viewGroup, false));
    }


    @SuppressLint("WrongConstant")
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        final String str = this.list.get(i);
        MyViewHolder myViewHolder = (MyViewHolder) viewHolder;
        myViewHolder.setIsRecyclable(false);


        if (selected == 2) {
            if (GalleryActivity.selectedWall.contains(list.get(i))) {
                myViewHolder.lock.setVisibility(View.VISIBLE);
            } else {
                myViewHolder.lock.setVisibility(View.GONE);
            }
        }


        if (selected == 3) {
            if (GallerySelectedActivity.sremoveWall.contains(list.get(i))) {
                myViewHolder.lock.setVisibility(View.VISIBLE);
            } else {
                myViewHolder.lock.setVisibility(View.GONE);
            }
        }

        Glide.with(activity).load(str).override(500, 500).placeholder(R.drawable.downloading).into(myViewHolder.imageView);

        if (selected != 2) {
            if (selected == 3) {
                myViewHolder.imageView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {

                        if (g == true) {
                            GallerySelectedActivity.sremoveWall.add(list.get(i));
                            myViewHolder.lock.setVisibility(View.VISIBLE);
                            g = false;
                        }
                        return true;
                    }
                });
            }
        }


        myViewHolder.imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                TinyDB t = new TinyDB(activity);
                if (selected == 2) {
                    ArrayList<String> b1 = t.getListString("gallery");
                    if (GalleryActivity.selectedWall.contains(list.get(i))) {

                        List<String> favList3 = GalleryActivity.selectedWall;

                        for (int j = 0; j < favList3.size(); j++) {
                            if (favList3.get(j).equals(list.get(i))) {
                                favList3.remove(j);
                            }
                        }
                        GalleryActivity.selectedWall = favList3;
                        myViewHolder.lock.setVisibility(View.GONE);

                    } else if (b1.contains(list.get(i))) {
                        Toast.makeText(activity, "Already Added...", Toast.LENGTH_SHORT).show();
                    } else {
                        GalleryActivity.selectedWall.add(list.get(i));
                        myViewHolder.lock.setVisibility(View.VISIBLE);
                    }

                } else if (selected == 3) {

                    if (g == true) {

                        GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                            @Override
                            public void adsCall() {
                                Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                                i2.putExtra("str", i);
                                i2.putExtra("current", "gallery");
                                activity.startActivity(i2);

                            }
                        });
                    } else {
                        if (GallerySelectedActivity.sremoveWall.contains(list.get(i))) {

                            ArrayList<String> favList1 = GallerySelectedActivity.sremoveWall;

                            for (int j = 0; j < favList1.size(); j++) {
                                if (favList1.get(j).equals(list.get(i))) {
                                    favList1.remove(j);
                                }
                            }
                            GallerySelectedActivity.sremoveWall = favList1;
                            myViewHolder.lock.setVisibility(View.GONE);

                        } else {
                            GallerySelectedActivity.sremoveWall.add(list.get(i));
                            myViewHolder.lock.setVisibility(View.VISIBLE);
                            g = false;
                        }
                    }
                } else if (selected == 7) {

                    Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                    i2.putExtra("str", i);
                    i2.putExtra("current", "galp");
                    activity.startActivity(i2);

                } else if (selected == 5) {
                    Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                    i2.putExtra("str", i);
                    i2.putExtra("current", "gallery");
                    activity.startActivity(i2);
                    activity.finish();
                } else if (selected == 8) {

                    Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                    i2.putExtra("str", i);
                    i2.putExtra("current", "fp");
                    activity.startActivity(i2);
                    activity.finish();
                } else if (selected == 9) {
                    GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                        @Override
                        public void adsCall() {
                            Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                            i2.putExtra("str", i);
                            i2.putExtra("current", "fp");
                            activity.startActivity(i2);
                        }
                    });
                } else if (selected == 1) {
                    GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                        @Override
                        public void adsCall() {
                            Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                            i2.putExtra("str", i);
                            i2.putExtra("current", "gallery");
                            activity.startActivity(i2);

                        }
                    });
                } else if (selected == 10) {
                    GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                        @Override
                        public void adsCall() {
                            Intent i2 = new Intent(activity, ImagePreviewActivity.class);
                            i2.putExtra("str", i);
                            i2.putExtra("current", "fp");
                            activity.startActivity(i2);
                        }
                    });
                }
            }
        });

    }


    @Override
    public int getItemCount() {
        return list.size();
    }
}
