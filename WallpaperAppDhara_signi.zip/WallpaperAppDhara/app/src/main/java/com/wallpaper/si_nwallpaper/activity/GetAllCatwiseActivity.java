package com.wallpaper.si_nwallpaper.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.AllSubCatAdapter;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;
import java.util.List;

public class GetAllCatwiseActivity extends AppCompatActivity {


    RecyclerView gallery;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selectedgallery);

        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView c = findViewById(R.id.c);
        NativeAdsAllWallP.banerAllShowWallpaper(admobNativeLarge2, GetAllCatwiseActivity.this, c);

        TextView txt = findViewById(R.id.txt);

        txt.setVisibility(View.GONE);


        TinyDB t = new TinyDB(GetAllCatwiseActivity.this);
        gallery = findViewById(R.id.gallery);
        Integer pos = getIntent().getIntExtra("current", 0);

        ImageView drw = findViewById(R.id.drw);
        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              onBackPressed();
            }
        });

        String str1 = getIntent().getStringExtra("str");

        TextView t1 = findViewById(R.id.title);
        String output = str1.substring(0, 1).toUpperCase() + str1.substring(1);
        t1.setText(output);

        ImageView addwallpaper = findViewById(R.id.addwallpaper);
        addwallpaper.setVisibility(View.GONE);
        ArrayList<AllCat.Datum> alllust = t.getListAll("allcat");
        List<AllCat.Wallpaper> b = alllust.get(pos).getWallpaper();


        if (pos == t.getInt("exclusive")) {

            List<AllCat.Wallpaper> newList = alllust.get(t.getInt("exclusive")).getWallpaper();
            ArrayList<Integer> coinlist = new ArrayList<>();

            coinlist = t.getListInt("coinlist");

            if (coinlist.size() == 0) {
                for (int j = 0; j < newList.size(); j++) {
                    final int min = 3;
                    final int max = 8;
                    Integer coi = 4;

                    String d = String.valueOf(j);
                    String str = String.valueOf(j);
                    if (j > 10) {
                        str = d.substring(d.length() - 1, d.length());
                    }

                    if (String.valueOf(str).contains("0")) {
                        coi = 5;
                    } else if (String.valueOf(str).contains("1")) {
                        coi = 3;
                    } else if (String.valueOf(str).contains("2")) {
                        coi = 7;
                    } else if (String.valueOf(str).contains("3")) {
                        coi = 4;
                    } else if (String.valueOf(str).contains("4")) {
                        coi = 6;
                    } else if (String.valueOf(str).contains("5")) {
                        coi = 8;
                    } else if (String.valueOf(str).contains("6")) {
                        coi = 4;
                    } else if (String.valueOf(str).contains("7")) {
                        coi = 5;
                    } else if (String.valueOf(str).contains("8")) {
                        coi = 6;
                    } else if (String.valueOf(str).contains("9")) {
                        coi = 3;
                    }
                    coinlist.add(coi);
                }

            }
            t.putListInt("coinlist", coinlist);

        }

        GridLayoutManager gridLayoutManager = new GridLayoutManager(GetAllCatwiseActivity.this, 3);
        AllSubCatAdapter wallpapersAdapter = new AllSubCatAdapter(b, GetAllCatwiseActivity.this, pos, "0");
        gallery.setLayoutManager(gridLayoutManager);
        gallery.setHasFixedSize(true);
        gallery.setItemAnimator(new DefaultItemAnimator());
        gallery.setAdapter(wallpapersAdapter);

    }


    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(GetAllCatwiseActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });
    }

    private int getIndex(String rawPath, ArrayList<String> list) {
        int i = 0;
        while (i < list.size()) {
            if (list.get(i).equals(rawPath)) {
                return i;
            }
            i++;
        }
        return -1;
    }

}
