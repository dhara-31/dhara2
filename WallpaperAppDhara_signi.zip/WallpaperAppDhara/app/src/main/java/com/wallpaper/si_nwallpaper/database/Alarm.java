package com.wallpaper.si_nwallpaper.database;

import java.io.Serializable;

/**
 * this is Alarm class present for alarm object implements
 * Serializable to support in transfer object Alarm
 * through intent
 */
public class Alarm implements Serializable {

    private String alarm_Name;
    private Integer colorname;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;

    public String getPath() {
        return alarm_Name;
    }

    public void setPath(String alarm_Name) {
        this.alarm_Name = alarm_Name;
    }

    public Integer getCatopgoty() {
        return colorname;
    }

    public void setCatogory(Integer colorname) {
        this.colorname = colorname;
    }

}

