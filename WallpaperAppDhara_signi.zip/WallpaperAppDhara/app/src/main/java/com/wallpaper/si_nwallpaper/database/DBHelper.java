package com.wallpaper.si_nwallpaper.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String CONTACTS_TABLE_NAME = "contacts";
    public static final String CONTACTS_COLUMN_ID = "id";
    public static final String CONTACTS_COLUMN_NAME = "name";
    public static final String CONTACTS_COLUMN_color = "color";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL("create table contacts " + "(id integer primary key, name text,color text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);
    }

    public boolean insertContact(String name,  String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("color", email);
        db.insert("contacts", null, contentValues);
        return true;
    }



    public Integer deleteFav(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("contacts",
                "id = ? ",
                new String[]{Integer.toString(id)});
    }

    @SuppressLint("Range")
    public ArrayList<Alarm> getAllFav() {
        ArrayList<Alarm> array_list = new ArrayList<Alarm>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from contacts", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            Alarm a = new Alarm();
            a.setId(res.getInt(res.getColumnIndex(CONTACTS_COLUMN_ID)));
            a.setPath(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
            a.setCatogory(res.getInt(res.getColumnIndex(CONTACTS_COLUMN_color)));
            array_list.add(a);
            res.moveToNext();
        }
        return array_list;
    }
}
