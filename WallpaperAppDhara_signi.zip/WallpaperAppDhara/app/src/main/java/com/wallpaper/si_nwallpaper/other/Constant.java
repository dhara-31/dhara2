package com.wallpaper.si_nwallpaper.other;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.AlertDialog;

import com.wallpaper.si_nwallpaper.R;

import java.util.ArrayList;

public class Constant {
    private static Constant mInstance;

    public TextView text;

    public static Constant getInstance() {
        if (mInstance == null) {
            mInstance = new Constant();
        }
        return mInstance;
    }

    public AlertDialog alertDialog;
    public static Integer coinget = 0 ;
    public static ArrayList<Integer> c = new ArrayList<>();
    public static Integer v = 0 ;


    public void showprogress(Activity context) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.progressdialog, null);

        VideoView videoView = dialogView.findViewById(R.id.videoView);
        videoView.setVideoURI(Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.loading));
        videoView.start();

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                videoView.start();
            }
        });

        text = dialogView.findViewById(R.id.download);
        dialogBuilder.setView(dialogView);
        alertDialog = dialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setCancelable(false);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        alertDialog.show();
    }


    public void hideprogress() {
        try {
            if (alertDialog != null) {
                if (alertDialog.isShowing()) {
                    alertDialog.dismiss();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
