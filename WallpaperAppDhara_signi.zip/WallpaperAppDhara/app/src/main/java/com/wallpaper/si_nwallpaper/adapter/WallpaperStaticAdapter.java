package com.wallpaper.si_nwallpaper.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.activity.AActivity;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;
import java.util.List;


public class WallpaperStaticAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity activity;
    public List<AllCat.Wallpaper> list;

    public Integer c;
    TinyDB t;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        View bg;
        ImageView imageView;
        ImageView lock;
        public View parent;
        public TextView title;
        TextView coin;
        LinearLayout llc;

        public MyViewHolder(View view) {
            super(view);
            this.parent = view;
            this.title = (TextView) view.findViewById(R.id.title);
            this.lock = (ImageView) view.findViewById(R.id.lock);
            this.bg = view.findViewById(R.id.bg);
            this.imageView = (ImageView) view.findViewById(R.id.close);
            coin = view.findViewById(R.id.coin);
            llc = view.findViewById(R.id.llc);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.wallpaper_view_item, viewGroup, false));
    }


    public WallpaperStaticAdapter(List<AllCat.Wallpaper> list2, Activity activity2, Integer c) {
        this.list = list2;
        this.activity = activity2;
        this.c = c;
        t = new TinyDB(activity2);
    }


    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        final String str = this.list.get(i).getThumbnail();

        MyViewHolder myViewHolder = (MyViewHolder) viewHolder;

// TODO: 09-05-2022 change
        if (c != t.getInt("exclusive")) {
            myViewHolder.llc.setVisibility(View.GONE);
        } else {

            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

            if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") && appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {
                myViewHolder.llc.setVisibility(View.VISIBLE);
                ArrayList<Integer> coinlist = t.getListInt("coinlist");

                if (coinlist.get(i) != null) {
                    if (coinlist.get(i) == 0) {
                        myViewHolder.llc.setVisibility(View.GONE);
                    } else {
                        myViewHolder.llc.setVisibility(View.VISIBLE);
                    }
                    myViewHolder.coin.setText(String.valueOf(coinlist.get(i)).toString());
                }
            } else {
                myViewHolder.llc.setVisibility(View.GONE);
            }
        }

        Glide.with(activity).load(str).placeholder(R.drawable.downloading).override(400, 700).into(myViewHolder.imageView);

        myViewHolder.imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                        activity.finish();
                        Intent i2 = new Intent(activity, AActivity.class);
                        i2.putExtra("str", str);
                        i2.putExtra("current", c);
                        i2.putExtra("pos", i);
                        activity.overridePendingTransition(R.anim.no, R.anim.down);
                        activity.startActivity(i2);
            }
        });


    }


    @Override
    public int getItemCount() {
        return list.size();
    }
}
