package com.wallpaper.si_nwallpaper.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.PagerAdapter;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;

import com.bumptech.glide.request.RequestListener;

import com.bumptech.glide.request.target.Target;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;
import java.util.Objects;

public class ViewPagerAllAdapter extends PagerAdapter {

    Activity context;
    ArrayList<AllCat.Wallpaper> images;
    LayoutInflater mLayoutInflater;

    TinyDB t;
    Integer positiomn;

    public ViewPagerAllAdapter(Activity context, ArrayList<AllCat.Wallpaper> images, Integer pos) {
        this.context = context;
        this.images = images;
        positiomn = pos;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        t = new TinyDB(context);
    }

    @Override
    public int getCount() {
        return images.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == ((LinearLayout) object);
    }

    @SuppressLint("ClickableViewAccessibility")
    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        View itemView = mLayoutInflater.inflate(R.layout.item, container, false);

        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageViewMain);
        ImageView imageView0 = (ImageView) itemView.findViewById(R.id.imageViewMain1);

        ImageView imageView1 = (ImageView) itemView.findViewById(R.id.i1);
        ImageView imageView2 = (ImageView) itemView.findViewById(R.id.i2);
        ImageView imageView3 = (ImageView) itemView.findViewById(R.id.i3);

        LottieAnimationView lottieAnimationView2 = itemView.findViewById(R.id.lottieAnimationView2);
        RelativeLayout bottom = itemView.findViewById(R.id.bottom);


        // TODO: 07-05-2022 p

        if (positiomn == t.getInt("exclusive")) {
            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
            if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") &&
                    appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {

                ArrayList<Integer> coinList = t.getListInt("coinlist");

                if (coinList.size() != 0) {
                    if (coinList.get(position) == 0) {
                        bottom.setVisibility(View.VISIBLE);
                    } else {
                        bottom.setVisibility(View.GONE);
                    }
                }
            }
        }

        lottieAnimationView2.setVisibility(View.VISIBLE);

        Glide.with(context).load(images.get(position).getThumbnail()).fallback(R.drawable.downloading).listener(new RequestListener<Drawable>() {

            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {

                Glide.with(context)
                        .load(images.get(position).getOriginal()).fallback(R.drawable.downloading)
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                lottieAnimationView2.setVisibility(View.GONE);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                lottieAnimationView2.setVisibility(View.GONE);
                                return false;
                            }
                        }).into(imageView0);

                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                Glide.with(context)
                        .load(images.get(position).getOriginal()).fallback(R.drawable.downloading)
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                lottieAnimationView2.setVisibility(View.GONE);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                lottieAnimationView2.setVisibility(View.GONE);
                                return false;
                            }
                        }).into(imageView0);
                return false;
            }
        }).into(imageView);


        Objects.requireNonNull(container).addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }
}