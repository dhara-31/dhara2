package com.wallpaper.si_nwallpaper.retrofitcall;

import java.util.ArrayList;

public class ResponseApp {
    private ArrayList<DetailAds> adsdetail = new ArrayList<>();
    private AppDetailWp appdetail;

    public ArrayList<DetailAds> getAdsdetail() {
        return adsdetail;
    }

    public void setAdsdetail(ArrayList<DetailAds> adsdetail) {
        this.adsdetail = adsdetail;
    }

    public AppDetailWp getAppdetail() {
        return appdetail;
    }

    public void setAppdetail(AppDetailWp appdetail) {
        this.appdetail = appdetail;
    }

}
