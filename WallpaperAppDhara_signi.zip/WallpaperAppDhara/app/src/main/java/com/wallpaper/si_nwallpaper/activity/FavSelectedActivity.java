package com.wallpaper.si_nwallpaper.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.FavAdapter;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.database.Alarm;
import com.wallpaper.si_nwallpaper.database.DBHelper;

import java.util.ArrayList;

public class FavSelectedActivity extends AppCompatActivity {


    RecyclerView gallery;
    public static ArrayList<Alarm> FavsremoveWall = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selectedgallery);

        TextView title = findViewById(R.id.title);
        title.setText("Favourite");


        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView c1 = findViewById(R.id.c);
        NativeAdsAllWallP.banerAllShowWallpaper(admobNativeLarge2, FavSelectedActivity.this, c1);

        ImageView drw = findViewById(R.id.drw);
        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               onBackPressed();
            }
        });


        gallery = findViewById(R.id.gallery);
        DBHelper db = new DBHelper(FavSelectedActivity.this);
        FavsremoveWall.clear();
        ImageView addwallpaper = findViewById(R.id.addwallpaper);
        addwallpaper.setImageDrawable(getResources().getDrawable(R.drawable.remove_wallpaper));

        ArrayList<Alarm> favList = db.getAllFav();

        if (favList.size() != 0) {
            addwallpaper.setVisibility(View.VISIBLE);
            findViewById(R.id.txt).setVisibility(View.VISIBLE);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(FavSelectedActivity.this, 3);
            FavAdapter wallpapersAdapter = new FavAdapter(favList, FavSelectedActivity.this, 3);
            gallery.setLayoutManager(gridLayoutManager);
            gallery.setHasFixedSize(true);
            gallery.setItemAnimator(new DefaultItemAnimator());
            gallery.setAdapter(wallpapersAdapter);
        } else {
            addwallpaper.setVisibility(View.GONE);
            findViewById(R.id.txt).setVisibility(View.GONE);
        }


        addwallpaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ArrayList<Alarm> favList = db.getAllFav();

                if (FavsremoveWall.size() != 0) {

                    for (int j = 0; j < FavsremoveWall.size(); j++) {
                        int indes = getIndex(FavsremoveWall.get(j).getPath(), favList);
                        db.deleteFav(FavsremoveWall.get(j).getId());
                    }

                    favList = db.getAllFav();

                    GridLayoutManager gridLayoutManager = new GridLayoutManager(FavSelectedActivity.this, 3);
                    FavAdapter wallpapersAdapter = new FavAdapter(favList, FavSelectedActivity.this, 3);
                    gallery.setLayoutManager(gridLayoutManager);
                    gallery.setHasFixedSize(true);
                    gallery.setItemAnimator(new DefaultItemAnimator());
                    gallery.setAdapter(wallpapersAdapter);
                    FavsremoveWall.clear();
                } else {
                    Toast.makeText(FavSelectedActivity.this, "Please Select Image", Toast.LENGTH_LONG).show();
                }
            }
        });

    }


    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(FavSelectedActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });
    }


    private int getIndex(String rawPath, ArrayList<Alarm> list) {
        int i = 0;
        while (i < list.size()) {


            if (list.get(i).getPath().equals(rawPath)) {
                return i;
            }
            i++;
        }
        return -1;
    }

}
