package com.wallpaper.si_nwallpaper.retrofitcall;

public class DetailAds {
    private float id;
    private String app_name, app_icon, app_url;

    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public String getApp_name() {
        return app_name;
    }

    public void setApp_name(String app_name) {
        this.app_name = app_name;
    }

    public String getApp_icon() {
        return app_icon;
    }

    public void setApp_icon(String app_icon) {
        this.app_icon = app_icon;
    }

    public String getApp_url() {
        return app_url;
    }

    public void setApp_url(String app_url) {
        this.app_url = app_url;
    }
}
