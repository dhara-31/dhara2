package com.wallpaper.si_nwallpaper.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.ViewPagerAllAdapter;
import com.wallpaper.si_nwallpaper.adsclass.RewardAd;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;
import com.wallpaper.si_nwallpaper.database.Alarm;
import com.wallpaper.si_nwallpaper.database.DBHelper;
import com.wallpaper.si_nwallpaper.database.DBplaylist;
import com.wallpaper.si_nwallpaper.database.PlayList;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.Constant;
import com.wallpaper.si_nwallpaper.other.TinyDB;
import com.wallpaper.si_nwallpaper.adapter.WallpaperStaticAdapter;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AActivity extends AppCompatActivity {

    ViewPager mViewPager;
    ViewPagerAllAdapter mViewPagerAdapter;
    File sdImageMainDirectory;

    private String current = "";
    private DBHelper mydb;
    ImageView fav;
    ImageView addplaylist;

    private FirebaseDatabase mFirebaseInstance;
    private DatabaseReference mFirebaseDatabase;

    Integer pos;
    TinyDB t;
    List<AllCat.Wallpaper> bAllList;
    ArrayList<Integer> coinList = new ArrayList<>();
    LinearLayout llcoin;
    TextView number;
    LinearLayout premin;
    LinearLayout free;
    TextView coinvalue;
    TextView coin;
    LinearLayout yes;
    MediaPlayer music;
    TextView coin1;

    Integer pos1;

    ArrayList<AllCat.Datum> alllust;

    ImageView addplay;
    DBplaylist playListdb;

    public WallpaperManager wallpaperManager;
    ImageView imageView1, imageView2, imageView3;
    RelativeLayout bottom;

    ConstraintLayout bottomSheet;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagepreview);


        imageView1 = (ImageView) findViewById(R.id.i1);

        imageView2 = (ImageView) findViewById(R.id.i2);
        imageView3 = (ImageView) findViewById(R.id.i3);


        if (WallApplication.getInstance().isNetworkAvailable()) {

        } else {
            InternetDialgWall();
        }


        bottomSheet = findViewById(R.id.bottomSheet);
        BottomSheetBehavior<ConstraintLayout> bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);


        bottom = findViewById(R.id.bottom);
        this.wallpaperManager = WallpaperManager.getInstance(this);

        playListdb = new DBplaylist(this);
        coin = findViewById(R.id.coin);
        coin1 = findViewById(R.id.coin1);

        music = MediaPlayer.create(this, R.raw.xbox);
        pos = getIntent().getIntExtra("current", 0);
        yes = findViewById(R.id.yes);

        addplay = findViewById(R.id.abc);

        pos1 = getIntent().getIntExtra("pos", 0);
        t = new TinyDB(AActivity.this);

        alllust = t.getListAll("allcat");
        bAllList = alllust.get(pos).getWallpaper();

        number = findViewById(R.id.number);
        free = findViewById(R.id.free);
        premin = findViewById(R.id.premin);

        coinvalue = findViewById(R.id.coinvalue);

        coin.setText(String.valueOf(Constant.coinget));

        coinList = t.getListInt("coinlist");

        mFirebaseInstance = FirebaseDatabase.getInstance("https://wallpaperapp-e7e13-default-rtdb.firebaseio.com/");
        mFirebaseDatabase = mFirebaseInstance.getReference().child("wallCoinsData");


        mydb = new DBHelper(this);
        fav = findViewById(R.id.fav);

        llcoin = findViewById(R.id.llcoin);
        addplaylist = findViewById(R.id.addplaylist);
        fav.setVisibility(View.VISIBLE);

        addplaylist.setVisibility(View.GONE);
        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        mViewPagerAdapter = new ViewPagerAllAdapter(AActivity.this, (ArrayList) bAllList, pos);
        mViewPager.setAdapter(mViewPagerAdapter);
        mViewPager.setCurrentItem(pos1);


        if (bAllList.size() > pos1 + 1) {
            Glide.with(this).load(bAllList.get(pos1 + 1).getThumbnail()).into(imageView1);
        }

        if (bAllList.size() > pos1 + 2) {
            Glide.with(this).load(bAllList.get(pos1 + 2).getThumbnail()).into(imageView2);
        }

        if (bAllList.size() > pos1 + 3) {
            Glide.with(this).load(bAllList.get(pos1 + 3).getThumbnail()).into(imageView3);
        }


        if (pos == t.getInt("exclusive")) {
            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
            if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") &&
                    appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {

                ArrayList<Integer> coinList = t.getListInt("coinlist");

                if (coinList.size() != 0) {
                    if (coinList.get((pos1)) == 0) {

                        // TODO: 31-05-2022 change

                        bottomSheet.setVisibility(View.VISIBLE);
                        callBottomsheet();
                    } else {

                        bottomSheet.setVisibility(View.GONE);

                        // TODO: 31-05-2022 change

                    }
                }
            }
        }


        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bAllList.size() > mViewPager.getCurrentItem() + 1) {
                    mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                }
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bAllList.size() > mViewPager.getCurrentItem() + 2) {
                    mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 2);
                }
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bAllList.size() > mViewPager.getCurrentItem() + 3) {
                    mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 3);
                }
            }
        });


        callBottomsheet();

        ArrayList<PlayList> pList = playListdb.getAllPlayList();
        int index7 = getIndexplaylist(alllust.get(pos).getCategory() + alllust.get(pos).getWallpaper().get(mViewPager.getCurrentItem()).getName(), pList);
        if (index7 == -1) {
            addplay.setImageResource(R.drawable.add_play);
        } else {
            addplay.setImageResource(R.drawable.minus);
        }

        addplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // TODO: 13-05-2022 p
                ArrayList<PlayList> pList = playListdb.getAllPlayList();
                int index7 = getIndexplaylist(alllust.get(pos).getCategory() + alllust.get(pos).getWallpaper().get(mViewPager.getCurrentItem()).getName(), pList);
                if (index7 == -1) {
                    addplay.setImageResource(R.drawable.minus);

                    Dialog popup = new Dialog(AActivity.this);
                    popup.getWindow().setBackgroundDrawable(new ColorDrawable(0));


                    popup.requestWindowFeature(1);
                    popup.setContentView(R.layout.added);


                    ImageView aad = popup.findViewById(R.id.aad);
                    aad.startAnimation(AnimationUtils.loadAnimation(AActivity.this, R.anim.pulse));


                    popup.setCancelable(true);
                    if (!isFinishing()) {
                        popup.show();

                    }


                    playListdb.insertPlaylist(bAllList.get(mViewPager.getCurrentItem()).getOriginal(), alllust.get(pos).getCategory() + alllust.get(pos).getWallpaper().get(mViewPager.getCurrentItem()).getName());

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (popup != null) {
                                popup.dismiss();
                            }
                        }
                    }, 2000);

                } else {
                    playListdb.deleteFav(index7);
                    addplay.setImageResource(R.drawable.add_play);


                    Dialog popup = new Dialog(AActivity.this);
                    popup.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                    popup.requestWindowFeature(1);
                    popup.setContentView(R.layout.added);

                    ImageView aad = popup.findViewById(R.id.aad);
                    aad.setImageResource(R.drawable.w_removed);
                    aad.startAnimation(AnimationUtils.loadAnimation(AActivity.this, R.anim.pulse));

                    popup.setCancelable(true);
                    if (!isFinishing()) {
                        popup.show();
                    }


                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (popup != null) {
                                popup.dismiss();
                            }
                        }
                    }, 2000);

                }
            }
        });


        ImageView drw = findViewById(R.id.drw);
        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        if (pos == t.getInt("exclusive")) {

            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
            if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") && appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {

                if (coinList != null && coinList.size() != 0) {

                    coinvalue.setText(String.valueOf(coinList.get(mViewPager.getCurrentItem())));

                    if (coinList.get(mViewPager.getCurrentItem()) <= Constant.coinget) {
                        if (coinList.get(mViewPager.getCurrentItem()) == 0) {
                            free.setVisibility(View.VISIBLE);
                            premin.setVisibility(View.GONE);
                        } else {

                            free.setVisibility(View.GONE);
                            premin.setVisibility(View.VISIBLE);

                            coin1.setText(String.valueOf(coinList.get(mViewPager.getCurrentItem())));
                        }
                    } else {
                        free.setVisibility(View.GONE);
                        premin.setVisibility(View.VISIBLE);
                    }
                }
            } else {
                llcoin.setVisibility(View.INVISIBLE);
                premin.setVisibility(View.GONE);
                free.setVisibility(View.VISIBLE);
            }

        } else {
            llcoin.setVisibility(View.INVISIBLE);
            premin.setVisibility(View.GONE);
            free.setVisibility(View.VISIBLE);
        }


        premin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (coinList.get(mViewPager.getCurrentItem()) <= Constant.coinget) {
                    showDialog();
                } else {
                    InternetDialogUpdate();
                }
            }
        });

        number.setText(mViewPager.getCurrentItem() + 1 + " of " + bAllList.size());

        ArrayList<Alarm> favList = mydb.getAllFav();

        int index = getIndex(bAllList.get(mViewPager.getCurrentItem()).getOriginal(), favList);

        if (index == -1) {
            fav.setImageResource(R.drawable.fav_d);
        } else {
            fav.setImageResource(R.drawable.fav_a);
        }


        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {


                if (WallApplication.getInstance().isNetworkAvailable()) {

                } else {
                    InternetDialgWall();
                }


                ArrayList<Alarm> favList = mydb.getAllFav();
                int index = getIndex(bAllList.get(mViewPager.getCurrentItem()).getOriginal(), favList);

                if (index != -1) {
                    fav.setImageResource(R.drawable.fav_a);
                } else {
                    fav.setImageResource(R.drawable.fav_d);
                }

                ArrayList<PlayList> pList = playListdb.getAllPlayList();
                int index7 = getIndexplaylist(alllust.get(pos).getCategory() + alllust.get(pos).getWallpaper().get(mViewPager.getCurrentItem()).getName(), pList);
                if (index7 == -1) {
                    addplay.setImageResource(R.drawable.add_play);
                } else {
                    addplay.setImageResource(R.drawable.minus);
                }


                if (pos == t.getInt("exclusive")) {

                    AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

                    if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") && appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {

                        if (coinList.size() != 0) {


                            coinvalue.setText(String.valueOf(coinList.get(mViewPager.getCurrentItem())));
                            coin1.setText(String.valueOf(coinList.get(mViewPager.getCurrentItem())));

                            if (coinList.get(mViewPager.getCurrentItem()) <= Constant.coinget) {

                                if (coinList.get(mViewPager.getCurrentItem()) == 0) {
                                    free.setVisibility(View.VISIBLE);
                                    premin.setVisibility(View.GONE);
                                } else {
                                    free.setVisibility(View.GONE);
                                    premin.setVisibility(View.VISIBLE);
                                }
                            } else {
                                free.setVisibility(View.GONE);
                                premin.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                }


                if (pos == t.getInt("exclusive")) {
                    AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
                    if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") &&
                            appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {


                        if (coinList.size() != 0) {
                            if (coinList.get((mViewPager.getCurrentItem())) == 0) {

                                // TODO: 31-05-2022 change


                                bottomSheet.setVisibility(View.VISIBLE);
                                callBottomsheet();
                            } else {

                                // TODO: 31-05-2022 change

                                bottomSheet.setVisibility(View.GONE);

                            }
                        }
                    }
                }


                number.setText(mViewPager.getCurrentItem() + 1 + " of " + bAllList.size());


                if (bAllList.size() > position + 1) {
                    Glide.with(AActivity.this).load(bAllList.get(position + 1).getThumbnail()).into(imageView1);
                }

                if (bAllList.size() > position + 2) {
                    Glide.with(AActivity.this).load(bAllList.get(position + 2).getThumbnail()).into(imageView2);
                }

                if (bAllList.size() > position + 3) {
                    Glide.with(AActivity.this).load(bAllList.get(position + 3).getThumbnail()).into(imageView3);
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }

        });


        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<Alarm> favList = mydb.getAllFav();
                int index = getIndex(bAllList.get(mViewPager.getCurrentItem()).getOriginal(), favList);
                if (index == -1) {
                    fav.setImageResource(R.drawable.fav_a);
                    mydb.insertContact(bAllList.get(mViewPager.getCurrentItem()).getOriginal(), current);
                } else {
                    mydb.deleteFav(index);
                    fav.setImageResource(R.drawable.fav_d);
                }
            }
        });

        ImageView lock = findViewById(R.id.lock);

        lock.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.R)
            @Override
            public void onClick(View v) {
                if (pos == t.getInt("exclusive")) {
                    AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

                    if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") && appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {

                        if (coinList.get(mViewPager.getCurrentItem()) == 0) {
                            Downloadimage();
                        } else {
                            if (coinList.get(mViewPager.getCurrentItem()) <= Constant.coinget) {
                                Downloadimage();
                            } else {
                                if (SelectCatActivity.adtime == true) {
                                    showRewardedVideo();
                                } else {
                                    Toast.makeText(AActivity.this, "After 30 sec you can watch ads", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    } else {
                        Downloadimage();
                    }
                } else {
                    Downloadimage();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            try {
                final Uri imageUri = data.getData();
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);

                Bitmap b = cropBitmapFromCenterAndScreenSize(bitmap);
                WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                manager.setBitmap(b);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } else {

        }
    }


    @SuppressLint("ResourceType")
    public void callBottomsheet() {


        pos = getIntent().getIntExtra("current", 0);
        pos1 = getIntent().getIntExtra("pos", 0);

        RecyclerView recy = (RecyclerView) findViewById(R.id.recy);
        ArrayList<AllCat.Datum> alllust = t.getListAll("allcat");
        List<AllCat.Wallpaper> b = alllust.get(pos).getWallpaper();
        GridLayoutManager gridLayoutManager = new GridLayoutManager(AActivity.this, 3);
        WallpaperStaticAdapter wallpapersAdapter = new WallpaperStaticAdapter(b, AActivity.this, pos);
        recy.setLayoutManager(gridLayoutManager);
        recy.setHasFixedSize(true);
        recy.setItemAnimator(new DefaultItemAnimator());
        recy.setAdapter(wallpapersAdapter);

    }


    private Bitmap cropBitmapFromCenterAndScreenSize(Bitmap bitmap) {

        int screenWidth, screenHeight;
        float bitmap_width = bitmap.getWidth(), bitmap_height = bitmap.getHeight();

        Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();

        screenWidth = display.getWidth();
        screenHeight = display.getHeight();

        float bitmap_ratio = (float) (bitmap_width / bitmap_height);

        float screen_ratio = (float) (screenWidth / screenHeight);

        int bitmapNewWidth, bitmapNewHeight;

        if (screen_ratio > bitmap_ratio) {
            bitmapNewWidth = (int) screenWidth;
            bitmapNewHeight = (int) (bitmapNewWidth / bitmap_ratio);
        } else {
            bitmapNewHeight = (int) screenHeight;
            bitmapNewWidth = (int) (bitmapNewHeight * bitmap_ratio);
        }

        bitmap = Bitmap.createScaledBitmap(bitmap, bitmapNewWidth, bitmapNewHeight, true);

        int bitmapGapX, bitmapGapY;
        bitmapGapX = (int) ((bitmapNewWidth - screenWidth) / 2.0f);
        bitmapGapY = (int) ((bitmapNewHeight - screenHeight) / 2.0f);


        bitmap = Bitmap.createBitmap(bitmap, bitmapGapX, bitmapGapY, screenWidth, screenHeight);
        return bitmap;
    }

    private int getIndexplaylist(String rawPath, ArrayList<PlayList> list) {
        int i = 0;
        while (i < list.size()) {
            if (list.get(i).getColorname().equals(rawPath)) {
                return list.get(i).getId();
            }
            i++;
        }
        return -1;
    }

    public void InternetDialogUpdate() {
        Dialog dialog = new Dialog(AActivity.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.notenodialog);
        dialog.setCancelable(true);
        ImageView txt_yes = (ImageView) dialog.findViewById(R.id.yes);
        ImageView r_retry = (ImageView) dialog.findViewById(R.id.r_retry);


        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        r_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();


                if (SelectCatActivity.adtime == true) {
                    watchAd();
                } else {
                    someAfter30();
                }
            }
        });
        if (!isFinishing()) {
            dialog.show();
        }
    }


    public void showDialog() {
        Dialog dialog = new Dialog(AActivity.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.show);
        dialog.setCancelable(true);
        LinearLayout txt_yes = (LinearLayout) dialog.findViewById(R.id.yes);
        TextView txt_yes1 = (TextView) dialog.findViewById(R.id.coin1);

        txt_yes1.setText(String.valueOf(coinList.get(mViewPager.getCurrentItem())));

        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (coinList.get(mViewPager.getCurrentItem()) <= Constant.coinget) {

                    Constant.coinget = Constant.coinget - coinList.get(mViewPager.getCurrentItem());
                    coin.setText(String.valueOf(Constant.coinget));
                    String android_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

                    free.setVisibility(View.VISIBLE);
                    premin.setVisibility(View.GONE);
                    mFirebaseDatabase.child(android_id).setValue(Constant.coinget);

                    coinList.add(mViewPager.getCurrentItem(), 0);
                    t.putListInt("coinlist", coinList);

                    // TODO: 31-05-2022

                    callBottomsheet();
                    bottomSheet.setVisibility(View.VISIBLE);


                } else {
                }

                dialog.dismiss();

            }
        });
        if (!isFinishing()) {
            dialog.show();
        }
    }


    public void watchAd() {
        Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.watchad);
        dialog.setCancelable(false);
        ImageView txt_yes = (ImageView) dialog.findViewById(R.id.yes);
        ImageView r_retry = (ImageView) dialog.findViewById(R.id.r_retry);

        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        r_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (SelectCatActivity.adtime == true) {
                    showRewardedVideo();
                } else {
                    someAfter30();
                }

                dialog.dismiss();

            }
        });
        if (!isFinishing()) {
            dialog.show();
        }
    }


    public void someAfter30() {
        Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.aftersecond);
        dialog.setCancelable(false);
        ImageView txt_yes = (ImageView) dialog.findViewById(R.id.yes);
        ImageView r_retry = (ImageView) dialog.findViewById(R.id.r_retry);


        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        if (!isFinishing()) {
            dialog.show();
        }
    }


    private void showRewardedVideo() {

        if (RewardAd.rewAd == null) {
            RewardAd.counter++;

            if (RewardAd.counter > 4) {
                RewardAd.loadRewardedAd(AActivity.this);
                RewardAd.counter = 0;
            }


            Toast toast = new Toast(AActivity.this);
            View view = LayoutInflater.from(AActivity.this)
                    .inflate(R.layout.toast_layout, null);
            toast.setView(view);
            toast.show();

            return;
        }

        RewardAd.rewAd.setFullScreenContentCallback(
                new FullScreenContentCallback() {
                    @Override
                    public void onAdShowedFullScreenContent() {
                        RewardAd.counter = 0;
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        RewardAd.rewAd = null;
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        SelectCatActivity.adtime = false;
                        if (SelectCatActivity.c != null) {
                            SelectCatActivity.c.cancel();
                            SelectCatActivity.c.start();
                        }

                        RewardAd.rewAd = null;
                        RewardAd.loadRewardedAd(AActivity.this);
                    }
                });

        Activity activityContext = AActivity.this;

        RewardAd.rewAd.show(activityContext, new OnUserEarnedRewardListener() {
            @Override
            public void onUserEarnedReward(@NonNull RewardItem rewardItem) {

                SelectCatActivity.adtime = false;

                if (SelectCatActivity.c != null) {
                    SelectCatActivity.c.cancel();
                    SelectCatActivity.c.start();
                }

                coin1.setText(String.valueOf(coinList.get(mViewPager.getCurrentItem())));
                Constant.coinget++;
                coin.setText(String.valueOf(Constant.coinget));


                String android_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                mFirebaseDatabase.child(android_id).setValue(Constant.coinget);

                if (coinList.get(mViewPager.getCurrentItem()) <= Constant.coinget) {

                } else {

                }

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        music.start();
//                        llcoin.startAnimation(AnimationUtils.loadAnimation(AActivity.this, R.anim.pulse));

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                music.stop();
//                                llcoin.clearAnimation();
                            }
                        }, 3000);

                    }
                }, 1000);
            }
        });
    }


    private int getIndex(String rawPath, ArrayList<Alarm> list) {
        int i = 0;
        while (i < list.size()) {
            if (list.get(i).getPath().equals(rawPath)) {
                return list.get(i).getId();
            }
            i++;
        }
        return -1;
    }


    void Downloadimage() {

        File root = null;

        root = new File(getExternalFilesDir("") + File.separator + "Wallpaper" + File.separator);


        root.mkdirs();
        sdImageMainDirectory = new File(root, alllust.get(pos).getCategory() + alllust.get(pos).getWallpaper().get(mViewPager.getCurrentItem()).getName());

        if (sdImageMainDirectory.exists()) {

            try {

                Uri uri = FileProvider.getUriForFile(AActivity.this, getPackageName() + ".provider", new File(sdImageMainDirectory.getAbsolutePath()));
                if (uri != null) {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    if (bitmap != null) {
                        Bitmap b = cropBitmapFromCenterAndScreenSize(bitmap);

                        if (b != null) {
                            WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());

                            Display display = getWindowManager().getDefaultDisplay();
                            Point size = new Point();
                            display.getSize(size);

                            int width = size.x;
                            int height = size.y;

                            manager.setWallpaperOffsetSteps(1, 1);
                            manager.suggestDesiredDimensions(width, height);
                            manager.setBitmap(b);

                            Toast.makeText(AActivity.this, "Wallpaper set sucessfully..", Toast.LENGTH_LONG).show();

                        }
                    }


                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Constant.getInstance().showprogress(this);
            DownloadFile downloadFile = new DownloadFile();
            downloadFile.execute(bAllList.get(mViewPager.getCurrentItem()).getOriginal(), alllust.get(pos).getCategory() + alllust.get(pos).getWallpaper().get(mViewPager.getCurrentItem()).getName());
        }
    }

    private class DownloadFile extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... sUrl) {
            try {

                URL url = new URL(sUrl[0]);
                URLConnection connection = url.openConnection();
                connection.connect();
                int fileLength = connection.getContentLength();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
                String currentDateandTime = sdf.format(new Date());

                InputStream input = new BufferedInputStream(url.openStream());
                File root = null;
                int currentapiVersion = Build.VERSION.SDK_INT;


                root = new File(getExternalFilesDir("") + File.separator + "Wallpaper" + File.separator);


                sdImageMainDirectory = new File(root, alllust.get(pos).getCategory() + alllust.get(pos).getWallpaper().get(mViewPager.getCurrentItem()).getName());
                root.mkdirs();

                FileOutputStream output = new FileOutputStream(sdImageMainDirectory);

                byte data[] = new byte[1024];
                long total = 0;
                int count;

                while ((count = input.read(data)) != -1) {
                    total += count;
                    publishProgress("" + (int) ((total * 100) / fileLength));
                    output.write(data, 0, count);
                }

                output.flush();
                output.close();
                input.close();

            } catch (Exception e) {

            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            Constant.getInstance().text.setText(String.valueOf(Integer.parseInt(values[0])) + " %");
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Constant.getInstance().hideprogress();
            try {

                mViewPager.getAdapter().notifyDataSetChanged();
                MediaScannerConnection.scanFile(AActivity.this,
                        new String[]{sdImageMainDirectory.getAbsolutePath()}, null,
                        new MediaScannerConnection.OnScanCompletedListener() {

                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });

                Uri uri = FileProvider.getUriForFile(AActivity.this, getPackageName() + ".provider", new File(sdImageMainDirectory.getAbsolutePath()));

                if (uri != null) {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    if (bitmap != null) {
                        Bitmap b = cropBitmapFromCenterAndScreenSize(bitmap);
                        if (b != null) {
                            WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                            manager.setBitmap(b);

                            Toast.makeText(AActivity.this, "Wallpaper set sucessfully..", Toast.LENGTH_LONG).show();
                        }
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void InternetDialgWall() {
        Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.net_connection);
        dialog.setCancelable(false);
        RelativeLayout txt_yes = (RelativeLayout) dialog.findViewById(R.id.yes);
        RelativeLayout r_retry = (RelativeLayout) dialog.findViewById(R.id.r_retry);
        TextView txt = (TextView) dialog.findViewById(R.id.txt);
        txt.setText("Internet is not working.\n" + "Start your Internet and restart app.");


        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });

        r_retry.setVisibility(View.GONE);


        dialog.show();

    }

    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(AActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });
    }
}