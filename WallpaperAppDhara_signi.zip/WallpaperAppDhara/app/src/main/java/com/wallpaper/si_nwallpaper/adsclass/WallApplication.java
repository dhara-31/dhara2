

package com.wallpaper.si_nwallpaper.adsclass;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.retrofitcall.DetailAds;

import java.util.ArrayList;

public class WallApplication extends Application implements Application.ActivityLifecycleCallbacks {


    public static boolean isSplashFinissh = false;

    public static String splashscreennameWall = "SplashActivity";

    public Integer openvalueWalll = 0;

    public Integer intervalueWlall = 0;

    private static WallApplication ourInstance;

    public SharedPreferences preferences;

    public static WallApplication getInstance() {
        return ourInstance;
    }

    public static final String MyPREFERENCES = "MyAdsPrefs";
    private static final String PREF_APP_DETAILS = "app_details", PREF_ADS_DETAILS = "ads_details";
    private ArrayList<DetailAds> detailAds;
    public static WallAppOpen appWall;

    public static WallApplication c() {
        return ourInstance;
    }

    Dialog dialog;

    public static String one_signal = "";

    @Override
    public void onCreate() {
        super.onCreate();
        ourInstance = this;
        registerActivityLifecycleCallbacks(this);

        preferences = getApplicationContext().getSharedPreferences(MyPREFERENCES, MODE_PRIVATE);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        callOneSignal();
    }


    public void callOneSignal() {

    }

    public void initializeOpenVideo() {
        appWall = new WallAppOpen(this);
    }


    public AppDetailWp getAppDetailVWallStatic() {
        return new Gson().fromJson(preferences.getString(PREF_APP_DETAILS, ""), AppDetailWp.class);
    }


    public boolean isNetworkAvailable() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            boolean isAvailable = false;
            if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                isAvailable = true;
            }
            return isAvailable;
        } catch (Exception e) {
            return false;
        }
    }

    public void setAppDetail(AppDetailWp appDetail) {
        preferences.edit().putString(PREF_APP_DETAILS, new Gson().toJson(appDetail)).apply();
    }

    public ArrayList<DetailAds> getAdsDetails() {
        return new Gson().fromJson(preferences.getString(PREF_ADS_DETAILS, ""), new TypeToken<ArrayList<DetailAds>>() {
        }.getType());
    }

    public void setAdsDetails(ArrayList<DetailAds> adsDetails) {
        this.detailAds = adsDetails;
        preferences.edit().putString(PREF_ADS_DETAILS, new Gson().toJson(adsDetails)).apply();
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
        try {
            if (activity != null && !activity.toString().contains("SplashActivity")) {
                if (appWall == null) {
                    appWall = new WallAppOpen(this);
                    openvalueWalll = 2;
                    intervalueWlall = 2;
                }


            }
        } catch (Exception e) {
        }
    }


    @Override
    public void onActivityStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {

    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {

    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {

    }
}
