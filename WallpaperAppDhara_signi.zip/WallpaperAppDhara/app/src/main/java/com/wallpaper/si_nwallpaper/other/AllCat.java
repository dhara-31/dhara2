package com.wallpaper.si_nwallpaper.other;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AllCat {

    public class Datum {

        @SerializedName("id")
        @Expose
        private Integer id;
        @SerializedName("category")
        @Expose
        private String category;

        @SerializedName("thumbnail")
        @Expose
        private String thumb;


        @SerializedName("wallpaper")
        @Expose
        private List<Wallpaper> wallpaper = null;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getCategory() {
            return category;
        }


        public String getthub() {
            return thumb;
        }

        public void setthumb(String thumb) {
            this.thumb = thumb;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public List<Wallpaper> getWallpaper() {
            return wallpaper;
        }

        public void setWallpaper(List<Wallpaper> wallpaper) {
            this.wallpaper = wallpaper;
        }

    }


    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private List<Datum> data = null;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }


    public class Wallpaper {

        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("original")
        @Expose
        private String original;
        @SerializedName("thumbnail")
        @Expose
        private String thumbnail;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOriginal() {
            return original;
        }

        public void setOriginal(String original) {
            this.original = original;
        }

        public String getThumbnail() {
            return thumbnail;
        }

        public void setThumbnail(String thumbnail) {
            this.thumbnail = thumbnail;
        }
    }
}
