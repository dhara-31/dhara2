package com.wallpaper.si_nwallpaper.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.AllCatAdapterMain;
import com.wallpaper.si_nwallpaper.adapter.AllSubCatAdapter;
import com.wallpaper.si_nwallpaper.adapter.CointAdapter;
import com.wallpaper.si_nwallpaper.adapter.FavAdapter;
import com.wallpaper.si_nwallpaper.adapter.GalleryAdapter;
import com.wallpaper.si_nwallpaper.adsclass.ActivityExit;
import com.wallpaper.si_nwallpaper.adsclass.RewardAd;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.database.Alarm;
import com.wallpaper.si_nwallpaper.database.DBHelper;
import com.wallpaper.si_nwallpaper.database.DBplaylist;
import com.wallpaper.si_nwallpaper.database.PlayList;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.Constant;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SelectCatActivity extends AppCompatActivity {

    ImageView colle;
    RecyclerView gallery;
    RecyclerView fav;
    File sdImageMainDirectory;
    AlertDialog alertDialogPopup;
    TextView text;
    public static int nextwall = 0;
    ArrayList<String> b;
    ImageView play;
    TextView coin;
    RecyclerView allcat;
    ImageView home, cato, newa, treding;
    RecyclerView recy;

    public static CountDownTimer c;
    public static Boolean adtime = true;
    ArrayList<AllCat.Datum> alllust;
    LinearLayout ll;
    ImageView next;
    Integer value = 0;
    TinyDB t;
    MediaPlayer music;
    DBplaylist dbplay;

    LinearLayout b9;


    private FirebaseDatabase mFirebaseInstance;
    private DatabaseReference mFirebaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectcat);

        music = MediaPlayer.create(this, R.raw.xbox);
        mFirebaseInstance = FirebaseDatabase.getInstance("https://wallpaperapp-e7e13-default-rtdb.firebaseio.com/");
        mFirebaseDatabase = mFirebaseInstance.getReference().child("wallCoinsData");

        dbplay = new DBplaylist(this);


        if (WallApplication.getInstance().isNetworkAvailable()) {

        } else {
            InternetDialgWall();
        }


        b9 = findViewById(R.id.b);

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GAdsWallPaperWp.getInstance().showInterWallpaper(SelectCatActivity.this, new GAdsWallPaperWp.AdsInterface() {
                    @Override
                    public void adsCall() {
                        startActivity(new Intent(SelectCatActivity.this, PlayListActivity.class));
                    }
                });

            }
        });


        LinearLayout l3 = findViewById(R.id.l3);
        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
        if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") && appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {
            l3.setVisibility(View.VISIBLE);
        } else {
            l3.setVisibility(View.INVISIBLE);
        }


        ImageView drw = findViewById(R.id.drw);
        l3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (SelectCatActivity.adtime == true) {
                    watchAd();
                } else {
                    someAfter30();
                }
            }
        });

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        LinearLayout rateus = drawerLayout.findViewById(R.id.rateus);
        LinearLayout privacy = findViewById(R.id.privacy);
        LinearLayout share = findViewById(R.id.share);

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.close();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey check out my great app.\nat: https://play.google.com/store/apps/details?id=" + getPackageName());
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });


     /*   LinearLayout sw = drawerLayout.findViewById(R.id.sw);

        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((HorizontalScrollView) findViewById(R.id.h)).post(new Runnable() {
                    public void run() {
                        ((HorizontalScrollView) findViewById(R.id.h)).fullScroll(View.FOCUS_UP);
                    }
                });

                ArrayList<AllCat.Datum> homeList = new ArrayList<>();
                colle.setImageDrawable(getResources().getDrawable(R.drawable.collection_d));
                treding.setImageDrawable(getResources().getDrawable(R.drawable.trending_d));
                home.setImageResource(R.drawable.home_a);
                cato.setImageResource(R.drawable.categories_d);
                newa.setImageResource(R.drawable.newly_d);

                allcat.setVisibility(View.VISIBLE);
                ll.setVisibility(View.GONE);
                recy.setVisibility(View.GONE);


                for (int j = 0; j < t.getListInt("chhose").size(); j++) {
                    homeList.add(alllust.get(t.getListInt("chhose").get(j)));
                }

                LinearLayoutManager gridLayoutManager = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.VERTICAL, false);
                AllCatAdapterMain wallpapersAdapter = new AllCatAdapterMain(homeList, SelectCatActivity.this, 1);
                allcat.setLayoutManager(gridLayoutManager);
                allcat.setHasFixedSize(true);
                allcat.setItemAnimator(new DefaultItemAnimator());
                allcat.setAdapter(wallpapersAdapter);

                drawerLayout.close();


            }
        });
*/
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.close();

                try {
                    if (WallApplication.getInstance().getAppDetailVWallStatic() != null) {
                        if (WallApplication.getInstance().getAppDetailVWallStatic().getPrivacy() != null && !WallApplication.getInstance().getAppDetailVWallStatic().getPrivacy().trim().isEmpty()) {

                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(WallApplication.getInstance().getAppDetailVWallStatic().getPrivacy()));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.setPackage("com.android.chrome");
                            try {
                                startActivity(i);
                            } catch (ActivityNotFoundException e) {
                                Toast.makeText(SelectCatActivity.this, "Unable to open chrome", Toast.LENGTH_SHORT).show();
                                i.setPackage(null);
                                startActivity(i);
                            }
                        } else {
                            Toast.makeText(SelectCatActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SelectCatActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(SelectCatActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                }
            }
        });

        rateus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.close();
                String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });


        coin = findViewById(R.id.coin);
//        l3.startAnimation(AnimationUtils.loadAnimation(this, R.anim.pulse));


        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.open();
            }
        });


        if (appDetail != null && appDetail.getAddmobcounter() != null && !TextUtils.isEmpty(appDetail.getAddmobcounter())) {
            Long timervalue = Long.parseLong(appDetail.getAddmobcounter()) * 1000;
            c = new CountDownTimer(timervalue, 1000) {
                public void onTick(long millisUntilFinished) {
                }

                public void onFinish() {
                    adtime = true;
                }
            }.start();

        } else {
            c = new CountDownTimer(30000, 1000) {

                public void onTick(long millisUntilFinished) {
                }

                public void onFinish() {
                    adtime = true;
                }
            }.start();

        }


        home = findViewById(R.id.home);
        allcat = findViewById(R.id.allcat);
        colle = findViewById(R.id.colle);
        newa = findViewById(R.id.newa);
        treding = findViewById(R.id.t);
        recy = findViewById(R.id.recy);
        cato = findViewById(R.id.cato);


        // TODO: 12-05-2022 change
        int currentapiVersion = Build.VERSION.SDK_INT;
        if (currentapiVersion <= 30) {
            nextwall = 0;
        }

        String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
        DatabaseReference reference = FirebaseDatabase.getInstance("https://wallpaperapp-e7e13-default-rtdb.firebaseio.com/").getReference().child("wallCoinsData");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Boolean a = false;

                for (DataSnapshot dataSnap : dataSnapshot.getChildren()) {
                    String object = dataSnap.getKey().toString();

                    if (android_id.equals(object)) {
                        a = true;
                        Constant.coinget = Integer.parseInt(dataSnap.getValue().toString());
                        coin.setText(String.valueOf(Constant.coinget));
                        break;
                    }
                }

                if (a == true) {

                } else {
                    reference.child(android_id).setValue(0);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });


        DBHelper db = new DBHelper(SelectCatActivity.this);
        gallery = findViewById(R.id.gallery);
        fav = findViewById(R.id.favrec);
        play = findViewById(R.id.play);

        ImageView image = findViewById(R.id.image);
        next = findViewById(R.id.next);

        ll = findViewById(R.id.ll);

        ImageView gallerall = findViewById(R.id.gallerall);
        ImageView favall = findViewById(R.id.favall);
        ImageView playall = findViewById(R.id.playall);
        ImageView g = findViewById(R.id.g);

        ll.setVisibility(View.GONE);

        t = new TinyDB(SelectCatActivity.this);

        alllust = t.getListAll("allcat");
        colle.setImageDrawable(getResources().getDrawable(R.drawable.collection_d));
        treding.setImageDrawable(getResources().getDrawable(R.drawable.trending_d));
        home.setImageResource(R.drawable.home_a);
        cato.setImageResource(R.drawable.categories_d);
        newa.setImageResource(R.drawable.newly_d);

        allcat.setVisibility(View.VISIBLE);
        ll.setVisibility(View.GONE);
        recy.setVisibility(View.GONE);

        List<AllCat.Wallpaper> newList = new ArrayList<>();

        newList = alllust.get(t.getInt("exclusive")).getWallpaper();
        ArrayList<Integer> coinlist = new ArrayList<>();
        coinlist = t.getListInt("coinlist");

        if (coinlist.size() == 0) {
            for (int j = 0; j < newList.size(); j++) {
                final int min = 3;
                final int max = 8;

                Integer coi = 4;

                String d = String.valueOf(j);
                String str = String.valueOf(j);
                if (j > 10) {
                    str = d.substring(d.length() - 1, d.length());
                }

                if (String.valueOf(str).contains("0")) {
                    coi = 5;
                } else if (String.valueOf(str).contains("1")) {
                    coi = 3;
                } else if (String.valueOf(str).contains("2")) {
                    coi = 7;
                } else if (String.valueOf(str).contains("3")) {
                    coi = 4;
                } else if (String.valueOf(str).contains("4")) {
                    coi = 6;
                } else if (String.valueOf(str).contains("5")) {
                    coi = 8;
                } else if (String.valueOf(str).contains("6")) {
                    coi = 4;
                } else if (String.valueOf(str).contains("7")) {
                    coi = 5;
                } else if (String.valueOf(str).contains("8")) {
                    coi = 6;
                } else if (String.valueOf(str).contains("9")) {
                    coi = 3;
                }
                coinlist.add(coi);

            }
        }

        t.putListInt("coinlist", coinlist);

        if (Constant.c.size() != 0 && Constant.c != null) {
            t.putListInt("chhose", Constant.c);
        }


        ArrayList<AllCat.Datum> homeList = new ArrayList<>();
        for (int j = 0; j < t.getListInt("chhose").size(); j++) {
            homeList.add(alllust.get(t.getListInt("chhose").get(j)));
        }

        LinearLayoutManager gridLayoutManager = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.VERTICAL, false);
        AllCatAdapterMain wallpapersAdapter = new AllCatAdapterMain(homeList, SelectCatActivity.this, 1);
        allcat.setLayoutManager(gridLayoutManager);
        allcat.setHasFixedSize(true);
        allcat.setItemAnimator(new DefaultItemAnimator());
        allcat.setAdapter(wallpapersAdapter);


        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ArrayList<AllCat.Datum> homeList = new ArrayList<>();
                colle.setImageDrawable(getResources().getDrawable(R.drawable.collection_d));
                treding.setImageDrawable(getResources().getDrawable(R.drawable.trending_d));
                home.setImageResource(R.drawable.home_a);
                cato.setImageResource(R.drawable.categories_d);
                newa.setImageResource(R.drawable.newly_d);

                allcat.setVisibility(View.VISIBLE);
                ll.setVisibility(View.GONE);
                recy.setVisibility(View.GONE);


                for (int j = 0; j < t.getListInt("chhose").size(); j++) {
                    homeList.add(alllust.get(t.getListInt("chhose").get(j)));
                }

                LinearLayoutManager gridLayoutManager = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.VERTICAL, false);
                AllCatAdapterMain wallpapersAdapter = new AllCatAdapterMain(homeList, SelectCatActivity.this, 1);
                allcat.setLayoutManager(gridLayoutManager);
                allcat.setHasFixedSize(true);
                allcat.setItemAnimator(new DefaultItemAnimator());
                allcat.setAdapter(wallpapersAdapter);

            }
        });


        cato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                colle.setImageDrawable(getResources().getDrawable(R.drawable.collection_d));
                treding.setImageDrawable(getResources().getDrawable(R.drawable.trending_d));
                home.setImageResource(R.drawable.home_d);
                cato.setImageResource(R.drawable.categories_a);
                newa.setImageResource(R.drawable.newly_d);

                allcat.setVisibility(View.VISIBLE);
                ll.setVisibility(View.GONE);
                recy.setVisibility(View.GONE);

                LinearLayoutManager gridLayoutManager = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.VERTICAL, false);
                AllCatAdapterMain wallpapersAdapter = new AllCatAdapterMain(alllust, SelectCatActivity.this, 2);
                allcat.setLayoutManager(gridLayoutManager);
                allcat.setHasFixedSize(true);
                allcat.setItemAnimator(new DefaultItemAnimator());
                allcat.setAdapter(wallpapersAdapter);

            }
        });


        newa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                value = 1;
                colle.setImageDrawable(getResources().getDrawable(R.drawable.collection_d));
                treding.setImageDrawable(getResources().getDrawable(R.drawable.trending_d));
                home.setImageResource(R.drawable.home_d);
                cato.setImageResource(R.drawable.categories_d);
                newa.setImageResource(R.drawable.newly_a);

                List<AllCat.Wallpaper> newList = new ArrayList<>();


                allcat.setVisibility(View.GONE);
                ll.setVisibility(View.GONE);
                recy.setVisibility(View.VISIBLE);

                newList = alllust.get(t.getInt("exclusive")).getWallpaper();

                ArrayList<Integer> coinlist = new ArrayList<>();

                coinlist = t.getListInt("coinlist");

                if (coinlist.size() == 0) {
                    for (int j = 0; j < newList.size(); j++) {
                        final int min = 3;
                        final int max = 8;

                        Integer coi = 4;


                        String d = String.valueOf(j);
                        String str = String.valueOf(j);
                        if (j > 10) {
                            str = d.substring(d.length() - 1, d.length());
                        }

                        if (String.valueOf(str).contains("0")) {
                            coi = 5;
                        } else if (String.valueOf(str).contains("1")) {
                            coi = 3;
                        } else if (String.valueOf(str).contains("2")) {
                            coi = 7;
                        } else if (String.valueOf(str).contains("3")) {
                            coi = 4;
                        } else if (String.valueOf(str).contains("4")) {
                            coi = 6;
                        } else if (String.valueOf(str).contains("5")) {
                            coi = 8;
                        } else if (String.valueOf(str).contains("6")) {
                            coi = 4;
                        } else if (String.valueOf(str).contains("7")) {
                            coi = 5;
                        } else if (String.valueOf(str).contains("8")) {
                            coi = 6;
                        } else if (String.valueOf(str).contains("9")) {
                            coi = 3;
                        }

                        coinlist.add(coi);

                    }
                }

                t.putListInt("coinlist", coinlist);
                recy = (RecyclerView) findViewById(R.id.recy);

                GridLayoutManager gridLayoutManager = new GridLayoutManager(SelectCatActivity.this, 3);
                CointAdapter wallpapersAdapter = new CointAdapter(newList, SelectCatActivity.this, t.getInt("exclusive"), "0", coinlist);
                recy.setLayoutManager(gridLayoutManager);
                recy.setHasFixedSize(true);
                recy.setItemAnimator(new DefaultItemAnimator());
                recy.setAdapter(wallpapersAdapter);

            }
        });


        treding.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                value = 2;
                ll.setVisibility(View.GONE);
                recy.setVisibility(View.VISIBLE);
                allcat.setVisibility(View.GONE);

                colle.setImageDrawable(getResources().getDrawable(R.drawable.collection_d));
                treding.setImageDrawable(getResources().getDrawable(R.drawable.trending_a));

                cato.setImageResource(R.drawable.categories_d);
                home.setImageResource(R.drawable.home_d);
                newa.setImageResource(R.drawable.newly_d);

                List<AllCat.Wallpaper> newList = new ArrayList<>();

                if (alllust.size() > 12) {
                    newList = alllust.get(12).getWallpaper();
                    recy = (RecyclerView) findViewById(R.id.recy);
                    GridLayoutManager gridLayoutManager = new GridLayoutManager(SelectCatActivity.this, 3);
                    AllSubCatAdapter wallpapersAdapter = new AllSubCatAdapter(newList, SelectCatActivity.this, 12, "0");
                    recy.setLayoutManager(gridLayoutManager);
                    recy.setHasFixedSize(true);
                    recy.setItemAnimator(new DefaultItemAnimator());
                    recy.setAdapter(wallpapersAdapter);
                }
            }
        });

        colle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ll.setVisibility(View.VISIBLE);
                allcat.setVisibility(View.GONE);
                recy.setVisibility(View.GONE);

                treding.setImageDrawable(getResources().getDrawable(R.drawable.trending_d));
                colle.setImageDrawable(getResources().getDrawable(R.drawable.collection_a));
                home.setImageResource(R.drawable.home_d);
                cato.setImageResource(R.drawable.categories_d);
                newa.setImageResource(R.drawable.newly_d);

                ArrayList<String> b = t.getListString("gallery");
                LinearLayoutManager gridLayoutManager = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.HORIZONTAL, false);
                GalleryAdapter wallpapersAdapter = new GalleryAdapter(b, SelectCatActivity.this, 1);
                gallery.setLayoutManager(gridLayoutManager);
                gallery.setHasFixedSize(true);
                gallery.setItemAnimator(new DefaultItemAnimator());
                gallery.setAdapter(wallpapersAdapter);


                ArrayList<Alarm> favList = db.getAllFav();

                if (favList.size() != 0) {
                    LinearLayout l1 = findViewById(R.id.l2);
                    l1.setVisibility(View.VISIBLE);
                    LinearLayoutManager gridLayoutManager1 = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.HORIZONTAL, false);
                    FavAdapter wallpapersAdapter1 = new FavAdapter(favList, SelectCatActivity.this, 1);
                    fav.setLayoutManager(gridLayoutManager1);
                    fav.setHasFixedSize(true);
                    fav.setItemAnimator(new DefaultItemAnimator());
                    fav.setAdapter(wallpapersAdapter1);
                } else {
                    LinearLayout l1 = findViewById(R.id.l2);
                    l1.setVisibility(View.GONE);
                }

                RecyclerView playallrec = findViewById(R.id.playallrec);


                ArrayList<String> b1 = new ArrayList<>();
                ArrayList<PlayList> pList = dbplay.getAllPlayList();

                for (PlayList a : pList) {
                    b1.add(a.getPath());
                }

                if (b1.size() != 0) {
                    LinearLayout l1 = findViewById(R.id.l6);
                    l1.setVisibility(View.VISIBLE);
                    LinearLayoutManager gridLayoutManager2 = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.HORIZONTAL, false);
                    GalleryAdapter wallpapersAdapter2 = new GalleryAdapter(b1, SelectCatActivity.this, 10);
                    playallrec.setLayoutManager(gridLayoutManager2);
                    playallrec.setHasFixedSize(true);
                    playallrec.setItemAnimator(new DefaultItemAnimator());
                    playallrec.setAdapter(wallpapersAdapter2);
                } else {
                    LinearLayout l3 = findViewById(R.id.l6);
                    l3.setVisibility(View.GONE);
                }
            }
        });

        gallerall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GAdsWallPaperWp.getInstance().showInterWallpaper(SelectCatActivity.this, new GAdsWallPaperWp.AdsInterface() {
                    @Override
                    public void adsCall() {
                        startActivity(new Intent(SelectCatActivity.this, GallerySelectedActivity.class));
                    }
                });
            }
        });


        favall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                GAdsWallPaperWp.getInstance().showInterWallpaper(SelectCatActivity.this, new GAdsWallPaperWp.AdsInterface() {
                    @Override
                    public void adsCall() {
                        startActivity(new Intent(SelectCatActivity.this, FavSelectedActivity.class));
                    }
                });
            }
        });


        playall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GAdsWallPaperWp.getInstance().showInterWallpaper(SelectCatActivity.this, new GAdsWallPaperWp.AdsInterface() {
                    @Override
                    public void adsCall() {
                        startActivity(new Intent(SelectCatActivity.this, PlayListActivity.class));
                    }
                });
            }
        });


        g.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                GAdsWallPaperWp.getInstance().showInterWallpaper(SelectCatActivity.this, new GAdsWallPaperWp.AdsInterface() {
                    @Override
                    public void adsCall() {
                        startActivity(new Intent(SelectCatActivity.this, GalleryActivity.class));
                    }
                });
            }
        });


        b = new ArrayList<>();
        ArrayList<PlayList> pList = dbplay.getAllPlayList();

        for (PlayList a : pList) {
            b.add(a.getPath());
        }

        if (b.size() != 0) {
            b9.setVisibility(View.VISIBLE);

            if (currentapiVersion >= 30) {
                if (Constant.v == 0) {
                    if (b.size() != 0) {
                        if (b.size() > nextwall) {
                            Glide.with(SelectCatActivity.this).load(b.get(nextwall)).into(image);
                        }
                    }
                } else {
                    if ((nextwall - 1) > -1) {
                        Glide.with(SelectCatActivity.this).load(b.get(nextwall - 1)).into(image);
                    } else {

                        Glide.with(SelectCatActivity.this).load(b.get(b.size() - 1)).into(image);
                    }
                }
            } else {
                Glide.with(SelectCatActivity.this).load(b.get(nextwall)).into(image);
            }
        } else {
            b9.setVisibility(View.GONE);
        }


        if (t.getBoolean("play") == false) {
            play.setImageResource(R.drawable.play);
        } else {
            play.setImageResource(R.drawable.pause);
        }

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (b.size() != 0) {

                    if (t.getBoolean("play") == false) {

                        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(SelectCatActivity.this);
                        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        View dialogView = inflater.inflate(R.layout.progressdialog, null);
                        VideoView videoView = dialogView.findViewById(R.id.videoView);
                        videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.loading));
                        videoView.start();
                        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {
                                videoView.start();
                            }
                        });


                        text = dialogView.findViewById(R.id.download);
                        dialogBuilder.setView(dialogView);
                        alertDialogPopup = dialogBuilder.create();
                        alertDialogPopup.setCanceledOnTouchOutside(false);
                        alertDialogPopup.setCancelable(false);
                        alertDialogPopup.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                        play.setImageResource(R.drawable.pause);
                        t.putBoolean("play", true);
                        Toast.makeText(SelectCatActivity.this, "Playlist On..", Toast.LENGTH_LONG).show();

                        File root = null;
                        int currentapiVersion = Build.VERSION.SDK_INT;
                        root = new File(getExternalFilesDir("") + File.separator + "Wallpaper" + File.separator);


                        if (b.size() != 0) {

                            if (b.size() > nextwall) {

                                ArrayList<PlayList> pList = dbplay.getAllPlayList();


                                Glide.with(SelectCatActivity.this).load(b.get(nextwall)).into(image);
                                root.mkdirs();

                                if (b.get(nextwall).startsWith("https")) {
                                    sdImageMainDirectory = new File(root, pList.get(nextwall).getColorname());
                                } else {
                                    sdImageMainDirectory = new File(b.get(nextwall));
                                }

                                if (sdImageMainDirectory.exists()) {

                                    Uri uri = FileProvider.getUriForFile(SelectCatActivity.this, getPackageName() + ".provider", new File(sdImageMainDirectory.getAbsolutePath()));
                                    WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                                    try {
                                        if (uri != null) {
                                            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                                            if (bitmap != null) {
                                                manager.clear();
                                                manager.setBitmap(bitmap);
                                                Toast.makeText(SelectCatActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
                                                nextwall++;
                                                Constant.v = 1;
                                            }
                                        }
                                    } catch (Exception e) {
                                    }
                                } else {
                                    Downloadimage();
                                }
                            } else {
                                Toast.makeText(SelectCatActivity.this, "Complete...", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(SelectCatActivity.this, "Please Add Playlist Data...", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        play.setImageResource(R.drawable.play);
                        t.putBoolean("play", false);
                        Toast.makeText(SelectCatActivity.this, "Playlist off..", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(SelectCatActivity.this, "Please Add Playlist Data...", Toast.LENGTH_LONG).show();
                }
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                next.setEnabled(false);
                ArrayList<PlayList> pList = dbplay.getAllPlayList();

                if (t.getBoolean("play") == true) {
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(SelectCatActivity.this);
                    LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    View dialogView = inflater.inflate(R.layout.progressdialog, null);
                    VideoView videoView = dialogView.findViewById(R.id.videoView);
                    videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.loading));
                    videoView.start();

                    videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            videoView.start();
                        }
                    });

                    text = dialogView.findViewById(R.id.download);
                    dialogBuilder.setView(dialogView);
                    alertDialogPopup = dialogBuilder.create();
                    alertDialogPopup.setCanceledOnTouchOutside(false);
                    alertDialogPopup.setCancelable(false);
                    alertDialogPopup.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));


                    File root = null;

                    int currentapiVersion = Build.VERSION.SDK_INT;
                    // TODO: 24-05-2022 add

                    root = new File(getExternalFilesDir("") + File.separator + "Wallpaper" + File.separator);


                    if (b.size() != 0) {

                        if (b.size() > nextwall) {
                            Glide.with(SelectCatActivity.this).load(b.get(nextwall)).into(image);
                            root.mkdirs();

                            if (b.get(nextwall).startsWith("http")) {
                                sdImageMainDirectory = new File(root, pList.get(nextwall).getColorname());
                            } else {

                                sdImageMainDirectory = new File(b.get(nextwall));
                            }


                            if (sdImageMainDirectory.exists()) {

                                Uri uri = Uri.fromFile(sdImageMainDirectory);
                                WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());

                                if (uri != null) {
                                    Bitmap bitmap = null;
                                    try {
                                        bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        if (bitmap != null) {
                                            manager.clear();
                                            manager.setBitmap(bitmap);
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    Toast.makeText(SelectCatActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
                                    nextwall++;
                                    Constant.v = 1;

                                    next.setEnabled(true);
                                    if (b.size() == nextwall) {
                                        nextwall = 0;
                                    }
                                }

                            } else {
                                Downloadimage();
                            }
                        } else {
                            next.setEnabled(true);
                            nextwall = 0;


                            Glide.with(SelectCatActivity.this).load(b.get(nextwall)).into(image);
                            root.mkdirs();

                            if (b.get(nextwall).startsWith("http")) {
                                sdImageMainDirectory = new File(root, pList.get(nextwall).getColorname());
                            } else {
                                sdImageMainDirectory = new File(b.get(nextwall));
                            }

                            if (sdImageMainDirectory.exists()) {

                                Uri uri = Uri.fromFile(sdImageMainDirectory);
                                WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());

                                if (uri != null) {
                                    Bitmap bitmap = null;

                                    try {
                                        bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        if (bitmap != null) {
                                            manager.clear();
                                            manager.setBitmap(bitmap);
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                    Toast.makeText(SelectCatActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
                                    nextwall++;
                                    Constant.v = 1;

                                    next.setEnabled(true);
                                    if (b.size() == nextwall) {
                                        nextwall = 0;
                                    }
                                }

                            } else {
                                Downloadimage();
                            }
                        }
                    } else {
                        Toast.makeText(SelectCatActivity.this, "Please Add Playlist Data...", Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(SelectCatActivity.this, "First Click On Play Button", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    public void InternetDialgWall() {
        Dialog popup = new Dialog(this);
        popup.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        popup.requestWindowFeature(1);
        popup.setContentView(R.layout.net_connection);
        popup.setCancelable(false);
        RelativeLayout txt_yes = (RelativeLayout) popup.findViewById(R.id.yes);
        RelativeLayout r_retry = (RelativeLayout) popup.findViewById(R.id.r_retry);
        TextView txt = (TextView) popup.findViewById(R.id.txt);
        txt.setText("Internet is not working.\n" + "Start your Internet and restart app.");


        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popup.dismiss();
                finish();

                finishAffinity();
            }
        });
        r_retry.setVisibility(View.GONE);
        popup.show();

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (WallApplication.getInstance().isNetworkAvailable()) {

        } else {
            InternetDialgWall();
        }


        DBHelper db = new DBHelper(SelectCatActivity.this);
        coin.setText(String.valueOf(Constant.coinget));


        if (value == 1) {
            List<AllCat.Wallpaper> newList = new ArrayList<>();
            newList = alllust.get(t.getInt("exclusive")).getWallpaper();

            ArrayList<Integer> coinlist = new ArrayList<>();
            coinlist = t.getListInt("coinlist");

            if (coinlist.size() == 0) {

                for (int j = 0; j < newList.size(); j++) {

                    final int min = 3;
                    final int max = 8;

                    Integer coi = 4;

                    int low = 3;
                    int high = 8;

                    if (String.valueOf(j).contains("0")) {
                        coi = 5;
                    } else if (String.valueOf(j).contains("1")) {
                        coi = 3;
                    } else if (String.valueOf(j).contains("2")) {
                        coi = 7;
                    } else if (String.valueOf(j).contains("3")) {
                        coi = 4;
                    } else if (String.valueOf(j).contains("4")) {
                        coi = 6;
                    } else if (String.valueOf(j).contains("5")) {
                        coi = 8;
                    } else if (String.valueOf(j).contains("6")) {
                        coi = 4;
                    } else if (String.valueOf(j).contains("7")) {
                        coi = 5;
                    } else if (String.valueOf(j).contains("8")) {
                        coi = 6;
                    } else if (String.valueOf(j).contains("9")) {
                        coi = 3;
                    }
                    coinlist.add(coi);
                }
            }

            t.putListInt("coinlist", coinlist);
            recy = (RecyclerView) findViewById(R.id.recy);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(SelectCatActivity.this, 3);
            CointAdapter wallpapersAdapter = new CointAdapter(newList, SelectCatActivity.this, t.getInt("exclusive"), "0", coinlist);
            recy.setLayoutManager(gridLayoutManager);
            recy.setHasFixedSize(true);
            recy.setItemAnimator(new DefaultItemAnimator());
            recy.setAdapter(wallpapersAdapter);
        }


        ArrayList<Alarm> favList = db.getAllFav();
        LinearLayout l10 = findViewById(R.id.l2);

        if (favList.size() != 0) {
            l10.setVisibility(View.VISIBLE);
            fav.setVisibility(View.VISIBLE);
            LinearLayoutManager gridLayoutManager1 = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.HORIZONTAL, false);
            FavAdapter wallpapersAdapter1 = new FavAdapter(favList, SelectCatActivity.this, 1);
            fav.setLayoutManager(gridLayoutManager1);
            fav.setHasFixedSize(true);
            fav.setItemAnimator(new DefaultItemAnimator());
            fav.setAdapter(wallpapersAdapter1);
        } else {
            l10.setVisibility(View.GONE);
            fav.setVisibility(View.GONE);
        }

        RecyclerView playallrec = findViewById(R.id.playallrec);

        b = new ArrayList<>();
        ArrayList<PlayList> pList = dbplay.getAllPlayList();

        for (PlayList a : pList) {
            b.add(a.getPath());
        }

        LinearLayout l9 = findViewById(R.id.l6);

        if (b.size() != 0) {
            b9.setVisibility(View.VISIBLE);
            playallrec.setVisibility(View.VISIBLE);
            l9.setVisibility(View.VISIBLE);
            LinearLayoutManager gridLayoutManager2 = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.HORIZONTAL, false);
            GalleryAdapter wallpapersAdapter2 = new GalleryAdapter(b, SelectCatActivity.this, 10);
            playallrec.setLayoutManager(gridLayoutManager2);
            playallrec.setHasFixedSize(true);
            playallrec.setItemAnimator(new DefaultItemAnimator());
            playallrec.setAdapter(wallpapersAdapter2);
        } else {
            playallrec.setVisibility(View.GONE);
            l9.setVisibility(View.GONE);
            b9.setVisibility(View.GONE);
        }


        ArrayList<String> b2 = t.getListString("gallery");
        LinearLayoutManager gridLayoutManager = new LinearLayoutManager(SelectCatActivity.this, LinearLayoutManager.HORIZONTAL, false);
        GalleryAdapter wallpapersAdapter = new GalleryAdapter(b2, SelectCatActivity.this, 1);
        gallery.setLayoutManager(gridLayoutManager);
        gallery.setHasFixedSize(true);
        gallery.setItemAnimator(new DefaultItemAnimator());
        gallery.setAdapter(wallpapersAdapter);
    }

    void Downloadimage() {


        if (WallApplication.getInstance().isNetworkAvailable()) {
            showprogress(this);
            DownloadFile downloadFile = new DownloadFile();
            ArrayList<PlayList> pList = dbplay.getAllPlayList();
            downloadFile.execute(b.get(nextwall), pList.get(nextwall).getColorname());
        } else {
            InternetDialgWall();
        }

    }


    public void showprogress(Activity context) {
        if (alertDialogPopup != null && !alertDialogPopup.isShowing()) {
            alertDialogPopup.show();
        }
    }


    private class DownloadFile extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... sUrl) {
            try {
                URL url = new URL(sUrl[0]);
                URLConnection connection = url.openConnection();
                connection.connect();
                int fileLength = connection.getContentLength();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
                String currentDateandTime = sdf.format(new Date());

                InputStream input = new BufferedInputStream(url.openStream());
                File root = null;

                int currentapiVersion = Build.VERSION.SDK_INT;

                root = new File(getExternalFilesDir("") + File.separator + "Wallpaper" + File.separator);


                root.mkdirs();

                if (b.get(nextwall).startsWith("http")) {
                    sdImageMainDirectory = new File(root, sUrl[1]);

                } else {
                    sdImageMainDirectory = new File(b.get(nextwall));
                }

                FileOutputStream output = new FileOutputStream(sdImageMainDirectory);

                byte data[] = new byte[1024];
                long total = 0;
                int count;

                while ((count = input.read(data)) != -1) {
                    total += count;
                    publishProgress("" + (int) ((total * 100) / fileLength));
                    output.write(data, 0, count);
                }

                output.flush();
                output.close();
                input.close();
            } catch (Exception e) {
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            text.setText(String.valueOf(Integer.parseInt(values[0])) + " %");
        }

        @SuppressLint("WrongThread")
        @RequiresApi(api = Build.VERSION_CODES.P)
        @Override
        protected void onPostExecute(String s) {

            super.onPostExecute(s);
            Down downloadFile = new Down();
            downloadFile.execute(b.get(nextwall), String.valueOf(nextwall));
        }
    }


    private class Down extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @RequiresApi(api = Build.VERSION_CODES.P)
        @Override
        protected String doInBackground(String... sUrl) {
            nextwall++;

            Constant.v = 1;

            if (b.size() == nextwall) {
                nextwall = 0;
            }

            hideprogress();


            Uri uri = FileProvider.getUriForFile(SelectCatActivity.this, getPackageName() + ".provider", new File(sdImageMainDirectory.getAbsolutePath()));


            if (uri != null) {
                Bitmap bitmap = null;
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Bitmap b = null;

                if (bitmap != null) {
                    b = cropBitmapFromCenterAndScreenSize(bitmap);
                }

                WallpaperManager manager = WallpaperManager.getInstance(getApplicationContext());
                Display display = getWindowManager().getDefaultDisplay();
                Point size = new Point();
                display.getSize(size);

                int width = size.x;
                int height = size.y;

                manager.setWallpaperOffsetSteps(1, 1);
                manager.suggestDesiredDimensions(width, height);
                try {
                    if (b != null) {
                        manager.setBitmap(b);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @SuppressLint("WrongThread")
        @RequiresApi(api = Build.VERSION_CODES.P)
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(SelectCatActivity.this, "Applied Successfully", Toast.LENGTH_SHORT).show();
            next.setEnabled(true);

        }
    }


    private Bitmap cropBitmapFromCenterAndScreenSize(Bitmap bitmap) {

        int screenWidth, screenHeight;
        float bitmap_width = bitmap.getWidth(), bitmap_height = bitmap.getHeight();

        Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();

        screenWidth = display.getWidth();
        screenHeight = display.getHeight();

        float bitmap_ratio = (float) (bitmap_width / bitmap_height);

        float screen_ratio = (float) (screenWidth / screenHeight);

        int bitmapNewWidth, bitmapNewHeight;

        if (screen_ratio > bitmap_ratio) {
            bitmapNewWidth = (int) screenWidth;
            bitmapNewHeight = (int) (bitmapNewWidth / bitmap_ratio);
        } else {
            bitmapNewHeight = (int) screenHeight;
            bitmapNewWidth = (int) (bitmapNewHeight * bitmap_ratio);
        }

        bitmap = Bitmap.createScaledBitmap(bitmap, bitmapNewWidth, bitmapNewHeight, true);

        int bitmapGapX, bitmapGapY;
        bitmapGapX = (int) ((bitmapNewWidth - screenWidth) / 2.0f);
        bitmapGapY = (int) ((bitmapNewHeight - screenHeight) / 2.0f);


        bitmap = Bitmap.createBitmap(bitmap, bitmapGapX, bitmapGapY, screenWidth, screenHeight);
        return bitmap;
    }


    public void hideprogress() {
        if (alertDialogPopup != null) {
            if (alertDialogPopup.isShowing()) {
                alertDialogPopup.dismiss();

            }
        }
    }

    public void showRewardedVideo(Activity activity) {
        if (RewardAd.rewAd == null) {
            RewardAd.counter++;

            if (RewardAd.counter > 4) {
                RewardAd.loadRewardedAd(activity);
                RewardAd.counter = 0;
            }

            Toast toast = new Toast(SelectCatActivity.this);
            View view = LayoutInflater.from(SelectCatActivity.this)
                    .inflate(R.layout.toast_layout, null);
            toast.setView(view);
            toast.show();

            return;
        }

        RewardAd.counter = 0;

        RewardAd.rewAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdShowedFullScreenContent() {
                RewardAd.counter = 0;
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError adError) {
                RewardAd.rewAd = null;
            }

            @Override
            public void onAdDismissedFullScreenContent() {
                SelectCatActivity.adtime = false;
                if (SelectCatActivity.c != null) {
                    SelectCatActivity.c.cancel();
                    SelectCatActivity.c.start();
                }

                RewardAd.rewAd = null;
                RewardAd.loadRewardedAd(activity);
            }
        });

        Activity activityContext = SelectCatActivity.this;

        RewardAd.rewAd.show(activityContext, new OnUserEarnedRewardListener() {
            @Override
            public void onUserEarnedReward(@NonNull RewardItem rewardItem) {

                SelectCatActivity.adtime = false;
                if (SelectCatActivity.c != null) {
                    SelectCatActivity.c.cancel();
                    SelectCatActivity.c.start();
                }

                Constant.coinget++;
                coin.setText(String.valueOf(Constant.coinget));

                String android_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                mFirebaseDatabase.child(android_id).setValue(Constant.coinget);

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        music.start();
//                        coin.startAnimation(AnimationUtils.loadAnimation(SelectCatActivity.this, R.anim.pulse));

                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                music.stop();
//                                coin.clearAnimation();
                            }
                        }, 3000);

                    }
                }, 1000);
            }
        });
    }


    public void watchAd() {

        Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.watchad);
        dialog.setCancelable(false);
        ImageView txt_yes = (ImageView) dialog.findViewById(R.id.yes);
        ImageView r_retry = (ImageView) dialog.findViewById(R.id.r_retry);

        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        r_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (SelectCatActivity.adtime == true) {
                    showRewardedVideo(SelectCatActivity.this);
                } else {
                    someAfter30();
                }
                dialog.dismiss();

            }
        });
        if (!isFinishing()) {
            dialog.show();
        }
    }


    public void someAfter30() {
        Dialog popup = new Dialog(this);
        popup.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        popup.requestWindowFeature(1);
        popup.setContentView(R.layout.aftersecond);
        popup.setCancelable(false);
        ImageView txt_yes = (ImageView) popup.findViewById(R.id.yes);
        ImageView r_retry = (ImageView) popup.findViewById(R.id.r_retry);


        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popup.dismiss();
            }
        });

        if (!isFinishing()) {
            popup.show();
        }
    }


    @Override
    public void onBackPressed() {

        GAdsWallPaperWp.getInstance().showBgReturn(SelectCatActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                WallApplication myApp = WallApplication.getInstance();
                if (myApp.getAppDetailVWallStatic() != null && myApp.getAppDetailVWallStatic().getAppscreennumber() != null && !TextUtils.isEmpty(myApp.getAppDetailVWallStatic().getAppscreennumber())) {
                    if (myApp.getAppDetailVWallStatic().getAppscreennumber().equalsIgnoreCase("0")) {
                        startActivity(new Intent(SelectCatActivity.this, ActivityExit.class));
                        overridePendingTransition(0, 0);
                    } else {
                        finish();
                        overridePendingTransition(0, 0);
                    }
                } else {
                    startActivity(new Intent(SelectCatActivity.this, ActivityExit.class));
                    overridePendingTransition(0, 0);

                }
            }
        });
    }

}



