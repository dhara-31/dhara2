package com.wallpaper.si_nwallpaper.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adsclass.ActivityExit;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.apidata.ApiClient;
import com.wallpaper.si_nwallpaper.apidata.ApiInterfaceAd;
import com.wallpaper.si_nwallpaper.apidata.ApiInterfaceSub;
import com.wallpaper.si_nwallpaper.apidata.ApiSubClient;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.Constant;
import com.wallpaper.si_nwallpaper.other.TinyDB;
import com.wallpaper.si_nwallpaper.sleect.ExampleClass;

import java.util.ArrayList;
import java.util.List;


import io.supercharge.shimmerlayout.ShimmerLayout;
import retrofit2.Call;
import retrofit2.Callback;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;


public class ChooseCatogory extends AppCompatActivity {


    ImageView explore, explore1;


    private static final int PERMISSION_REQUEST_CODE = 200;

    TinyDB t;
    RecyclerView recy;
    public static String nameFirstValueSub = "com.wallpaper.hdwallpaper";
    public static String valueTogive2 = "abstract";
    public static String mainWallUserName = "hdwallpaper";
    public static String mainWallPassword = "hdwallpaper.si";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        t = new TinyDB(ChooseCatogory.this);



        explore = findViewById(R.id.explore);


        VideoView videoView = findViewById(R.id.videoView);
        videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.loading));
        videoView.start();

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                videoView.start();
            }
        });

        explore1 = findViewById(R.id.explore1);

        recy = findViewById(R.id.recy);

        if (t.getBoolean("start") == false) {

            String android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
            DatabaseReference reference = FirebaseDatabase.getInstance("https://wallpaperapp-e7e13-default-rtdb.firebaseio.com/").getReference().child("wallCoinsData");


            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    Boolean a = false;

                    for (DataSnapshot dataSnap : dataSnapshot.getChildren()) {
                        String object = dataSnap.getKey().toString();
                        if (android_id.equals(object)) {
                            a = true;
                            Constant.coinget = Integer.parseInt(dataSnap.getValue().toString());
                            break;
                        }
                    }

                    if (a == true) {
                    } else {
                        reference.child(android_id).setValue(0);
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        }

        explore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!checkPermission()) {
                    requestPermission();
                } else {
                    if (Constant.c != null) {
                        if (Constant.c.size() != 0) {
                            GAdsWallPaperWp.getInstance().showInterWallpaper(ChooseCatogory.this, new GAdsWallPaperWp.AdsInterface() {
                                @Override
                                public void adsCall() {
                                    t.putBoolean("start", true);
                                    startActivity(new Intent(ChooseCatogory.this, SelectCatActivity.class));
                                    finish();
                                }
                            });

                        } else {
                            Toast.makeText(ChooseCatogory.this, "Please Select one Category", Toast.LENGTH_LONG).show();
                        }
                    }
                }

                if (Check_permission(ChooseCatogory.this)) {
                }

            }
        });


        Call<ExampleClass> call = ApiClient.getClient().create(ApiInterfaceAd.class).getAll(nameFirstValueSub, valueTogive2, mainWallUserName, mainWallPassword);
        call.enqueue(new Callback<ExampleClass>() {
            @Override
            public void onResponse(Call<ExampleClass> call, retrofit2.Response<ExampleClass> response) {

                if (response.isSuccessful()) {

                    String authheader = "";
                    String header = "";

                    String uname = response.body().getUsername();
                    String pass = response.body().getPassword();

                    String base = uname + ":" + pass;
                    authheader = "Basic " + Base64.encodeToString(base.getBytes(), Base64.NO_WRAP);
                    header = response.body().getHeaderkey();

                    Call<AllCat> call1 = ApiSubClient.getClient().create(ApiInterfaceSub.class).getAllCat(authheader, header, response.body().getPackageName());

                    call1.enqueue(new Callback<AllCat>() {
                        @Override
                        public void onResponse(Call<AllCat> call1, retrofit2.Response<AllCat> response) {

                            if (response.isSuccessful()) {

                                videoView.setVisibility(View.GONE);


                                ArrayList<Integer> b = new ArrayList<>();

                                b.add(2);
                                b.add(3);
                                b.add(5);
                                b.add(2);
                                b.add(9);

                                List<AllCat.Datum> tredingList = response.body().getData();
                                t.putListAll("allcat", ((ArrayList) tredingList));

                                if (tredingList != null && tredingList.size() != 0) {


                                    recy = (RecyclerView) findViewById(R.id.recy);
                                    GridLayoutManager gridLayoutManager = new GridLayoutManager(ChooseCatogory.this, 2);
                                    AllCatAdapter wallpapersAdapter = new AllCatAdapter(tredingList, ChooseCatogory.this, b);
                                    recy.setLayoutManager(gridLayoutManager);
                                    recy.setHasFixedSize(true);
                                    recy.setItemAnimator(new DefaultItemAnimator());
                                    recy.setAdapter(wallpapersAdapter);

                                }
                            }
                        }

                        @Override
                        public void onFailure(Call<AllCat> call1, Throwable t) {

                        }
                    });

                }
            }


            @Override
            public void onFailure(Call<ExampleClass> call, Throwable t) {


            }
        });


    }

    @SuppressLint("WrongConstant")
    public boolean Check_permission(Activity activity) {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        if (activity.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0 && activity.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        ActivityCompat.requestPermissions(activity, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1001);
        ActivityCompat.requestPermissions(activity, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1002);
        return false;
    }


    private void requestPermission() {

        ActivityCompat.requestPermissions(this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted && cameraAccepted) {

                        if (Constant.c != null) {
                            if (Constant.c.size() != 0) {
                                GAdsWallPaperWp.getInstance().showInterWallpaper(ChooseCatogory.this, new GAdsWallPaperWp.AdsInterface() {
                                    @Override
                                    public void adsCall() {
                                        t.putBoolean("start", true);
                                        startActivity(new Intent(ChooseCatogory.this, SelectCatActivity.class));
                                        finish();
                                    }
                                });

                            } else {
                                Toast.makeText(ChooseCatogory.this, "Please Select one Category", Toast.LENGTH_LONG).show();
                            }
                        }

                    } else {

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                            final Dialog dialog = new Dialog(ChooseCatogory.this);
                            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            dialog.setCancelable(false);
                            dialog.setContentView(R.layout.backgrounddd);

                            TextView txt = dialog.findViewById(R.id.txt);
                            txt.setText("Unable to open this Application. Go to Settings > Permission");

                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                            TextView mDialogNo = dialog.findViewById(R.id.no);

                            mDialogNo.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });

                            TextView mDialogOk = dialog.findViewById(R.id.yes);

                            mDialogOk.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent();
                                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                                    intent.setData(uri);
                                    startActivity(intent);
                                    dialog.dismiss();
                                }
                            });

                            dialog.show();

                            return;
                        }
                    }
                }

                break;
        }
    }


    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(ChooseCatogory.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                startActivity(new Intent(ChooseCatogory.this, ActivityExit.class));
            }
        });
    }


    public class AllCatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        Activity activity;
        public List<AllCat.Datum> list;


        public class MyViewHolder extends RecyclerView.ViewHolder {
            View bg;
            ImageView imageView;
            ImageView lock;
            public View parent;
            public TextView title;
            TextView coin;
            ImageView c;
            ShimmerLayout shimmerRecyclerPhoto;

            public MyViewHolder(View view) {
                super(view);
                this.parent = view;
                this.title = (TextView) view.findViewById(R.id.title);
                this.lock = (ImageView) view.findViewById(R.id.lock);
                this.bg = view.findViewById(R.id.bg);
                this.imageView = (ImageView) view.findViewById(R.id.close);
                coin = view.findViewById(R.id.coin);
                c = view.findViewById(R.id.c);
                shimmerRecyclerPhoto = view.findViewById(R.id.shimmer_recycler_view);
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.adapter_choose_cat, viewGroup, false));
        }

        public AllCatAdapter(List<AllCat.Datum> list2, Activity activity2, ArrayList<Integer> c) {
            this.list = list2;
            this.activity = activity2;
        }


        @Override
        public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
            final String str = this.list.get(i).getCategory();
            MyViewHolder myViewHolder = (MyViewHolder) viewHolder;
            String output = str.substring(0, 1).toUpperCase() + str.substring(1);
            myViewHolder.coin.setText(output);
            viewHolder.setIsRecyclable(true);

            myViewHolder.shimmerRecyclerPhoto.startShimmerAnimation();


            ImageView imageView = myViewHolder.imageView;

            Glide.with(activity).load(list.get(i).getthub()).listener(new RequestListener<Drawable>() {

                @Override
                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {

                    return false;
                }

                @Override
                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                    myViewHolder.shimmerRecyclerPhoto.stopShimmerAnimation();
                    myViewHolder.shimmerRecyclerPhoto.setVisibility(View.GONE);
                    return false;
                }
            }).into(imageView);

            if (str.equals("Exclusive")) {
                TinyDB t = new TinyDB(activity);
                t.putInt("exclusive", i);
            } else {
            }


            if (Constant.c.contains(i)) {
                myViewHolder.lock.setVisibility(View.VISIBLE);
            } else {
                myViewHolder.lock.setVisibility(View.GONE);
            }


            myViewHolder.imageView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (str.equals("Exclusive")) {
                        Toast.makeText(activity, "You can not Select Exclusive Category", Toast.LENGTH_LONG).show();
                    } else {

                        if (Constant.c.contains(i)) {
                            ArrayList<Integer> favList1 = Constant.c;
                            for (int j = 0; j < favList1.size(); j++) {
                                if (favList1.get(j).equals(i)) {
                                    favList1.remove(j);
                                }
                            }
                            Constant.c = favList1;
                            myViewHolder.lock.setVisibility(View.GONE);

                        } else {
                            myViewHolder.lock.setVisibility(View.VISIBLE);
                            Constant.c.add(i);
                            explore.setVisibility(View.VISIBLE);

                            explore.startAnimation(AnimationUtils.loadAnimation(ChooseCatogory.this, R.anim.pulse));

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    explore.clearAnimation();
                                }
                            }, 2000);

                        }
                    }
                }
            });
        }


        @Override
        public int getItemCount() {
            return list.size();
        }
    }


}
