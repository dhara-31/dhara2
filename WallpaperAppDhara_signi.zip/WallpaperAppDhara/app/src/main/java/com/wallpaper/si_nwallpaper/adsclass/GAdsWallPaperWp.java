package com.wallpaper.si_nwallpaper.adsclass;

import android.app.Activity;
import android.os.SystemClock;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;


public class GAdsWallPaperWp {


    private AdsInterface callBack;

    public static Integer counterNoramlCall_WallPaper = 0;
    public static Integer backcounter = 0;

    public InterstitialAd mInterstitialAd_WallPaper1;
    private static GAdsWallPaperWp ourInstance;

    private InterstitialAd mInter2_W2;

    public static Integer counter_Inter_WallPaper = 0;
    public static Integer countmInterstitialAd_D2_WallPaper2 = 0;

    private long mLastClickTime_Wall1 = 0;
    private long mLastClickTime2_Wall2 = 0;

    public interface AdsInterface {
        void adsCall();
    }

    public static GAdsWallPaperWp getInstance() {
        if (ourInstance == null) {
            ourInstance = new GAdsWallPaperWp();
        }
        return ourInstance;
    }


    public void showInterWallpaper(Activity context, AdsInterface _myCallback) {

        if (SystemClock.elapsedRealtime() - mLastClickTime_Wall1 < 700) {
            return;
        }

        mLastClickTime_Wall1 = SystemClock.elapsedRealtime();
        this.callBack = _myCallback;

        try {
            counterNoramlCall_WallPaper = counterNoramlCall_WallPaper + 1;
            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

            if (appDetail != null) {
                this.callBack = _myCallback;

                if (SplashActivity.valueinterLive == 0) {
                    if (mInterstitialAd_WallPaper1 != null) {
                        mInterstitialAd_WallPaper1.show(context);
                        counterNoramlCall_WallPaper = 0;
                        SplashActivity.valueinterLive = 1;
                    } else if (mInter2_W2 != null) {
                        mInter2_W2.show(context);
                        counterNoramlCall_WallPaper = 0;
                        SplashActivity.valueinterLive = 1;
                    } else {

                        if (mInter2_W2 == null) {

                            if (mInterstitialAd_WallPaper1 == null) {

                                countmInterstitialAd_D2_WallPaper2++;
                                if (countmInterstitialAd_D2_WallPaper2 >= 2) {
                                    SplashActivity.valueinterLive = 1;
                                    countmInterstitialAd_D2_WallPaper2 = 0;
                                    mInter2_W2 = null;

                                    if (WallApplication.getInstance().intervalueWlall != 2) {
                                        loadAd2_WalllPaper2(context);
                                    }
                                }
                            }
                        }

                        if (callBack != null) {
                            callBack.adsCall();
                            callBack = null;
                        }
                    }

                } else {

                    if (WallApplication.c().intervalueWlall == 2) {

                        if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                            if (mInterstitialAd_WallPaper1 == null) {
                                loadAd(context);
                            }
                        } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                            if (mInter2_W2 == null) {
                                loadAd2_WalllPaper2(context);
                            }
                        }
                        WallApplication.c().intervalueWlall = 1;
                    }


                    if (appDetail.getCounter() != null && Integer.parseInt(appDetail.getCounter()) <= 1) {
                        counterNoramlCall_WallPaper = Integer.parseInt(appDetail.getCounter()) + 2;
                    }


                    if (counterNoramlCall_WallPaper >= Integer.parseInt(appDetail.getCounter())) {

                        if (mInterstitialAd_WallPaper1 != null) {
                            mInterstitialAd_WallPaper1.show(context);
                            counterNoramlCall_WallPaper = 0;
                        } else if (mInter2_W2 != null) {
                            counterNoramlCall_WallPaper = 0;
                            mInter2_W2.show(context);
                            countmInterstitialAd_D2_WallPaper2 = 0;

                            if (mInterstitialAd_WallPaper1 == null) {
                                counter_Inter_WallPaper++;
                                if (counter_Inter_WallPaper >= 5) {
                                    counter_Inter_WallPaper = 0;
                                    mInterstitialAd_WallPaper1 = null;
                                    loadAd(context);
                                }
                            }
                        } else {
                            if (callBack != null) {
                                callBack.adsCall();
                                callBack = null;
                            }

                            if (mInterstitialAd_WallPaper1 == null) {
                                counter_Inter_WallPaper++;
                                if (counter_Inter_WallPaper >= 5) {
                                    counter_Inter_WallPaper = 0;
                                    mInterstitialAd_WallPaper1 = null;
                                    loadAd(context);
                                }
                            }


                            if (mInter2_W2 == null) {
                                countmInterstitialAd_D2_WallPaper2++;
                                if (countmInterstitialAd_D2_WallPaper2 >= 5) {
                                    countmInterstitialAd_D2_WallPaper2 = 0;
                                    mInter2_W2 = null;
                                    loadAd2_WalllPaper2(context);
                                }
                            }
                        }

                    } else {
                        if (callBack != null) {
                            callBack.adsCall();
                            callBack = null;
                        }
                    }
                }

            } else {

                if (callBack != null) {
                    callBack.adsCall();
                    callBack = null;
                }
            }
        } catch (Exception e) {
            if (callBack != null) {
                callBack.adsCall();
                callBack = null;
            }
        }
    }


    public void showBgReturn(Activity context, AdsInterface _myCallback) {

        if (SystemClock.elapsedRealtime() - mLastClickTime2_Wall2 < 700) {
            return;
        }

        mLastClickTime2_Wall2 = SystemClock.elapsedRealtime();
        this.callBack = _myCallback;

        try {
            backcounter = backcounter + 1;

            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

            if (appDetail != null && appDetail.getInterstitialbackpress() != null && appDetail.getInterstitialbackpress().equals("1")
                    && appDetail.getFbcounter() != null && !TextUtils.isEmpty(appDetail.getFbcounter())) {

                this.callBack = _myCallback;

                if (backcounter >= Integer.parseInt(appDetail.getFbcounter())) {
                    if (mInterstitialAd_WallPaper1 != null) {
                        mInterstitialAd_WallPaper1.show(context);
                        backcounter = 0;
                    } else if (mInter2_W2 != null) {
                        backcounter = 0;
                        mInter2_W2.show(context);
                        countmInterstitialAd_D2_WallPaper2 = 0;

                        if (mInterstitialAd_WallPaper1 == null) {
                            counter_Inter_WallPaper++;
                            if (counter_Inter_WallPaper >= 5) {
                                counter_Inter_WallPaper = 0;
                                mInterstitialAd_WallPaper1 = null;
                                loadAd(context);
                            }
                        }
                    } else {

                        if (callBack != null) {
                            callBack.adsCall();
                            callBack = null;
                        }


                        if (mInterstitialAd_WallPaper1 == null) {
                            counter_Inter_WallPaper++;

                            if (counter_Inter_WallPaper >= 5) {
                                counter_Inter_WallPaper = 0;
                                mInterstitialAd_WallPaper1 = null;
                                loadAd(context);
                            }
                        }
                        if (mInter2_W2 == null) {
                            countmInterstitialAd_D2_WallPaper2++;
                            if (countmInterstitialAd_D2_WallPaper2 >= 5) {
                                countmInterstitialAd_D2_WallPaper2 = 0;
                                mInter2_W2 = null;
                                loadAd2_WalllPaper2(context);
                            }
                        }

                    }

                } else {
                    if (callBack != null) {
                        callBack.adsCall();
                        callBack = null;
                    }
                }


            } else {
                if (callBack != null) {
                    callBack.adsCall();
                    callBack = null;
                }
            }
        } catch (Exception e) {
            if (callBack != null) {
                callBack.adsCall();
                callBack = null;
            }
        }
    }


    public void loadAd(final Activity context) {
        AdRequest adRequest = new AdRequest.Builder().build();
        AppDetailWp detailApp = WallApplication.getInstance().getAppDetailVWallStatic();
        if (detailApp != null) {

            if (detailApp != null && detailApp.getAdstatus().equalsIgnoreCase("1") && detailApp.getAdmobinter() != null && !TextUtils.isEmpty(detailApp.getAdmobinter())) {
                InterstitialAd.load(context, detailApp.getAdmobinter(), adRequest, new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd_WallPaper1 = interstitialAd;
                        counter_Inter_WallPaper = 0;

                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {

                                mInterstitialAd_WallPaper1 = null;

                                loadAd(context);
                                if (callBack != null) {
                                    callBack.adsCall();
                                    callBack = null;
                                }
                                SplashActivity.appopenLive = true;
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                mInterstitialAd_WallPaper1 = null;
                                SplashActivity.appopenLive = true;
                                if (callBack != null) {
                                    callBack.adsCall();
                                    callBack = null;
                                }
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                counter_Inter_WallPaper = 0;
                                SplashActivity.appopenLive = false;
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        mInterstitialAd_WallPaper1 = null;
                    }
                });
            }
        }
    }

    public void loadAd2_WalllPaper2(final Activity context) {
        AdRequest adRequest = new AdRequest.Builder().build();
        AppDetailWp detailApp = WallApplication.getInstance().getAppDetailVWallStatic();

        if (detailApp != null) {
            if (detailApp != null && detailApp.getAdstatus().equalsIgnoreCase("1") && detailApp.getAdmob2interstitial() != null && !TextUtils.isEmpty(detailApp.getAdmob2interstitial())) {

                InterstitialAd.load(context, detailApp.getAdmob2interstitial(), adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                mInter2_W2 = interstitialAd;
                                countmInterstitialAd_D2_WallPaper2 = 0;

                                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                    @Override
                                    public void onAdDismissedFullScreenContent() {


                                        mInter2_W2 = null;
                                        loadAd2_WalllPaper2(context);

                                        if (callBack != null) {
                                            callBack.adsCall();
                                            callBack = null;
                                        }
                                        SplashActivity.appopenLive = true;
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                                        mInter2_W2 = null;
                                        SplashActivity.appopenLive = true;
                                        if (callBack != null) {
                                            callBack.adsCall();
                                            callBack = null;
                                        }
                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {
                                        countmInterstitialAd_D2_WallPaper2 = 0;
                                        SplashActivity.appopenLive = false;
                                    }
                                });
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                mInter2_W2 = null;
                            }
                        });
            }

        }
    }


}
