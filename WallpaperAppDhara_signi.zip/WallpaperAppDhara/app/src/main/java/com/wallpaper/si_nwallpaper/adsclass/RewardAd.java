package com.wallpaper.si_nwallpaper.adsclass;

import android.app.Activity;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;

public class RewardAd {


    public static RewardedAd rewAd;
    public static boolean isLoading;
    public static int counter = 0;


    public static void loadRewardedAd(Activity activity) {

        try {
            if (rewAd == null) {

                isLoading = true;

                AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

                if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") && appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {

                    AdRequest adRequest = new AdRequest.Builder().build();

                    RewardedAd.load(activity, appDetail.getAdmobreward(), adRequest, new RewardedAdLoadCallback() {
                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            rewAd = null;
                            isLoading = false;
                        }

                        @Override
                        public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                            rewAd = rewardedAd;
                            isLoading = false;
                            counter = 0;
                        }
                    });
                }
            }

        }catch (Exception e){

        }
    }
}
