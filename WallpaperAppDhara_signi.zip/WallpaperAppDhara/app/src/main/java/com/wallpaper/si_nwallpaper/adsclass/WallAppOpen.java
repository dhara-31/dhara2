package com.wallpaper.si_nwallpaper.adsclass;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.wallpaper.si_nwallpaper.activity.SelectCatActivity;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.other.TinyDB;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.activity.ChooseCatogory;
import com.wallpaper.si_nwallpaper.activity.StartActivty;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static androidx.lifecycle.Lifecycle.Event.ON_START;

public class WallAppOpen implements LifecycleObserver, Application.ActivityLifecycleCallbacks {

    public static String AD_UNITWallPape = "";
    public static String AD_UNITWallPaper2 = "";

    public static boolean doNotDisplayAd = false;
    private static boolean isShowingAd = false;

    private final WallApplication myApplication;
    public static boolean firstFlagWallPape = false;

    public static AppOpenAd appOpenAWallPapestatic = null;
    public static AppOpenAd a2Wall2 = null;

    private Activity ruuningActivity;

    public static Activity SplashActivity;
    private AppOpenAd.AppOpenAdLoadCallback loadCallback;

    private long loadTimeLite = 0;
    private Integer failcountWallPape = 0;

    public CountDownTimer cAppOpen;
    public static Boolean appOpemshow = true;


    public WallAppOpen(WallApplication myApplication) {
        this.myApplication = myApplication;
        this.myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();


        if (appDetail != null && appDetail.getAdmob2counter() != null && !TextUtils.isEmpty(appDetail.getAdmob2counter())) {
            Long timervalue = Long.parseLong(appDetail.getAdmob2counter()) * 1000;
            cAppOpen = new CountDownTimer(timervalue, 1000) {

                public void onTick(long millisUntilFinished) {
                }

                public void onFinish() {
                    appOpemshow = true;
                }
            }.start();
        } else {

        }
    }


    public void geWallPaperOpenAds2() {

        if (isAdAvailable2()) {
            return;
        }

        if (!doNotDisplayAd) {
            loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {
                    super.onAdLoaded(a2Wall2);

                    WallAppOpen.this.a2Wall2 = ad;

                    WallAppOpen.this.loadTimeLite = (new Date()).getTime();
                    if (firstFlagWallPape) {

                        if (!WallApplication.isSplashFinissh) {
                            showAdIfAvailable();

                            WallApplication.isSplashFinissh = true;

                            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

                            if (appDetail != null && appDetail.getCounter() != null && !TextUtils.isEmpty(appDetail.getCounter())) {

                                if (Integer.parseInt(appDetail.getCounter()) > 1) {

                                    if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                                        GAdsWallPaperWp.getInstance().loadAd(SplashActivity);
                                    } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                                        GAdsWallPaperWp.getInstance().loadAd2_WalllPaper2(SplashActivity);
                                    }
                                } else {
                                    GAdsWallPaperWp.getInstance().loadAd(SplashActivity);
                                    GAdsWallPaperWp.getInstance().loadAd2_WalllPaper2(SplashActivity);
                                }
                            }

                            NativeAdsAllWallP.getInstance().loadNativeNormalVideoWall(SplashActivity);
                        }
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);

                }
            };
            AdRequest request = getAdRequest();
            AppOpenAd.load(myApplication, AD_UNITWallPaper2, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

        } else {
            doNotDisplayAd = false;
        }
    }


    public void getLiteOpenAdsWallpaper() {

        if (isAdAvailable()) {
            return;
        }


        if (!doNotDisplayAd) {
            loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {
                    super.onAdLoaded(appOpenAWallPapestatic);
                    failcountWallPape = 0;
                    WallAppOpen.this.appOpenAWallPapestatic = ad;
                    WallAppOpen.this.loadTimeLite = (new Date()).getTime();


                    if (firstFlagWallPape) {
                        if (!WallApplication.isSplashFinissh) {

                            showAdIfAvailable();

                            WallApplication.isSplashFinissh = true;

                            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

                            if (appDetail != null && appDetail.getCounter() != null && !TextUtils.isEmpty(appDetail.getCounter())) {
                                if (Integer.parseInt(appDetail.getCounter()) > 1) {
                                    if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                                        GAdsWallPaperWp.getInstance().loadAd(SplashActivity);
                                    } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                                        GAdsWallPaperWp.getInstance().loadAd2_WalllPaper2(SplashActivity);
                                    }
                                } else {
                                    GAdsWallPaperWp.getInstance().loadAd(SplashActivity);
                                    GAdsWallPaperWp.getInstance().loadAd2_WalllPaper2(SplashActivity);
                                }
                            }

                            NativeAdsAllWallP.getInstance().loadNativeNormalVideoWall(SplashActivity);
                        }
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);


                    WallAppOpen.AD_UNITWallPaper2 = myApplication.getAppDetailVWallStatic().getAdmob2appopen();
                    if (appOpenAWallPapestatic == null) {
                        myApplication.splashscreennameWall = "SplashActivity";

                        if (a2Wall2 == null) {

                            if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmob2appopen() != null
                                    && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmob2appopen())) {
                                geWallPaperOpenAds2();
                            }
                        }
                    }
                }
            };
            AdRequest request = getAdRequest();

            AppOpenAd.load(myApplication, AD_UNITWallPape, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

        } else {
            doNotDisplayAd = false;
        }
    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }


    private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
        long dateDifference = (new Date()).getTime() - this.loadTimeLite;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * numHours));
    }

    public boolean isAdAvailable() {
        return appOpenAWallPapestatic != null && wasLoadTimeLessThanNHoursAgo(4);
    }

    public boolean isAdAvailable2() {
        return a2Wall2 != null && wasLoadTimeLessThanNHoursAgo(4);
    }


    public void showAdIfAvailable() {

        if (!doNotDisplayAd) {

            if (appOpemshow == true) {


                if (!isShowingAd && isAdAvailable()) {

                    if (com.wallpaper.si_nwallpaper.adsclass.SplashActivity.appopenLive == true) {

                        isShowingAd = true;
                        FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {

                            @Override
                            public void onAdDismissedFullScreenContent() {
                                WallAppOpen.this.appOpenAWallPapestatic = null;

                                isShowingAd = false;


                                if (cAppOpen != null) {
                                    appOpemshow = false;
                                    cAppOpen.cancel();
                                    cAppOpen.start();
                                }

                                if (firstFlagWallPape) {
                                    firstFlagWallPape = false;
                                    if (com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value == false) {
                                        com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value = true;
                                        openNextScreenWallpaper();
                                    }
                                }

                                if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmobnew() != null
                                        && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmobnew())) {
                                    getLiteOpenAdsWallpaper();
                                }

                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                isShowingAd = false;


                                if (com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value == false) {
                                    com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value = true;
                                    openNextScreenWallpaper();
                                }
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                isShowingAd = true;
                            }
                        };


                        appOpenAWallPapestatic.setFullScreenContentCallback(fullScreenContentCallback);
                        appOpenAWallPapestatic.show(ruuningActivity);
                    }
                } else if (!isShowingAd && isAdAvailable2()) {

                    if (com.wallpaper.si_nwallpaper.adsclass.SplashActivity.appopenLive == true) {

                        isShowingAd = true;
                        FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {

                            @Override
                            public void onAdDismissedFullScreenContent() {


                                if (cAppOpen != null) {
                                    appOpemshow = false;
                                    cAppOpen.cancel();
                                    cAppOpen.start();
                                }
                                WallAppOpen.this.a2Wall2 = null;

                                isShowingAd = false;

                                if (firstFlagWallPape) {
                                    firstFlagWallPape = false;

                                    if (com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value == false) {
                                        com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value = true;
                                        openNextScreenWallpaper();
                                    }
                                }

                                if (appOpenAWallPapestatic == null) {

                                    if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmobnew() != null
                                            && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmobnew())) {
                                    } else {
                                        if (a2Wall2 == null) {
                                            if (!firstFlagWallPape) {

                                                if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmob2appopen() != null
                                                        && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmob2appopen())) {

                                                    geWallPaperOpenAds2();
                                                }
                                            }
                                        }
                                    }

                                    failcountWallPape++;
                                    if (failcountWallPape > 0) {
                                        failcountWallPape = 0;
                                        if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmobnew() != null
                                                && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmobnew())) {
                                            WallAppOpen.this.a2Wall2 = null;
                                            getLiteOpenAdsWallpaper();
                                        }

                                    }
                                }
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                if (com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value == false) {
                                    com.wallpaper.si_nwallpaper.adsclass.SplashActivity.value = true;
                                    openNextScreenWallpaper();
                                }

                            }

                            @Override
                            public void onAdShowedFullScreenContent() {

                                isShowingAd = true;
                            }
                        };
                        a2Wall2.setFullScreenContentCallback(fullScreenContentCallback);
                        a2Wall2.show(ruuningActivity);
                    }
                } else {

                    failcountWallPape++;
                    if (appOpenAWallPapestatic == null && a2Wall2 == null) {

                        if (WallApplication.getInstance().openvalueWalll == 2) {
                            if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmobnew() != null
                                    && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmobnew())) {
                                WallAppOpen.AD_UNITWallPape = myApplication.getAppDetailVWallStatic().getAdmobnew();
                                getLiteOpenAdsWallpaper();
                                failcountWallPape = 0;
                                WallApplication.getInstance().openvalueWalll = 1;
                            } else if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmob2appopen() != null
                                    && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmob2appopen())) {
                                WallAppOpen.AD_UNITWallPaper2 = myApplication.getAppDetailVWallStatic().getAdmob2appopen();
                                geWallPaperOpenAds2();
                                failcountWallPape = 0;
                                WallApplication.getInstance().openvalueWalll = 1;
                            }


                        } else {

                            if (failcountWallPape > 3) {
                                if (myApplication.getAppDetailVWallStatic() != null && myApplication.getAppDetailVWallStatic().getAdmobnew() != null
                                        && !TextUtils.isEmpty(myApplication.getAppDetailVWallStatic().getAdmobnew())) {

                                    getLiteOpenAdsWallpaper();
                                    failcountWallPape = 0;
                                }
                            }
                        }


                    }
                }
            } else {
                doNotDisplayAd = false;
            }
        }
    }
    TinyDB t;
    private void openNextScreenWallpaper() {

        firstFlagWallPape = false;
        if (internetConnectionAvailable(1500) && isNetworkAvailable()) {
            SplashActivity = null;

            if (ruuningActivity != null) {
                t = new TinyDB(ruuningActivity);

                WallApplication myApp = WallApplication.getInstance();
                if (myApp != null && myApp.getAppDetailVWallStatic() != null && myApp.getAppDetailVWallStatic().getAppscreennumber() != null
                        && !TextUtils.isEmpty(myApp.getAppDetailVWallStatic().getAppscreennumber())) {

                    int counterName = 0;
                    try {
                        counterName = Integer.valueOf(myApp.getAppDetailVWallStatic().getAppscreennumber());
                    } catch (Exception e) {

                    }

                    if (counterName >= 1) {
                        ruuningActivity.startActivity(new Intent(ruuningActivity, StartActivty.class));
                        ruuningActivity.finish();
                    } else {



                        if (t.getBoolean("start") == false) {
                            ruuningActivity.startActivity(new Intent(ruuningActivity, ChooseCatogory.class));
                            ruuningActivity.finish();
                        } else {
                            ruuningActivity.startActivity(new Intent(ruuningActivity, SelectCatActivity.class));
                            ruuningActivity.finish();
                        }
                    }
                } else {
                    if (t.getBoolean("start") == false) {
                        ruuningActivity.startActivity(new Intent(ruuningActivity, ChooseCatogory.class));
                        ruuningActivity.finish();
                    } else {
                        ruuningActivity.startActivity(new Intent(ruuningActivity, SelectCatActivity.class));
                        ruuningActivity.finish();
                    }
                }
            }

        } else {
            if (SplashActivity != null) {

                t = new TinyDB(SplashActivity);

                WallApplication myApp = WallApplication.getInstance();
                if (myApp != null && myApp.getAppDetailVWallStatic() != null && myApp.getAppDetailVWallStatic().getAppscreennumber() != null
                        && !TextUtils.isEmpty(myApp.getAppDetailVWallStatic().getAppscreennumber())) {

                    int counterName = 0;
                    try {
                        counterName = Integer.valueOf(myApp.getAppDetailVWallStatic().getAppscreennumber());
                    } catch (Exception e) {

                    }

                    if (counterName >= 1) {
                        SplashActivity.startActivity(new Intent(SplashActivity, StartActivty.class));
                        SplashActivity.finish();
                    } else {

                        if (t.getBoolean("start") == false) {
                            SplashActivity.startActivity(new Intent(SplashActivity, ChooseCatogory.class));
                            SplashActivity.finish();
                        } else {
                            SplashActivity.startActivity(new Intent(SplashActivity, SelectCatActivity.class));
                            SplashActivity.finish();
                        }
                    }
                } else {
                    if (t.getBoolean("start") == false) {
                        SplashActivity.startActivity(new Intent(SplashActivity, ChooseCatogory.class));
                        SplashActivity.finish();
                    } else {
                        SplashActivity.startActivity(new Intent(SplashActivity, SelectCatActivity.class));
                        SplashActivity.finish();
                    }
                }
            }
        }
    }


    private boolean isNetworkAvailable() {
        ConnectivityManager manager = (ConnectivityManager) myApplication.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        boolean isAvailable = false;
        if (networkInfo != null && networkInfo.isConnected()) {
            isAvailable = true;
        }
        return isAvailable;
    }


    private boolean internetConnectionAvailable(int timeOut) {
        InetAddress inetAddress = null;
        try {
            Future<InetAddress> future = Executors.newSingleThreadExecutor().submit(new Callable<InetAddress>() {
                @Override
                public InetAddress call() {
                    try {
                        return InetAddress.getByName("google.com");
                    } catch (UnknownHostException e) {
                        return null;
                    }
                }
            });
            inetAddress = future.get(timeOut, TimeUnit.MILLISECONDS);
            future.cancel(true);
        } catch (InterruptedException e) {
        } catch (ExecutionException e) {
        } catch (TimeoutException e) {
        }
        return inetAddress != null && !inetAddress.equals("");
    }

    @OnLifecycleEvent(ON_START)
    public void onStart() {
        showAdIfAvailable();
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle bundle) {
        if (activity.toString().contains(WallApplication.splashscreennameWall)) {
            ruuningActivity = activity;
        } else {
            isShowingAd = false;
        }
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        if (!activity.toString().contains(WallApplication.splashscreennameWall)) {
            ruuningActivity = activity;
        }
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle bundle) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        ruuningActivity = null;
    }
}
