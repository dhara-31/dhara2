package com.wallpaper.si_nwallpaper.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.GalleryAdapter;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;

public class GallerySelectedActivity extends AppCompatActivity {


    RecyclerView gallery;

    public static ArrayList<String> sremoveWall = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selectedgallery);

        TinyDB t = new TinyDB(GallerySelectedActivity.this);
        gallery = findViewById(R.id.gallery);
        sremoveWall.clear();


        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView c1 = findViewById(R.id.c);
        NativeAdsAllWallP.banerAllShowWallpaper(admobNativeLarge2, GallerySelectedActivity.this, c1);

        TextView nd = findViewById(R.id.nd);
        ImageView drw = findViewById(R.id.drw);

        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               onBackPressed();
            }
        });

        ImageView addwallpaper = findViewById(R.id.addwallpaper);
        addwallpaper.setImageDrawable(getResources().getDrawable(R.drawable.remove_wallpaper));
        ArrayList<String> b = t.getListString("gallery");

        if (b.size() != 0) {
            nd.setVisibility(View.GONE);
            gallery.setVisibility(View.VISIBLE);
            addwallpaper.setVisibility(View.VISIBLE);
            findViewById(R.id.txt).setVisibility(View.VISIBLE);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(GallerySelectedActivity.this, 3);
            GalleryAdapter wallpapersAdapter = new GalleryAdapter(b, GallerySelectedActivity.this, 3);
            gallery.setLayoutManager(gridLayoutManager);
            gallery.setHasFixedSize(true);
            gallery.setItemAnimator(new DefaultItemAnimator());
            gallery.setAdapter(wallpapersAdapter);
        } else {
            nd.setVisibility(View.VISIBLE);
            gallery.setVisibility(View.GONE);
            addwallpaper.setVisibility(View.GONE);
            findViewById(R.id.txt).setVisibility(View.GONE);
        }

        addwallpaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (sremoveWall.size() != 0) {

                    ArrayList<String> b1 = t.getListString("gallery");

                    for (int j = 0; j < sremoveWall.size(); j++) {
                        int indes = getIndex(sremoveWall.get(j), b1);
                        b1.remove(indes);
                    }

                    t.putListString("gallery", b1);

                    ArrayList<String> b = t.getListString("gallery");

                    if (b.size() != 0) {
                        nd.setVisibility(View.GONE);
                        gallery.setVisibility(View.VISIBLE);

                        GridLayoutManager gridLayoutManager = new GridLayoutManager(GallerySelectedActivity.this, 3);
                        GalleryAdapter wallpapersAdapter = new GalleryAdapter(b, GallerySelectedActivity.this, 3);
                        gallery.setLayoutManager(gridLayoutManager);
                        gallery.setHasFixedSize(true);
                        gallery.setItemAnimator(new DefaultItemAnimator());
                        gallery.setAdapter(wallpapersAdapter);
                    } else {
                        nd.setVisibility(View.VISIBLE);
                        gallery.setVisibility(View.GONE);
                    }

                    sremoveWall.clear();
                }
                else {
                    Toast.makeText(GallerySelectedActivity.this, "Please Select Image", Toast.LENGTH_LONG).show();
                }


            }
        });
    }

    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(GallerySelectedActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });

    }


    private int getIndex(String rawPath, ArrayList<String> list) {
        int i = 0;
        while (i < list.size()) {
            if (list.get(i).equals(rawPath)) {
                return i;
            }
            i++;
        }
        return -1;
    }

}
