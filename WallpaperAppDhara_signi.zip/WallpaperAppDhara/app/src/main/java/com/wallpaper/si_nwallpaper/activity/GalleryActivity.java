package com.wallpaper.si_nwallpaper.activity;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.adapter.GalleryAdapter;

import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;
import java.util.List;

public class GalleryActivity extends AppCompatActivity {


    public static List<String> selectedWall = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gallery);


        FrameLayout admobNativeLarge2 = findViewById(R.id.admobNative_Banner);
        CardView c1 = findViewById(R.id.c);
        NativeAdsAllWallP.banerAllShowWallpaper(admobNativeLarge2, GalleryActivity.this, c1);

        ImageView drw = findViewById(R.id.drw);

        drw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        ArrayList<String> b = getAllShownImagesPath(GalleryActivity.this);
        selectedWall.clear();

        TinyDB t = new TinyDB(GalleryActivity.this);
        RecyclerView recy = findViewById(R.id.recy);
        recy = (RecyclerView) findViewById(R.id.recy);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(GalleryActivity.this, 3);
        GalleryAdapter wallpapersAdapter = new GalleryAdapter(b, GalleryActivity.this, 2);
        recy.setLayoutManager(gridLayoutManager);
        recy.setHasFixedSize(true);
        recy.setItemAnimator(new DefaultItemAnimator());
        recy.setAdapter(wallpapersAdapter);

        ImageView addwallpaper = findViewById(R.id.addwallpaper);
        addwallpaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedWall.size() != 0) {
                    ArrayList<String> b1 = t.getListString("gallery");
                    b1.addAll(selectedWall);
                    t.putListString("gallery", b1);
                    Toast.makeText(GalleryActivity.this, "Wallpaper Add Sucessfully..", Toast.LENGTH_LONG).show();

                    finish();

                } else {
                    Toast.makeText(GalleryActivity.this, "Please Select Wallpaper", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


    private ArrayList<String> getAllShownImagesPath(Activity activity) {

        Uri uri;
        Cursor cursor;
        int column_index_data, column_index_folder_name;
        ArrayList<String> listOfAllImages = new ArrayList<String>();
        String absolutePathOfImage = null;
        uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.Images.Media.BUCKET_DISPLAY_NAME};
        cursor = activity.getContentResolver().query(uri, projection, null, null, null);

        column_index_data = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        column_index_folder_name = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
        while (cursor.moveToNext()) {

            absolutePathOfImage = cursor.getString(column_index_data);

            if (absolutePathOfImage.contains("-") || absolutePathOfImage.contains("("))  {

            } else {
                listOfAllImages.add(absolutePathOfImage);
            }

        }
        return listOfAllImages;
    }


    @Override
    public void onBackPressed() {
        GAdsWallPaperWp.getInstance().showBgReturn(GalleryActivity.this, new GAdsWallPaperWp.AdsInterface() {
            @Override
            public void adsCall() {
                finish();
            }
        });

    }
}
