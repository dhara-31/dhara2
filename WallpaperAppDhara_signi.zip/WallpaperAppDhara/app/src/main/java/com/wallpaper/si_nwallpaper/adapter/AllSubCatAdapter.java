package com.wallpaper.si_nwallpaper.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.activity.AActivity;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.adsclass.GAdsWallPaperWp;
import com.wallpaper.si_nwallpaper.adsclass.WallApplication;
import com.wallpaper.si_nwallpaper.other.AllCat;
import com.wallpaper.si_nwallpaper.other.TinyDB;

import java.util.ArrayList;
import java.util.List;

import io.supercharge.shimmerlayout.ShimmerLayout;


public class AllSubCatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity activity;
    public List<AllCat.Wallpaper> list;
    public Integer selected;
    public String layputt = "0";
    TinyDB t;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        View bg;
        ImageView imageView;
        ImageView lock;
        public View parent;
        public TextView title;
        LinearLayout llc;
        TextView coin;
        ShimmerLayout shimmerRecyclerPhoto;


        public MyViewHolder(View view) {
            super(view);
            this.parent = view;
            this.title = (TextView) view.findViewById(R.id.title);
            this.lock = (ImageView) view.findViewById(R.id.lock);
            this.bg = view.findViewById(R.id.bg);
            this.imageView = (ImageView) view.findViewById(R.id.close);
            if (layputt.equals("0") || layputt.equals("12")) {
                coin = view.findViewById(R.id.coin);
                llc = view.findViewById(R.id.llc);
            }
            shimmerRecyclerPhoto = view.findViewById(R.id.shimmer_recycler_view);
        }
    }

    public AllSubCatAdapter(List<AllCat.Wallpaper> list2, Activity activity2, Integer selct, String layput) {
        this.list = list2;
        this.activity = activity2;
        selected = selct;
        layputt = layput;
        t = new TinyDB(activity2);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (layputt.equals("0")) {
            return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.maintreding, viewGroup, false));
        } else if (layputt.equals("12")) {
            return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.wallpaper_view_item_collection, viewGroup, false));
        } else {
            return new MyViewHolder(LayoutInflater.from(activity).inflate(R.layout.wallpaper_view_item_collection, viewGroup, false));
        }
    }


    @SuppressLint("WrongConstant")
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {

        MyViewHolder myViewHolder = (MyViewHolder) viewHolder;



        if (layputt.equals("0") || layputt.equals("12")) {
            if (selected != t.getInt("exclusive")) {
                myViewHolder.llc.setVisibility(View.GONE);
            } else {
                AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();

                if (appDetail != null && appDetail.getAdstatus().equalsIgnoreCase("1") && appDetail.getAdmobreward() != null && !TextUtils.isEmpty(appDetail.getAdmobreward())) {
                    myViewHolder.llc.setVisibility(View.VISIBLE);
                    ArrayList<Integer> coinlist = t.getListInt("coinlist");

                    if (coinlist != null && coinlist.size() != 0 && coinlist.get(i) != null) {
                        if (coinlist.get(i) == 0) {
                            myViewHolder.llc.setVisibility(View.GONE);
                        } else {
                            myViewHolder.llc.setVisibility(View.VISIBLE);
                        }
                        myViewHolder.coin.setText(String.valueOf(coinlist.get(i)).toString());
                    }
                } else {
                    myViewHolder.llc.setVisibility(View.GONE);
                }
            }
        }

        String str = list.get(i).getThumbnail();

        Glide.with(activity).load(str).placeholder(R.drawable.downloading).listener(new RequestListener<Drawable>() {

            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {

                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                return false;
            }
        }).into(myViewHolder.imageView);


        myViewHolder.imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                GAdsWallPaperWp.getInstance().showInterWallpaper(activity, new GAdsWallPaperWp.AdsInterface() {
                    @Override
                    public void adsCall() {
                        Intent i2 = new Intent(activity, AActivity.class);
                        i2.putExtra("str", str);
                        i2.putExtra("current", selected);
                        i2.putExtra("pos", i);
                        activity.startActivity(i2);
                    }
                });
            }
        });


    }


    @Override
    public int getItemCount() {
        return list.size();
    }
}
