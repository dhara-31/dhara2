package com.wallpaper.si_nwallpaper.adsclass;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.wallpaper.si_nwallpaper.R;
import com.wallpaper.si_nwallpaper.activity.SelectCatActivity;
import com.wallpaper.si_nwallpaper.apidata.NativeAdsAllWallP;
import com.wallpaper.si_nwallpaper.other.TinyDB;
import com.wallpaper.si_nwallpaper.retrofitcall.AppDetailWp;
import com.wallpaper.si_nwallpaper.retrofitcall.ResponseApp;
import com.wallpaper.si_nwallpaper.activity.ChooseCatogory;
import com.wallpaper.si_nwallpaper.activity.StartActivty;

import retrofit2.Call;
import retrofit2.Callback;


public class SplashActivity extends AppCompatActivity {


    Handler handleSplash;
    Runnable runnableSPlasjLive;
    CountDownTimer timer;
    int timerScreen = 13000;
    public WallApplication myAppWallppaer = WallApplication.getInstance();
    boolean checkResumedLive = true;
    boolean overtimerLive = false;
    public Dialog popup;
    public static Boolean appopenLive = true;
    public static Boolean value = false;
    public String counterValueLive = "";
    public String backcounterValueLive = "";
    public static Integer valueinterLive = 0;
    public static Boolean exit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        WallAppOpen.appOpemshow = true;
        WallAppOpen.firstFlagWallPape = true;
        setContentView(R.layout.activity_main);

        exit = false;
        valueinterLive = 0;

        value = false;
        WallApplication.isSplashFinissh = false;

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        t = new TinyDB(SplashActivity.this);

        WallAppOpen.SplashActivity = SplashActivity.this;

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            try {
                if (popup != null && popup.isShowing()) {
                    popup.dismiss();
                }
            } catch (Exception ignored) {
            }

            getApiValuesSplash();
            startLive();
        } else {

            if (WallAppOpen.appOpenAWallPapestatic == null && WallAppOpen.a2Wall2 == null) {
                InternetDialogUpdate();
            }
        }
    }


    public void getApiValuesSplash() {

        Call<ResponseApp> call = ApiClientdWallP.getClient().create(ApiInterfaceAd.class).getAll("com.dharatest.androidapp");
        call.enqueue(new Callback<ResponseApp>() {
            @Override
            public void onResponse(Call<ResponseApp> call, retrofit2.Response<ResponseApp> response) {
                if (response.isSuccessful()) {



                    response.body().getAppdetail().setAdmobreward("1");

                    myAppWallppaer.setAppDetail(response.body().getAppdetail());
                    myAppWallppaer.setAdsDetails(response.body().getAdsdetail());


                    RewardAd.loadRewardedAd(SplashActivity.this);


                    counterValueLive = myAppWallppaer.getAppDetailVWallStatic().getCounter();
                    backcounterValueLive = myAppWallppaer.getAppDetailVWallStatic().getFbcounter();

                    if (myAppWallppaer.getAppDetailVWallStatic().getAdstatus().equalsIgnoreCase("2")) {
                        StartMainWallpaper();
                    } else if (myAppWallppaer.getAppDetailVWallStatic().getAdstatus().equals("1")) {

                        if (myAppWallppaer.getAppDetailVWallStatic() != null && myAppWallppaer.getAppDetailVWallStatic().getAdmobnew() != null && !TextUtils.isEmpty(myAppWallppaer.getAppDetailVWallStatic().getAdmobnew())) {

                            WallAppOpen.AD_UNITWallPape = myAppWallppaer.getAppDetailVWallStatic().getAdmobnew();

                            myAppWallppaer.initializeOpenVideo();

                            myAppWallppaer.splashscreennameWall = "SplashActivity";
                            WallAppOpen.SplashActivity = SplashActivity.this;

                            WallApplication.appWall.firstFlagWallPape = true;

                            if (WallAppOpen.appOpenAWallPapestatic == null) {
                                WallApplication.appWall.getLiteOpenAdsWallpaper();
                            }

                        } else if (myAppWallppaer.getAppDetailVWallStatic() != null && myAppWallppaer.getAppDetailVWallStatic().getAdmob2appopen() != null
                                && !TextUtils.isEmpty(myAppWallppaer.getAppDetailVWallStatic().getAdmob2appopen())) {

                            WallAppOpen.AD_UNITWallPaper2 = myAppWallppaer.getAppDetailVWallStatic().getAdmob2appopen();
                            myAppWallppaer.initializeOpenVideo();

                            myAppWallppaer.splashscreennameWall = "SplashActivity";
                            WallAppOpen.SplashActivity = SplashActivity.this;
                            WallApplication.appWall.firstFlagWallPape = true;

                            if (WallAppOpen.a2Wall2 == null) {
                                WallApplication.appWall.geWallPaperOpenAds2();
                            }

                        } else {
                            StartMainWallpaper();
                        }
                    }

                } else {
                    StartMainWallpaper();
                }
            }

            @Override
            public void onFailure(Call<ResponseApp> call, Throwable t) {
                StartMainWallpaper();
            }
        });
    }


    public void startLive() {

        overtimerLive = false;
        runnableSPlasjLive = new Runnable() {
            @Override
            public void run() {
                overtimerLive = true;
                WallApplication.isSplashFinissh = true;

                if (isNetworkAvailable()) {

                    try {
                        if (popup != null && popup.isShowing()) {
                            popup.dismiss();
                        }
                    } catch (Exception e) {
                    }

                    if (checkResumedLive) {


                        if (exit == false) {

                            value = true;

                            WallApplication.isSplashFinissh = true;

                            AppDetailWp appDetail = WallApplication.getInstance().getAppDetailVWallStatic();
                            if (appDetail != null && appDetail.getCounter() != null && !TextUtils.isEmpty(appDetail.getCounter())) {

                                if (Integer.parseInt(counterValueLive) > 1) {

                                    if (appDetail != null && appDetail.getAdmobinter() != null && !TextUtils.isEmpty(appDetail.getAdmobinter()) && appDetail.getAdstatus().equals("1")) {
                                        GAdsWallPaperWp.getInstance().loadAd(SplashActivity.this);
                                    } else if (appDetail != null && appDetail.getAdmob2interstitial() != null && !TextUtils.isEmpty(appDetail.getAdmob2interstitial()) && appDetail.getAdstatus().equals("1")) {
                                        GAdsWallPaperWp.getInstance().loadAd2_WalllPaper2(SplashActivity.this);
                                    }

                                } else {
                                    GAdsWallPaperWp.getInstance().loadAd(SplashActivity.this);
                                    GAdsWallPaperWp.getInstance().loadAd2_WalllPaper2(SplashActivity.this);
                                }
                            }

                            NativeAdsAllWallP.getInstance().loadNativeNormalVideoWall(SplashActivity.this);



                            WallApplication myApp = WallApplication.getInstance();
                            if (myApp != null && myApp.getAppDetailVWallStatic() != null && myApp.getAppDetailVWallStatic().getAppscreennumber() != null
                                    && !TextUtils.isEmpty(myApp.getAppDetailVWallStatic().getAppscreennumber())) {

                                int counterName = 0;
                                try {
                                    counterName = Integer.valueOf(myApp.getAppDetailVWallStatic().getAppscreennumber());
                                } catch (Exception e) {

                                }

                               if (counterName >= 1) {
                                    Intent goIntent = new Intent(SplashActivity.this, StartActivty.class);
                                    startActivity(goIntent);
                                    finish();
                                } else {
                                   if (t.getBoolean("start") == false) {
                                       Intent goIntent = new Intent(SplashActivity.this, ChooseCatogory.class);
                                       startActivity(goIntent);
                                       finish();
                                   } else {
                                       startActivity(new Intent(SplashActivity.this, SelectCatActivity.class));
                                       finish();
                                   }


                                }
                            } else {
                                if (t.getBoolean("start") == false) {
                                    Intent goIntent = new Intent(SplashActivity.this, ChooseCatogory.class);
                                    startActivity(goIntent);
                                    finish();
                                } else {
                                    startActivity(new Intent(SplashActivity.this, SelectCatActivity.class));
                                    finish();
                                }
                            }
                        }

                    }
                } else {
                    WallApplication.isSplashFinissh = true;
                    try {
                        if (popup != null && popup.isShowing()) {
                            popup.dismiss();
                        }
                    } catch (Exception e) {
                    }
                    InternetDialogUpdate();
                }
            }
        };

        try {
            if (handleSplash != null) {
                handleSplash.removeCallbacks(runnableSPlasjLive);
            }
        } catch (Exception e) {

        }

        try {
            if (timer != null) {
                timer.cancel();
            }
        } catch (Exception e) {

        }

        handleSplash = new Handler();

        handleSplash.postDelayed(runnableSPlasjLive, timerScreen);

        timer = new CountDownTimer(timerScreen, 100) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
            }

        }.start();
    }
    TinyDB t;
    @Override
    protected void onPause() {
        super.onPause();
        checkResumedLive = false;
    }

    private void StartMainWallpaper() {

        WallApplication.appWall.firstFlagWallPape = false;
        t = new TinyDB(SplashActivity.this);

        WallApplication myApp = WallApplication.getInstance();
        if (myApp != null && myApp.getAppDetailVWallStatic() != null && myApp.getAppDetailVWallStatic().getAppscreennumber() != null && !TextUtils.isEmpty(myApp.getAppDetailVWallStatic().getAppscreennumber())) {

            int counterName = 0;
            try {
                counterName = Integer.valueOf(myApp.getAppDetailVWallStatic().getAppscreennumber());
            } catch (Exception e) {

            }

            if (counterName >= 1) {
                WallApplication.appWall.firstFlagWallPape = false;
                Intent goIntent = new Intent(SplashActivity.this, StartActivty.class);
                startActivity(goIntent);
                finish();
            } else {
                WallApplication.appWall.firstFlagWallPape = false;

                if (t.getBoolean("start") == false) {
                    Intent goIntent = new Intent(SplashActivity.this, ChooseCatogory.class);
                    startActivity(goIntent);
                    finish();
                } else {
                    startActivity(new Intent(SplashActivity.this, SelectCatActivity.class));
                    finish();
                }
            }
        } else {
            WallApplication.appWall.firstFlagWallPape = false;

            if (t.getBoolean("start") == false) {
                Intent goIntent = new Intent(SplashActivity.this, ChooseCatogory.class);
                startActivity(goIntent);
                finish();
            } else {
                startActivity(new Intent(SplashActivity.this, SelectCatActivity.class));
                finish();
            }
        }
    }


    @Override
    protected void onResume() {
        checkResumedLive = true;
        super.onResume();
    }


    public void InternetDialogUpdate() {
        popup = new Dialog(SplashActivity.this);
        popup.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        popup.requestWindowFeature(1);
        popup.setContentView(R.layout.net_connection);
        popup.setCancelable(false);
        RelativeLayout txt_yes = (RelativeLayout) popup.findViewById(R.id.yes);
        RelativeLayout r_retry = (RelativeLayout) popup.findViewById(R.id.r_retry);
        TextView txt = (TextView) popup.findViewById(R.id.txt);
        txt.setText("Internet is not working.\n" + "Start your Internet and restart app.");

        try {
            timer.cancel();
            handleSplash.removeCallbacks(runnableSPlasjLive);
        } catch (Exception e) {

        }

        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                popup.dismiss();
            }
        });

        r_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    timer.cancel();
                    handleSplash.removeCallbacks(runnableSPlasjLive);
                } catch (Exception e) {

                }

                if (isNetworkAvailable()) {
                    WallApplication.isSplashFinissh = false;
                    try {
                        if (popup != null && popup.isShowing()) {
                            popup.dismiss();
                        }
                    } catch (Exception e) {
                    }
                    startLive();
                    getApiValuesSplash();

                } else {
                    Toast.makeText(SplashActivity.this, "Please check your internet connection!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (!isFinishing()) {
            popup.show();
        }
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            boolean isAvailable = false;
            if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                isAvailable = true;
            }
            return isAvailable;
        } catch (Exception e) {
            return false;
        }

    }


    @Override
    protected void onDestroy() {
        try {
            if (handleSplash != null) {
                handleSplash.removeCallbacks(runnableSPlasjLive);
            }
        } catch (Exception e) {

        }
        try {
            if (timer != null) {
                timer.cancel();
            }
        } catch (Exception e) {
        }
        super.onDestroy();
    }


    @Override
    public void onBackPressed() {
    }
}
