package com.habittracker.todolist.activity;

import  android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.IntentService;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.widget.ImageViewCompat;

import com.habittracker.todolist.R;

import com.habittracker.todolist.service.Connstant;
import com.habittracker.todolist.service.DBHelper;
import com.habittracker.todolist.service.NotificationSound;
import com.habittracker.todolist.service.TimerNoti;
import com.habittracker.todolist.service.TinyDB;

public class TimerActvitiy extends AppCompatActivity {

    public static CountDownTimer countDownTimer;
    public ProgressBar progressbar_of_st;
    TextView song_sleep_timer_txt;
    private long valuereamin = 0;
    private boolean value = false;
    TinyDB t;
    ImageView st_reset_img;
    private Boolean chkfinish = false;


    @SuppressLint("Range")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);
        
        TextView txt = findViewById(R.id.txt);
        ImageView Imgback = findViewById(R.id.Imgback);
        TextView txtdes = findViewById(R.id.txtdes);

        t = new TinyDB(TimerActvitiy.this);


        ImageView edit = findViewById(R.id.edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                        Intent i = new Intent(TimerActvitiy.this, SoundActivity.class);
                        i.putExtra("id", getIntent().getIntExtra("id", 0));
                        startActivity(i);

            }
        });


        ImageView st_cancel_img = findViewById(R.id.st_cancel_img);
        st_cancel_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    TimerNoti.cacel();
                } catch (Exception e) {

                }
                if (countDownTimer != null) {
                    countDownTimer.cancel();
                }
                finish();

            }
        });

        st_reset_img = findViewById(R.id.st_reset_img);
        st_reset_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (value == false) {

                    value = true;
                    if (countDownTimer != null) {
                        countDownTimer.cancel();
                    }

                    st_reset_img.setImageResource(R.drawable.pl);

                } else {
                    st_reset_img.setImageResource(R.drawable.pu);
                    if (countDownTimer != null) {
                        countDownTimer.cancel();
                    }

                    if (chkfinish == true) {

                        long b = getIntent().getLongExtra("value", Connstant.value);
                        cursorvalue(b, false);

                        int seconds = (int) (b / 1000) % 60;
                        int minutes = (int) ((b / (1000 * 60)) % 60);


                        if (minutes <= 9 && seconds <= 9) {
                            song_sleep_timer_txt.setText("0" + minutes + ":" + "0" + seconds);
                        } else if (minutes <= 9 && seconds <= 9) {
                            song_sleep_timer_txt.setText(minutes + ":" + "0" + seconds);
                        } else if (seconds <= 9) {
                            song_sleep_timer_txt.setText(minutes + ":" + "0" + seconds);
                        } else if (minutes <= 9) {
                            song_sleep_timer_txt.setText("0" + minutes + ":" + seconds);
                        } else if (minutes <= 9) {
                            song_sleep_timer_txt.setText(minutes + ":" + seconds);
                        } else if (seconds <= 9) {
                            song_sleep_timer_txt.setText(minutes + ":" + "0" + seconds);
                        } else if (minutes == 0 && seconds == 0) {
                            song_sleep_timer_txt.setText("00:00:00");
                        } else {
                            song_sleep_timer_txt.setText(minutes + ":" + seconds);
                        }
                    } else {
                        value = false;
                        cursorvalue(valuereamin, true);
                    }
                }
            }
        });


        DBHelper db = new DBHelper(TimerActvitiy.this);
        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        Cursor rs = db.getData(getIntent().getIntExtra("id", 0));
        if (rs.getCount() > 0) {
            rs.moveToFirst();
            txt.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NAME)));
            txtdes.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_des)));

            ImageView icon = findViewById(R.id.icon);
            icon.setImageResource(Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_icon))));

            if (rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)) != null && !TextUtils.isEmpty(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)))) {

                if (!rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)).equals("nagative")) {
                    if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 0) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 1) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c1)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 2) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c2)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 3) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c3)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 4) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c4)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 5) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                    }
                } else {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.red)));
                }
            }
        }

        if (countDownTimer != null) {
            countDownTimer.cancel();
        }

        progressbar_of_st = findViewById(R.id.progressbar_of_st);
        song_sleep_timer_txt = findViewById(R.id.song_sleep_timer_txt);


        long b = getIntent().getLongExtra("value", Connstant.value);
        cursorvalue(b, false);
    }


    public void cursorvalue(long b, boolean chk) {
        countDownTimer = new CountDownTimer(b, 1000) {

            public void onTick(long timing) {

                chkfinish = false;
                valuereamin = timing;

                if (chk == false) {
                    long vlau = b;
                    progressbar_of_st.setMax((int) vlau);
                }

                int seconds = (int) (timing / 1000) % 60;
                int minutes = (int) ((timing / (1000 * 60)) % 60);

                if (minutes <= 9 && seconds <= 9) {
                    song_sleep_timer_txt.setText("0" + minutes + ":" + "0" + seconds);

                } else if (minutes <= 9 && seconds <= 9) {
                    song_sleep_timer_txt.setText(minutes + ":" + "0" + seconds);
                } else if (seconds <= 9) {
                    song_sleep_timer_txt.setText(minutes + ":" + "0" + seconds);
                } else if (minutes <= 9) {
                    song_sleep_timer_txt.setText("0" + minutes + ":" + seconds);
                } else if (minutes <= 9) {
                    song_sleep_timer_txt.setText(minutes + ":" + seconds);
                } else if (seconds <= 9) {
                    song_sleep_timer_txt.setText(minutes + ":" + "0" + seconds);
                } else if (minutes == 0 && seconds == 0) {
                    song_sleep_timer_txt.setText("00:00:00");
                } else {
                    song_sleep_timer_txt.setText(minutes + ":" + seconds);
                }


                TimerNoti TimerNoti = new TimerNoti(TimerActvitiy.this, song_sleep_timer_txt.getText().toString());
                NotificationCompat.Builder builder = TimerNoti.getchannel();
                builder.setSilent(true);
                TimerNoti.getManager().notify(6, builder.build());
                progressbar_of_st.setProgress((int) timing);

            }

            public void onFinish() {

                if (countDownTimer != null) {
                    countDownTimer.cancel();
                }

                try {
                    TimerNoti.cacel();
                } catch (Exception e) {

                }


                chkfinish = true;
                st_reset_img.setImageResource(R.drawable.pl);
                progressbar_of_st.setProgress(0);
                song_sleep_timer_txt.setText("00:00:00");

                if (t.getBoolean("soundnoti") == true) {
                    NotificationSound notification_ = new NotificationSound(TimerActvitiy.this, "Habit done");
                    NotificationCompat.Builder builder = notification_.getchannel();

                    notification_.getManager().notify(1, builder.build());
                }
            }

        }.start();
    }


    @Override
    public void onBackPressed() {

        super.onBackPressed();
        Dialog bottomSheetDialog = new Dialog(TimerActvitiy.this);
        bottomSheetDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        bottomSheetDialog.setContentView(R.layout.leave);
        TextView no = bottomSheetDialog.findViewById(R.id.no);
        TextView yes = bottomSheetDialog.findViewById(R.id.yes);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
                finish();

                try {
                    TimerNoti.cacel();
                } catch (Exception e) {

                }
                if (countDownTimer != null) {
                    countDownTimer.cancel();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bottomSheetDialog.dismiss();

            }
        });

        bottomSheetDialog.show();

    }


    public  static class NotificationActionService extends IntentService {
        public NotificationActionService() {


            super(NotificationActionService.class.getSimpleName());
        }

        @Override
        protected void onHandleIntent(Intent intent) {
            String action = intent.getAction();



            if ("StopSound".equals(action)) {
                try {
                    if (TimerActvitiy.countDownTimer != null) {
                        TimerActvitiy.countDownTimer.cancel();
                        TimerNoti.cacel();
                    }
                }
                catch (Exception e)
                {

                }
            }
        }
    }

}

