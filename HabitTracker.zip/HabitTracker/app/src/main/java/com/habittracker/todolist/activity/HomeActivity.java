package com.habittracker.todolist.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import com.habittracker.todolist.service.graph.DBGraph;
import com.habittracker.todolist.horizontalcalendar.utils.Utils;
import com.habittracker.todolist.service.Connstant;
import com.habittracker.todolist.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

import com.habittracker.todolist.service.Alarm;
import com.habittracker.todolist.service.DBHelper;
import com.habittracker.todolist.service.ReminderService;
import com.habittracker.todolist.service.TinyDB;
import com.habittracker.todolist.horizontalcalendar.HorizontalCalendar;
import com.habittracker.todolist.horizontalcalendar.adapter.DaysAdapter;
import com.habittracker.todolist.horizontalcalendar.utils.HorizontalCalendarListener;

public class HomeActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {

    public ArrayList<Alarm> alarmArrayList = new ArrayList<>();
    RecyclerView patternrecycleview;
    SnapRecyclerAdapter1 emojiadapter;
    private String dateformate;
    TextView noitem;
    public static String datastring = "";
    public TextView month;
    public static HomeActivity homeActivity;
    public String datadate = "";
    ImageView move;
    HorizontalCalendar horizontalCalendar;
    DBHelper db;
    Boolean enablebtn = true;
    ImageView add;

    long mLastClickTime;
    public long CLICK_TIME_INTERVAL;

    private BarChart chart;
    private SeekBar seekBarX, seekBarY;
    private TextView tvX, tvY;
    ImageView share;
    ArrayList<BarEntry> values = new ArrayList<>();
    public static Integer total = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homeactivity);


        

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        homeActivity = HomeActivity.this;
        month = findViewById(R.id.month);
        move = findViewById(R.id.move);


        TinyDB t = new TinyDB(HomeActivity.this);
        t.putBoolean("tutorial", true);

        Calendar startDate = Calendar.getInstance();
        startDate.add(Calendar.MONTH, 0);
        db = new DBHelper(HomeActivity.this);
        noitem = findViewById(R.id.noitem);

        Intent intent1 = new Intent(this, ReminderService.class);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                this.startForegroundService(intent1);
            } else {
                startService(intent1);
            }
        } catch (Exception e) {

        }


        RelativeLayout habit = findViewById(R.id.habit);
        RelativeLayout grapgh = findViewById(R.id.grapgh);
        RelativeLayout dailysec = findViewById(R.id.dailysec);
        share = findViewById(R.id.share);


        habit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        Intent i = new Intent(HomeActivity.this, PartActivity.class);
                        startActivity(i);

            }
        });


        grapgh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        Intent i = new Intent(HomeActivity.this, AnotherBarActivity.class);
                        startActivity(i);

            }
        });

        dailysec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        Intent i = new Intent(HomeActivity.this, MAEPartActivity.class);
                        startActivity(i);

            }
        });


        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {

                    return;
                }
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hey check out my great app.\nat: https://play.google.com/store/apps/details?id=" + getPackageName());
                sendIntent.setType("text/plain");
                startActivity(sendIntent);

                mLastClickTime = System.currentTimeMillis();
                CLICK_TIME_INTERVAL = 2000;
            }
        });


        alarmArrayList = db.getAllCotacts();
        patternrecycleview = findViewById(R.id.patternrecycleview);
        LinearLayoutManager ll = new LinearLayoutManager(HomeActivity.this, LinearLayoutManager.VERTICAL, false);
        patternrecycleview.setLayoutManager(ll);


        Calendar endDate = Calendar.getInstance();
        endDate.add(Calendar.MONTH, 11);

        add = findViewById(R.id.add);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        Intent i = new Intent(HomeActivity.this, MainActivity.class);
                        i.putExtra("datastring", datastring);
                        i.putExtra("habit", 1);
                        startActivity(i);

            }
        });

        ImageView setting = findViewById(R.id.setting);

        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        Intent i = new Intent(HomeActivity.this, SettingActivity.class);
                        startActivity(i);

            }
        });


        final Calendar defaultSelectedDate = Calendar.getInstance();
        horizontalCalendar = new HorizontalCalendar.Builder(this, R.id.calendarView)
                .range(startDate, endDate)
                .datesNumberOnScreen(5)
                .build();


        String selectedDateStr1 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();
        String selectedDateStr2 = DateFormat.format("EEE, d/MMMM/yyyy", defaultSelectedDate).toString();


        datadate = selectedDateStr1;
        String replace = selectedDateStr1.replace(',', '~');
        String[] split = replace.split("~");

        String replace1 = selectedDateStr2.replace(',', '~');
        String[] split1 = replace1.split("~");

        String dateformate1 = split1[1].trim();
        String[] split2 = dateformate1.split("/");
        String moth = split2[1].trim();
        month.setText(moth);

        dateformate = split[1].trim();

        datastring = dateformate;

         ArrayList<Alarm> abc = new ArrayList<>();

        for (Alarm flag : alarmArrayList) {

            if (flag.getDorw() != null) {

                if (flag.getDatee() != null) {

                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    Date mydate1 = null;

                    try {
                        mydate1 = sdf.parse(flag.getDatee());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    Date strDate = null;
                    try {
                        strDate = sdf.parse(dateformate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    if (mydate1.after(strDate)) {

                    } else {

                        if (flag.getDorw().equals("d")) {
                            abc.add(flag);
                        } else if (flag.getDorw().equals("w")) {
                            if (flag.getDays().contains(split[0])) {
                                abc.add(flag);
                            }
                        } else if (flag.getDorw().equals("c")) {
                            if (flag.getDatee() != null) {
                                String abc1 = split[1].trim();
                                if (flag.getDatee().toString().equalsIgnoreCase(abc1)) {
                                    abc.add(flag);
                                }
                            }
                        }
                    }
                }
            }
        }


        total = abc.size();

        if (abc.size() == 0) {
            noitem.setVisibility(View.VISIBLE);
            patternrecycleview.setVisibility(View.GONE);
        } else {


            Collections.reverse(abc);
            emojiadapter = new SnapRecyclerAdapter1(HomeActivity.this, abc, 1);
            patternrecycleview.setAdapter(emojiadapter);
            emojiadapter.notifyDataSetChanged();

            noitem.setVisibility(View.GONE);
            patternrecycleview.setVisibility(View.VISIBLE);
        }


        horizontalCalendar.setCalendarListener(new HorizontalCalendarListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDateSelected(Calendar date, int position) {

                Connstant.scroll = true;
                alarmArrayList = db.getAllCotacts();

                String selectedDateStr = DateFormat.format("EEE, d/MM/yyyy", date).toString();
                String selectedDateStr1 = DateFormat.format("EEE, d/MMMM/yyyy", date).toString();


                SimpleDateFormat sdf1 = new SimpleDateFormat("d/MM/yyyy");

                Date strDate1 = null;


                datadate = selectedDateStr;


                String replace1 = selectedDateStr1.replace(',', '~');

                String[] split1 = replace1.split("~");
                String dateformate1 = split1[1].trim();

                String[] split2 = dateformate1.split("/");
                String moth = split2[1].trim();
                month.setText(moth);

                ArrayList<Alarm> abc = new ArrayList<>();
                String replace = selectedDateStr.replace(',', '~');


                String[] split = replace.split("~");
                dateformate = split[1].trim();


                String date3 = new SimpleDateFormat("d/MM/yyyy", Locale.getDefault()).format(new Date());

                try {
                    strDate1 = sdf1.parse(dateformate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (dateformate.equals(date3)) {
                    enablebtn = true;
                    add.setImageResource(R.drawable.add);
                    add.setEnabled(true);
                } else {
                    if (new Date().after(strDate1)) {
                        enablebtn = false;
                        add.setEnabled(false);
                        add.setImageResource(R.drawable.create_disable);
                    } else {
                        add.setImageResource(R.drawable.add);
                        enablebtn = true;
                        add.setEnabled(true);
                    }
                }

                for (Alarm flag : alarmArrayList) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    Date mydate1 = null;
                    try {
                        mydate1 = sdf.parse(flag.getDatee());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    Date strDate = null;

                    try {
                        strDate = sdf.parse(dateformate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    if (mydate1.after(strDate)) {

                    } else {
                        if (flag.getDorw() != null) {
                            if (flag.getDorw().equals("d")) {
                                abc.add(flag);
                            } else if (flag.getDorw().equals("w")) {
                                if (flag.getDays().contains(split[0])) {
                                    abc.add(flag);
                                }
                            } else if (flag.getDorw().equals("c")) {
                                if (flag.getDatee() != null) {
                                    String abc1 = split[1].trim();

                                    if (flag.getDatee().toString().equalsIgnoreCase(abc1)) {
                                        abc.add(flag);
                                    }
                                }
                            }
                        }
                    }
                }

                if (abc.size() == 0) {
                    noitem.setVisibility(View.VISIBLE);
                    patternrecycleview.setVisibility(View.GONE);
                } else {
                    Collections.reverse(abc);

                    emojiadapter = new SnapRecyclerAdapter1(HomeActivity.this, abc, 1);
                    patternrecycleview.setAdapter(emojiadapter);
                    emojiadapter.notifyDataSetChanged();

                    noitem.setVisibility(View.GONE);
                    patternrecycleview.setVisibility(View.VISIBLE);
                }
            }
        });


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String selectedDateStr3 = DateFormat.format("EEE, d/MMMM/yyyy", defaultSelectedDate).toString();
                String replace3 = selectedDateStr3.replace(',', '~');
                String[] split3 = replace3.split("~");
                String dateformate3 = split3[1].trim();
                String[] split34 = dateformate3.split("/");
                String moth3 = split34[1].trim();
                month.setText(moth3);
            }
        }, 500);

        move.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                horizontalCalendar.call();
                add.setImageResource(R.drawable.add);
                enablebtn = true;
                add.setEnabled(true);
                DaysAdapter.pos = -1;
                String selectedDateStr1 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();
                String selectedDateStr2 = DateFormat.format("EEE, d/MMMM/yyyy", defaultSelectedDate).toString();
                datadate = selectedDateStr1;
                String replace = selectedDateStr1.replace(',', '~');
                String[] split = replace.split("~");

                String replace1 = selectedDateStr2.replace(',', '~');
                String[] split1 = replace1.split("~");

                String dateformate1 = split1[1].trim();

                String[] split2 = dateformate1.split("/");
                String moth = split2[1].trim();

                month.setText(moth);
                dateformate = split[1].trim();

                datastring = dateformate;
                ArrayList<Alarm> abc = new ArrayList<>();
                if (db != null && db.getAllCotacts() != null && db.getAllCotacts().size() != 0) {
                    alarmArrayList = db.getAllCotacts();
                    for (Alarm flag : alarmArrayList) {

                        if (flag.getDorw() != null) {

                            if (flag.getDatee() != null) {

                                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                Date mydate1 = null;

                                try {
                                    mydate1 = sdf.parse(flag.getDatee());
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                Date strDate = null;
                                try {
                                    strDate = sdf.parse(dateformate);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                if (mydate1.after(strDate)) {

                                } else {

                                    if (flag.getDorw().equals("d")) {
                                        abc.add(flag);
                                    } else if (flag.getDorw().equals("w")) {
                                        if (flag.getDays().contains(split[0])) {
                                            abc.add(flag);
                                        }
                                    } else if (flag.getDorw().equals("c")) {
                                        if (flag.getDatee() != null) {
                                            String abc1 = split[1].trim();
                                            if (flag.getDatee().toString().equalsIgnoreCase(abc1)) {
                                                abc.add(flag);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                total = abc.size();
                if (abc.size() == 0) {
                    noitem.setVisibility(View.VISIBLE);
                    patternrecycleview.setVisibility(View.GONE);
                } else {
                    Collections.reverse(abc);

                    emojiadapter = new SnapRecyclerAdapter1(HomeActivity.this, abc, 1);
                    patternrecycleview.setAdapter(emojiadapter);
                    emojiadapter.notifyDataSetChanged();

                    noitem.setVisibility(View.GONE);
                    patternrecycleview.setVisibility(View.VISIBLE);
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        String selectedDateStr3 = DateFormat.format("EEE, d/MMMM/yyyy", defaultSelectedDate).toString();
                        String replace3 = selectedDateStr3.replace(',', '~');
                        String[] split3 = replace3.split("~");
                        String dateformate3 = split3[1].trim();
                        String[] split34 = dateformate3.split("/");
                        String moth3 = split34[1].trim();
                        month.setText(moth3);
                    }
                }, 200);

            }
        });


        calculate();

        tvX = findViewById(R.id.tvXMax);
        tvY = findViewById(R.id.tvYMax);

        seekBarX = findViewById(R.id.seekBar1);
        seekBarX.setOnSeekBarChangeListener(this);

        seekBarY = findViewById(R.id.seekBar2);
        seekBarY.setOnSeekBarChangeListener(this);

        chart = findViewById(R.id.chart1);

        chart.getDescription().setEnabled(false);
        chart.setMaxVisibleValueCount(60);

        chart.setPinchZoom(false);

        chart.setDrawBarShadow(false);
        chart.setDrawGridBackground(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);


        int NUM_DAYS = 7;
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.SUNDAY);
        calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());


        DBGraph dbGraph = new DBGraph(HomeActivity.this);

        for (int i = 0; i < NUM_DAYS; i++) {

            Date date = calendar.getTime();

            String selectedDateStr5 = new SimpleDateFormat("EEE, d/MM/yyyy").format(date);


            Cursor b = dbGraph.getData(selectedDateStr5);
            int total = Utils.values.get(i);
            int val;
            if (b.getCount() != 0) {
                if (total != 0) {
                    int m = (b.getCount() * 100);
                    val = m / total;
                } else {
                    val = 0;
                }
            } else {
                val = 0;
            }

            values.add(new BarEntry(i, val));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        chart.getAxisLeft().setDrawGridLines(false);
        seekBarX.setProgress(10);
        seekBarY.setProgress(100);
        chart.animateY(1500);
        chart.getLegend().setEnabled(false);
        botttm();

    }


    public void botttm() {
        RelativeLayout l3 = findViewById(R.id.l3);
        RelativeLayout l1 = findViewById(R.id.l1);
        LinearLayout l2 = findViewById(R.id.l2);


        LinearLayout b3 = findViewById(R.id.b3);
        LinearLayout b1 = findViewById(R.id.b1);
        LinearLayout b2 = findViewById(R.id.b2);


        TextView t1 = findViewById(R.id.t1);
        TextView t2 = findViewById(R.id.t2);
        TextView t3 = findViewById(R.id.t3);

        ImageView i1 = findViewById(R.id.i1);
        ImageView i2 = findViewById(R.id.i2);
        ImageView i3 = findViewById(R.id.i3);

        final Calendar defaultSelectedDate = Calendar.getInstance();
        RelativeLayout today = findViewById(R.id.today);

        today.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                l3.setVisibility(View.GONE);
                l2.setVisibility(View.GONE);
                l1.setVisibility(View.VISIBLE);
                add.setVisibility(View.VISIBLE);

                share.setVisibility(View.GONE);
                move.setVisibility(View.VISIBLE);


                t1.setTextColor(getResources().getColor(R.color.black));
                t2.setTextColor(getResources().getColor(R.color.color));
                t3.setTextColor(getResources().getColor(R.color.color));

                i1.setImageResource(R.drawable.i1);
                i2.setImageResource(R.drawable.i2);
                i3.setImageResource(R.drawable.i3);
                horizontalCalendar.call();
                add.setImageResource(R.drawable.add);
                enablebtn = true;
                add.setEnabled(true);
                DaysAdapter.pos = -1;
                String selectedDateStr1 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();
                String selectedDateStr2 = DateFormat.format("EEE, d/MMMM/yyyy", defaultSelectedDate).toString();
                datadate = selectedDateStr1;
                String replace = selectedDateStr1.replace(',', '~');
                String[] split = replace.split("~");

                String replace1 = selectedDateStr2.replace(',', '~');
                String[] split1 = replace1.split("~");

                String dateformate1 = split1[1].trim();

                String[] split2 = dateformate1.split("/");
                String moth = split2[1].trim();

                month.setText(moth);
                dateformate = split[1].trim();

                datastring = dateformate;
                ArrayList<Alarm> abc = new ArrayList<>();
                if (db != null && db.getAllCotacts() != null && db.getAllCotacts().size() != 0) {
                    alarmArrayList = db.getAllCotacts();
                    for (Alarm flag : alarmArrayList) {

                        if (flag.getDorw() != null) {

                            if (flag.getDatee() != null) {

                                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                Date mydate1 = null;

                                try {
                                    mydate1 = sdf.parse(flag.getDatee());
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                Date strDate = null;
                                try {
                                    strDate = sdf.parse(dateformate);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                if (mydate1.after(strDate)) {

                                } else {

                                    if (flag.getDorw().equals("d")) {
                                        abc.add(flag);
                                    } else if (flag.getDorw().equals("w")) {
                                        if (flag.getDays().contains(split[0])) {
                                            abc.add(flag);
                                        }
                                    } else if (flag.getDorw().equals("c")) {
                                        if (flag.getDatee() != null) {
                                            String abc1 = split[1].trim();
                                            if (flag.getDatee().toString().equalsIgnoreCase(abc1)) {
                                                abc.add(flag);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }


                if (abc.size() == 0) {
                    noitem.setVisibility(View.VISIBLE);
                    patternrecycleview.setVisibility(View.GONE);
                } else {
                    Collections.reverse(abc);

                    emojiadapter = new SnapRecyclerAdapter1(HomeActivity.this, abc, 1);
                    patternrecycleview.setAdapter(emojiadapter);
                    emojiadapter.notifyDataSetChanged();

                    noitem.setVisibility(View.GONE);
                    patternrecycleview.setVisibility(View.VISIBLE);
                }

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        String selectedDateStr3 = DateFormat.format("EEE, d/MMMM/yyyy", defaultSelectedDate).toString();
                        String replace3 = selectedDateStr3.replace(',', '~');
                        String[] split3 = replace3.split("~");
                        String dateformate3 = split3[1].trim();
                        String[] split34 = dateformate3.split("/");
                        String moth3 = split34[1].trim();
                        month.setText(moth3);
                    }
                }, 200);

            }
        });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                l3.setVisibility(View.GONE);
                l2.setVisibility(View.GONE);
                l1.setVisibility(View.VISIBLE);
                add.setVisibility(View.VISIBLE);

                share.setVisibility(View.GONE);
                move.setVisibility(View.VISIBLE);


                t1.setTextColor(getResources().getColor(R.color.black));
                t2.setTextColor(getResources().getColor(R.color.color));
                t3.setTextColor(getResources().getColor(R.color.color));

                i1.setImageResource(R.drawable.i1);
                i2.setImageResource(R.drawable.i2);
                i3.setImageResource(R.drawable.i3);


            }
        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                l2.setVisibility(View.VISIBLE);
                l3.setVisibility(View.GONE);
                l1.setVisibility(View.GONE);
                add.setVisibility(View.GONE);

                move.setVisibility(View.GONE);

                t2.setTextColor(getResources().getColor(R.color.black));
                t1.setTextColor(getResources().getColor(R.color.color));
                t3.setTextColor(getResources().getColor(R.color.color));
                share.setVisibility(View.VISIBLE);

                i1.setImageResource(R.drawable.i1_d);
                i2.setImageResource(R.drawable.i2_s);
                i3.setImageResource(R.drawable.i3);
            }
        });


        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                l3.setVisibility(View.VISIBLE);
                l1.setVisibility(View.GONE);
                l2.setVisibility(View.GONE);
                add.setVisibility(View.GONE);
                share.setVisibility(View.VISIBLE);
                move.setVisibility(View.GONE);


                t3.setTextColor(getResources().getColor(R.color.black));
                t2.setTextColor(getResources().getColor(R.color.color));
                t1.setTextColor(getResources().getColor(R.color.color));

                i1.setImageResource(R.drawable.i1_d);
                i2.setImageResource(R.drawable.i2);
                i3.setImageResource(R.drawable.i3_s);

                callgraph();
                chart = findViewById(R.id.chart1);


                chart.setMaxVisibleValueCount(60);

                // scaling can now only be done on x- and y-axis separately
                chart.setPinchZoom(false);
                chart.setDrawBarShadow(false);
                chart.setDrawGridBackground(false);

                XAxis xAxis = chart.getXAxis();
                xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
                xAxis.setDrawGridLines(false);


                seekBarX.setProgress(10);
                seekBarY.setProgress(100);


                DBGraph dbGraph = new DBGraph(HomeActivity.this);
                final Calendar defaultSelectedDate = Calendar.getInstance();
                String selectedDateStr1 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();

                Cursor b = dbGraph.getData(selectedDateStr1);

                TextView d2 = findViewById(R.id.d2);
                d2.setText(String.valueOf(b.getCount()));


                TextView d3 = findViewById(R.id.d3);

                int remian = total - b.getCount();
                d3.setText(String.valueOf(remian));


                int NUM_DAYS = 7;
                Calendar calendar = Calendar.getInstance();
                calendar.setFirstDayOfWeek(Calendar.SUNDAY); // The first day you want dates from.
                calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());

                for (int i = 0; i < NUM_DAYS; i++) {

                    Date date = calendar.getTime();
                    String selectedDateStr5 = new SimpleDateFormat("EEE, d/MM/yyyy").format(date);


                    Cursor b4 = dbGraph.getData(selectedDateStr5);

                    int total = Utils.values.get(i);


                    int val;

                    if (b4.getCount() != 0) {
                        int m = (b4.getCount() * 100);
                        val = m / total;

                    } else {
                        val = 0;
                    }

                    values.add(new BarEntry(i, val));
                    calendar.add(Calendar.DAY_OF_MONTH, 1);
                }

            }
        });


    }


    public void callgraph() {

        int NUM_DAYS = 7;
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.SUNDAY); // The first day you want dates from.
        calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());

        values.clear();
        DBGraph dbGraph = new DBGraph(HomeActivity.this);

        for (int i = 0; i < NUM_DAYS; i++) {

            Date date = calendar.getTime();

            String selectedDateStr5 = new SimpleDateFormat("EEE, d/MM/yyyy").format(date);

            Cursor b = dbGraph.getData(selectedDateStr5);
            int total = Utils.values.get(i);
            int val;
            if (b.getCount() != 0) {
                int m = (b.getCount() * 100);
                val = m / total;
            } else {
                val = 0;
            }
            values.add(new BarEntry(i, val));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }


    }


    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        tvX.setText(String.valueOf(seekBarX.getProgress()));
        tvY.setText(String.valueOf(seekBarY.getProgress()));

        BarDataSet set1;

        if (chart.getData() != null &&
                chart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) chart.getData().getDataSetByIndex(0);
            set1.setValues(values);
            chart.getData().notifyDataChanged();
            chart.notifyDataSetChanged();
        } else {
            set1 = new BarDataSet(values, "Data Set");
            set1.setColors(ColorTemplate.VORDIPLOM_COLORS);
            set1.setDrawValues(false);

            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1);

            BarData data = new BarData(dataSets);



            chart.setData(data);
            chart.setFitBars(true);
        }

        chart.invalidate();
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }


    public void calculate() {

        int NUM_DAYS = 7;

        Calendar calendar1 = Calendar.getInstance();
        calendar1.setFirstDayOfWeek(Calendar.SUNDAY); // The first day you want dates from.
        calendar1.set(Calendar.DAY_OF_WEEK, calendar1.getFirstDayOfWeek());

        Utils.values.clear();
        for (int i = 0; i < NUM_DAYS; i++) {

            Date date = calendar1.getTime();
            String selectedDateStr1 = new SimpleDateFormat("EEE, d/MM/yyyy").format(date);



            String replace = selectedDateStr1.replace(',', '~');
            String[] split = replace.split("~");

            ArrayList<Alarm> abc = new ArrayList<>();

            for (Alarm flag : alarmArrayList) {

                if (flag.getDorw() != null) {

                    if (flag.getDatee() != null) {

                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                        Date mydate1 = null;

                        try {
                            mydate1 = sdf.parse(flag.getDatee());
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                        Date strDate = null;
                        try {
                            strDate = sdf.parse(dateformate);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                        if (mydate1.after(strDate)) {

                        } else {

                            if (flag.getDorw().equals("d")) {
                                abc.add(flag);
                            } else if (flag.getDorw().equals("w")) {
                                if (flag.getDays().contains(split[0])) {
                                    abc.add(flag);
                                }
                            } else if (flag.getDorw().equals("c")) {
                                if (flag.getDatee() != null) {
                                    String abc1 = split[1].trim();
                                    if (flag.getDatee().toString().equalsIgnoreCase(abc1)) {
                                        abc.add(flag);
                                    }
                                }
                            }
                        }
                    }
                }

            }

            calendar1.add(Calendar.DAY_OF_MONTH, 1);
            Utils.values.add(abc.size());
        }


    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private class SnapRecyclerAdapter1 extends RecyclerView.Adapter<SnapRecyclerAdapter1.ReyclerViewHolder> {
        int type = 1;
        private LayoutInflater layoutInflater;
        private ArrayList<Alarm> items = new ArrayList<>();
        private int data = -1;


        public SnapRecyclerAdapter1(Context context, ArrayList<Alarm> items, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            this.items = items;
            this.type = type;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.eq, parent, false);
            return new ReyclerViewHolder(item);
        }


        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            if (items.get(position).getPause().equals("false")) {
                holder.Imgsticker.setText(this.items.get(position).getAlarm_Name());
                holder.pause.setVisibility(View.GONE);
                holder.des.setText(this.items.get(position).getDescription());
            } else {
                holder.Imgsticker.setText(this.items.get(position).getAlarm_Name());
                holder.pause.setVisibility(View.VISIBLE);
                holder.des.setText(this.items.get(position).getDescription());
            }


            if (items.get(position).getDescription() != null && !TextUtils.isEmpty(items.get(position).getDescription())) {
                holder.des.setVisibility(View.VISIBLE);
            } else {
                holder.des.setVisibility(View.GONE);
            }


            if (items.get(position).getNagtive() != null && !TextUtils.isEmpty(items.get(position).getNagtive())) {
                if (items.get(position).getNagtive().equals("nagative")) {
                    holder.cardfont.setBackground(getResources().getDrawable(R.drawable.cardnegative));
                    holder.des.setTextColor(getResources().getColor(R.color.red));
                    holder.Imgsticker.setTextColor(getResources().getColor(R.color.red));
                    ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.red)));
                } else {
                    holder.cardfont.setBackground(getResources().getDrawable(R.drawable.cardbg));
                    holder.des.setTextColor(getResources().getColor(R.color.grey));
                }
            } else {
                holder.cardfont.setBackground(getResources().getDrawable(R.drawable.cardbg));
                holder.des.setTextColor(getResources().getColor(R.color.grey));
            }


            if (items.get(position).getChkclock().equals("true")) {
                holder.clock.setVisibility(View.VISIBLE);
            } else {
                holder.clock.setVisibility(View.GONE);
            }


            holder.clock.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                            Intent i = new Intent(HomeActivity.this, ClockActivity.class);
                            i.putExtra("datastring", datastring);
                            i.putExtra("id", items.get(position).getId());
                            i.putExtra("date", dateformate);
                            i.putExtra("data", data);
                            startActivity(i);

                }
            });


            holder.image.setImageResource(this.items.get(position).getIcon());
            if (items.get(position).getNagtive() != null && !TextUtils.isEmpty(items.get(position).getNagtive())) {

                if (!items.get(position).getNagtive().equals("nagative")) {
                    if (items.get(position).getColorname() == 0) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                    } else if (items.get(position).getColorname() == 1) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c1)));
                    } else if (items.get(position).getColorname() == 2) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c2)));
                    } else if (items.get(position).getColorname() == 3) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c3)));
                    } else if (items.get(position).getColorname() == 4) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c4)));
                    } else if (items.get(position).getColorname() == 5) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                    }
                }
            }

            holder.cardfont.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                            Intent i = new Intent(HomeActivity.this, ViewActivity.class);
                            i.putExtra("datastring", datastring);
                            i.putExtra("id", items.get(position).getId());
                            i.putExtra("date", dateformate);
                            i.putExtra("data", data);
                            i.putExtra("total", items.size());
                            startActivityForResult(i, 1);

                }
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {

            private RelativeLayout cardfont;
            private TextView Imgsticker;
            private ImageView image, clock;
            private ImageView pause;
            private TextView des;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (TextView) v.findViewById(R.id.texview);
                image = v.findViewById(R.id.image);
                clock = v.findViewById(R.id.clock);
                pause = v.findViewById(R.id.pause);
                cardfont = v.findViewById(R.id.cardfont);
                des = v.findViewById(R.id.des);
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1) {

            String replace = datadate.replace(',', '~');
            String[] split = replace.split("~");
            ArrayList<Alarm> abc = new ArrayList<>();
            if (db != null && db.getAllCotacts() != null && db.getAllCotacts().size() != 0) {
                alarmArrayList = db.getAllCotacts();
                for (Alarm flag : alarmArrayList) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    Date mydate1 = null;
                    try {
                        mydate1 = sdf.parse(flag.getDatee());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    Date strDate = null;

                    try {
                        strDate = sdf.parse(dateformate);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    if (mydate1.after(strDate)) {

                    } else {
                        if (flag.getDorw() != null) {
                            if (flag.getDorw().equals("d")) {
                                abc.add(flag);
                            } else if (flag.getDorw().equals("w")) {

                                if (flag.getDays().contains(split[0])) {
                                    abc.add(flag);
                                }
                            } else if (flag.getDorw().equals("c")) {
                                if (flag.getDatee() != null) {
                                    String abc1 = split[1].trim();

                                    if (flag.getDatee().toString().equalsIgnoreCase(abc1)) {
                                        abc.add(flag);
                                    }
                                }
                            }
                        }
                    }
                }

            }

            if (abc.size() == 0) {
                noitem.setVisibility(View.VISIBLE);
                patternrecycleview.setVisibility(View.GONE);
            } else {
                Collections.reverse(abc);
                emojiadapter = new SnapRecyclerAdapter1(HomeActivity.this, abc, 1);
                patternrecycleview.setAdapter(emojiadapter);
                emojiadapter.notifyDataSetChanged();

                noitem.setVisibility(View.GONE);
                patternrecycleview.setVisibility(View.VISIBLE);
            }


            final Calendar defaultSelectedDate1 = Calendar.getInstance();
            String selectedDateStr13 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate1).toString();
            String replace0 = selectedDateStr13.replace(',', '~');
            String[] split9 = replace0.split("~");

            String dateformate1 = split9[1].trim();
            ArrayList<Alarm> abc4 = new ArrayList<>();

            if (db != null && db.getAllCotacts() != null && db.getAllCotacts().size() != 0) {
                alarmArrayList = db.getAllCotacts();
                for (Alarm flag : alarmArrayList) {

                    if (flag.getDorw() != null) {

                        if (flag.getDatee() != null) {

                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date mydate1 = null;

                            try {
                                mydate1 = sdf.parse(flag.getDatee());
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            Date strDate = null;
                            try {
                                strDate = sdf.parse(dateformate1);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            if (mydate1.after(strDate)) {

                            } else {

                                if (flag.getDorw().equals("d")) {
                                    abc4.add(flag);
                                } else if (flag.getDorw().equals("w")) {
                                    if (flag.getDays().contains(split9[0])) {
                                        abc4.add(flag);
                                    }
                                } else if (flag.getDorw().equals("c")) {
                                    if (flag.getDatee() != null) {
                                        String abc1 = split9[1].trim();
                                        if (flag.getDatee().toString().equalsIgnoreCase(abc1)) {
                                            abc4.add(flag);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }


            total = abc4.size();


        }
    }

    @Override
    public void onBackPressed() {


        super.onBackPressed();
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(HomeActivity.this);
        bottomSheetDialog.setContentView(R.layout.exitdialog);
        TextView no = bottomSheetDialog.findViewById(R.id.no);
        TextView yes = bottomSheetDialog.findViewById(R.id.yes);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
                finishAffinity();
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bottomSheetDialog.dismiss();

            }
        });

        bottomSheetDialog.show();


    }


}
