package com.habittracker.todolist.service;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.habittracker.todolist.R;
import com.habittracker.todolist.activity.Storage;
import com.habittracker.todolist.activity.TimerActvitiy;


public class TimerNoti extends ContextWrapper {
    private static final String channelID = "channelID";
    private static final String channelName = "channel Name";

    public static NotificationManager notificationManager;
    private String name;
    TinyDB t;
    Storage storage;


    public TimerNoti(Context base, String namer) {
        super(base);
        storage = new Storage(base);
        name = namer;
        t = new TinyDB(base);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createchannel();
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createchannel() {
        NotificationChannel channel = new NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH);
        getManager().createNotificationChannel(channel);
    }

    public NotificationManager getManager() {
        if (notificationManager == null) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return notificationManager;
    }


    public static void cacel() {
        if (notificationManager != null) {
            notificationManager.cancel(6);
        }
    }

    public NotificationCompat.Builder getchannel() {



        Intent stopSoundIntent = new Intent(getApplicationContext(),
                TimerActvitiy.NotificationActionService.class)
                .setAction("StopSound");

        PendingIntent stopSoundPendingIntent = PendingIntent.getService(getApplicationContext(), 0, stopSoundIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);

        int icon = storage.getIcon();

        return new NotificationCompat.Builder(getApplicationContext(), channelID).setAutoCancel(false).
                setContentTitle("Timer..." + name).setContentTitle("Timer..." + name).setSound(null).addAction(new NotificationCompat.Action(R.drawable.move,
                "Stop Timer", stopSoundPendingIntent)).setSmallIcon(icon);

    }
}

