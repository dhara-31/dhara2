package com.habittracker.todolist.habitcomon;


import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.habittracker.todolist.R;


import com.habittracker.todolist.activity.StartActivity;

public class SplashActivity extends AppCompatActivity {


    public static Handler handleSplash;
    public static Runnable runnableSPlasjD;
    CountDownTimer timer;
    int timerScreen = 6000;
    public DAppHAbitlication myApp = DAppHAbitlication.getInstance();
    boolean checkResumed = true;
    boolean overtimerLive = false;

    public Dialog dialog;
    public static Boolean appopenD = true;

    public static Boolean value = false;
    public static Integer valueinterD = 0;
    public static Boolean exit = false;

    public static int screennumber = 0;

    public static Boolean Ads = false;


    private static final int REQ_CODE_VERSION_UPDATE = 530;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        

        setContentView(R.layout.splashscreen);



        startActivity(new Intent(SplashActivity.this, StartActivity.class));
        finish();
    }




    @Override
    public void onBackPressed() {
    }
}
