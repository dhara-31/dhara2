package com.habittracker.todolist.activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.CalendarView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.widget.ImageViewCompat;

import com.habittracker.todolist.R;

import com.habittracker.todolist.service.graph.DBGraph;
import com.habittracker.todolist.service.DBHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ViewActivity extends AppCompatActivity {


    int delatableId;
    @SuppressLint("Range")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        

        TextView txt = findViewById(R.id.txt);



        ImageView Imgback = findViewById(R.id.Imgback);

        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        CalendarView calendar_view = findViewById(R.id.simpleCalendarView);
        DBHelper db = new DBHelper(ViewActivity.this);

        ImageView dlete = findViewById(R.id.delete);
        TextView txtdes = findViewById(R.id.txtdes);


        ImageView edit = findViewById(R.id.edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                        Intent i = new Intent(ViewActivity.this, EditHabitAddActivity.class);
                        i.putExtra("id", getIntent().getIntExtra("id", 0));
                        startActivity(i);

            }
        });

        Cursor rs = db.getData(getIntent().getIntExtra("id", 0));

        if (rs.getCount() > 0) {
            rs.moveToFirst();
            txt.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NAME)));
            txtdes.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_des)));
            ImageView icon = findViewById(R.id.icon);
            icon.setImageResource(Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_icon))));


            String title = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_title));
            String name = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NAME));
            ImageView finish = findViewById(R.id.finish);


            final Calendar defaultSelectedDate = Calendar.getInstance();
            String selectedDateStr1 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();
            String replace = selectedDateStr1.replace(',', '~');
            String[] split = replace.split("~");

            String check = split[1].trim();



             int id = getIntent().getIntExtra("id", 0);
            if (check.equals(HomeActivity.datastring)) {

                DBGraph dbGraph = new DBGraph(ViewActivity.this);

                List<Long> idlist = new ArrayList<>();

                idlist = dbGraph.getAllIds();



                boolean containsId = false;

                for (Long ids : idlist) {


                    if (ids == id) {

                        delatableId = id;
                        containsId = true;
                        break;
                    }
                }
                if (containsId) {
                    finish.setVisibility(View.GONE);

                } else {
                    finish.setVisibility(View.VISIBLE);

                }

            } else {
                finish.setVisibility(View.GONE);
            }


            dlete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    db.deleteContact(getIntent().getIntExtra("id", 0));
                    Toast.makeText(ViewActivity.this, "Habit Deleted...", Toast.LENGTH_LONG).show();

                    DBGraph dbGraph = new DBGraph(ViewActivity.this);

                    dbGraph.deleteContact(getIntent().getIntExtra("id", 0));
                    dbGraph.close();
                    finish.setVisibility(View.GONE);

                    finish();

                }
            });

            finish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    Dialog dialog = new Dialog(ViewActivity.this);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.requestWindowFeature(1);
                    dialog.setContentView(R.layout.finish);
                    dialog.setCancelable(false);
                    TextView txt_yes = (TextView) dialog.findViewById(R.id.yes);
                    TextView r_retry = (TextView) dialog.findViewById(R.id.no);
                    TextView txt = (TextView) dialog.findViewById(R.id.txt);

                    r_retry.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (dialog != null) {
                                dialog.dismiss();
                            }
                        }
                    });


                    txt_yes.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Toast.makeText(ViewActivity.this, "Habit Finish...", Toast.LENGTH_LONG).show();
                            if (dialog != null) {
                                dialog.dismiss();
                            }
                            DBGraph dbGraph = new DBGraph(ViewActivity.this);
                            Boolean value = dbGraph.val(name, selectedDateStr1, title);
                            if (value == false) {
                                dbGraph.insertContact(getIntent().getIntExtra("id", 0),txt.getText().toString(), selectedDateStr1, getIntent().getIntExtra("total", 0), title);
                                dbGraph.close();
                                finish.setVisibility(View.GONE);
                            }
                        }
                    });

                    dialog.show();


                }
            });


            if (rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)) != null && !TextUtils.isEmpty(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)))) {

                if (!rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)).equals("nagative")) {
                    if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 0) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 1) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c1)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 2) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c2)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 3) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c3)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 4) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c4)));
                    } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 5) {
                        ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                    }
                } else {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.red)));
                }

            }


            TextView daily = findViewById(R.id.daily);
            String dorw = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_dorw));

            if (dorw.equals("d")) {
                daily.setText("Daily");
            } else if (dorw.equals("w")) {
                daily.setText("Weekly");
            } else if (dorw.equals("c")) {
                daily.setText("Custom");
            }

            TextView remind = findViewById(R.id.remind);
            String mornig = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_morning));

            if (mornig.isEmpty()) {
                remind.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_time)));
            }

            if (mornig.equals("morning")) {
                remind.setText("Morning");
            } else if (mornig.equals("afternoon")) {
                remind.setText("Afternoon");
            } else if (mornig.equals("evening")) {
                remind.setText("Evening");
            }


            String nam1 = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_pause));
            ImageView pause = findViewById(R.id.pause);


            if (nam1.equals("false")) {
                pause.setImageResource(R.drawable.pause);
            } else {
                pause.setImageResource(R.drawable.play);
            }


            pause.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Cursor rs4 = db.getData(getIntent().getIntExtra("id", 0));
                    rs4.moveToFirst();

                    String nam2 = rs4.getString(rs4.getColumnIndex(DBHelper.CONTACTS_pause));


                    if (nam2.equals("false")) {

                        Cursor rs1 = db.getData(getIntent().getIntExtra("id", 0));
                        rs1.moveToFirst();

                        if (db.updatePause(getIntent().getIntExtra("id", 0), "true")) {
                            pause.setImageResource(R.drawable.play);
                        }

                    } else {
                        Cursor rs2 = db.getData(getIntent().getIntExtra("id", 0));
                        rs2.moveToFirst();

                        if (db.updatePause(getIntent().getIntExtra("id", 0), "false")) {
                            pause.setImageResource(R.drawable.pause);
                        }
                    }
                }
            });

            calendar_view.setClickable(false);


            if (rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_dorw)).equals("c")) {

                TextView r = findViewById(R.id.r);
                r.setText("One Task");
                @SuppressLint("Range")
                String nam = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_date));

                if (!rs.isClosed()) {
                    rs.close();
                }
                String date = nam;
                String parts[] = date.split("/");

                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]);
                int year = Integer.parseInt(parts[2]);

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month - 1);
                calendar.set(Calendar.DAY_OF_MONTH, day);

                long milliTime = calendar.getTimeInMillis();

                calendar_view.setDate(milliTime);
            } else {
                String nam = getIntent().getStringExtra("date");

                String date = nam;
                String parts[] = date.split("/");

                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]);
                int year = Integer.parseInt(parts[2]);

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month - 1);
                calendar.set(Calendar.DAY_OF_MONTH, day);

                long milliTime = calendar.getTimeInMillis();
                calendar_view.setDate(milliTime);
            }
        }

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


}
