package com.habittracker.todolist.other;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.habittracker.todolist.R;

import java.util.ArrayList;

public class PermissionClass {
    private Activity activity;
    private ArrayList<String> permissionList;
    private boolean showDialog;
    private OnPermissionAllowed permissionAllowed;

    private boolean permissionSetting = false;
    private boolean permissionViewAdded = false;
    private View view = null;
    private TextView tvAllow = null;
    private String permissioncontent=null;
    private ArrayList<String> newPermissionList = new ArrayList<>();

    public PermissionClass(Activity activity, ArrayList<String> permissionList, boolean showDialog, String content, OnPermissionAllowed permissionAllowed) {
        this.activity = activity;
        this.permissionList = permissionList;
        this.showDialog = showDialog;
        this.permissionAllowed = permissionAllowed;
        this.permissioncontent =content;
        callOnPermission(checkAskPermissionAndroid(permissionList));
    }

    private void callOnPermission(boolean permission) {
        permissionAllowed.onPermission(permission);

        if (!showDialog) {
            if (!permission) {
                addView();
            } else {
                removeView();
            }
        }
    }

    private void addView() {
        if (view == null) {
            view = LayoutInflater.from(activity).inflate(R.layout.view_permission, (ViewGroup) activity.getWindow().getDecorView(), false);
            ((ViewGroup) activity.getWindow().getDecorView()).addView(view);
            permissionViewAdded = true;

            tvAllow = ((ViewGroup) activity.getWindow().getDecorView()).findViewById(R.id.tvAllow);

            checkShouldPermission(newPermissionList);

            tvAllow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    askPermission();
                }
            });
        }
    }

    private void removeView() {
        if (view != null) {
            ((ViewGroup) activity.getWindow().getDecorView()).removeView(view);
            view = null;
        }
    }

    private void checkShouldPermission(ArrayList<String> permissionList) {

        ArrayList<String> tempListShould = new ArrayList<>();

        for (String checkPermission : permissionList) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, checkPermission)) {
                if (getPermissionWrite(activity, checkPermission)) {
                    tempListShould.add(checkPermission);
                }
            } else {
                setPermissionWrite(activity, checkPermission, true);
            }
        }

        if (tempListShould.size() > 0) {
            for (String permission : tempListShould) {
                setPermissionWrite(activity, permission, true);
            }
            if (showDialog) {
                permissionDialog(permissioncontent);
            } else {
                permissionSetting = true;
                if (tvAllow != null) {
                    tvAllow.setText("Setting");
                }
            }
        }
    }

    public interface OnPermissionAllowed {
        void onPermission(boolean allowed);
    }

    public boolean checkAskPermissionAndroid(ArrayList<String> permissionList) {
        newPermissionList = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
                newPermissionList.add(permission);
            }
        }

        if (newPermissionList.size() == 0) {
            return true;
        } else {
            if (showDialog) {
                askPermission();
            }
            return false;
        }
    }

    public void checkPermission() {
        newPermissionList = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
                newPermissionList.add(permission);
            }
        }

        callOnPermission(newPermissionList.size() == 0);
    }

    public void askPermission() {
        newPermissionList = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
                newPermissionList.add(permission);
            }
        }

        if (permissionSetting) {
            activity.startActivityForResult(
                    new Intent("android.settings.APPLICATION_DETAILS_SETTINGS",
                            Uri.fromParts("package", activity.getPackageName(), null)), 969);
        } else {
            ActivityCompat.requestPermissions(activity, newPermissionList.toArray(new String[0]), 969);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 969) {
            if (grantResults.length > 0) {
                ArrayList<String> tempList = new ArrayList<>();

                for (String checkPermission : permissions) {
                    if (ContextCompat.checkSelfPermission(activity, checkPermission) != PackageManager.PERMISSION_GRANTED) {
                        tempList.add(checkPermission);
                     }
                }


                if (tempList.isEmpty()) {
                    for (String permission : permissions) {
                        setPermissionWrite(activity, permission, true);
                    }
                    callOnPermission(true);
                    return;
                } else {
                    callOnPermission(false);
                }

                ArrayList<String> checkList = new ArrayList<>();
                for (String permission : permissions) {
                    checkList.add(permission);
                }

                checkShouldPermission(checkList);
            }
        }
    }

    private void permissionDialog(String permissioncontent) {
        Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.dialog_permission);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(false);

        ImageView img_cancel = dialog.findViewById(R.id.img_cancel);
        ImageView img_setting = dialog.findViewById(R.id.img_setting);
        TextView tvSubText  =dialog.findViewById(R.id.tvSubText);

        tvSubText.setText(permissioncontent);


        img_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.startActivityForResult(
                        new Intent("android.settings.APPLICATION_DETAILS_SETTINGS",Uri.fromParts("package", activity.getPackageName(), null)), 969);
                dialog.dismiss();
            }
        });
        img_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void setPermissionWrite(Activity activity, String permissionKey, boolean permission) {
        SharedPreferences.Editor editor = activity.getSharedPreferences("PrefData", Context.MODE_PRIVATE).edit();
        editor.putBoolean(permissionKey, permission);
        editor.apply();
    }

    private boolean getPermissionWrite(Activity activity, String permissionKey) {
        SharedPreferences prefs = activity.getSharedPreferences("PrefData", Context.MODE_PRIVATE);
        return prefs.getBoolean(permissionKey, false);
    }
}
