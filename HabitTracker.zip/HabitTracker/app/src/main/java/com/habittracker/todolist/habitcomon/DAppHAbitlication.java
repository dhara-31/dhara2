

package com.habittracker.todolist.habitcomon;

import android.app.Application;
import android.content.SharedPreferences;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class DAppHAbitlication extends Application  {


    public static boolean isSplashFinissh = false;

    public static String splashscreennamHAbite = "SplashActivity";

    public Integer openvalue = 0;

    public Integer intervalue = 0;

    private static DAppHAbitlication ourInstance;

    public SharedPreferences preferences;
    public static  Boolean inter = true ;
    public static DAppHAbitlication getInstance() {
        return ourInstance;
    }

    public static final String MyPREFERENCES = "MyAdsPrefs";

    public static DAppHAbitlication c() {
        return ourInstance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ourInstance = this;

        preferences = getApplicationContext().getSharedPreferences(MyPREFERENCES, MODE_PRIVATE);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
    }



}
