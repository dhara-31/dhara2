package com.habittracker.todolist.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.todolist.R;

import com.habittracker.todolist.other.PermissionClass;
import com.habittracker.todolist.service.TinyDB;

import java.util.ArrayList;

public class SoundActivity extends AppCompatActivity {

    RecyclerView patternrecycleview;
    SnapRecyclerAdapter1 emojiadapter;
    int[] resID = {R.raw.s1, R.raw.s2, R.raw.s3};
    MediaPlayer mediaPlayer;
    TinyDB t;
    LinearLayout ll;

    public static final String content ="Allow Permission to access Timer.";

    PermissionClass permissionClass;

    @SuppressLint("Range")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sound);

        



        ImageView Imgback = findViewById(R.id.Imgback);
        ImageView sw = findViewById(R.id.swi);
        ImageView swinoti = findViewById(R.id.swinoti);
        ll = findViewById(R.id.ll);
        t = new TinyDB(SoundActivity.this);


        if (t.getBoolean("soundnoti") == false) {
            swinoti.setImageResource(R.drawable.soff);
            sw.setEnabled(false);
        } else {
            swinoti.setImageResource(R.drawable.son);
            sw.setEnabled(true);
            ll.setAlpha(1.0f);
        }

        swinoti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT > 32) {
                    ArrayList<String> PermissionList = new ArrayList<>();
                    PermissionList.add(Manifest.permission.POST_NOTIFICATIONS);

                      permissionClass = new PermissionClass(SoundActivity.this, PermissionList, true, content, new PermissionClass.OnPermissionAllowed() {
                        @Override
                        public void onPermission(boolean allowed) {
                            if(allowed){

                                if (t.getBoolean("soundnoti") == false) {
                                    t.putBoolean("soundnoti", true);
                                    swinoti.setImageResource(R.drawable.son);
                                    ll.setAlpha(1.0f);
                                    sw.setEnabled(true);
                                } else {
                                    t.putBoolean("soundnoti", false);
                                    sw.setEnabled(false);
                                    ll.setAlpha(0.4f);
                                    swinoti.setImageResource(R.drawable.soff);
                                }
                            }
                        }
                    });
                }else {


                    if (t.getBoolean("soundnoti") == false) {
                        t.putBoolean("soundnoti", true);
                        swinoti.setImageResource(R.drawable.son);
                        ll.setAlpha(1.0f);
                        sw.setEnabled(true);
                    } else {
                        t.putBoolean("soundnoti", false);
                        sw.setEnabled(false);
                        ll.setAlpha(0.4f);
                        swinoti.setImageResource(R.drawable.soff);
                    }
                }
            }
        });

        if (t.getBoolean("sound") == false) {
            sw.setImageResource(R.drawable.soff);
        } else {
            sw.setImageResource(R.drawable.son);
        }

        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (t.getBoolean("sound") == false) {
                    t.putBoolean("sound", true);
                    sw.setImageResource(R.drawable.son);
                } else {
                    t.putBoolean("sound", false);
                    sw.setImageResource(R.drawable.soff);
                }
            }
        });


        patternrecycleview = findViewById(R.id.patternrecycleview);
        patternrecycleview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        patternrecycleview.setHasFixedSize(true);

        emojiadapter = new SnapRecyclerAdapter1(SoundActivity.this, resID);
        patternrecycleview.setAdapter(emojiadapter);
        emojiadapter.notifyDataSetChanged();


        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }

    private class SnapRecyclerAdapter1 extends RecyclerView.Adapter<SnapRecyclerAdapter1.ReyclerViewHolder> {
        int type = 1;
        private LayoutInflater layoutInflater;
        private int data = 0;
        int[] resID1;


        public SnapRecyclerAdapter1(Context context, int[] resID) {
            this.layoutInflater = LayoutInflater.from(context);
            resID1 = resID;
            this.type = type;
            data = t.getInt("not");
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.adapter_sound, parent, false);
            return new ReyclerViewHolder(item);
        }

        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            holder.sname.setText("Sonund " + (position + 1));

            if (t.getBoolean("soundnoti") == true && t.getBoolean("sound") == true) {
                if (data == position) {
                    holder.pause.setVisibility(View.VISIBLE);
                } else {
                    holder.pause.setVisibility(View.GONE);
                }
            }


            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (t.getBoolean("soundnoti") == true && t.getBoolean("sound") == true) {
                        int resId = resID[position];

                        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                            mediaPlayer.stop();
                            mediaPlayer.release();
                        }
                        t.putInt("not", position);

                        mediaPlayer = null;

                        mediaPlayer = MediaPlayer.create(SoundActivity.this, resId);
                        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        mediaPlayer.setLooping(false);
                        if (mediaPlayer != null) {

                            if (mediaPlayer.isPlaying()) {
                                mediaPlayer.stop();
                                mediaPlayer.release();
                            }
                            mediaPlayer.start();
                        } else {
                            mediaPlayer.pause();
                        }
                        data = position;
                        holder.pause.setVisibility(View.VISIBLE);

                        notifyDataSetChanged();
                    }
                }
            });


        }

        @Override
        public int getItemCount() {
            return resID1.length;
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {

            private RelativeLayout cardfont;
            private TextView sname;
            private ImageView image;
            private ImageView pause;


            private ReyclerViewHolder(final View v) {
                super(v);
                sname = (TextView) v.findViewById(R.id.texview);
                image = v.findViewById(R.id.image);
                pause = v.findViewById(R.id.pause);
                cardfont = v.findViewById(R.id.cardfont);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permissionClass.onRequestPermissionsResult(requestCode,permissions,grantResults);

    }


}

