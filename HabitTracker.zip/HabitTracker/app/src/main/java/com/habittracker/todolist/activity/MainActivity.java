package com.habittracker.todolist.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.habittracker.todolist.R;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView patternrecycleview;
    int select = 1;
    public String regular = "regular";

    TextView a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        

        ImageView Imgback = findViewById(R.id.Imgback);
        a = findViewById(R.id.a);

        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });



        ImageView cardOneTimeHabit = findViewById(R.id.cardOneTimeHabit);
        ImageView cadRepeatHabit = findViewById(R.id.cardRepeatHabit);
        ImageView nagative = findViewById(R.id.nagative);


        patternrecycleview = findViewById(R.id.patternrecycleview);
        patternrecycleview.setLayoutManager(new GridLayoutManager(this, 2));
        patternrecycleview.setHasFixedSize(true);
        patternrecycleview.setEnabled(false);

        patternrecycleview.setVisibility(View.GONE);
        a.setVisibility(View.GONE);
        ArrayList<String> equalizerPresetNames = new ArrayList<>();
        ArrayList<String> equalizerPresetNames1 = new ArrayList<>();

        int[] i2 = new int[]{R.drawable.card_0, R.drawable.card_1, R.drawable.card_2, R.drawable.card_3,
                R.drawable.card_4, R.drawable.card_5, R.drawable.card_6, R.drawable.card_7,
                R.drawable.card_8, R.drawable.card_9, R.drawable.card_10, R.drawable.card_11,
                R.drawable.card_12, R.drawable.card_13, R.drawable.card_14, R.drawable.card_15,};

        cardOneTimeHabit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                patternrecycleview.setVisibility(View.GONE);
                a.setVisibility(View.GONE);
                regular = "onetime";
                cadRepeatHabit.setImageResource(R.drawable.re_un);
                nagative.setImageResource(R.drawable.neg_un);
                cardOneTimeHabit.setImageResource(R.drawable.one_time_task);



                        Intent i = new Intent(MainActivity.this, HabitAddActivity.class);
                        i.putExtra("habit", 2);
                        i.putExtra("nagtive", regular);
                        startActivity(i);

            }
        });


        nagative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                regular = "nagative";
                patternrecycleview.setVisibility(View.VISIBLE);
                a.setVisibility(View.VISIBLE);
                cadRepeatHabit.setImageResource(R.drawable.re_un);
                nagative.setImageResource(R.drawable.negative_b);
                cardOneTimeHabit.setImageResource(R.drawable.one_un);

                patternrecycleview.setEnabled(true);

            }
        });


        cadRepeatHabit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                regular = "regular";
                patternrecycleview.setVisibility(View.VISIBLE);
                a.setVisibility(View.VISIBLE);
                cadRepeatHabit.setImageResource(R.drawable.repeat_habit);
                nagative.setImageResource(R.drawable.neg_un);
                cardOneTimeHabit.setImageResource(R.drawable.one_un);

                patternrecycleview.setEnabled(true);


            }
        });


        equalizerPresetNames.add("Trending Habit");
        equalizerPresetNames.add("Staying at home");
        equalizerPresetNames.add("Preventive Care");
        equalizerPresetNames.add("Must have habit");
        equalizerPresetNames.add("Morning routine");
        equalizerPresetNames.add("Nighttime ritual");
        equalizerPresetNames.add("Getting stuff done");
        equalizerPresetNames.add("Healthy body");
        equalizerPresetNames.add("Stress relief");
        equalizerPresetNames.add("Mindful self care ");
        equalizerPresetNames.add("Learn & Explore");
        equalizerPresetNames.add("Staying fit");
        equalizerPresetNames.add("Personal finance ");
        equalizerPresetNames.add("Loved ones");
        equalizerPresetNames.add("Around the house");
        equalizerPresetNames.add("New Year's Resolution");


        equalizerPresetNames1.add("Take a step in the right\n" +
                "direction");
        equalizerPresetNames1.add("Use this time to do \n" +
                "something new");
        equalizerPresetNames1.add("Protect yourself and \n" +
                "others");
        equalizerPresetNames1.add("Small effort, \n" +
                "big result");
        equalizerPresetNames1.add("Get started on a\n" +
                "productive day");
        equalizerPresetNames1.add("Sleep tight for\n" +
                "better health");
        equalizerPresetNames1.add("Boost your everyday\n" +
                "productivity");
        equalizerPresetNames1.add("The foundation of your\n" +
                "well-being");
        equalizerPresetNames1.add("Release tension and\n" +
                "increase calm");
        equalizerPresetNames1.add("Take care with daily\n" +
                "activities");
        equalizerPresetNames1.add("Expand your\n" +
                "knowledge");
        equalizerPresetNames1.add("Feel strong and increase\n" +
                "energy");
        equalizerPresetNames1.add("Take control of your\n" +
                "budget ");
        equalizerPresetNames1.add("Nurture important\n" +
                "relationships");
        equalizerPresetNames1.add("Clean your space and\n" +
                "your mind");
        equalizerPresetNames1.add("New habit’s\n" + "new you");

        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(MainActivity.this, i2, equalizerPresetNames, equalizerPresetNames1, 1);
        patternrecycleview.setAdapter(emojiadapter);
        emojiadapter.notifyDataSetChanged();
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    public class SnapRecyclerAdapter1 extends RecyclerView.Adapter<SnapRecyclerAdapter1.ReyclerViewHolder> {
        int type = 1;
        private LayoutInflater layoutInflater;
        private int[] items = new int[]{};
        private ArrayList<String> a = new ArrayList<String>();
        private ArrayList<String> decription1 = new ArrayList<String>();
        private int data = -1;

        public SnapRecyclerAdapter1(Context context, int[] items, ArrayList<String> equalizerPresetNames, ArrayList<String> decription, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            a = equalizerPresetNames;
            decription1 = decription;
            this.items = items;
            this.type = type;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.adp_allhabit, parent, false);
            return new ReyclerViewHolder(item);
        }


        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            holder.Imgsticker.setImageResource(this.items[position]);
            holder.a.setText(a.get(position).toString());
            holder.p.setText(decription1.get(position).toString());

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                            Intent i = new Intent(MainActivity.this, AllHabitActivity.class);
                            i.putExtra("name", a.get(position).toString());
                            i.putExtra("position", position);
                            i.putExtra("nagtive", regular);
                            startActivity(i);
                }
            });
        }

        @Override
        public int getItemCount() {
            return items.length;
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {
            private ImageView Imgsticker;

            private TextView a;
            private TextView p;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (ImageView) v.findViewById(R.id.image);
                a = (TextView) v.findViewById(R.id.a);
                p = (TextView) v.findViewById(R.id.p);
            }
        }
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();

    }
}


