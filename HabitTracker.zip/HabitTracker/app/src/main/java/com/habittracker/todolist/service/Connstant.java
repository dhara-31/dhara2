package com.habittracker.todolist.service;

public class Connstant {

    public static  long value = 0 ;
    public static  Integer id = 0 ;
    public static Boolean scroll= false ;
}
