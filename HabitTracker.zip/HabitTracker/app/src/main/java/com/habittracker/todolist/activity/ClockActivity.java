package com.habittracker.todolist.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.widget.ImageViewCompat;
import com.habittracker.todolist.R;

import com.shawnlin.numberpicker.NumberPicker;
import com.habittracker.todolist.service.Connstant;
import com.habittracker.todolist.service.DBHelper;

public class ClockActivity extends AppCompatActivity {

    NumberPicker number_picker;
    NumberPicker number_picker2;

    public static int h;
    public static int m;

    Storage storage;

    @SuppressLint("Range")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock);
        storage = new Storage(ClockActivity.this);

        TextView txt = findViewById(R.id.txt);

        number_picker = findViewById(R.id.number_picker);
        number_picker2 = findViewById(R.id.number_picker2);
        




        DBHelper db = new DBHelper(ClockActivity.this);
        ImageView Imgback = findViewById(R.id.Imgback);
        TextView txtdes = findViewById(R.id.txtdes);

        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        ImageView edit = findViewById(R.id.edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                        Intent i = new Intent(ClockActivity.this, SoundActivity.class);
                        i.putExtra("id", getIntent().getIntExtra("id", 0));
                        startActivity(i);
            }
        });

        Cursor rs = db.getData(getIntent().getIntExtra("id", 0));
        rs.moveToFirst();

        txt.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NAME)));
        txtdes.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_des)));
        ImageView icon = findViewById(R.id.icon);
        icon.setImageResource(Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_icon))));
        ImageView btnDone = findViewById(R.id.iv_timer_apply);


        if (rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)) != null && !TextUtils.isEmpty(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)))) {

            if (!rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)).equals("nagative")) {
                if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 0) {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 1) {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c1)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 2) {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c2)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 3) {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c3)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 4) {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c4)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 5) {
                    ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                }
            } else {
                ImageViewCompat.setImageTintList(icon, ColorStateList.valueOf(getResources().getColor(R.color.red)));
            }


        }

        number_picker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                h = number_picker.getValue();
                m = number_picker2.getValue();
                if (h == 0 && m == 0) {
                    btnDone.setEnabled(false);
                    btnDone.setImageResource(R.drawable.start_dis);
                } else {
                    btnDone.setEnabled(true);
                    btnDone.setImageResource(R.drawable.start);
                }
            }
        });

        number_picker2.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                h = number_picker.getValue();
                m = number_picker2.getValue();
                if (h == 0 && m == 0) {
                    btnDone.setEnabled(false);
                    btnDone.setImageResource(R.drawable.start_dis);
                } else {
                    btnDone.setEnabled(true);
                    btnDone.setImageResource(R.drawable.start);
                }
            }
        });

        h = number_picker.getValue();
        m = number_picker2.getValue();
        if (h == 0 && m == 0) {
            btnDone.setEnabled(false);
            btnDone.setImageResource(R.drawable.start_dis);
        } else {
            btnDone.setEnabled(true);
            btnDone.setImageResource(R.drawable.start);
        }
        btnDone.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                h = number_picker.getValue();
                m = number_picker2.getValue();
                long temp_secound = h * 60;
                long final_minute_mili = temp_secound * 1000;
                long sec = m * 1000;


                storage.saveIcon( (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_icon)))));




                if (h == 0 && m == 0) {
                } else {


                            Intent i = new Intent(ClockActivity.this, TimerActvitiy.class);
                            i.putExtra("value", final_minute_mili + sec);
                            Connstant.value = final_minute_mili + sec;
                            Connstant.id = getIntent().getIntExtra("id", 0);
                            i.putExtra("id", getIntent().getIntExtra("id", 0));
                            startActivity(i);


                }

            }
        });

    }



}
