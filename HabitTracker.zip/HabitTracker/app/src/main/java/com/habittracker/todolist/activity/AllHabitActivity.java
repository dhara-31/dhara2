package com.habittracker.todolist.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.habittracker.todolist.R;


public class AllHabitActivity extends AppCompatActivity {

    RecyclerView patternrecycleview;
    String[] i;
    String[] sub;
    int[] h;
    int positon = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allhabit);




        TextView txt = findViewById(R.id.txt);
        txt.setText(getIntent().getStringExtra("name"));
        ImageView toolbar = findViewById(R.id.toolbar);

        ImageView Imgback = findViewById(R.id.Imgback);
        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        positon = getIntent().getIntExtra("positon", 0);
        patternrecycleview = findViewById(R.id.patternrecycleview);
        patternrecycleview.setLayoutManager(new LinearLayoutManager(AllHabitActivity.this, LinearLayoutManager.VERTICAL, false));
        patternrecycleview.setHasFixedSize(true);

        switch (getIntent().getIntExtra("position", 0)) {

            case 0:
                toolbar.setBackgroundResource(R.drawable.card_0);

                this.i = new String[]{"Study online", "Learn a new language",
                        "Read", "Drink water",
                        "Morning exercise", "Brush & floss",
                        "Meditate", "Eat a healthy meal",
                        "Go for a walk", "Make the bed",
                        "Wake up early", "Sleep for 8 hours",
                        "Wash hands regularly"};


                this.sub = new String[]{"A word of new discoveries await", "Think of all the things that make you happy. Dream big!",
                        "Crack a book and broaden the mind", "Stay hydrated and flush out toxins",
                        "Charge your batteries", "Keep teeth and gums healthy", "Feel the zen",
                        "Increase energy with a balanced diet",
                        "Strengthen your body and improve your mood", "Rise, shine, and start the day off right",
                        "Add some extra hours to your day", "Your body will be grateful",
                        "The First step to illness prevention"};

                break;


            case 1:
                toolbar.setBackgroundResource(R.drawable.card_1);
                this.i = new String[]{"Study online", "Host movie marathon",
                        "Play board game", "Do a puzzle",
                        "Learn a new language", "Work out",
                        "Create a wishlist", "Do a DIY project",
                        "Write a blog post", "Video call your close ones",
                        "Learn to play an instrument",
                        "Try a new recipe", "Do karaoke"
                };


                this.sub = new String[]{"A word of new discoveries await", "May the Force be with you!",
                        "Turn off the TV and challenge everyone to play", "Puzzles are a calming way to spend time together",
                        "Think of all the things that make you happy. Dream big!", "Turn on your favorite music and get your blood pumping",
                        "Think of all the things that make you happy. Dream big!", "Cultivate your creative side",
                        "Share your new hobbies and experiences with the world", "Make time for friends and relatives you haven't seen in ages",
                        "Start your own band",
                        "Find it online or create one — delight your taste buds!", "Have an evening of laughter and joy",};
                break;

            case 2:
                toolbar.setBackgroundResource(R.drawable.card_2);
                this.i = new String[]{"Wash hands regularly", "Avoid touching your face",
                        "Practice social distancing", "Use a tissue when coughing",
                        "Disinfect high-touch surfaces", "Stay home",
                        "Take temperature daily"};

                this.sub = new String[]{"The first step to illness prevention", "Stop illness before it starts",
                        "Avoid crowds to keep safe and healthy", "Cover your cough to prevent spreading infection",
                        "Use hand sanitizer to clean frequently used surfaces", "Reduce your risk of getting sick by staying put",
                        "Keep track of daily temperatures"};
                break;

            case 3:
                toolbar.setBackgroundResource(R.drawable.card_3);
                this.i = new String[]{"Make time for myself", "Set goals",
                        "Sleep for 8 hours", "Spend time with family",
                        "Read", "Meditate",
                        "Go for a walk", "Morning exercise",
                        "Drink water", "Eat fruits and veggies"};


                this.sub = new String[]{"Stop the daily rush and tune into you", "Stay motivated and focused",
                        "Your body will be grateful", "Engage and stay connected",
                        " Crack a book and broaden the mind", "Feel the zen",
                        "Strengthen your body and improve your mood", "Charge your batteries",
                        "Stay hydrated and flush out toxins", "An essential source of nutrients and fiber",};
                break;
            case 4:
                toolbar.setBackgroundResource(R.drawable.card_4);
                this.i = new String[]{"Practice affirmations", "Practice visualization", "Wake up early",
                        "Meditate", "Make the bed",
                        "Morning exercise", "Brush floss",
                        "Drink water",
                        "Eat a healthy meal"};

                this.sub = new String[]{"Positive thinking can transform your entire life", "Use the power of your subconscious mind",
                        "Add some extra hours to your day", "Feel the zen", "Rise, shine, and start the day off right",
                        "Charge your batteries", "Keep teeth and gums healthy",
                        "Stay hydrated and flush out toxins", "Increase energy with a balanced diet",
                };
                break;

            case 5:
                toolbar.setBackgroundResource(R.drawable.card_5);
                this.i = new String[]{"Gain perspective and set priorities", "Turn off gadgets and devices",
                        "Your body will be grateful", "Feel refreshed in the morning",
                        "Look back at your day and reflect", "Crack a book and broaden the mind",
                        "Feel the zen", "Strengthen your body and improve your mood",
                        "Try caffeine-free instead", "Stay hydrated and flush out toxins",};

                this.sub = new String[]{"Reflect on the day", "Block distractions",
                        "Sleep for 8 hours", "Go to sleep by 11pm",
                        "Write in my journal", "Read ",
                        "Meditate", "Go for a walk",
                        "Limit caffeine", "Drink water"};

                break;

            case 6:
                toolbar.setBackgroundResource(R.drawable.card_6);
                this.i = new String[]{"Set goals", "Focus on my dream",
                        "Log my time", "Block distractions",
                        "Make a list", "Wake up early",
                        "Inbox zero", "Write in my journal",
                };

                this.sub = new String[]{"Stay motivated and focused", "Think about one step at a time",
                        "Make every minute count", "Turn off gadgets and devices",
                        "Stay organized and keep everything on task", "Add some extra hours to your day",
                        "Deal with all the e-mails", "Look back at your day and reflect",
                };

                break;


            case 7:
                toolbar.setBackgroundResource(R.drawable.card_7);
                this.i = new String[]{"Limit fried food", "Fast",
                        "Limit sugar", "Cook more often",
                        "Limit caffeine", " Take vitamins",
                        "Drink water", "Eat fruits and veggies",
                        "Eat a healthy meal"
                };

                this.sub = new String[]{"Opt for baked rather than fried", "Cleanse your body and mind",
                        "Replace candy with fruit", "Whip up a favorite recipe",
                        "Try caffeine - free instead", "Get a immune system",
                        "Stay hydrated and flush out toxins", "An essential source of nutrients and fiber",
                        "Increase energy with a balanced diet"
                };

                break;


            case 8:
                toolbar.setBackgroundResource(R.drawable.card_8);
                this.i = new String[]{"Practice deep breathing", "Enjoy the sunrise",
                        "Practice visualization", "Sit and think",
                        "Block distractions", "Sleep for 8 hours",
                        "Get outdoors", "Write in my journal",
                        "Read ", "Meditate",
                        "Go for a walk", "Limit caffeine",
                };

                this.sub = new String[]{"Calm and strengthen your mind", "Set your mind to the natural rhythm",
                        "Use the power of your subconscious mind", "A relaxed mind is a creative mind",
                        "Turn off gadgets and devices", "Your body will be grateful",
                        "Take a deep breath of fresh air", "Look back at your day and reflect",
                        "Crack a book and broaden the mind", "Feel the zen",
                        "Strengthen your body and improve your mood", "Try caffeine-free instead",
                };
                break;


            case 9:
                toolbar.setBackgroundResource(R.drawable.card_9);
                this.i = new String[]{"Practice deep breathing", "Make time for myself",
                        "Connect with nature", "Practice affirmations",
                        "Practice visualization", "Focus on my dream",
                        "Pause to be grateful", "Reflect on the day",
                        "Write anything", "Have fun",
                        "Sit and think", "Volunteer",
                        "Get outdoors", "Paint or draw",
                        "Meditate", "Practice yoga"
                };


                this.sub = new String[]{"Calm and strengthen your mind", "Stop the daily rush and tune into you",
                        "Slow down and take it all in", "Positive thinking can transform your entire life",
                        "Use the power of your subconscious mind", "Think about one step at a time",
                        "Treasure the good moments", "Gain perspective and set priorities",
                        "Find your own voice", "Make the most of today",
                        "A relaxed mind is a creative mind", "Make a difference",
                        "Take a deep breath of fresh air", "Feel those creative juices flow",
                        "Feel the zen", "Slow down and connect with yourself"
                };

                break;

            case 10:
                toolbar.setBackgroundResource(R.drawable.card_10);
                this.i = new String[]{
                        "Listen to podcasts", "Try something new",
                        "Reflect on the day", "Write anything",
                        "Sit and think", "Volunteer",
                        "Write in my journal", "Practice a new skill",
                        "Paint or draw", "Read"
                };

                this.sub = new String[]{
                        "Get educated and informed anytime, anywhere", "You are capable of more than you know",
                        "Gain perspective and set priorities", "Find your own voice",
                        "A relaxed mind is a creative mind", "Make a difference",
                        "Look back at your day and reflect", "You are capable of more than you know",
                        " Feel those creative juices flow", "Crack a book and broaden the mind",
                };
                break;

            case 11:
                toolbar.setBackgroundResource(R.drawable.card_11);
                this.i = new String[]{
                        "Limit sugar", "Stretch out",
                        "Practice yoga", "Go for a swim",
                        "Go for a ride", "Go for a run",
                        "Go for a walk", "Morning exercise",
                        "Hit the gym", "Check posture",
                        "Drink water", "Eat a healthy breakfast",
                };


                this.sub = new String[]{
                        "Replace candy with fruit", "Feel stronger and more flexible",
                        "Slow down and connect with yourself", "Dive in to lower stress and blood pressure",
                        "Pedal that bike to a healthier you", "Break a sweat and relieve stress",
                        "Strengthen your body and improve your mood", "Charge your batteries",
                        "Fill your body with endorphins", "Are you slouching?",
                        "Stay hydrated and flush out toxins", "It's fuel for a productive day",
                };
                break;


            case 12:
                toolbar.setBackgroundResource(R.drawable.card_12);

                this.i = new String[]{
                        "Create shopping list", "Reduce restaurant dining",
                        "Make a donation", "Plan spending",
                        "Save at least 10%", "Track expenses",
                        "It'll feel good to have it done"
                };

                this.sub = new String[]{
                        "Save time and money", "Cook something at home",
                        "Share your good fortune", "Prevent impulsive purchases",
                        "Build yourself a safety net", "Keep a balanced budget",
                        "Pay the bills"
                };


                break;

            case 13:
                toolbar.setBackgroundResource(R.drawable.card_13);
                this.i = new String[]{
                        "Cuddle", "Hug and kiss",
                        "Make a gift", "Call your parents",
                        "Meet with a friend", "Spend time with family"
                };

                this.sub = new String[]{
                        "Embrace your tender side", "Showing love and affection is easy",
                        "Be a reason someone smiles today", "One call can make their day",
                        "Build new memories", "Engage and stay connected"
                };
                break;


            case 14:
                toolbar.setBackgroundResource(R.drawable.card_14);
                this.i = new String[]{"Vacuum",
                        "Work in the garden", "Do the laundry",
                        "Tidy the house", "Take out the trash",
                        "Water plants"
                };
                this.sub = new String[]{"Clear out the dirt and dust",
                        "Lift your spirit by helping things grow", "Separate your lights and darks",
                        "Keep it sparkling", "Clear out for a fresh start", "Help them grow"
                };
                break;

            case 15:

                toolbar.setBackgroundResource(R.drawable.card_15);
                this.i = new String[]{"Find a significant other",
                        "Get a new job", "Travel more",
                        "Spend time with family", "Try something new",
                        "Meet new people", "Save at least 10%", "Make your hobby a career",
                        "Learn a new language", "Meditate", "Volunteer", "Go for a walk", "Read", "Lose weight"
                        , "Limit smoking"
                };

                this.sub = new String[]{"Share good and bad times with someone important",
                        "Change your life for the better", "Expand your horizons and world view",
                        "Engage and stay connected", "You are capable of more than you know",
                        "Grow your inner circle with meaningful connection", "Build yourself a safety net", "If you love it, " +
                        "it doesn\\'t feel like work", "Open up a world of opportunities",
                        "Feel the zen", "Make a difference", "Strengthen your body and improve your mood",
                        "Crack a book and broaden the mind", "Maintain a healthy lifestyle", "Reduce health risks"
                };
                break;

        }

        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(AllHabitActivity.this, this.i, this.sub, getIntent().getIntExtra("position", 0));
        patternrecycleview.setAdapter(emojiadapter);
        emojiadapter.notifyDataSetChanged();
    }


    public class SnapRecyclerAdapter1 extends RecyclerView.Adapter<SnapRecyclerAdapter1.ReyclerViewHolder> {
        int type = 1;
        private LayoutInflater layoutInflater;
        public String[] items = new String[]{};
        public String[] sunitem = new String[]{};
        private int data = -1;

        public SnapRecyclerAdapter1(Context context, String[] items, String[] subitem, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            this.items = items;
            this.type = type;
            this.sunitem = subitem;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.adaper_all_habit, parent, false);
            return new ReyclerViewHolder(item);
        }

        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            holder.Imgsticker.setText(this.items[position].toString());
            holder.subtext.setText(this.sunitem[position].toString());

            Integer i = getIntent().getIntExtra("position", 0);
            String v = "h" + String.valueOf(i) + "_" + position;
            String mDrawableName = v;
            int resID = getResources().getIdentifier(mDrawableName, "drawable", getPackageName());

            holder.card_imgleft.setImageResource(resID);

            holder.card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                            Intent intent = new Intent(AllHabitActivity.this, HabitAddActivity.class);
                            intent.putExtra("icon", resID);
                            intent.putExtra("name", items[position].toString());
                            intent.putExtra("des", sunitem[position].toString());
                            intent.putExtra("nagtive", getIntent().getStringExtra("nagtive"));
                            intent.putExtra("title",getIntent().getStringExtra("name"));
                            startActivity(intent);

                }
            });

        }

        @Override
        public int getItemCount() {
            return items.length;
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {

            private TextView Imgsticker;
            private TextView subtext;
            private ImageView card_imgleft;
            private RelativeLayout card;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (TextView) v.findViewById(R.id.card_text);
                subtext = (TextView) v.findViewById(R.id.sub_text);
                card_imgleft = v.findViewById(R.id.card_imgleft);
                card = v.findViewById(R.id.card);
            }
        }
    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();

    }
}

