
package com.habittracker.todolist.activity;

import static com.habittracker.todolist.activity.HomeActivity.total;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.habittracker.todolist.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.XAxis.XAxisPosition;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import com.habittracker.todolist.service.graph.DBGraph;
import com.habittracker.todolist.horizontalcalendar.utils.Utils;
import com.habittracker.todolist.other.PermissionClass;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class AnotherBarActivity extends AppCompatActivity implements OnSeekBarChangeListener {

    private BarChart chart;
    private SeekBar seekBarX, seekBarY;
    private TextView tvX, tvY;

    ArrayList<BarEntry> values = new ArrayList<>();

    LinearLayout cv_exdocments;
    private File file32;


    ArrayList<String> PermissionList = new ArrayList<>();

    PermissionClass permissionClass;

    ImageView share, btn_export;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barchart);


        


        setTitle("AnotherBarActivity");
        cv_exdocments = findViewById(R.id.cv_exdocments);

        btn_export = findViewById(R.id.btn_export);
        share = findViewById(R.id.share);


        if (Build.VERSION.SDK_INT > 32) {
            PermissionList.add(Manifest.permission.READ_MEDIA_IMAGES);
        } else {
            PermissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            PermissionList.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }


        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                locationAndContactsTask2();
            }
        });

        btn_export.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                locationAndContactsTask();
            }
        });

        ImageView Imgback = findViewById(R.id.Imgback);

        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        final Calendar defaultSelectedDate = Calendar.getInstance();
        DecimalFormat decimalFormat = new DecimalFormat("0");


        String selectedDateStr5 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();

        TextView date0 = findViewById(R.id.date);
        date0.setText(selectedDateStr5);

        DBGraph dbGraph = new DBGraph(AnotherBarActivity.this);
        String selectedDateStr9 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();

        Cursor b1 = dbGraph.getData(selectedDateStr9);


        TextView d1 = findViewById(R.id.d1);
        d1.setText(total.toString());

        TextView d2 = findViewById(R.id.d2);

        d2.setText(String.valueOf(b1.getCount()));


        TextView d3 = findViewById(R.id.d3);


        if(total!=0) {
            int remian = total - b1.getCount();
            d3.setText(decimalFormat.format(remian));
        }else {
            d3.setText(decimalFormat.format(0));
        }


        tvX = findViewById(R.id.tvXMax);
        tvY = findViewById(R.id.tvYMax);

        seekBarX = findViewById(R.id.seekBar1);
        seekBarX.setOnSeekBarChangeListener(this);

        seekBarY = findViewById(R.id.seekBar2);
        seekBarY.setOnSeekBarChangeListener(this);

        chart = findViewById(R.id.chart1);

        chart.getDescription().setEnabled(false);

        chart.setMaxVisibleValueCount(60);


        chart.setPinchZoom(false);

        chart.setDrawBarShadow(false);
        chart.setDrawGridBackground(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);


        int NUM_DAYS = 7;


        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.SUNDAY);
        calendar.set(Calendar.DAY_OF_WEEK, calendar.getFirstDayOfWeek());


        for (int i = 0; i < NUM_DAYS; i++) {

            Date date = calendar.getTime();

            String selectedDateStr1 = new SimpleDateFormat("EEE, d/MM/yyyy").format(date);


            Cursor b = dbGraph.getData(selectedDateStr1);
            int total = Utils.values.get(i);
            int val;
            if (b.getCount() != 0 && total!=0) {
                int m = (b.getCount() * 100);
                val = m / total;
            } else {
                val = 0;
            }

            values.add(new BarEntry(i, val));
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        chart.getAxisLeft().setDrawGridLines(false);
        seekBarX.setProgress(10);
        seekBarY.setProgress(100);

        chart.animateY(1500);

        chart.getLegend().setEnabled(false);
    }


    public void locationAndContactsTask() {


        permissionClass = new PermissionClass(AnotherBarActivity.this, PermissionList, true, "Permission Required..", new PermissionClass.OnPermissionAllowed() {
            @Override
            public void onPermission(boolean allowed) {

                if(allowed){

                    cv_exdocments.setDrawingCacheEnabled(true);
                    cv_exdocments.buildDrawingCache(true);
                    Bitmap lastbit = Bitmap.createBitmap(cv_exdocments.getDrawingCache());

                    getImageUri(AnotherBarActivity.this, lastbit);

                    try {
                        extportdoc(getImageUri(AnotherBarActivity.this, lastbit), 1);
                    } catch (DocumentException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }

            }
        });

    }


    public void locationAndContactsTask2() {

        permissionClass = new PermissionClass(AnotherBarActivity.this, PermissionList, true, "Permission Required..", new PermissionClass.OnPermissionAllowed() {
            @Override
            public void onPermission(boolean allowed) {

                if(allowed){

                    cv_exdocments.setDrawingCacheEnabled(true);
                    cv_exdocments.buildDrawingCache(true);
                    Bitmap lastbit = Bitmap.createBitmap(cv_exdocments.getDrawingCache());


                    getImageUri(AnotherBarActivity.this, lastbit);


                    try {


                        extportdoc(getImageUri(AnotherBarActivity.this, lastbit), 2);


                    } catch (DocumentException e) {

                        e.printStackTrace();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        permissionClass.onRequestPermissionsResult(requestCode,permissions,grantResults);

    }

    private void extportdoc(File fileinpiut, int type) throws DocumentException, IOException {

        try {
            Dialog dialog = new Dialog(AnotherBarActivity.this);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.exp);
            dialog.setCancelable(false);
            TextView txt_yes = (TextView) dialog.findViewById(R.id.yes);
            TextView r_retry = (TextView) dialog.findViewById(R.id.no);
            EditText hname = dialog.findViewById(R.id.hname);

            r_retry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (dialog != null) {
                        dialog.dismiss();
                    }
                }
            });


            txt_yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {



                    if (hname.getText().toString() != null && !TextUtils.isEmpty(hname.getText().toString().trim())) {

                        Toast.makeText(AnotherBarActivity.this,"Export Sucessfully..",Toast.LENGTH_LONG).show();
                        if (dialog != null) {
                            dialog.dismiss();
                        }

                        File folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + Environment.DIRECTORY_DOWNLOADS);
                        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + Environment.DIRECTORY_DOWNLOADS, "Habit");


                        if (!folder.exists()) {
                            folder.mkdir();
                        }

                        if (!file.exists()) {
                            file.mkdir();
                        }

                        String filename = hname.getText().toString() + ".pdf";


                        File outpath = new File(file.getAbsolutePath(), filename);


                        Document document = new Document();
                        try {
                            PdfWriter.getInstance(document, new FileOutputStream(outpath));


                        } catch (DocumentException e) {
                            e.printStackTrace();


                        } catch (FileNotFoundException e) {

                            e.printStackTrace();
                        }

                        document.open();

                        Image image = null;
                        try {
                            image = Image.getInstance(fileinpiut.getAbsolutePath());
                        } catch (BadElementException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        float scaler = ((document.getPageSize().getWidth() - document.leftMargin()
                                - document.rightMargin() - 0) / image.getWidth()) * 100;
                        image.scalePercent(scaler);
                        image.setAlignment(Image.ALIGN_CENTER | Image.ALIGN_TOP);


                        try {
                            document.add(image);
                        } catch (DocumentException e) {
                            e.printStackTrace();
                        }
                        document.close();


                        file32 = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + Environment.DIRECTORY_DOWNLOADS, "Habit");

                        for (int i = 0; i < file32.listFiles().length; i++) {

                            if (file32.listFiles()[i].getAbsolutePath().contains(".jpg")) {
                                file32.listFiles()[i].delete();

                            }

                            file32 = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + Environment.DIRECTORY_DOWNLOADS, "Habit");

                        }

                        if (type == 2) {

                            defaultOpenFile(outpath);
                        } else {


                            btn_export.setVisibility(View.INVISIBLE);

                        }


                    } else {

                        Toast.makeText(AnotherBarActivity.this, "Please Enter name", Toast.LENGTH_LONG).show();
                        return;
                    }


                }
            });

            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    private void defaultOpenFile(File file) {


        Uri uri = FileProvider.getUriForFile(AnotherBarActivity.this, getPackageName() + ".provider", file);

        String type = mimeType(file);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(type);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);

    }

    private String cachedMimeType = null;

    public String mimeType(File file) {

        if (cachedMimeType == null) {
            cachedMimeType = mimeTypeV1(file);

            if (cachedMimeType == null) {
                cachedMimeType = mimeTypeV2(file);
                if (cachedMimeType == null) {
                    cachedMimeType = "*/*";
                }
            }
        }

        return cachedMimeType;
    }

    private String mimeTypeV1(File file) {
        try {
            return URLConnection.guessContentTypeFromName(file.getAbsolutePath());
        } catch (Exception e) {
            return null;
        }
    }

    private String mimeTypeV2(File file) {
        try {
            String extension = MimeTypeMap.getFileExtensionFromUrl(file.getAbsolutePath());

            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        } catch (Exception e) {
            return null;
        }
    }

    public File getImageUri(Context context, Bitmap bitmap) {

        File folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + Environment.DIRECTORY_DOWNLOADS);
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + Environment.DIRECTORY_DOWNLOADS, "Habit");


        if (!folder.exists()) {
            folder.mkdir();
        }

        if (!file.exists()) {
            file.mkdir();
        }

        String filename = System.currentTimeMillis() + ".jpg";

        File outpath = new File(file.getAbsolutePath(), filename);

        try {
            FileOutputStream outputStream = new FileOutputStream(outpath);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            outputStream.flush();
            outputStream.close();


            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent.setData(Uri.fromFile(outpath));
            sendBroadcast(intent);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return outpath;
    }


    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        tvX.setText(String.valueOf(seekBarX.getProgress()));
        tvY.setText(String.valueOf(seekBarY.getProgress()));


        BarDataSet set1;

        if (chart.getData() != null &&
                chart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) chart.getData().getDataSetByIndex(0);
            set1.setValues(values);
            chart.getData().notifyDataChanged();
            chart.notifyDataSetChanged();
        } else {
            set1 = new BarDataSet(values, "Data Set");
            set1.setColors(ColorTemplate.VORDIPLOM_COLORS);
            set1.setDrawValues(false);

            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(set1);

            BarData data = new BarData(dataSets);
            chart.setData(data);
            chart.setFitBars(true);
        }

        chart.invalidate();
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
