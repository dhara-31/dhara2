package com.habittracker.todolist.activity;

import android.content.Context;
import android.content.SharedPreferences;

public class Storage {

    public static final String PREFRENCE_NAME = "MYPREF";

    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String key  = "Icon";
    int  defaultValue = 0;




    public Storage(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREFRENCE_NAME,Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public  void saveIcon(int Value){
        editor.putInt(key,Value);
        editor.commit();

    }

    public  int getIcon(){
        int val = sharedPreferences.getInt(key,defaultValue);

        return  val;
    }


















}
