package com.habittracker.todolist.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.todolist.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import com.habittracker.todolist.other.PermissionClass;
import com.habittracker.todolist.service.DBHelper;


import java.util.ArrayList;
import java.util.Calendar;

public class EditHabitAddActivity extends AppCompatActivity {

    private DBHelper mydb;
    EditText editTitle;
    EditText editDescription;
    private TextView mDateText, mTimeText;
    TextView daily, weekly;
    LinearLayout layoutSubMenuDaily;
    private int mYear, mMonth, mHour, mMinute, mDay;
    private String mTime;

    int[] i1, i2;
    Integer iconpos = -1;
    RecyclerView patternrecycleview;
    ImageView iconimage, colorimage;
    Integer iconid;

    String dorw;
    TextView textDayMon, textDaySat, textDaySun, textDayThi, textDayTue, textDayWed, textDayFri;

    Integer colorposition = 0;

    public static final String content ="Allow Permission to access CountDown.";
    String days = "";
    LinearLayout mprmiomg, aftrenoon, evening;
    private String morning = "";
    RelativeLayout date;
    private Integer positon = 0;
    private Integer id;

    Dialog alertDialog2;
    CalendarView calendar_view;
    BottomSheetDialog bottomSheetDialog;
    LinearLayout mor, lltitle;
    ImageView imagafter, imgmor, imgeven, back, edit;
    TextView txtmor, txtafter, txteven;

    Integer posicon = 0;

    PermissionClass permissionClass;
    private Boolean chkclok = false;

    @SuppressLint("Range")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dharaaddactivity);
        editDescription = findViewById(R.id.description);
        


        mor = findViewById(R.id.mor);
        calendar_view = findViewById(R.id.simpleCalendarView);
        back = findViewById(R.id.back);

        edit = findViewById(R.id.edit);
        lltitle = findViewById(R.id.lltitle);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTitle.setVisibility(View.VISIBLE);
                lltitle.setVisibility(View.GONE);
            }
        });


        Calendar c = Calendar.getInstance();
        mor = findViewById(R.id.mor);
        Long min = c.getTime().getTime();

        calendar_view.setMinDate(min);
        mDateText = (TextView) findViewById(R.id.set_date);


        String nam1 = HomeActivity.datastring;
        String date2 = nam1;
        String parts2[] = date2.split("/");


        if (parts2.length != 0) {


            int day = Integer.parseInt(parts2[0]);
            int month = Integer.parseInt(parts2[1]);
            int year = Integer.parseInt(parts2[2]);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month - 1);
            calendar.set(Calendar.DAY_OF_MONTH, day);

            long milliTime = calendar.getTimeInMillis();
            calendar_view.setDate(milliTime);
        }

        calendar_view.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view,
                                            int year,
                                            int month,
                                            int dayOfMonth) {
                String Date;
                if (month < 10) {
                    Date = dayOfMonth + "/" + "0" + (month + 1) + "/" + year;
                } else {
                    Date = dayOfMonth + "/" + (month + 1) + "/" + year;
                }
                mDateText.setText(Date);
            }
        });


        this.textDayMon = (TextView) findViewById(R.id.textDayMon);
        this.textDayTue = (TextView) findViewById(R.id.textDayTue);
        this.textDayWed = (TextView) findViewById(R.id.textDayWed);
        this.textDayThi = (TextView) findViewById(R.id.textDayThi);
        this.textDayFri = (TextView) findViewById(R.id.textDayFri);
        this.textDaySat = (TextView) findViewById(R.id.textDaySat);
        this.textDaySun = (TextView) findViewById(R.id.textDaySun);
        imagafter = findViewById(R.id.imagafter);
        imgmor = findViewById(R.id.imgmor);
        imgeven = findViewById(R.id.imgeven);

        txtafter = findViewById(R.id.txtafter);
        txtmor = findViewById(R.id.txtmor);
        txteven = findViewById(R.id.txteven);


        iconimage = findViewById(R.id.iconimage);

        i1 = new int[]{R.drawable.l_1, R.drawable.l_2, R.drawable.l_3, R.drawable.l_4,
                R.drawable.l_5, R.drawable.l_6, R.drawable.l_7, R.drawable.l_8,
                R.drawable.l_9, R.drawable.l_10, R.drawable.l_11, R.drawable.l_12,
                R.drawable.l_13,
                R.drawable.l_14, R.drawable.l_15, R.drawable.l_16, R.drawable.l_17,
                R.drawable.l_18, R.drawable.l_19, R.drawable.l_20};

        i2 = new int[]{R.drawable.cir1, R.drawable.cir2, R.drawable.cir3, R.drawable.cir4, R.drawable.cir5, R.drawable.cir6};

        LinearLayout llicon = findViewById(R.id.llicon);

        llicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetDialog = new BottomSheetDialog(EditHabitAddActivity.this);
                bottomSheetDialog.setContentView(R.layout.dialog_add_icon);


                patternrecycleview = bottomSheetDialog.findViewById(R.id.patternrecycleview);
                patternrecycleview.setLayoutManager(new GridLayoutManager(EditHabitAddActivity.this, 5));
                patternrecycleview.setHasFixedSize(true);

                TextView t1 = bottomSheetDialog.findViewById(R.id.t1);
                TextView t2 = bottomSheetDialog.findViewById(R.id.t2);
                TextView t3 = bottomSheetDialog.findViewById(R.id.t3);
                TextView t4 = bottomSheetDialog.findViewById(R.id.t4);
                TextView t5 = bottomSheetDialog.findViewById(R.id.t5);
                TextView t6 = bottomSheetDialog.findViewById(R.id.t6);
                TextView t7 = bottomSheetDialog.findViewById(R.id.t7);
                ImageView set = bottomSheetDialog.findViewById(R.id.set);

                iconpos = -1;
                t1.setTextColor(getResources().getColor(R.color.another));
                t2.setTextColor(getResources().getColor(R.color.grey));
                t3.setTextColor(getResources().getColor(R.color.grey));
                t4.setTextColor(getResources().getColor(R.color.grey));
                t5.setTextColor(getResources().getColor(R.color.grey));
                t6.setTextColor(getResources().getColor(R.color.grey));
                t7.setTextColor(getResources().getColor(R.color.grey));

                i1 = new int[]{R.drawable.l_1, R.drawable.l_2, R.drawable.l_3, R.drawable.l_4,
                        R.drawable.l_5, R.drawable.l_6, R.drawable.l_7, R.drawable.l_8,
                        R.drawable.l_9, R.drawable.l_10, R.drawable.l_11, R.drawable.l_12,
                        R.drawable.l_13,
                        R.drawable.l_14, R.drawable.l_15, R.drawable.l_16, R.drawable.l_17,
                        R.drawable.l_18, R.drawable.l_19, R.drawable.l_20};

                SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                patternrecycleview.setAdapter(emojiadapter);
                emojiadapter.notifyDataSetChanged();


                set.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (iconpos != -1) {
                            iconid = i1[posicon];
                            iconimage.setImageResource(i1[posicon]);
                        }


                        if (bottomSheetDialog != null) {
                            bottomSheetDialog.dismiss();
                        }

                    }
                });


                t1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.another));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.l_1, R.drawable.l_2, R.drawable.l_3, R.drawable.l_4,
                                R.drawable.l_5, R.drawable.l_6, R.drawable.l_7, R.drawable.l_8,
                                R.drawable.l_9, R.drawable.l_10, R.drawable.l_11, R.drawable.l_12,
                                R.drawable.l_13,
                                R.drawable.l_14, R.drawable.l_15, R.drawable.l_16, R.drawable.l_17,
                                R.drawable.l_18, R.drawable.l_19, R.drawable.l_20};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });
                t2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.another));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));


                        i1 = new int[]{R.drawable.r_1, R.drawable.r_2, R.drawable.r_3, R.drawable.r_4,
                                R.drawable.r_5, R.drawable.r_6, R.drawable.r_7, R.drawable.r_8,
                                R.drawable.r_9, R.drawable.r_10, R.drawable.r_11, R.drawable.r_12,
                                R.drawable.r_13,
                                R.drawable.r_14, R.drawable.r_15, R.drawable.r_16, R.drawable.r_17,
                                R.drawable.r_18, R.drawable.r_19};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();
                    }
                });

                t3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.another));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.d_1, R.drawable.d_2, R.drawable.d_3, R.drawable.d_4,
                                R.drawable.d_5, R.drawable.d_6, R.drawable.d_7, R.drawable.d_8,
                                R.drawable.d_9, R.drawable.d_10, R.drawable.d_11, R.drawable.d_12,
                                R.drawable.d_13,
                                R.drawable.d_14};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });
                t4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.another));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.n_1, R.drawable.n_2, R.drawable.n_3, R.drawable.n_4,
                                R.drawable.n_5, R.drawable.n_6, R.drawable.n_7, R.drawable.n_8,
                                R.drawable.n_9, R.drawable.n_10, R.drawable.n_11, R.drawable.n_12,
                                R.drawable.n_13,
                                R.drawable.n_14, R.drawable.n_15};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.another));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.he_01, R.drawable.he_02, R.drawable.he_03, R.drawable.he_04,
                                R.drawable.he_05, R.drawable.he_06, R.drawable.he_07, R.drawable.he_08,
                                R.drawable.he_09, R.drawable.he_10, R.drawable.he_11, R.drawable.he_12,
                                R.drawable.he_13,
                                R.drawable.he_14, R.drawable.he_15, R.drawable.he_16, R.drawable.he_17, R.drawable.he_18, R.drawable.he_19, R.drawable.he_20};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.another));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.ho_01, R.drawable.ho_02, R.drawable.ho_03, R.drawable.ho_04,
                                R.drawable.ho_05, R.drawable.ho_06, R.drawable.ho_07, R.drawable.ho_08,
                                R.drawable.ho_09, R.drawable.ho_10, R.drawable.ho_11, R.drawable.ho_12,
                                R.drawable.ho_13,
                                R.drawable.ho_14, R.drawable.ho_15, R.drawable.ho_16, R.drawable.ho_17, R.drawable.ho_18, R.drawable.ho_19, R.drawable.ho_20};


                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t7.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.another));

                        i1 = new int[]{R.drawable.n_1, R.drawable.n_2, R.drawable.n_3, R.drawable.n_4,
                                R.drawable.n_5, R.drawable.n_6, R.drawable.n_7, R.drawable.n_8,
                                R.drawable.n_9, R.drawable.n_10, R.drawable.n_11, R.drawable.n_12,
                                R.drawable.n_13,
                                R.drawable.n_14, R.drawable.n_15};


                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(EditHabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                bottomSheetDialog.show();


            }
        });

        LinearLayout llcolor = findViewById(R.id.llcolor);


        this.mprmiomg = (LinearLayout) findViewById(R.id.mprmiomg);
        this.aftrenoon = (LinearLayout) findViewById(R.id.aftrenoon);
        this.evening = (LinearLayout) findViewById(R.id.evening);
        mDateText = (TextView) findViewById(R.id.set_date);
        mTimeText = (TextView) findViewById(R.id.set_time);
        editTitle = findViewById(R.id.editTitle);
        daily = findViewById(R.id.daily);
        weekly = findViewById(R.id.weekly);


        editTitle.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String str = s.toString();
                if (str.length() < 2 && str.contains(" ")) {
                    editTitle.setError("Space is not allowed");
                    editTitle.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override

            public void afterTextChanged(Editable s) {
            }
        });


        editDescription.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String str = s.toString();
                if (str.length() < 2 && str.contains(" ")) {
                    editDescription.setError("Space is not allowed");
                    editDescription.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override

            public void afterTextChanged(Editable s) {
            }
        });


        layoutSubMenuDaily = findViewById(R.id.layoutSubMenuDaily);
        colorimage = findViewById(R.id.colorimage);
        ImageView btnConfirm = findViewById(R.id.btnConfirm);
        TextView custom = findViewById(R.id.custom);
        TextView textTitle = findViewById(R.id.textTitle);
        date = findViewById(R.id.date);
        ImageView swinoti = findViewById(R.id.swi);


        id = getIntent().getIntExtra("id", 0);
        mydb = new DBHelper(this);

        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(this, this.i1, getIntent().getIntExtra("position", 0));
        emojiadapter.notifyDataSetChanged();


        SnapRecyclerAdapter2 emojiadapter2 = new SnapRecyclerAdapter2(this, this.i2, getIntent().getIntExtra("position", 0));
        emojiadapter2.notifyDataSetChanged();


        Cursor rs = mydb.getData(getIntent().getIntExtra("id", 0));
        rs.moveToFirst();
        editTitle.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NAME)).toString());
        textTitle.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_NAME)).toString());
        iconimage.setImageResource(rs.getInt(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_icon)));
        iconid = rs.getInt(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_icon));
        positon = rs.getInt(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color));
        String chkl = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_chkclock));


        if (rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)) != null && !TextUtils.isEmpty(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)))) {

            if (!rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_negatie)).equals("nagative")) {
                if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 0) {
                    ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 1) {
                    ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c1)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 2) {
                    ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c2)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 3) {
                    ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c3)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 4) {
                    ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c4)));
                } else if (Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_color))) == 5) {
                    ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                }
            } else {

                llcolor.setVisibility(View.GONE);
                ImageView line = findViewById(R.id.line);
                line.setVisibility(View.GONE);


                ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.red)));
            }
        }


        llcolor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                alertDialog2 = new Dialog(EditHabitAddActivity.this);
                alertDialog2.requestWindowFeature(Window.FEATURE_NO_TITLE);
                alertDialog2.setContentView(R.layout.dialogi);
                alertDialog2.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                alertDialog2.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
                RecyclerView patternrecycleview1 = alertDialog2.findViewById(R.id.patternrecycleview);
                patternrecycleview1.setLayoutManager(new GridLayoutManager(EditHabitAddActivity.this, 3));
                patternrecycleview1.setHasFixedSize(true);
                SnapRecyclerAdapter2 emojiadapter2 = new SnapRecyclerAdapter2(EditHabitAddActivity.this, i2, getIntent().getIntExtra("position", 0));
                patternrecycleview1.setAdapter(emojiadapter2);
                emojiadapter2.notifyDataSetChanged();
                alertDialog2.show();
            }
        });
        if (chkl.equals("true")) {
            chkclok = true;
            swinoti.setImageResource(R.drawable.son);
        } else {
            chkclok = false;
            swinoti.setImageResource(R.drawable.soff);
        }


        if (positon == 0) {
            colorimage.setImageResource(R.drawable.cir1);
        } else if (positon == 1) {
            colorimage.setImageResource(R.drawable.cir2);
        } else if (positon == 2) {
            colorimage.setImageResource(R.drawable.cir3);
        } else if (positon == 3) {
            colorimage.setImageResource(R.drawable.cir4);
        } else if (positon == 4) {
            colorimage.setImageResource(R.drawable.cir5);
        } else if (positon == 3) {
            colorimage.setImageResource(R.drawable.cir6);
        }


        swinoti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (chkclok == false) {
                    chkclok = true;
                    swinoti.setImageResource(R.drawable.son);

                } else {
                    chkclok = false;
                    swinoti.setImageResource(R.drawable.soff);
                }
            }
        });
        dorw = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_dorw));
        String dattet = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_date));
        mDateText.setText(dattet);

        if (dorw.equals("d")) {
            daily.setBackground(getResources().getDrawable(R.drawable.select));
            daily.setTextColor(getResources().getColor(R.color.white));
        } else if (dorw.equals("w")) {
            layoutSubMenuDaily.setVisibility(View.VISIBLE);
            weekly.setBackground(getResources().getDrawable(R.drawable.select));
            weekly.setTextColor(getResources().getColor(R.color.white));
        } else if (dorw.equals("c")) {
            date.setVisibility(View.VISIBLE);
            mor.setVisibility(View.GONE);
            custom.setTextColor(getResources().getColor(R.color.white));
            custom.setBackground(getResources().getDrawable(R.drawable.select));

            if (rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_dorw)).equals("c")) {

                @SuppressLint("Range")
                String nam = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_date));
                String date = nam;
                String parts[] = date.split("/");

                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]);
                int year = Integer.parseInt(parts[2]);


                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month - 1);
                calendar.set(Calendar.DAY_OF_MONTH, day);
                long milliTime = calendar.getTimeInMillis();
                calendar_view.setDate(milliTime);
                mDateText.setText(nam);
            }
        }


        morning = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_morning));
        if (morning.equals("morning")) {
            mprmiomg.setBackground(getResources().getDrawable(R.drawable.select));
            imgmor.setImageResource(R.drawable.m_fill);
            txtmor.setTextColor(getResources().getColor(R.color.white));
        } else if (morning.equals("afternoon")) {
            aftrenoon.setBackground(getResources().getDrawable(R.drawable.select));
            imagafter.setImageResource(R.drawable.a_fill);
            txtafter.setTextColor(getResources().getColor(R.color.white));
        } else if (morning.equals("evening")) {
            evening.setBackground(getResources().getDrawable(R.drawable.select));
            imgeven.setImageResource(R.drawable.e_fill);
            txteven.setTextColor(getResources().getColor(R.color.white));
        } else {
            mor.setVisibility(View.GONE);
        }

        mTime = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_time));
        mTimeText.setText(mTime);

        days = rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_days));

        editDescription.setText(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_des)));

        textDayTue.setTag("R.drawable.t_pres");
        textDayMon.setTag("R.drawable.m_press");
        textDayWed.setTag("R.drawable.w_press");
        textDayThi.setTag("R.drawable.t_pres");
        textDayFri.setTag("R.drawable.f_press");
        textDaySat.setTag("R.drawable.s_pres");
        textDaySun.setTag("R.drawable.s_pres");


        if (days.contains("Mon")) {
            textDayMon.setTextColor(getResources().getColor(R.color.white));
            textDayMon.setBackground(getDrawable(R.drawable.select));
            textDayMon.setTag("R.drawable.m");
        } else {
            textDayMon.setTextColor(getResources().getColor(R.color.grey));
            textDayMon.setBackground(null);
            textDayMon.setTag("R.drawable.m_press");
        }
        if (days.contains("Tue")) {
            textDayTue.setTextColor(getResources().getColor(R.color.white));
            textDayTue.setBackground(getDrawable(R.drawable.select));
            textDayTue.setTag("R.drawable.t");
        } else {
            textDayTue.setTextColor(getResources().getColor(R.color.grey));
            textDayTue.setBackground(null);
            textDayTue.setTag("R.drawable.t_pres");
        }
        if (days.contains("Wed")) {
            textDayWed.setTextColor(getResources().getColor(R.color.white));
            textDayWed.setBackground(getDrawable(R.drawable.select));
            textDayWed.setTag("R.drawable.w");
        } else {
            textDayWed.setTextColor(getResources().getColor(R.color.grey));
            textDayWed.setBackground(null);
            textDayWed.setTag("R.drawable.w_press");
        }
        if (days.contains("Thu")) {
            textDayThi.setTextColor(getResources().getColor(R.color.white));
            textDayThi.setBackground(getDrawable(R.drawable.select));
            textDayThi.setTag("R.drawable.t");
        } else {
            textDayThi.setTextColor(getResources().getColor(R.color.grey));
            textDayThi.setBackground(null);
            textDayThi.setTag("R.drawable.t_pres");
        }
        if (days.contains("Fri")) {
            textDayFri.setTextColor(getResources().getColor(R.color.white));
            textDayFri.setBackground(getDrawable(R.drawable.select));
            textDayFri.setTag("R.drawable.f");
        } else {
            textDayFri.setTextColor(getResources().getColor(R.color.grey));
            textDayFri.setTag("R.drawable.f_press");
            textDayFri.setBackground(null);
        }
        if (days.contains("Sat")) {
            textDaySat.setTextColor(getResources().getColor(R.color.white));
            textDaySat.setBackground(getDrawable(R.drawable.select));
            textDaySat.setTag("R.drawable.s");
        } else {
            textDaySat.setTextColor(getResources().getColor(R.color.grey));
            textDaySat.setTag("R.drawable.s_pres");
            textDaySat.setBackground(null);
        }
        if (days.contains("Sun")) {
            textDaySun.setTextColor(getResources().getColor(R.color.white));
            textDaySun.setBackground(getDrawable(R.drawable.select));
            textDaySun.setTag("R.drawable.s");
        } else {
            textDaySun.setTextColor(getResources().getColor(R.color.grey));
            textDaySun.setTag("R.drawable.s_pres");
            textDaySun.setBackground(null);
        }

        if (rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_dorw)).toString().equals("c")) {
            dorw = "c";
        }

        mprmiomg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTimeText.setText("");
                evening.setBackground(getResources().getDrawable(R.drawable.cardbg));
                aftrenoon.setBackground(getResources().getDrawable(R.drawable.cardbg));
                mprmiomg.setBackground(getResources().getDrawable(R.drawable.select));

                imgmor.setImageResource(R.drawable.m_fill);
                imgeven.setImageResource(R.drawable.e_un);
                imagafter.setImageResource(R.drawable.a_un);

                txtafter.setTextColor(getResources().getColor(R.color.grey));
                txteven.setTextColor(getResources().getColor(R.color.grey));
                txtmor.setTextColor(getResources().getColor(R.color.white));

                morning = "morning";

                mTimeText.setText("");
            }
        });

        aftrenoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTimeText.setText("");
                morning = "afternoon";
                evening.setBackground(getResources().getDrawable(R.drawable.cardbg));
                mprmiomg.setBackground(getResources().getDrawable(R.drawable.cardbg));
                aftrenoon.setBackground(getResources().getDrawable(R.drawable.select));


                imgmor.setImageResource(R.drawable.ad);
                imgeven.setImageResource(R.drawable.e_un);
                imagafter.setImageResource(R.drawable.a_fill);

                txtafter.setTextColor(getResources().getColor(R.color.white));
                txteven.setTextColor(getResources().getColor(R.color.grey));
                txtmor.setTextColor(getResources().getColor(R.color.grey));
                mTimeText.setText("");
            }
        });

        evening.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTimeText.setText("");

                morning = "evening";

                aftrenoon.setBackground(getResources().getDrawable(R.drawable.cardbg));
                mprmiomg.setBackground(getResources().getDrawable(R.drawable.cardbg));
                evening.setBackground(getResources().getDrawable(R.drawable.select));

                imgmor.setImageResource(R.drawable.ad);
                imgeven.setImageResource(R.drawable.e_fill);
                imagafter.setImageResource(R.drawable.a_un);

                txtafter.setTextColor(getResources().getColor(R.color.grey));
                txteven.setTextColor(getResources().getColor(R.color.white));
                txtmor.setTextColor(getResources().getColor(R.color.grey));
                mTimeText.setText("");
            }
        });


        daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                days = "";
                custom.setBackground(getResources().getDrawable(R.drawable.cardbg));
                weekly.setBackground(getResources().getDrawable(R.drawable.cardbg));
                daily.setBackground(getResources().getDrawable(R.drawable.select));

                custom.setTextColor(getResources().getColor(R.color.grey));
                weekly.setTextColor(getResources().getColor(R.color.grey));
                daily.setTextColor(getResources().getColor(R.color.white));

                date.setVisibility(View.GONE);
                layoutSubMenuDaily.setVisibility(View.GONE);
                dorw = "d";
                mor.setVisibility(View.VISIBLE);
            }
        });

        custom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dorw = "c";
                days = "";

                layoutSubMenuDaily.setVisibility(View.GONE);
                date.setVisibility(View.VISIBLE);

                weekly.setBackground(getResources().getDrawable(R.drawable.cardbg));
                daily.setBackground(getResources().getDrawable(R.drawable.cardbg));
                custom.setBackground(getResources().getDrawable(R.drawable.select));


                daily.setTextColor(getResources().getColor(R.color.grey));
                weekly.setTextColor(getResources().getColor(R.color.grey));
                custom.setTextColor(getResources().getColor(R.color.white));
                mor.setVisibility(View.GONE);
            }
        });

        weekly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                custom.setBackground(getResources().getDrawable(R.drawable.cardbg));
                daily.setBackground(getResources().getDrawable(R.drawable.cardbg));
                weekly.setBackground(getResources().getDrawable(R.drawable.select));


                daily.setTextColor(getResources().getColor(R.color.grey));
                custom.setTextColor(getResources().getColor(R.color.grey));
                weekly.setTextColor(getResources().getColor(R.color.white));

                layoutSubMenuDaily.setVisibility(View.VISIBLE);
                date.setVisibility(View.GONE);
                mor.setVisibility(View.VISIBLE);
                dorw = "w";
            }
        });

        textDayMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayMon.getTag().toString().equals("R.drawable.m_press")) {
                    textDayMon.setBackground(getDrawable(R.drawable.select));
                    days = days + "Mon";
                    textDayMon.setTag("R.drawable.m");
                    textDayMon.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Mon", "");
                    textDayMon.setTextColor(getResources().getColor(R.color.grey));
                    textDayMon.setBackground(null);
                    textDayMon.setTag("R.drawable.m_press");
                }
            }
        });

        textDayTue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayTue.getTag().toString().equals("R.drawable.t_pres")) {
                    textDayTue.setBackground(getDrawable(R.drawable.select));
                    days = days + "Tue";
                    textDayTue.setTag("R.drawable.t");
                    textDayTue.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Tue", "");
                    textDayTue.setTextColor(getResources().getColor(R.color.grey));
                    textDayTue.setBackground(null);
                    textDayTue.setTag("R.drawable.t_pres");
                }
            }
        });

        textDayWed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayWed.getTag().toString().equals("R.drawable.w_press")) {
                    textDayWed.setBackground(getDrawable(R.drawable.select));
                    days = days + "Wed";
                    textDayWed.setTag("R.drawable.w");
                    textDayWed.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Wed", "");
                    textDayWed.setTextColor(getResources().getColor(R.color.grey));
                    textDayWed.setBackground(null);
                    textDayWed.setTag("R.drawable.w_press");
                }
            }
        });

        textDayThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayThi.getTag().toString().equals("R.drawable.t_pres")) {
                    textDayThi.setBackground(getDrawable(R.drawable.select));
                    days = days + "Thu";
                    textDayThi.setTag("R.drawable.t");
                    textDayThi.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Thu", "");
                    textDayThi.setTextColor(getResources().getColor(R.color.grey));
                    textDayThi.setBackground(null);
                    textDayThi.setTag("R.drawable.t_pres");

                }
            }
        });


        textDayFri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayFri.getTag().toString().equals("R.drawable.f_press")) {
                    textDayFri.setBackground(getDrawable(R.drawable.select));
                    days = days + "Fri";
                    textDayFri.setTag("R.drawable.f");
                    textDayFri.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Fri", "");
                    textDayFri.setTextColor(getResources().getColor(R.color.grey));
                    textDayFri.setBackground(null);
                    textDayFri.setTag("R.drawable.f_press");

                }
            }
        });

        textDaySat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDaySat.getTag().toString().equals("R.drawable.s_pres")) {
                    textDaySat.setBackground(getDrawable(R.drawable.select));
                    days = days + "Sat";
                    textDaySat.setTag("R.drawable.s");
                    textDaySat.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Sat", "");
                    textDaySat.setTextColor(getResources().getColor(R.color.grey));
                    textDaySat.setBackground(null);
                    textDaySat.setTag("R.drawable.s_pres");
                }
            }
        });

        textDaySun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDaySun.getTag().toString().equals("R.drawable.s_pres")) {
                    textDaySun.setBackground(getDrawable(R.drawable.select));
                    days = days + "Sun";
                    textDaySun.setTag("R.drawable.s");
                    textDaySun.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Sun", "");
                    textDaySun.setTextColor(getResources().getColor(R.color.grey));
                    textDaySun.setBackground(null);
                    textDaySun.setTag("R.drawable.s_pres");
                }
            }
        });


        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String abc = "false";
                if (chkclok == false) {
                    abc = "false";
                } else {
                    abc = "true";
                }


                if (dorw.equals("c")) {
                    morning = "";
                }

                if (dorw.equals("w")) {

                    if (days.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please Select Days", Toast.LENGTH_SHORT).show();
                    } else {
                        if (editTitle.getText().toString().trim().length() != 0) {

                            if (mTimeText.getText().toString().trim().length() == 0) {
                                if (mydb.updateContact(id, editTitle.getText().toString(), editDescription.getText().toString(), iconid, positon, dorw, days, morning, mDateText.getText().toString(), mTimeText.getText().toString(), abc)) {
                                    call();

                                } else {

                                }
                            } else {
                                morning = "";
                                mor.setVisibility(View.GONE);

                                if (mydb.updateContact(id, editTitle.getText().toString(), editDescription.getText().toString(), iconid, positon, dorw, days, morning, mDateText.getText().toString(), mTimeText.getText().toString(), abc)) {
                                    call();

                                } else {

                                }
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Please Enter Name", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {

                    if (editTitle.getText().toString().trim().length() != 0) {

                        if (dorw.equals("c")) {

                            if (mDateText.getText().toString() != null && mDateText.getText().toString().trim().length() != 0) {

                                if (mTimeText.getText().toString() != null && mTimeText.getText().toString().trim().length() != 0) {
                                    if (mydb.updateContact(id, editTitle.getText().toString(), editDescription.getText().toString(), iconid, positon, dorw, days, morning, mDateText.getText().toString(), mTimeText.getText().toString(), abc)) {
                                        call();
                                    } else {

                                    }
                                } else {
                                    Toast.makeText(getApplicationContext(), "Time must be Select", Toast.LENGTH_SHORT).show();

                                }
                            } else {
                                final Calendar defaultSelectedDate = Calendar.getInstance();

                                String selectedDateStr1 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();
                                String replace = selectedDateStr1.replace(',', '~');
                                String[] split = replace.split("~");
                                String abc1 = split[1].trim();

                                mDateText.setText(abc1);
                                if (mTimeText.getText().toString() != null && mTimeText.getText().toString().trim().length() != 0) {
                                    if (mydb.updateContact(id, editTitle.getText().toString(), editDescription.getText().toString(), iconid, positon, dorw, days, morning, mDateText.getText().toString(), mTimeText.getText().toString(), abc)) {
                                        call();


                                    } else {

                                    }
                                } else {
                                    Toast.makeText(getApplicationContext(), "Time must be Select", Toast.LENGTH_SHORT).show();

                                }

                            }
                        } else {

                            if (mTimeText.getText().toString().trim().length() == 0) {
                                if (mydb.updateContact(id, editTitle.getText().toString(), editDescription.getText().toString(), iconid, positon, dorw, days, morning, mDateText.getText().toString(), mTimeText.getText().toString(), abc)) {
                                    call();
                                } else {

                                }
                            } else {
                                morning = "";
                                mor.setVisibility(View.GONE);
                                if (mydb.updateContact(id, editTitle.getText().toString(), editDescription.getText().toString(), iconid, positon, dorw, days, morning, mDateText.getText().toString(), mTimeText.getText().toString(), abc)) {
                                    call();
                                } else {

                                }
                            }
                        }


                    } else {
                        Toast.makeText(getApplicationContext(), "Please Enter Name", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }


    private void call() {

                startActivity(new Intent(EditHabitAddActivity.this, HomeActivity.class));
                finish();

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    public void setTime(View v) {

        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        if (Build.VERSION.SDK_INT > 32) {
            ArrayList<String> PermissionList = new ArrayList<>();
            PermissionList.add(Manifest.permission.POST_NOTIFICATIONS);

            permissionClass = new PermissionClass(EditHabitAddActivity.this, PermissionList, true, content, new PermissionClass.OnPermissionAllowed() {
                @Override
                public void onPermission(boolean allowed) {
                    if(allowed){



                        TimePickerDialog timePickerDialog = new TimePickerDialog(EditHabitAddActivity.this,
                                new TimePickerDialog.OnTimeSetListener() {

                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                        mHour = hourOfDay;
                                        mMinute = minute;

                                        if (minute < 10) {
                                            mTime = hourOfDay + ":" + "0" + minute;
                                        } else {
                                            mTime = hourOfDay + ":" + minute;
                                        }
                                        mTimeText.setText(mTime);

                                        morning = "";

                                        imgmor.setImageResource(R.drawable.ad);
                                        imgeven.setImageResource(R.drawable.e_un);
                                        imagafter.setImageResource(R.drawable.a_un);

                                        txtafter.setTextColor(getResources().getColor(R.color.grey));
                                        txteven.setTextColor(getResources().getColor(R.color.grey));
                                        txtmor.setTextColor(getResources().getColor(R.color.grey));

                                        evening.setBackground(getResources().getDrawable(R.drawable.cardbg));
                                        aftrenoon.setBackground(getResources().getDrawable(R.drawable.cardbg));
                                        mprmiomg.setBackground(getResources().getDrawable(R.drawable.cardbg));
                                    }
                                }, mHour, mMinute, false);
                        timePickerDialog.show();
                    }
                }
            });
        }else {

            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            mHour = hourOfDay;
                            mMinute = minute;

                            if (minute < 10) {
                                mTime = hourOfDay + ":" + "0" + minute;
                            } else {
                                mTime = hourOfDay + ":" + minute;
                            }
                            mTimeText.setText(mTime);

                            morning = "";

                            imgmor.setImageResource(R.drawable.ad);
                            imgeven.setImageResource(R.drawable.e_un);
                            imagafter.setImageResource(R.drawable.a_un);

                            txtafter.setTextColor(getResources().getColor(R.color.grey));
                            txteven.setTextColor(getResources().getColor(R.color.grey));
                            txtmor.setTextColor(getResources().getColor(R.color.grey));

                            evening.setBackground(getResources().getDrawable(R.drawable.cardbg));
                            aftrenoon.setBackground(getResources().getDrawable(R.drawable.cardbg));
                            mprmiomg.setBackground(getResources().getDrawable(R.drawable.cardbg));
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();


        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permissionClass.onRequestPermissionsResult(requestCode,permissions,grantResults);

    }


    private class SnapRecyclerAdapter1 extends RecyclerView.Adapter<SnapRecyclerAdapter1.ReyclerViewHolder> {

        int type = 1;
        private LayoutInflater layoutInflater;
        private int[] items = new int[]{};
        private int data = -1;

        public SnapRecyclerAdapter1(Context context, int[] items, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            this.items = items;
            this.type = type;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.icon, parent, false);
            return new ReyclerViewHolder(item);
        }

        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            if (iconpos == position) {
                holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.select));
                ImageViewCompat.setImageTintList(holder.Imgsticker, ColorStateList.valueOf(getResources().getColor(R.color.white)));
            } else {
                holder.Imgsticker.setBackground(null);
                ImageViewCompat.setImageTintList(holder.Imgsticker, ColorStateList.valueOf(getResources().getColor(R.color.black)));
            }

            holder.Imgsticker.setImageResource(this.items[position]);

            holder.Imgsticker.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    iconpos = position;
                    posicon = position;
                    ImageViewCompat.setImageTintList(holder.Imgsticker, ColorStateList.valueOf(getResources().getColor(R.color.white)));
                    holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.select));
                    notifyDataSetChanged();

                }
            });

        }

        @Override
        public int getItemCount() {
            return items.length;
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {

            private ImageView Imgsticker;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (ImageView) v.findViewById(R.id.texview);
            }
        }
    }


    private class SnapRecyclerAdapter2 extends RecyclerView.Adapter<SnapRecyclerAdapter2.ReyclerViewHolder> {

        int type = 1;
        private LayoutInflater layoutInflater;
        private int[] items = new int[]{};
        private int data = -1;

        public SnapRecyclerAdapter2(Context context, int[] items, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            this.items = items;
            this.type = type;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.coloradp, parent, false);
            return new ReyclerViewHolder(item);
        }


        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            holder.Imgsticker.setImageResource(this.items[position]);
            holder.Imgsticker.setImageResource(this.items[position]);

            if (colorposition == position) {
                holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.cardicon));
            } else {
                holder.Imgsticker.setBackground(null);
            }

            holder.Imgsticker.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    colorposition = position;
                    positon = colorposition;
                    colorimage.setImageResource(items[position]);
                    holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.cardicon));
                    alertDialog2.cancel();
                    notifyDataSetChanged();


                    if (position == 0) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                    } else if (position == 1) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c1)));
                    } else if (position == 2) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c2)));
                    } else if (position == 3) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c3)));
                    } else if (position == 4) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c4)));
                    } else if (position == 5) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                    }
                }
            });

        }


        @Override
        public int getItemCount() {
            return items.length;
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {
            private ImageView Imgsticker;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (ImageView) v.findViewById(R.id.texview);
            }
        }
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();
        Intent i = new Intent(EditHabitAddActivity.this, HomeActivity.class);
        i.putExtra("data", getIntent().getStringExtra("data"));
        startActivity(i);

    }
}
