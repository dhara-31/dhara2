package com.habittracker.todolist.activity;

import android.app.TimePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.habittracker.todolist.R;
import com.habittracker.todolist.service.TinyDB;

import org.threeten.bp.LocalTime;

import java.util.Calendar;

public class TimeActivity extends AppCompatActivity {


    TinyDB t;
    private int mHour, mMinute;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timeractivity);

        t = new TinyDB(TimeActivity.this);


        ImageView Imgback = findViewById(R.id.Imgback);
        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        RelativeLayout time = findViewById(R.id.time);
        RelativeLayout habit = findViewById(R.id.habit);
        RelativeLayout today = findViewById(R.id.today);

        TextView morning = findViewById(R.id.morning);
        TextView afternoon = findViewById(R.id.afternoon);
        TextView evening = findViewById(R.id.evening);

        morning.setText(t.getString("morning", "5:30"));
        afternoon.setText(t.getString("afternoon", "13:15"));
        evening.setText(t.getString("evening", "18:15"));

        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(TimeActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @RequiresApi(api = Build.VERSION_CODES.O)
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                                String hourOfDay1 = "";

                                if (hourOfDay < 10) {
                                    hourOfDay1 = "0" + String.valueOf(hourOfDay);
                                } else {
                                    hourOfDay1 = String.valueOf(hourOfDay);
                                }

                                String minute1 = "";
                                if (minute < 10) {
                                    minute1 = "0" + String.valueOf(minute);
                                } else {
                                    minute1 = String.valueOf(minute);
                                 }

                                LocalTime now = null;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    now = LocalTime.parse(hourOfDay1 + ":" + minute1);
                                }

                                LocalTime limit = null;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    limit = LocalTime.parse("13:15");
                                }

                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    Boolean isLate = now.isBefore(limit);


                                    if (isLate == true) {
                                        morning.setText(hourOfDay + ":" + minute1);
                                        t.putString("morning", morning.getText().toString());
                                    } else {
                                        Toast.makeText(TimeActivity.this, "Time is not valid ", Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    morning.setText(hourOfDay + ":" + minute1);
                                    t.putString("morning", morning.getText().toString());
                                }
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();
            }
        });

        habit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);


                TimePickerDialog timePickerDialog = new TimePickerDialog(TimeActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {


                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                                String hourOfDay1 = "";

                                if (hourOfDay < 10) {
                                    hourOfDay1 = "0" + String.valueOf(hourOfDay);
                                } else {
                                    hourOfDay1 = String.valueOf(hourOfDay);
                                }

                                String minute1 = "";
                                if (minute < 10) {

                                    minute1 = "0" + String.valueOf(minute);

                                } else {
                                    minute1 = String.valueOf(minute);
                                }


                                LocalTime now = null;

                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    now = LocalTime.parse(hourOfDay1 + ":" + minute1);
                                }
                                LocalTime limit = null;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    limit = LocalTime.parse("18:15");
                                }

                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    Boolean isLate = now.isBefore(limit);

                                    if (isLate == true) {
                                        afternoon.setText(hourOfDay + ":" + minute1);
                                        t.putString("afternoon", afternoon.getText().toString());
                                    } else {
                                        Toast.makeText(TimeActivity.this, "Time is not valid ", Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    afternoon.setText(hourOfDay + ":" + minute1);
                                    t.putString("afternoon", afternoon.getText().toString());
                                }

                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();

            }
        });

        today.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR_OF_DAY);
                mMinute = c.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(TimeActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                String hourOfDay1 = "";

                                if (hourOfDay < 10) {
                                    hourOfDay1 = "0" + String.valueOf(hourOfDay);

                                } else {
                                    hourOfDay1 = String.valueOf(hourOfDay);
                                }


                                String minute1 = "";
                                if (minute < 10) {
                                    minute1 = "0" + String.valueOf(minute);

                                } else {
                                    minute1 = String.valueOf(minute);
                                }

                                LocalTime now = null;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    now = LocalTime.parse(hourOfDay1 + ":" + minute1);
                                }
                                LocalTime limit = null;
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    limit = LocalTime.parse("16:00");
                                }


                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    Boolean isLate = now.isAfter(limit);

                                    if (isLate == true) {
                                        evening.setText(hourOfDay + ":" + minute1);
                                        t.putString("evening", evening.getText().toString());

                                    } else {
                                        Toast.makeText(TimeActivity.this, "Time is not valid ", Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    evening.setText(hourOfDay + ":" + minute1);
                                    t.putString("evening", evening.getText().toString());
                                }

                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();

            }

        });
    }

    @Override
    protected void onResume() {
        super.onResume();

    }


    @Override
    public void onBackPressed() {

        finish();

    }
}
