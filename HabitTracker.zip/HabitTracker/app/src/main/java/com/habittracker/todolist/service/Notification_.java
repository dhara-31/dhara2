package com.habittracker.todolist.service;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.habittracker.todolist.R;
import com.habittracker.todolist.activity.HomeActivity;

import java.io.IOException;

public class Notification_ extends ContextWrapper {
    private static final String channelID = "channelID";
    private static final String channelName = "channel Name";

    private NotificationManager notificationManager;
    private String name;

    Integer icons;

    public Notification_(Context base, String namer, Integer icon) {
        super(base);
        name = namer;
        icons =icon;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createchannel();
        }

        Uri path = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.s1);

        Uri myUri = Uri.parse(String.valueOf(path));
        MediaPlayer mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(base, myUri);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mediaPlayer.start();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mediaPlayer.stop();
            }
        }, 2000);

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createchannel() {
        NotificationChannel channel = new NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH);
        getManager().createNotificationChannel(channel);
    }

    public NotificationManager getManager() {
        if (notificationManager == null) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return notificationManager;
    }

    public NotificationCompat.Builder getchannel() {
        Intent notificationIntent = new Intent(getApplicationContext(), HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent contentIntent = PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);


        return new NotificationCompat.Builder(getApplicationContext(), channelID).setContentTitle("Alarm..").setContentTitle(name + " Reminder").setContentIntent(contentIntent).setAutoCancel(true).setSmallIcon(icons);
    }
}