package com.habittracker.todolist.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.todolist.R;

import com.habittracker.todolist.service.Alarm;
import com.habittracker.todolist.service.DBHelper;

import java.util.ArrayList;

public class MAEPartActivity extends AppCompatActivity {

    RecyclerView patternrecycleview;
    SnapRecyclerAdapter1 emojiadapter;
    public ArrayList<Alarm> alarmArrayList = new ArrayList<>();
    TextView noitem;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maepartactivity);
        

        ImageView Imgback = findViewById(R.id.Imgback);
        Imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });



        noitem = findViewById(R.id.noitem);

        DBHelper db = new DBHelper(MAEPartActivity.this);

        alarmArrayList = db.getAllCotacts();

        ImageView time = findViewById(R.id.time);
        ImageView onetime = findViewById(R.id.onetime);
        ImageView nagative = findViewById(R.id.negaive);


        ArrayList<Alarm> abc = new ArrayList<>();

        for (Alarm flag : alarmArrayList) {
            if (flag.getDorw() != null) {
                if (flag.getDorw().equals("d")) {
                    abc.add(flag);
                }
            }
        }

        if (abc.size() == 0) {
            patternrecycleview = findViewById(R.id.patternrecycleview);
            noitem.setVisibility(View.VISIBLE);
            patternrecycleview.setVisibility(View.GONE);

        } else {
            patternrecycleview = findViewById(R.id.patternrecycleview);
            patternrecycleview.setLayoutManager(new LinearLayoutManager(MAEPartActivity.this, LinearLayoutManager.VERTICAL, false));
            patternrecycleview.setHasFixedSize(true);
            emojiadapter = new SnapRecyclerAdapter1(MAEPartActivity.this, abc, 1);
            patternrecycleview.setAdapter(emojiadapter);
            emojiadapter.notifyDataSetChanged();

            noitem.setVisibility(View.GONE);
            patternrecycleview.setVisibility(View.VISIBLE);
        }


        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                time.setImageResource(R.drawable.regular_e1);
                onetime.setImageResource(R.drawable.one_time_d1);
                nagative.setImageResource(R.drawable.negative_d1);


                ArrayList<Alarm> abc = new ArrayList<>();
                for (Alarm flag : alarmArrayList) {
                    if (flag.getDorw() != null) {

                        if (flag.getDorw().equals("d")) {
                            abc.add(flag);
                        }
                    }


                }

                if (abc.size() == 0) {
                    noitem.setVisibility(View.VISIBLE);
                    patternrecycleview = findViewById(R.id.patternrecycleview);
                    patternrecycleview.setVisibility(View.GONE);
                } else {
                    patternrecycleview = findViewById(R.id.patternrecycleview);
                    patternrecycleview.setLayoutManager(new LinearLayoutManager(MAEPartActivity.this, LinearLayoutManager.VERTICAL, false));
                    patternrecycleview.setHasFixedSize(true);
                    emojiadapter = new SnapRecyclerAdapter1(MAEPartActivity.this, abc, 1);
                    patternrecycleview.setAdapter(emojiadapter);
                    emojiadapter.notifyDataSetChanged();
                    noitem.setVisibility(View.GONE);
                    patternrecycleview.setVisibility(View.VISIBLE);
                }

            }
        });


        nagative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                time.setImageResource(R.drawable.regualr_d1);
                onetime.setImageResource(R.drawable.one_time_d1);
                nagative.setImageResource(R.drawable.negative_e1);
                ArrayList<Alarm> abc = new ArrayList<>();
                for (Alarm flag : alarmArrayList) {

                    if (flag.getDorw() != null) {

                        if (flag.getDorw().equals("c")) {
                            abc.add(flag);
                        }
                    }


                }

                if (abc.size() == 0) {
                    noitem.setVisibility(View.VISIBLE);
                    patternrecycleview = findViewById(R.id.patternrecycleview);
                    patternrecycleview.setVisibility(View.GONE);
                } else {
                    patternrecycleview = findViewById(R.id.patternrecycleview);
                    patternrecycleview.setLayoutManager(new LinearLayoutManager(MAEPartActivity.this, LinearLayoutManager.VERTICAL, false));
                    patternrecycleview.setHasFixedSize(true);
                    emojiadapter = new SnapRecyclerAdapter1(MAEPartActivity.this, abc, 1);
                    patternrecycleview.setAdapter(emojiadapter);
                    emojiadapter.notifyDataSetChanged();
                    noitem.setVisibility(View.GONE);
                    patternrecycleview.setVisibility(View.VISIBLE);
                }

            }
        });
        onetime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                time.setImageResource(R.drawable.regualr_d1);
                onetime.setImageResource(R.drawable.one_time_e1);
                nagative.setImageResource(R.drawable.negative_d1);


                ArrayList<Alarm> abc = new ArrayList<>();

                for (Alarm flag : alarmArrayList) {
                    if (flag.getDorw() != null) {
                        if (flag.getDorw().equals("w")) {
                            abc.add(flag);
                        }
                    }
                }


                if (abc.size() == 0) {
                    noitem.setVisibility(View.VISIBLE);
                    patternrecycleview = findViewById(R.id.patternrecycleview);
                    patternrecycleview.setVisibility(View.GONE);
                } else {
                    patternrecycleview = findViewById(R.id.patternrecycleview);
                    patternrecycleview.setLayoutManager(new LinearLayoutManager(MAEPartActivity.this, LinearLayoutManager.VERTICAL, false));
                    patternrecycleview.setHasFixedSize(true);
                    emojiadapter = new SnapRecyclerAdapter1(MAEPartActivity.this, abc, 1);
                    patternrecycleview.setAdapter(emojiadapter);
                    emojiadapter.notifyDataSetChanged();
                    noitem.setVisibility(View.GONE);
                    patternrecycleview.setVisibility(View.VISIBLE);

                }
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


    private class SnapRecyclerAdapter1 extends RecyclerView.Adapter<SnapRecyclerAdapter1.ReyclerViewHolder> {
        int type = 1;
        private LayoutInflater layoutInflater;
        private ArrayList<Alarm> items = new ArrayList<>();
        private int data = -1;


        public SnapRecyclerAdapter1(Context context, ArrayList<Alarm> items, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            this.items = items;
            this.type = type;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.eq1, parent, false);
            return new ReyclerViewHolder(item);
        }

        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            holder.Imgsticker.setText(this.items.get(position).getAlarm_Name());

            holder.texview1.setText(this.items.get(position).getDescription());


            if (items.get(position).getNagtive() != null && !TextUtils.isEmpty(items.get(position).getNagtive())) {
                if (!items.get(position).getNagtive().equals("nagative")) {
                    if (items.get(position).getColorname() == 0) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                    } else if (items.get(position).getColorname() == 1) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c1)));

                    } else if (items.get(position).getColorname() == 2) {

                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c2)));

                    } else if (items.get(position).getColorname() == 3) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c3)));

                    } else if (items.get(position).getColorname() == 4) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c4)));

                    } else if (items.get(position).getColorname() == 5) {
                        ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                    }

                } else {
                    holder.Imgsticker.setTextColor(getResources().getColor(R.color.red));
                    ImageViewCompat.setImageTintList(holder.image, ColorStateList.valueOf(getResources().getColor(R.color.red)));
                }
            }

            holder.image.setImageResource(this.items.get(position).getIcon());
            holder.Imgsticker.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {

            private TextView Imgsticker, texview1;
            private ImageView image;
            private TextView pause;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (TextView) v.findViewById(R.id.texview);
                image = v.findViewById(R.id.image);
                pause = v.findViewById(R.id.pause);
                texview1 = v.findViewById(R.id.texview1);
            }
        }
    }
}
