package com.habittracker.todolist.horizontalcalendar.adapter;

import android.annotation.SuppressLint;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.View;

import com.habittracker.todolist.habitcomon.DAppHAbitlication;
import com.habittracker.todolist.service.Connstant;
import com.habittracker.todolist.R;
import com.habittracker.todolist.activity.HomeActivity;
import com.habittracker.todolist.horizontalcalendar.HorizontalCalendar;
import com.habittracker.todolist.horizontalcalendar.model.HorizontalCalendarConfig;
import com.habittracker.todolist.horizontalcalendar.utils.CalendarEventsPredicate;
import com.habittracker.todolist.horizontalcalendar.utils.HorizontalCalendarPredicate;
import com.habittracker.todolist.horizontalcalendar.utils.Utils;

import java.util.Calendar;
import java.util.List;


public class DaysAdapter extends HorizontalCalendarBaseAdapter<DateViewHolder, Calendar> {


    public static int pos = -1;
    public int before = 0;

    public DaysAdapter(HorizontalCalendar horizontalCalendar, Calendar startDate, Calendar endDate, HorizontalCalendarPredicate disablePredicate, CalendarEventsPredicate eventsPredicate) {
        super(R.layout.hc_item_calendar, horizontalCalendar, startDate, endDate, disablePredicate, eventsPredicate);
        pos = -1;
    }

    @Override
    protected DateViewHolder createViewHolder(View itemView, int cellWidth) {
        final DateViewHolder holder = new DateViewHolder(itemView);
        holder.layoutContent.setMinimumWidth(cellWidth);

        return holder;
    }

    @Override
    public void onBindViewHolder(DateViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Calendar day = getItem(position);
        HorizontalCalendarConfig config = horizontalCalendar.getConfig();

        final Calendar defaultSelectedDate = Calendar.getInstance();
        String selectedDateStr1 = DateFormat.format("d/MM/yyyy", defaultSelectedDate).toString();
        String selectedDateStr2 = DateFormat.format("d/MMMM/yyyy", day).toString();
        String[] split2 = selectedDateStr2.split("/");
        String moth = split2[1].trim();


        if (HomeActivity.homeActivity != null) {
                HomeActivity.homeActivity.month.setText(moth);
           }


        if (selectedDateStr1.equals(DateFormat.format("d/MM/yyyy", day))) {
            holder.layoutContent.setBackground(DAppHAbitlication.getInstance().getResources().getDrawable(R.drawable.select));
            holder.textMiddle.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
            holder.textBottom.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
        }

        if (pos == position) {

            if (position >= before) {
                holder.layoutContent.setBackground(DAppHAbitlication.getInstance().getResources().getDrawable(R.drawable.select));
                holder.textMiddle.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                holder.textBottom.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
            } else {
                holder.layoutContent.setBackground(DAppHAbitlication.getInstance().getResources().getDrawable(R.drawable.selectano));
                holder.textMiddle.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                holder.textBottom.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
            }

        } else {

            holder.layoutContent.setBackground(null);
            holder.textMiddle.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.black));
            holder.textBottom.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.grey));


            if (pos == -1) {

                if (selectedDateStr1.equals(DateFormat.format("d/MM/yyyy", day))) {
                    before = position;
                    holder.layoutContent.setBackground(DAppHAbitlication.getInstance().getResources().getDrawable(R.drawable.select));
                    holder.textMiddle.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                    holder.textBottom.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                }
            }
        }


        holder.layoutContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos = position;
                holder.layoutContent.setBackground(DAppHAbitlication.getInstance().getResources().getDrawable(R.drawable.select));

                holder.textBottom.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                holder.textMiddle.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                notifyDataSetChanged();


                if (position < before) {
                    holder.layoutContent.setBackground(DAppHAbitlication.getInstance().getResources().getDrawable(R.drawable.selectano));
                    holder.textBottom.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                    holder.textMiddle.setTextColor(DAppHAbitlication.getInstance().getResources().getColor(R.color.white));
                    notifyDataSetChanged();
                }


                Connstant.scroll = true;

                horizontalCalendar.getCalendarListener().onDateSelected(horizontalCalendar.getDateAt(position), position);

                String selectedDateStr = DateFormat.format("EEE, d/MM/yyyy", horizontalCalendar.getDateAt(position)).toString();
                String replace = selectedDateStr.replace(',', '~');

                String[] split = replace.split("~");
                String dateformate = split[1].trim();
                HomeActivity.datastring = dateformate;

            }
        });


        holder.textMiddle.setText(DateFormat.format(config.getFormatMiddleText(), day));


        holder.textMiddle.setTextSize(TypedValue.COMPLEX_UNIT_SP, config.getSizeMiddleText());

        if (config.isShowTopText()) {
            holder.textTop.setVisibility(View.GONE);
        } else {
            holder.textTop.setVisibility(View.GONE);
        }

        if (config.isShowBottomText()) {
            holder.textBottom.setText(DateFormat.format(config.getFormatBottomText(), day));
            holder.textBottom.setTextSize(TypedValue.COMPLEX_UNIT_SP, config.getSizeBottomText());
        } else {
            holder.textBottom.setVisibility(View.GONE);
        }

        showEvents(holder, day);
        applyStyle(holder, day, position);

    }

    @Override
    public void onBindViewHolder(DateViewHolder holder, int position, List<Object> payloads) {
        if ((payloads == null) || payloads.isEmpty()) {
            onBindViewHolder(holder, position);
            return;
        }

        Calendar date = getItem(position);
        applyStyle(holder, date, position);
    }

    @Override
    public Calendar getItem(int position) throws IndexOutOfBoundsException {
        if (position >= itemsCount) {
            throw new IndexOutOfBoundsException();
        }

        int daysDiff = position - horizontalCalendar.getShiftCells();

        Calendar calendar = (Calendar) startDate.clone();
        calendar.add(Calendar.DATE, daysDiff);

        return calendar;
    }

    @Override
    protected int calculateItemsCount(Calendar startDate, Calendar endDate) {
        int days = Utils.daysBetween(startDate, endDate) + 1;
        return days + (horizontalCalendar.getShiftCells() * 2);
    }
}
