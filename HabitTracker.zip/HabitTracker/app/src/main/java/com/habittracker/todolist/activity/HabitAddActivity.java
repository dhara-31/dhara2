package com.habittracker.todolist.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.habittracker.todolist.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import com.habittracker.todolist.other.PermissionClass;
import com.habittracker.todolist.service.DBHelper;


import java.util.ArrayList;
import java.util.Calendar;

public class HabitAddActivity extends AppCompatActivity {

    private DBHelper mydb;
    EditText editTitle;
    EditText editDescription;
    private TextView mDateText, mTimeText, mRepeatText, mRepeatNoText, mRepeatTypeText;
    TextView daily, weekly;
    LinearLayout layoutSubMenuDaily;
    private int mYear, mMonth, mHour, mMinute, mDay;
    private String mTime;
    private String mDate;
    int[] i1, colorArry;
    RecyclerView patternrecycleview, patternrecycleview1;
    ImageView iconimage, colorimage;
    Integer iconid;
    Integer colorposition = 0;
    Integer iconpos = -1;
    String dorw = "d";
    BottomSheetDialog bottomSheetDialog;
    TextView textDayMon, textDaySat, textDaySun, textDayThi, textDayTue, textDayWed, textDayFri;
    long mLastClickTime;
    public long CLICK_TIME_INTERVAL;
    String days = "MonTueWedThuFriSat";
    LinearLayout mprmiomg, aftrenoon, evening;
    ImageView imagafter, imgmor, imgeven;
    TextView txtmor, txtafter, txteven;
    private String morning = "morning";
    RelativeLayout date;
    Dialog  alertDialog2;
    CalendarView calendar_view;
    ImageView edit, back;
    Integer posicon = 0;
    LinearLayout mor, lltitle;
    private Boolean chkclok = false;

    PermissionClass permissionClass;
    public static final String content ="Allow Permission to access CountDown.";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dharaaddactivity);
        iconimage = findViewById(R.id.iconimage);



        calendar_view = findViewById(R.id.simpleCalendarView);
        mDateText = (TextView) findViewById(R.id.set_date);
        edit = findViewById(R.id.edit);
        lltitle = findViewById(R.id.lltitle);
        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        ImageView swinoti = findViewById(R.id.swi);
        swinoti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (chkclok == false) {
                    chkclok = true;
                    swinoti.setImageResource(R.drawable.son);

                } else {
                    chkclok = false;
                    swinoti.setImageResource(R.drawable.soff);
                }
            }
        });


        Calendar c = Calendar.getInstance();
        mor = findViewById(R.id.mor);
        Long min = c.getTime().getTime();

        calendar_view.setMinDate(min);
        String nam = HomeActivity.datastring;
        String date1 = nam;
        String parts[] = date1.split("/");


        if (parts.length != 0) {

            int day = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]);
            int year = Integer.parseInt(parts[2]);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month - 1);
            calendar.set(Calendar.DAY_OF_MONTH, day);

            long milliTime = calendar.getTimeInMillis();
            calendar_view.setDate(milliTime);
            mDateText.setText(nam);
        }

        calendar_view.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

                String Date;
                if (month < 10) {
                    Date = dayOfMonth + "/" + "0" + (month + 1) + "/" + year;
                } else {
                    Date = dayOfMonth + "/" + (month + 1) + "/" + year;
                }
                mDateText.setText(Date);

            }
        });


        this.textDayMon = (TextView) findViewById(R.id.textDayMon);
        this.textDayTue = (TextView) findViewById(R.id.textDayTue);
        this.textDayWed = (TextView) findViewById(R.id.textDayWed);
        this.textDayThi = (TextView) findViewById(R.id.textDayThi);
        this.textDayFri = (TextView) findViewById(R.id.textDayFri);
        this.textDaySat = (TextView) findViewById(R.id.textDaySat);
        this.textDaySun = (TextView) findViewById(R.id.textDaySun);


        date = findViewById(R.id.date);
        this.mprmiomg = (LinearLayout) findViewById(R.id.mprmiomg);
        this.aftrenoon = (LinearLayout) findViewById(R.id.aftrenoon);
        this.evening = (LinearLayout) findViewById(R.id.evening);

        imagafter = findViewById(R.id.imagafter);
        imgmor = findViewById(R.id.imgmor);
        imgeven = findViewById(R.id.imgeven);

        txtafter = findViewById(R.id.txtafter);
        txtmor = findViewById(R.id.txtmor);
        txteven = findViewById(R.id.txteven);


        i1 = new int[]{R.drawable.l_1, R.drawable.l_2, R.drawable.l_3, R.drawable.l_4,
                R.drawable.l_5, R.drawable.l_6, R.drawable.l_7, R.drawable.l_8,
                R.drawable.l_9, R.drawable.l_10, R.drawable.l_11, R.drawable.l_12,
                R.drawable.l_13,
                R.drawable.l_14, R.drawable.l_15, R.drawable.l_16, R.drawable.l_17,
                R.drawable.l_18, R.drawable.l_19, R.drawable.l_20};


        colorArry = new int[]{R.drawable.cir1, R.drawable.cir2, R.drawable.cir3, R.drawable.cir4, R.drawable.cir5, R.drawable.cir6};

        LinearLayout llicon = findViewById(R.id.llicon);

        llicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                bottomSheetDialog = new BottomSheetDialog(HabitAddActivity.this);
                bottomSheetDialog.setContentView(R.layout.dialog_add_icon);


                patternrecycleview = bottomSheetDialog.findViewById(R.id.patternrecycleview);
                patternrecycleview.setLayoutManager(new GridLayoutManager(HabitAddActivity.this, 5));
                patternrecycleview.setHasFixedSize(true);

                i1 = new int[]{R.drawable.l_1, R.drawable.l_2, R.drawable.l_3, R.drawable.l_4,
                        R.drawable.l_5, R.drawable.l_6, R.drawable.l_7, R.drawable.l_8,
                        R.drawable.l_9, R.drawable.l_10, R.drawable.l_11, R.drawable.l_12,
                        R.drawable.l_13,
                        R.drawable.l_14, R.drawable.l_15, R.drawable.l_16, R.drawable.l_17,
                        R.drawable.l_18, R.drawable.l_19, R.drawable.l_20};

                iconpos = -1;

                SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                patternrecycleview.setAdapter(emojiadapter);
                emojiadapter.notifyDataSetChanged();

                TextView t1 = bottomSheetDialog.findViewById(R.id.t1);
                TextView t2 = bottomSheetDialog.findViewById(R.id.t2);
                TextView t3 = bottomSheetDialog.findViewById(R.id.t3);
                TextView t4 = bottomSheetDialog.findViewById(R.id.t4);
                TextView t5 = bottomSheetDialog.findViewById(R.id.t5);
                TextView t6 = bottomSheetDialog.findViewById(R.id.t6);
                TextView t7 = bottomSheetDialog.findViewById(R.id.t7);
                ImageView set = bottomSheetDialog.findViewById(R.id.set);


                set.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (iconpos != -1) {
                            iconid = i1[posicon];
                            iconimage.setImageResource(i1[posicon]);
                        }

                        if (bottomSheetDialog != null) {
                            bottomSheetDialog.dismiss();
                        }
                    }
                });


                t1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        t1.setTextColor(getResources().getColor(R.color.another));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        iconpos = -1;
                        i1 = new int[]{R.drawable.l_1, R.drawable.l_2, R.drawable.l_3, R.drawable.l_4,
                                R.drawable.l_5, R.drawable.l_6, R.drawable.l_7, R.drawable.l_8,
                                R.drawable.l_9, R.drawable.l_10, R.drawable.l_11, R.drawable.l_12,
                                R.drawable.l_13,
                                R.drawable.l_14, R.drawable.l_15, R.drawable.l_16, R.drawable.l_17,
                                R.drawable.l_18, R.drawable.l_19, R.drawable.l_20};
                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.another));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));


                        i1 = new int[]{R.drawable.r_1, R.drawable.r_2, R.drawable.r_3, R.drawable.r_4,
                                R.drawable.r_5, R.drawable.r_6, R.drawable.r_7, R.drawable.r_8,
                                R.drawable.r_9, R.drawable.r_10, R.drawable.r_11, R.drawable.r_12,
                                R.drawable.r_13,
                                R.drawable.r_14, R.drawable.r_15, R.drawable.r_16, R.drawable.r_17,
                                R.drawable.r_18, R.drawable.r_19};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();
                    }
                });

                t3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.another));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.d_1, R.drawable.d_2, R.drawable.d_3, R.drawable.d_4,
                                R.drawable.d_5, R.drawable.d_6, R.drawable.d_7, R.drawable.d_8,
                                R.drawable.d_9, R.drawable.d_10, R.drawable.d_11, R.drawable.d_12,
                                R.drawable.d_13,
                                R.drawable.d_14};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.another));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.n_1, R.drawable.n_2, R.drawable.n_3, R.drawable.n_4,
                                R.drawable.n_5, R.drawable.n_6, R.drawable.n_7, R.drawable.n_8,
                                R.drawable.n_9, R.drawable.n_10, R.drawable.n_11, R.drawable.n_12,
                                R.drawable.n_14,
                                R.drawable.n_14, R.drawable.n_15};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.another));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.he_01, R.drawable.he_02, R.drawable.he_03, R.drawable.he_04,
                                R.drawable.he_05, R.drawable.he_06, R.drawable.he_07, R.drawable.he_08,
                                R.drawable.he_09, R.drawable.he_10, R.drawable.he_11, R.drawable.he_12,
                                R.drawable.he_13,
                                R.drawable.he_14, R.drawable.he_15, R.drawable.he_16, R.drawable.he_17, R.drawable.he_18, R.drawable.he_19, R.drawable.he_20};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.another));
                        t7.setTextColor(getResources().getColor(R.color.grey));

                        i1 = new int[]{R.drawable.ho_01, R.drawable.ho_02, R.drawable.ho_03, R.drawable.ho_04,
                                R.drawable.ho_05, R.drawable.ho_06, R.drawable.ho_07, R.drawable.ho_08,
                                R.drawable.ho_09, R.drawable.ho_10, R.drawable.ho_11, R.drawable.ho_12,
                                R.drawable.ho_13,
                                R.drawable.ho_14, R.drawable.ho_15, R.drawable.ho_16, R.drawable.ho_17, R.drawable.ho_18, R.drawable.ho_19, R.drawable.ho_20};


                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });

                t7.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        iconpos = -1;
                        t1.setTextColor(getResources().getColor(R.color.grey));
                        t2.setTextColor(getResources().getColor(R.color.grey));
                        t3.setTextColor(getResources().getColor(R.color.grey));
                        t4.setTextColor(getResources().getColor(R.color.grey));
                        t5.setTextColor(getResources().getColor(R.color.grey));
                        t6.setTextColor(getResources().getColor(R.color.grey));
                        t7.setTextColor(getResources().getColor(R.color.another));

                        i1 = new int[]{R.drawable.n_1, R.drawable.n_2, R.drawable.n_3, R.drawable.n_4,
                                R.drawable.n_5, R.drawable.n_6, R.drawable.n_7, R.drawable.n_8,
                                R.drawable.n_9, R.drawable.n_10, R.drawable.n_11, R.drawable.n_12,
                                R.drawable.n_14,
                                R.drawable.n_14, R.drawable.n_15};

                        SnapRecyclerAdapter1 emojiadapter = new SnapRecyclerAdapter1(HabitAddActivity.this, i1, getIntent().getIntExtra("position", 0));
                        patternrecycleview.setAdapter(emojiadapter);
                        emojiadapter.notifyDataSetChanged();

                    }
                });
                bottomSheetDialog.show();


            }
        });


        LinearLayout llcolor = findViewById(R.id.llcolor);

        try {
            if (getIntent().getStringExtra("nagtive").equals("nagative")) {
                llcolor.setVisibility(View.GONE);
                ImageView line = findViewById(R.id.line);
                line.setVisibility(View.GONE);
            }
        } catch (Exception e) {
        }

        llcolor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                alertDialog2 = new Dialog(HabitAddActivity.this);
                alertDialog2.requestWindowFeature(Window.FEATURE_NO_TITLE);
                alertDialog2.setContentView(R.layout.dialogi);
                alertDialog2.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                alertDialog2.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
                patternrecycleview1 = alertDialog2.findViewById(R.id.patternrecycleview);
                patternrecycleview1.setLayoutManager(new GridLayoutManager(HabitAddActivity.this, 3));
                patternrecycleview1.setHasFixedSize(true);
                SnapRecyclerAdapter2 emojiadapter2 = new SnapRecyclerAdapter2(HabitAddActivity.this, colorArry, getIntent().getIntExtra("position", 0));
                patternrecycleview1.setAdapter(emojiadapter2);
                emojiadapter2.notifyDataSetChanged();
                alertDialog2.show();
            }
        });


        TextView custom = findViewById(R.id.custom);
        TextView textTitle = findViewById(R.id.textTitle);
        textTitle.setText(getIntent().getStringExtra("name"));

        mTimeText = (TextView) findViewById(R.id.set_time);
        editTitle = findViewById(R.id.editTitle);
        editDescription = findViewById(R.id.description);
        editTitle.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
                String str = s.toString();
                if (str.length() < 2 && str.contains(" ")) {
                    editTitle.setError("Space is not allowed");
                    editTitle.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override

            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }
        });


        editDescription.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
                String str = s.toString();
                if (str.length() < 2 && str.contains(" ")) {
                    editDescription.setError("Space is not allowed");
                    editDescription.setText("");
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override

            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }
        });

        daily = findViewById(R.id.daily);
        weekly = findViewById(R.id.weekly);
        layoutSubMenuDaily = findViewById(R.id.layoutSubMenuDaily);
        colorimage = findViewById(R.id.colorimage);

        iconimage.setImageResource(getIntent().getIntExtra("icon", 0));
        iconid = getIntent().getIntExtra("icon", 0);


        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTitle.setVisibility(View.VISIBLE);
                lltitle.setVisibility(View.GONE);
            }
        });

        mprmiomg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTimeText.setText("");
                evening.setBackground(getResources().getDrawable(R.drawable.cardbg));
                aftrenoon.setBackground(getResources().getDrawable(R.drawable.cardbg));
                mprmiomg.setBackground(getResources().getDrawable(R.drawable.select));

                imgmor.setImageResource(R.drawable.m_fill);
                imgeven.setImageResource(R.drawable.e_un);
                imagafter.setImageResource(R.drawable.a_un);

                txtafter.setTextColor(getResources().getColor(R.color.grey));
                txteven.setTextColor(getResources().getColor(R.color.grey));
                txtmor.setTextColor(getResources().getColor(R.color.white));

                morning = "morning";
            }
        });

        aftrenoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTimeText.setText("");
                morning = "afternoon";
                evening.setBackground(getResources().getDrawable(R.drawable.cardbg));
                mprmiomg.setBackground(getResources().getDrawable(R.drawable.cardbg));
                aftrenoon.setBackground(getResources().getDrawable(R.drawable.select));

                imgmor.setImageResource(R.drawable.ad);
                imgeven.setImageResource(R.drawable.e_un);
                imagafter.setImageResource(R.drawable.a_fill);

                txtafter.setTextColor(getResources().getColor(R.color.white));
                txteven.setTextColor(getResources().getColor(R.color.grey));
                txtmor.setTextColor(getResources().getColor(R.color.grey));

            }
        });

        evening.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTimeText.setText("");
                morning = "evening";
                aftrenoon.setBackground(getResources().getDrawable(R.drawable.cardbg));
                mprmiomg.setBackground(getResources().getDrawable(R.drawable.cardbg));
                evening.setBackground(getResources().getDrawable(R.drawable.select));

                imgmor.setImageResource(R.drawable.ad);
                imgeven.setImageResource(R.drawable.e_fill);
                imagafter.setImageResource(R.drawable.a_un);

                txtafter.setTextColor(getResources().getColor(R.color.grey));
                txteven.setTextColor(getResources().getColor(R.color.white));
                txtmor.setTextColor(getResources().getColor(R.color.grey));
            }
        });


        daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                custom.setBackground(getResources().getDrawable(R.drawable.cardbg));
                weekly.setBackground(getResources().getDrawable(R.drawable.cardbg));
                daily.setBackground(getResources().getDrawable(R.drawable.select));

                custom.setTextColor(getResources().getColor(R.color.grey));
                weekly.setTextColor(getResources().getColor(R.color.grey));
                daily.setTextColor(getResources().getColor(R.color.white));

                layoutSubMenuDaily.setVisibility(View.GONE);
                date.setVisibility(View.GONE);
                dorw = "d";
                mor.setVisibility(View.VISIBLE);
            }
        });

        custom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dorw = "c";
                layoutSubMenuDaily.setVisibility(View.GONE);
                date.setVisibility(View.VISIBLE);
                weekly.setBackground(getResources().getDrawable(R.drawable.cardbg));
                daily.setBackground(getResources().getDrawable(R.drawable.cardbg));
                custom.setBackground(getResources().getDrawable(R.drawable.select));


                daily.setTextColor(getResources().getColor(R.color.grey));
                weekly.setTextColor(getResources().getColor(R.color.grey));
                custom.setTextColor(getResources().getColor(R.color.white));

                mor.setVisibility(View.GONE);
            }
        });

        weekly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                custom.setBackground(getResources().getDrawable(R.drawable.cardbg));
                daily.setBackground(getResources().getDrawable(R.drawable.cardbg));
                weekly.setBackground(getResources().getDrawable(R.drawable.select));


                daily.setTextColor(getResources().getColor(R.color.grey));
                custom.setTextColor(getResources().getColor(R.color.grey));
                weekly.setTextColor(getResources().getColor(R.color.white));


                layoutSubMenuDaily.setVisibility(View.VISIBLE);
                date.setVisibility(View.GONE);
                dorw = "w";
                mor.setVisibility(View.VISIBLE);
            }
        });


        textDayMon.setTag("R.drawable.m");
        textDayTue.setTag("R.drawable.t");
        textDayWed.setTag("R.drawable.w");
        textDayThi.setTag("R.drawable.t");
        textDayFri.setTag("R.drawable.f");
        textDaySat.setTag("R.drawable.s");
        textDaySun.setTag("R.drawable.s_pres");

        editTitle.setText(getIntent().getStringExtra("name"));

        editDescription.setText(getIntent().getStringExtra("des"));

        if (getIntent().getIntExtra("habit", 0) == 4) {
            dorw = "d";
            editTitle.setText("Regular habit");
            int resID = getResources().getIdentifier("glass", "drawable", getPackageName());
            iconid = resID;
            iconimage.setImageResource(resID);
        }


        if (getIntent().getIntExtra("habit", 0) == 2) {
            dorw = "c";
            layoutSubMenuDaily.setVisibility(View.GONE);
            date.setVisibility(View.VISIBLE);
            mprmiomg.setVisibility(View.GONE);
            evening.setVisibility(View.GONE);
            aftrenoon.setVisibility(View.GONE);
            daily.setVisibility(View.GONE);
            daily.setVisibility(View.GONE);
            weekly.setVisibility(View.GONE);
            custom.setVisibility(View.GONE);
            editTitle.setText("One Time Task");

            int resID = getResources().getIdentifier("star", "drawable", getPackageName());
            iconid = resID;
            iconimage.setImageResource(resID);

            editTitle.setVisibility(View.VISIBLE);
            lltitle.setVisibility(View.GONE);

        } else {
            daily.setBackground(getResources().getDrawable(R.drawable.select));
            custom.setTextColor(getResources().getColor(R.color.grey));
            weekly.setTextColor(getResources().getColor(R.color.grey));
            daily.setTextColor(getResources().getColor(R.color.white));
        }


        mprmiomg.setBackground(getResources().getDrawable(R.drawable.select));
        txtmor.setTextColor(getResources().getColor(R.color.white));
        imgmor.setImageResource(R.drawable.m_fill);

        mydb = new DBHelper(this);
        ImageView btnConfirm = findViewById(R.id.btnConfirm);


        textDayMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayMon.getTag().toString().equals("R.drawable.m_press")) {
                    textDayMon.setBackground(getDrawable(R.drawable.select));
                    days = days + "Mon";
                    textDayMon.setTag("R.drawable.m");
                    textDayMon.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Mon", "");
                    textDayMon.setTextColor(getResources().getColor(R.color.grey));
                    textDayMon.setBackground(null);
                    textDayMon.setTag("R.drawable.m_press");
                }
            }
        });

        textDayTue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayTue.getTag().toString().equals("R.drawable.t_pres")) {
                    textDayTue.setBackground(getDrawable(R.drawable.select));
                    days = days + "Tue";
                    textDayTue.setTag("R.drawable.t");
                    textDayTue.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Tue", "");
                    textDayTue.setTextColor(getResources().getColor(R.color.grey));
                    textDayTue.setBackground(null);
                    textDayTue.setTag("R.drawable.t_pres");
                }
            }
        });

        textDayWed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayWed.getTag().toString().equals("R.drawable.w_press")) {
                    textDayWed.setBackground(getDrawable(R.drawable.select));
                    days = days + "Wed";
                    textDayWed.setTag("R.drawable.w");
                    textDayWed.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Wed", "");
                    textDayWed.setTextColor(getResources().getColor(R.color.grey));
                    textDayWed.setBackground(null);
                    textDayWed.setTag("R.drawable.w_press");
                }
            }
        });

        textDayThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayThi.getTag().toString().equals("R.drawable.t_pres")) {
                    textDayThi.setBackground(getDrawable(R.drawable.select));
                    days = days + "Thu";
                    textDayThi.setTag("R.drawable.t");
                    textDayThi.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Thu", "");
                    textDayThi.setTextColor(getResources().getColor(R.color.grey));
                    textDayThi.setBackground(null);
                    textDayThi.setTag("R.drawable.t_pres");
                }
            }
        });


        textDayFri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDayFri.getTag().toString().equals("R.drawable.f_press")) {
                    textDayFri.setBackground(getDrawable(R.drawable.select));
                    days = days + "Fri";
                    textDayFri.setTag("R.drawable.f");
                    textDayFri.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Fri", "");
                    textDayFri.setTextColor(getResources().getColor(R.color.grey));
                    textDayFri.setBackground(null);
                    textDayFri.setTag("R.drawable.f_press");

                }
            }
        });

        textDaySat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDaySat.getTag().toString().equals("R.drawable.s_pres")) {
                    textDaySat.setBackground(getDrawable(R.drawable.select));
                    days = days + "Sat";
                    textDaySat.setTag("R.drawable.s");
                    textDaySat.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Sat", "");
                    textDaySat.setTextColor(getResources().getColor(R.color.grey));
                    textDaySat.setBackground(null);
                    textDaySat.setTag("R.drawable.s_pres");
                }
            }
        });

        textDaySun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textDaySun.getTag().toString().equals("R.drawable.s_pres")) {
                    textDaySun.setBackground(getDrawable(R.drawable.select));
                    days = days + "Sun";
                    textDaySun.setTag("R.drawable.s");
                    textDaySun.setTextColor(getResources().getColor(R.color.white));
                } else {
                    days = days.replace("Sun", "");
                    textDaySun.setTextColor(getResources().getColor(R.color.grey));
                    textDaySun.setBackground(null);
                    textDaySun.setTag("R.drawable.s_pres");
                }
            }
        });


        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }

                if (dorw.equals("c")) {
                    morning = "";
                }

                if (dorw.equals("w")) {
                    if (days.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please Select Days", Toast.LENGTH_SHORT).show();
                    } else {
                        if (editTitle.getText().toString().trim().length() != 0) {
                            if (mTimeText.getText().toString().trim().length() == 0) {
                                callfub();
                            } else {
                                morning = "";
                                mor.setVisibility(View.GONE);
                                callfub();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Please Enter Name", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                else {
                    if (editTitle.getText().toString().trim().length() != 0) {

                        if (dorw.equals("c")) {
                            if (mDateText.getText().toString() != null && mDateText.getText().toString().trim().length() != 0) {
                                if (mTimeText.getText().toString() != null && mTimeText.getText().toString().trim().length() != 0) {
                                    callfub();
                                } else {
                                    Toast.makeText(getApplicationContext(), "Time must be Select", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                final Calendar defaultSelectedDate = Calendar.getInstance();
                                String selectedDateStr1 = DateFormat.format("EEE, d/MM/yyyy", defaultSelectedDate).toString();
                                String replace = selectedDateStr1.replace(',', '~');
                                String[] split = replace.split("~");
                                String abc1 = split[1].trim();
                                mDateText.setText(abc1);
                                if (mTimeText.getText().toString() != null && mTimeText.getText().toString().trim().length() != 0) {
                                    callfub();
                                } else {
                                    Toast.makeText(getApplicationContext(), "Time must be Select", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            if (mTimeText.getText().toString().trim().length() == 0) {
                                callfub();
                            } else {
                                morning = "";
                                mor.setVisibility(View.GONE);
                                callfub();
                            }
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Please Enter Name", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
    }


    private Boolean last = false ;

    private void callfub() {
         String abc = "false";
        if (chkclok == false) {
            abc = "false";
        } else {
            abc = "true";
        }

        if(last == false) {
            if (mydb.insertContact(editTitle.getText().toString(), editDescription.getText().toString(), iconid, colorposition, dorw, days, morning, mDateText.getText().toString(), mTimeText.getText().toString() , getIntent().getStringExtra("nagtive"), abc,getIntent().getStringExtra("title"))) {
                last = true;

                        startActivity(new Intent(HabitAddActivity.this, HomeActivity.class));
                        finish();
                        return;

            } else {

            }
        }
        mLastClickTime = System.currentTimeMillis();
        CLICK_TIME_INTERVAL = 3000;

    }


    public void setTime(View v) {


        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);


        if (Build.VERSION.SDK_INT > 32) {
            ArrayList<String> PermissionList = new ArrayList<>();
            PermissionList.add(Manifest.permission.POST_NOTIFICATIONS);

            permissionClass  =new PermissionClass(HabitAddActivity.this, PermissionList, true, content, new PermissionClass.OnPermissionAllowed() {
                @Override
                public void onPermission(boolean allowed) {
                    if(allowed){
                        setTimer();
                    }
                }
            });

        }else {

            setTimer();
        }

    }

    private void setTimer() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                        mHour = hourOfDay;
                        mMinute = minute;
                        if (minute < 10) {
                            mTime = hourOfDay + ":" + "0" + minute;
                        } else {
                            mTime = hourOfDay + ":" + minute;
                        }
                        mTimeText.setText(mTime);


                        morning = "";

                        imgmor.setImageResource(R.drawable.ad);
                        imgeven.setImageResource(R.drawable.e_un);
                        imagafter.setImageResource(R.drawable.a_un);

                        txtafter.setTextColor(getResources().getColor(R.color.grey));
                        txteven.setTextColor(getResources().getColor(R.color.grey));
                        txtmor.setTextColor(getResources().getColor(R.color.grey));

                        evening.setBackground(getResources().getDrawable(R.drawable.cardbg));
                        aftrenoon.setBackground(getResources().getDrawable(R.drawable.cardbg));
                        mprmiomg.setBackground(getResources().getDrawable(R.drawable.cardbg));

                        //  mor.setVisibility(View.GONE);
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }


    private class SnapRecyclerAdapter1 extends RecyclerView.Adapter<SnapRecyclerAdapter1.ReyclerViewHolder> {

        int type = 1;
        private LayoutInflater layoutInflater;
        private int[] items = new int[]{};
        private int data = -1;


        public SnapRecyclerAdapter1(Context context, int[] items, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            this.items = items;
            this.type = type;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.icon, parent, false);
            return new ReyclerViewHolder(item);
        }

        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            if (iconpos == position) {
                holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.select));
                ImageViewCompat.setImageTintList(holder.Imgsticker, ColorStateList.valueOf(getResources().getColor(R.color.white)));
            } else {
                holder.Imgsticker.setBackground(null);
                ImageViewCompat.setImageTintList(holder.Imgsticker, ColorStateList.valueOf(getResources().getColor(R.color.black)));
            }


            holder.Imgsticker.setImageResource(this.items[position]);
            holder.Imgsticker.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    posicon = position;
                    iconpos = position;
                    ImageViewCompat.setImageTintList(holder.Imgsticker, ColorStateList.valueOf(getResources().getColor(R.color.white)));
                    holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.select));
                    notifyDataSetChanged();
                }
            });
        }

        @Override
        public int getItemCount() {
            return items.length;
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {

            private ImageView Imgsticker;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (ImageView) v.findViewById(R.id.texview);
            }
        }
    }


    private class SnapRecyclerAdapter2 extends RecyclerView.Adapter<SnapRecyclerAdapter2.ReyclerViewHolder> {

        int type = 1;
        private LayoutInflater layoutInflater;
        private int[] items = new int[]{};
        private int data = -1;

        public SnapRecyclerAdapter2(Context context, int[] items, int type) {
            this.layoutInflater = LayoutInflater.from(context);
            this.items = items;
            this.type = type;
        }


        @Override
        public ReyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View item = layoutInflater.inflate(R.layout.coloradp, parent, false);
            return new ReyclerViewHolder(item);
        }

        @Override
        public void onBindViewHolder(final ReyclerViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            holder.Imgsticker.setImageResource(this.items[position]);

            if (colorposition == position) {
                holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.cardicon));
            } else {
                holder.Imgsticker.setBackground(null);
            }

            holder.Imgsticker.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    colorposition = position;
                    colorimage.setImageResource(items[position]);
                    holder.Imgsticker.setBackground(getResources().getDrawable(R.drawable.cardicon));
                    alertDialog2.cancel();


                    if (position == 0) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c0)));
                    } else if (position == 1) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c1)));
                    } else if (position == 2) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c2)));
                    } else if (position == 3) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c3)));
                    } else if (position == 4) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c4)));
                    } else if (position == 5) {
                        ImageViewCompat.setImageTintList(iconimage, ColorStateList.valueOf(getResources().getColor(R.color.c5)));
                    }

                    notifyDataSetChanged();


                }
            });
        }

        @Override
        public int getItemCount() {
            return items.length;
        }

        class ReyclerViewHolder extends RecyclerView.ViewHolder {
            private ImageView Imgsticker;

            private ReyclerViewHolder(final View v) {
                super(v);
                Imgsticker = (ImageView) v.findViewById(R.id.texview);
            }
        }
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        finish();

    }
}
