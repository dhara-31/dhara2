package com.habittracker.todolist.service;

import java.io.Serializable;

public class Alarm implements Serializable {

    private String alarm_Name;
    private String alarm_desci;
    private Integer icon ;
    private Integer colorname;
    private String dorw;
    private String days;
    private String morning;
    private String datee;
    private String time;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private String title;

    public String getPause() {
        return pause;
    }

    public void setPause(String pause) {
        this.pause = pause;
    }

    private String pause ;

    public String getChkclock() {
        return chkclock;
    }

    public void setChkclock(String chkclock) {
        this.chkclock = chkclock;
    }

    private String chkclock ;

    public String getNagtive() {
        return nagtive;
    }

    public void setNagtive(String nagtive) {
        this.nagtive = nagtive;
    }

    private String nagtive;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;

    public String getAlarm_Name() {
        return alarm_Name;
    }

    public void setAlarm_Name(String alarm_Name) {
        this.alarm_Name = alarm_Name;
    }



    public String getDescription() {
        return alarm_desci;
    }

    public void setDescription(String alarm_desci) {
        this.alarm_desci = alarm_desci;
    }

    public Integer getIcon() {
        return icon;
    }

    public void setIcon(Integer icon) {
        this.icon = icon;
    }

    public Integer getColorname() {
        return colorname;
    }

    public void setColorname(Integer colorname) {
        this.colorname = colorname;
    }

    public String getDorw() {
        return dorw;
    }

    public void setDorw(String dorw) {
        this.dorw = dorw;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getMorning() {
        return morning;
    }

    public void setMorning(String morning) {
        this.morning = morning;
    }

    public String getDatee() {
        return datee;
    }

    public void setDatee(String datee) {
        this.datee = datee;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}

