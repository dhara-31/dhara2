package com.habittracker.todolist.service.graph;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.habittracker.todolist.service.Alarm;

import java.util.ArrayList;
import java.util.List;

public class DBGraph extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Graph.db";
    public static final String CONTACTS_COLUMN_ID = "id";
    public static final String CONTACTS_COLUMN_NAME = "name";
    public static final String CONTACTS_des = "des";
    public static final String CONTACTS_COLUMN_icon = "icon";
    public static final String CONTACTS_COLUMN_title = "title";

    public DBGraph(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table graph " + "(id integer primary key, name text,des text,icon integer,title text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS graph");
        onCreate(db);
    }


    public boolean insertContact(int id,String name, String description, Integer phone, String title) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id",id);
        contentValues.put("name", name);
        contentValues.put("des", description);
        contentValues.put("icon", phone);
        contentValues.put("title", title);
        db. insert("graph", null, contentValues);
        return true;
    }


    @SuppressLint("Range")
    public Cursor getData(String id) {


        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + "graph" + " WHERE " + "des" + "=?", new String[]{id});
        if ((res != null) && (res.getCount() > 0)) {
        }
        return res;
    }

    public boolean updateContact(Integer id, String name, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("des", description);
        db.update("graph", contentValues, "id = ? ", new String[]{Integer.toString(id)});
        return true;
    }

    public boolean updatePause(Integer id, String pause) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("pause", pause);
        db.update("graph", contentValues, "id = ? ", new String[]{Integer.toString(id)});
        return true;
    }


    public Boolean val(String a, String b, String title) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCourses = db.rawQuery("SELECT * FROM " + "graph" + " WHERE name =? AND des =? AND  title  =?", new String[]{String.valueOf(a), String.valueOf(b), String.valueOf(title)});

        if (cursorCourses.moveToFirst()) {
            do {

                return true;


            } while (cursorCourses.moveToNext());

        }

        cursorCourses.close();

        return false;

    }

    @SuppressLint("Range")
    public Cursor val2(String a, String b, String title) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCourses = db.rawQuery("SELECT * FROM " + "graph" + " WHERE name =? AND des =? AND  title  =?", new String[]{String.valueOf(a), String.valueOf(b), String.valueOf(title)});

        if (cursorCourses.moveToFirst()) {

        }
        return cursorCourses;


    }

    public Integer deleteContact(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("graph", "id = ? ", new String[]{Integer.toString(id)});

    }

    @SuppressLint("Range")
    public ArrayList<Alarm> getAllCotacts() {
        ArrayList<Alarm> array_list = new ArrayList<Alarm>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from graph", null);

        if (res.getCount() > 0) {

            res.moveToFirst();

            while (res.isAfterLast() == false) {

                Alarm a = new Alarm();

                a.setId(res.getInt(res.getColumnIndex(CONTACTS_COLUMN_ID)));
                a.setAlarm_Name(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
                a.setDescription(res.getString(res.getColumnIndex(CONTACTS_des)));
                a.setIcon(res.getInt(res.getColumnIndex(CONTACTS_COLUMN_icon)));
                a.setTitle(res.getString(res.getColumnIndex(CONTACTS_COLUMN_title)));

                array_list.add(a);
                res.moveToNext();
            }
        }
        return array_list;
    }

    public List<Long> getAllIds() {
        List<Long> ids = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(
                "graph",
                new String[]{"id"}, // Specify the columns you want to retrieve
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                @SuppressLint("Range") long id = cursor.getLong(cursor.getColumnIndex("id"));
                ids.add(id);
                cursor.moveToNext();
            }
            cursor.close();
        }

        return ids;
    }
}
