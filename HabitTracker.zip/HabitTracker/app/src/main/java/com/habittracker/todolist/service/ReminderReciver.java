package com.habittracker.todolist.service;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.habittracker.todolist.R;
import com.habittracker.todolist.activity.HomeActivity;

import org.threeten.bp.DayOfWeek;
import org.threeten.bp.LocalDate;
import org.threeten.bp.format.TextStyle;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ReminderReciver extends BroadcastReceiver {


    public ArrayList<Alarm> alarmArrayList = new ArrayList<>();
    TinyDB t;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onReceive(Context context, Intent intent) {
        DBHelper db = new DBHelper(context);


        alarmArrayList = db.getAllCotacts();

        t = new TinyDB(context);

        String morning = t.getString("morning", "5:30");

        String afternoon = t.getString("afternoon", "13:15");

        String evening = t.getString("evening", "18:15");

        String currentDate = new SimpleDateFormat("d/MM/yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("H:mm", Locale.getDefault()).format(new Date());

        LocalDate date = LocalDate.now();

        DayOfWeek dow = date.getDayOfWeek();
      //  String dayName = dow.getDisplayName(TextStyle.SHORT, Locale.ENGLISH);


        if (alarmArrayList.size() > 0) {

            for (Alarm flag : alarmArrayList) {

                if (flag.getDorw() != null) {


                    if (flag.getPause().equals("false")) {

                        if (flag.getDorw().equals("d")) {

                            if (flag.getDatee() != null) {

                                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                Date mydate1 = null;
                                try {
                                    mydate1 = sdf.parse(flag.getDatee());
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                Date strDate = null;
                                try {
                                    strDate = sdf.parse(currentDate);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                if (mydate1.after(strDate)) {

                                } else {
                                    if (flag.getTime() != null && flag.getTime().toString().trim().length() != 0) {
                                        if (flag.getTime().equals(currentTime)) {
                                            call(context, flag);
                                        }
                                    } else {
                                        if (flag.getMorning().equals("morning")) {

                                            if (currentTime.equals(morning)) {
                                                call(context, flag);
                                            }
                                        } else if (flag.getMorning().equals("afternoon")) {

                                            if (currentTime.equals(afternoon)) {
                                                call(context, flag);
                                            }

                                        } else if (flag.getMorning().equals("evening")) {
                                            if (currentTime.equals(evening)) {
                                                call(context, flag);
                                            }
                                        }
                                    }
                                }

                            }
                        } else if (flag.getDorw().equals("c")) {

                            if (flag.getDatee().trim().equals(currentDate)) {
                                if (flag.getTime().equals(currentTime)) {

                                    call(context, flag);
                                }
                            }
                        } else if (flag.getDorw().equals("w")) {

                            if (flag.getDays() != null) {

                                if (flag.getDatee() != null) {
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                    Date mydate1 = null;
                                    try {
                                        mydate1 = sdf.parse(flag.getDatee());
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }

                                    Date strDate = null;
                                    try {
                                        strDate = sdf.parse(currentDate);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }

                                    if (mydate1.after(strDate)) {

                                    } else {
                                      //  if (flag.getDays().contains(dayName)) {

                                            if (flag.getTime().equals(currentTime)) {

                                                call(context, flag);
                                            } else {
                                                if (flag.getMorning().equals("morning")) {

                                                    if (currentTime.equals(morning)) {
                                                        call(context, flag);
                                                    }

                                                } else if (flag.getMorning().equals("afternoon")) {
                                                    if (currentTime.equals(afternoon)) {
                                                        call(context, flag);
                                                    }

                                                } else if (flag.getMorning().equals("evening")) {
                                                    if (currentTime.equals(evening)) {
                                                        call(context, flag);
                                                    }
                                                }
                                            }
                                       // }
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }


    private void call(Context context, Alarm flag) {


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            Notification_ notification_ = new Notification_(context, flag.getAlarm_Name(),flag.getIcon());
            NotificationCompat.Builder builder = notification_.getchannel();
            Intent notificationIntent = new Intent(context, HomeActivity.class);

            PendingIntent contentIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            builder.setContentIntent(contentIntent);

            notification_.getManager().notify(flag.getId(), builder.build());
        } else {
            NotificationCompat.Builder builder1 =
                    new NotificationCompat.Builder(context)
                            .setSmallIcon(R.drawable.logo_512)
                            .setContentTitle(flag.getAlarm_Name());

            Intent notificationIntent = new Intent(context, HomeActivity.class);
            PendingIntent contentIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            builder1.setContentIntent(contentIntent);
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            manager.notify(flag.getId(), builder1.build());
        }
    }

}
