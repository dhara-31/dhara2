package com.apptools.payal_mywahtrecorder.Jaylanguage;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;


public class SystemUtil {


    public static String getPreLanguage(Context context) {
        String language = "en";
        SharedPreferences sharedPreferences = context.getSharedPreferences("MY_PRE", 0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            language = Resources.getSystem().getConfiguration().getLocales().get(0).getLanguage();
            if (!getLanguageApp(context).contains(language)) {
                return sharedPreferences.getString("KEY_LANGUAGE", "en");
            }
        }
        return sharedPreferences.getString("KEY_LANGUAGE", language);
    }

    public static void setPreLanguage(Context context, String str) {
        if (str == null || str.equals("")) {
            str = "en";
        }
        context.getSharedPreferences("MY_PRE", 0).edit().putString("KEY_LANGUAGE", str).apply();
    }

    public static List<String> getLanguageApp(Context context) {
        boolean z = context.getSharedPreferences("MY_PRE", 0).getBoolean("openLanguage", false);
        ArrayList<String> arrayList = new ArrayList<>();
        if (z) {
            arrayList.add("en");
            arrayList.add("ko");
            arrayList.add("ja");
            arrayList.add("fr");
            arrayList.add("hi");
            arrayList.add("pt");
            arrayList.add("es");
            arrayList.add("in");
            arrayList.add("ms");
            arrayList.add("phi");
            arrayList.add("zh");
            arrayList.add("de");
        } else {
            arrayList.add("en");
            arrayList.add("fr");
            arrayList.add("pt");
            arrayList.add("es");
            arrayList.add("de");
        }
        return arrayList;
    }


}
