package com.apptools.payal_mywahtrecorder;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;


public class LoadingVideos {

    Context context;
    Dialog dialog;

    public LoadingVideos(Context context) {
        this.context = context;
    }

    public void showDialog(){
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.loadingvideos_dialog);

        dialog.setCancelable(false);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            dialog.create();
        }
        dialog.show();
    }

    public void hideDialog(){
        dialog.dismiss();
    }

}
