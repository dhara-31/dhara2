package com.apptools.payal_mywahtrecorder.ads;

import android.app.Activity;
import android.app.Application;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.widget.RemoteViews;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


import com.apptools.payal_mywahtrecorder.Jayutils.DatabaseUtils;
import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.google.gson.Gson;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JAydata.RecordData;
import com.apptools.payal_mywahtrecorder.Jayservice.RecordService;

public class DApplication extends Application implements Application.ActivityLifecycleCallbacks {
    private static DApplication myVcallApplication;
    //private static MyVcallApplication ourInstaviddecgtme;

    public SharedPreferences prefeviddecgtmces;

    public static DApplication getInstance() {
        return myVcallApplication;
    }

    public static final String MyPREFERENCES = "MyAdsPrefs";
    private static final String PREF_APP_DETAILS = "app_details";
    public void dg() {
        appOviddecgtmger = new AppOpenclass(this);
    }

    public static AppOpenclass appOviddecgtmger;

    public static DApplication c() {
        return myVcallApplication;
    }
    public static boolean a = false;

    public static String b = "SplashActivity";

    public Integer c = 0;

    public Integer d = 0;

    public static DApplication getMeVcallApplication() {
        return myVcallApplication;
    }


    @Override
    public void sendBroadcast(Intent intent) {
        super.sendBroadcast(intent);
        try {
            bm.sendBroadcast(intent);
        } catch (Exception e) {

        }
    }


    public static boolean statusAfterCloseIntermediate() {
        int myHelper = 1;
        try {
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelper != null && myModelHelper.getFbreward() != null && !TextUtils.isEmpty(myModelHelper.getFbreward())) {
                myHelper = Integer.valueOf(myModelHelper.getFbreward());
            }
        } catch (Exception e) {
        }
        return myHelper == 1;
    }


    public static Notification notification = null;

    public static boolean getTwoUrk() {

        if (DApplication.getMeVcallApplication() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdstatus())) {
            return true;
        } else if (!DApplication.getMeVcallApplication().getAppDetails().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else {
            if (DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner() != null && !TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner())) {
                return false;
            } else {
                return true;
            }
        }
    }

    public static RemoteViews notificationMenu = null;


    public static RemoteViews notificationMenuSmall = null;


    public static RecordService recordService = null;


    public static int screenDpi = 0;


    public static int screenHeight = 0;


    public static MediaProjection screenProjection = null;


    public static int screenWidth = 0;

    public void onCreate() {

        super.onCreate();

        context = getApplicationContext();

        myVcallApplication = this;


     //  AdSettings.setTestMode(true);

        try {
            preferenceMineData = getApplicationContext().getSharedPreferences("MyAdsPrefs", MODE_PRIVATE);
        } catch (Exception e) {

        }


        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().build());


        AudienceNetworkAds.initialize(this);

        if (!AudienceNetworkAds.isInitialized(this)) {

            AudienceNetworkAds.buildInitSettings(this).withInitListener(new AudienceNetworkAds.InitListener() {
                @Override
                public void onInitialized(AudienceNetworkAds.InitResult initResult) {

                }
            }).initialize();
        }


        DatabaseUtils.getInstance();
        bm = LocalBroadcastManager.getInstance(this);
        try {
            sP = getSharedPreferences("easyrecorder", 0);
        } catch (Exception e) {

        }


    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
        try {
            if (activity != null && !activity.toString().contains("SplashActivity")) {
                if (appOviddecgtmger == null) {
                    appOviddecgtmger = new AppOpenclass(this);
                    c = 2;
                    d = 2;
                }
            }
        } catch (Exception e) {

        }
    }

    public static boolean fourNativeUrl() {

        if (DApplication.getMeVcallApplication() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdstatus())) {
            return true;
        } else if (!DApplication.getMeVcallApplication().getAppDetails().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else {
            if (DApplication.getMeVcallApplication().getAppDetails().getAdmob3native() != null && !TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdmob3native())) {
                return false;
            } else {
                return true;
            }
        }
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {

    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {

        try {
            try {
                if (InterAdCall.getHelpIndicatorExplicit().recorderTimer != null) {
                    InterAdCall.getHelpIndicatorExplicit().recorderTimer.pause();
                    InterAdCall.getHelpIndicatorExplicit().recorderTimer.cancel();
                }
            } catch (Exception e) {

            }

            if (InterAdCall.getHelpIndicatorExplicit().dialogHelpIndicate != null) {
                InterAdCall.getHelpIndicatorExplicit().pauseRunDialog();
            }
        } catch (Exception e) {

        }
    }

    public boolean adMainStateOfLive() {
        if (getAppDetails() == null) {
            return true;
        } else if (getAppDetails().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(getAppDetails().getAdstatus())) {
            return true;
        } else if (!getAppDetails().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else {
            return false;
        }
    }

    private static final String keySystemModel = "app_details";


    public static LocalBroadcastManager bm = null;

    public static LocalBroadcastManager getBm() {
        return bm;
    }


    public static Context context = null;

    public static Context getContext() {
        return context;
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {

    }

    public static boolean onePageHowMuchShown() {
        int openDetector = 2;
        try {
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelper != null && myModelHelper.getNativebuttoncolor() != null && !TextUtils.isEmpty(myModelHelper.getNativebuttoncolor())) {
                openDetector = Integer.valueOf(myModelHelper.getNativebuttoncolor());
            }
        } catch (Exception e) {
        }
        return openDetector == 1;
    }

    public static int getNativeButtonSizeWidthAndHeight() {
        int vAppFlag = 2;
        try {
            AppDetail myModelHelperWit = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelperWit != null && myModelHelperWit.getAdmob3counter() != null && !TextUtils.isEmpty(myModelHelperWit.getAdmob3counter())) {
                vAppFlag = Integer.valueOf(myModelHelperWit.getAdmob3counter());
            }
        } catch (Exception e) {
        }
        return vAppFlag;
    }


    public static int numberDetector() {
        int screenCount = 0;
        try {
            DApplication meVcallApplication = DApplication.getMeVcallApplication();
            if (meVcallApplication != null && meVcallApplication.getAppDetails() != null && meVcallApplication.getAppDetails().getAppscreennumber() != null
                    && !TextUtils.isEmpty(meVcallApplication.getAppDetails().getAppscreennumber())) {
                try {
                    screenCount = Integer.valueOf(meVcallApplication.getAppDetails().getAppscreennumber());
                } catch (Exception e) {
                }
            }
        } catch (Exception e) {

        }
        return screenCount;
    }

    public static void tabToIntent(Activity activity, String lastURlToG0) {
        try {
            CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
            builder.setToolbarColor(ContextCompat.getColor(activity, R.color.white));
            CustomTabsIntent customTabsIntent = builder.build();
            customTabsIntent.intent.setPackage("com.android.chrome");
            customTabsIntent.launchUrl(activity, Uri.parse(lastURlToG0));
        } catch (Exception e) {

        }
    }

    public static int getSizeWay() {
        try {
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelper != null && myModelHelper.getFbappname() != null && !TextUtils.isEmpty(myModelHelper.getFbappname()) && !myModelHelper.getFbappname().equalsIgnoreCase("both")) {
                if (myModelHelper.getFbappname().equalsIgnoreCase("qureka")) {
                    return 1;
                } else if (myModelHelper.getFbappname().equalsIgnoreCase("gamezop")) {
                    return 2;
                } else {
                    return 3;
                }
            } else {
                return 3;
            }
        } catch (Exception e) {
            return 3;
        }
    }


    public static SharedPreferences preferenceMineData;

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {

    }

    public static int wholeInterCountdown() {
        int callcountdown = 3;
        try {
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelper != null && myModelHelper.getCounter() != null && !TextUtils.isEmpty(myModelHelper.getCounter())) {

                callcountdown = Integer.valueOf(myModelHelper.getCounter());
            }
        } catch (Exception e) {
        }
        return callcountdown;
    }

    public static int newcountdon() {
        int qcountdown = 1;
        try {
            AppDetail modelDirectDj = DApplication.getMeVcallApplication().getAppDetails();
            if (modelDirectDj != null && modelDirectDj.getAdmob2counter() != null && !TextUtils.isEmpty(modelDirectDj.getAdmob2counter())) {

                qcountdown = Integer.valueOf(modelDirectDj.getAdmob2counter());
            }
        } catch (Exception e) {
        }

        return qcountdown;
    }

    public AppDetail getAppDetails() {
        try {
            return new Gson().fromJson(preferenceMineData.getString(keySystemModel, ""), AppDetail.class);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean getZopIntert() {

        if (DApplication.getMeVcallApplication() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdstatus())) {
            return true;
        } else if (!DApplication.getMeVcallApplication().getAppDetails().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else {
            if (DApplication.getMeVcallApplication().getAppDetails().getAdmob3interstitial() != null && !TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdmob3interstitial())) {
                return false;
            } else {
                return true;
            }
        }
    }


    public static boolean afterAppButtonScreenGet() {
        int backflagButton = 2;
        try {
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelper != null && myModelHelper.getBackbuttonscreen() != null && !TextUtils.isEmpty(myModelHelper.getBackbuttonscreen())) {
                backflagButton = Integer.valueOf(myModelHelper.getBackbuttonscreen());
            }
        } catch (Exception e) {
        }
        return backflagButton == 1;
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        //MultiDex.install(this);
    }

    public void setMyModelHelper(AppDetail appDetail) {
        try {
            preferenceMineData.edit().putString(keySystemModel, new Gson().toJson(appDetail)).apply();
        } catch (Exception e) {

        }
    }


    public static boolean compileTopsideLayout() {
        try {
            if (DApplication.getMeVcallApplication().getAppDetails() == null) {
                return true;
            } else if (DApplication.getMeVcallApplication().getAppDetails().getAdstatus() == null) {
                return true;
            } else if (TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdstatus())) {
                return true;
            } else if (!DApplication.getMeVcallApplication().getAppDetails().getAdstatus().equalsIgnoreCase("1")) {
                return true;
            } else {
                if (DApplication.getMeVcallApplication().getAppDetails().getFbnative() != null && !TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getFbnative())) {
                    return false;
                } else {
                    return true;
                }
            }
        } catch (Exception e) {
            return true;
        }
    }

    public static boolean getUrlOne() {
        if (DApplication.getMeVcallApplication() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails() == null) {
            return true;
        } else if (DApplication.getMeVcallApplication().getAppDetails().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getAdstatus())) {
            return true;
        } else if (!DApplication.getMeVcallApplication().getAppDetails().getAdstatus().equalsIgnoreCase("1")) {
            return true;
        } else {
            if (DApplication.getMeVcallApplication().getAppDetails().getQurekaurl() != null && !TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getQurekaurl())) {
                return false;
            } else {
                return true;
            }
        }
    }

    public static boolean checkNetworkAvailable(Activity activity) {
        try {
            ConnectivityManager manager = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            boolean isAvailable = false;
            if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                isAvailable = true;
            }
            return isAvailable;
        } catch (Exception e) {
            return false;
        }

    }


    public static RecordData currRecord = new RecordData();


    public static boolean getOverlayPermision = false;

    public boolean bigForShowIfAvail() {

        if (getAppDetails() == null) {
            return true;
        } else if (getAppDetails().getAdstatus() == null) {
            return true;
        } else if (TextUtils.isEmpty(getAppDetails().getAdstatus())) {
            return true;
        } else if (!getAppDetails().getAdstatus().equalsIgnoreCase("1")) {
            return true;

        } else {
            if (getAppDetails().getFbinter() != null && !TextUtils.isEmpty(getAppDetails().getFbinter())) {

                return false;
            } else {
                return true;
            }
        }
    }

    public static SharedPreferences sP = null;


    public static void checkRecordService() {
        if (recordService == null) {
            Context context2 = context;
            context2.startService(new Intent(context2, RecordService.class));
        }
    }


}
