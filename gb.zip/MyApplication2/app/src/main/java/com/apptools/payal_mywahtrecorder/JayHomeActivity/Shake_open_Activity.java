package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.SensorService;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jaycommon.ShakeGestureReceiver;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

public class Shake_open_Activity extends AppCompatActivity {

    ImageView imgSwitch;
    SharedPreferences SharedPref;

    @Override
    protected void onResume() {
        super.onResume();

    }
    private Activity activity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shake_open);
        activity = this;

        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        imgSwitch = findViewById(R.id.imgSwitch);
        SharedPref = getSharedPreferences("ShakePRef", Context.MODE_MULTI_PROCESS);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        imgSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isKeyOn = SharedPref.getBoolean("shake_on_off_switch_key", false);
                if (isKeyOn) {
                    SharedPreferences.Editor editor = SharedPref.edit();
                    editor.putBoolean("shake_on_off_switch_key", false);
                    editor.apply();
                    imgSwitch.setImageResource(R.drawable.custom_icon_off);

                    try {

                        stopService(new Intent(Shake_open_Activity.this, SensorService.class));
                    } catch (Exception e) {

                    }
                } else {


                    if (isAppInstalled(Constants.app1) && isAppInstalled(Constants.app2)) {
                        openBothDialog();
                    } else if (isAppInstalled(Constants.app1)) {
                        SharedPreferences.Editor editor = SharedPref.edit();
                        editor.putBoolean("shake_on_off_switch_key", true);
                        editor.putString("Wshap", "wa");
                        editor.apply();
                        imgSwitch.setImageResource(R.drawable.custom_icon_on);


                        try {

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(new Intent(Shake_open_Activity.this, SensorService.class));
                            } else {
                                startService(new Intent(Shake_open_Activity.this, SensorService.class));
                            }
                        } catch (Exception e) {

                        }

                    } else if (isAppInstalled(Constants.app2)) {
                        SharedPreferences.Editor editor = SharedPref.edit();
                        editor.putBoolean("shake_on_off_switch_key", true);
                        editor.putString("Wshap", "wb");
                        editor.apply();
                        imgSwitch.setImageResource(R.drawable.custom_icon_on);


                        try {

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(new Intent(Shake_open_Activity.this, SensorService.class));
                            } else {
                                startService(new Intent(Shake_open_Activity.this, SensorService.class));
                            }
                        } catch (Exception e) {

                        }
                    } else {
                        Toast.makeText(Shake_open_Activity.this, JemsProviderKt.getMyString(activity,R.string.app_not_installed), Toast.LENGTH_SHORT).show();
                    }


                }
            }
        });


        shakeGestureReceiver = new ShakeGestureReceiver();
        try {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("key_shake_detector");
            registerReceiver(shakeGestureReceiver, intentFilter);
        } catch (Exception e) {

        }
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);

        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

        boolean isKeyOn = SharedPref.getBoolean("shake_on_off_switch_key", false);
        if (isKeyOn) {
            try {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(new Intent(Shake_open_Activity.this, SensorService.class));
                } else {
                    startService(new Intent(Shake_open_Activity.this, SensorService.class));
                }

            } catch (Exception e) {

            }
            imgSwitch.setImageResource(R.drawable.custom_icon_on);
        } else {
            imgSwitch.setImageResource(R.drawable.custom_icon_off);
        }
        BannerAdLayout.fillMeAlone(this, findViewById(R.id.relQbanner1), findViewById(R.id.frameQbanner1));
    }

    private boolean isAppInstalled(String packageName) {
        PackageManager pm = getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    public void openBothDialog() {
        Dialog alertDialog = new Dialog(Shake_open_Activity.this);
        final View customLayout = LayoutInflater.from(Shake_open_Activity.this).inflate(R.layout.dialog_selcte_whaz_set, null, false);
        alertDialog.setContentView(customLayout);

        Window window = alertDialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.addFlags(2);
        window.setDimAmount(0.82f);
        window.setAttributes(attributes);

        TextView img_btn_dilog_set_wtsapp = customLayout.findViewById(R.id.btn_dilog_set_whaz);
        TextView img_btn_dilog_set_wtsapp_buess = customLayout.findViewById(R.id.btn_dilog_set_whaz_w4b);
        TextView text_select2 = customLayout.findViewById(R.id.text_select2);
        text_select2.setText(JemsProviderKt.getMyString(activity,R.string.please_select_from_below_you_want_open_by_shake));

        img_btn_dilog_set_wtsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = SharedPref.edit();
                editor.putBoolean("shake_on_off_switch_key", true);
                editor.putString("Wshap", "wa");
                editor.apply();
                imgSwitch.setImageResource(R.drawable.custom_icon_on);


                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(new Intent(Shake_open_Activity.this, SensorService.class));
                    } else {
                        startService(new Intent(Shake_open_Activity.this, SensorService.class));
                    }
                } catch (Exception e) {

                }

                alertDialog.dismiss();
            }
        });

        img_btn_dilog_set_wtsapp_buess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = SharedPref.edit();
                editor.putBoolean("shake_on_off_switch_key", true);
                editor.putString("Wshap", "wb");
                editor.apply();
                imgSwitch.setImageResource(R.drawable.custom_icon_on);


                try {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(new Intent(Shake_open_Activity.this, SensorService.class));
                    } else {
                        startService(new Intent(Shake_open_Activity.this, SensorService.class));
                    }
                } catch (Exception e) {

                }

                alertDialog.dismiss();

            }
        });
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
    }

    @Override
    public void onBackPressed() {
        finish();
        InterAdCall.callForAniimation(this);
    }

    ShakeGestureReceiver shakeGestureReceiver;
}