package com.apptools.payal_mywahtrecorder.ads;

import static androidx.lifecycle.Lifecycle.Event.ON_START;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.apptools.payal_mywahtrecorder.JayTokandata.Activity.ExtraActivity;
import com.apptools.payal_mywahtrecorder.Jaylanguage.LanguageActivity;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class AppOpenclass implements LifecycleObserver, Application.ActivityLifecycleCallbacks {

    public static String gf = "";


    public static boolean df = false;
    private static boolean th = false;

    private final DApplication myApplication;
    public static boolean fividdecgtmag = false;

    public static AppOpenAd f = null;

    private Activity fghf;

    public static Activity Splasviddecgtmty;
    private AppOpenAd.AppOpenAdLoadCallback loadCallback;

    private long loadTimeLite = 0;
    private Integer yh = 0;


    public AppOpenclass(DApplication myApplication) {
        this.myApplication = myApplication;
        this.myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }


    public void getOpeviddecgtms() {

        if (isAdAvailable()) {
            return;
        }

        if (!df) {
            loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {

                    Log.e("TAG", "loadd: ");

                    super.onAdLoaded(f);
                    yh = 0;
                    AppOpenclass.this.f = ad;
                    AppOpenclass.this.loadTimeLite = (new Date()).getTime();

                    if (fividdecgtmag) {
                        if (!DApplication.a) {

                            dfgd();
                            DApplication.a = true;

                        }
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);

                    Log.e("TAG", "dharaxakk: " + loadAdError);
                }
            };
            AdRequest request = getAdRequest();

            AppOpenAd.load(myApplication, gf, request, AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);

        } else {
            df = false;
        }
    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }


    private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
        long dateDifference = (new Date()).getTime() - this.loadTimeLite;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * numHours));
    }

    public boolean isAdAvailable() {
        return f != null && wasLoadTimeLessThanNHoursAgo(4);
    }


    public void dfgd() {

        if (!df) {
            if (!th && isAdAvailable()) {

                Log.e("TAG", "shiww: ");

                //  if (SplashActivity.apgtDopenD == true) {

                th = true;
                FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        AppOpenclass.this.f = null;

                        th = false;

                        if (fividdecgtmag) {


                            fividdecgtmag = false;
                            if (SplashActivity.fg == false) {
                                SplashActivity.fg = true;
                                gdg();

                                try {
                                    if (SplashActivity.f != null) {
                                        SplashActivity.f.removeCallbacks(SplashActivity.rth);
                                    }
                                } catch (Exception e) {
                                }

                            }
                        }

                        if (myApplication.getAppDetails() != null && myApplication.getAppDetails().getAppopenAdmob() != null
                                && !TextUtils.isEmpty(myApplication.getAppDetails().getAppopenAdmob())) {
                            getOpeviddecgtms();
                        }

                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        th = false;
                        if (SplashActivity.fg == false) {
                            SplashActivity.fg = true;
                            gdg();
                        }
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        th = true;
                    }
                };


                f.setFullScreenContentCallback(fullScreenContentCallback);
                f.show(fghf);
                //}
            } else {

                yh++;
                if (f == null) {

                    if (DApplication.getInstance().c == 2) {
                        if (myApplication.getAppDetails() != null && myApplication.getAppDetails().getAppopenAdmob() != null
                                && !TextUtils.isEmpty(myApplication.getAppDetails().getAppopenAdmob())) {

                            AppOpenclass.gf = myApplication.getAppDetails().getAppopenAdmob();
                            getOpeviddecgtms();
                            yh = 0;
                            DApplication.getInstance().c = 1;
                        }
                    } else {

                        if (yh > 3) {
                            if (myApplication.getAppDetails() != null && myApplication.getAppDetails().getAppopenAdmob() != null
                                    && !TextUtils.isEmpty(myApplication.getAppDetails().getAppopenAdmob())) {

                                getOpeviddecgtms();
                                yh = 0;
                            }
                        }
                    }


                }
            }
        } else {
            df = false;
        }
    }

    private void gdg() {
        fividdecgtmag = false;
        if (internetConnectionAvailable(1500) && isNetworkAvailable()) {
            Splasviddecgtmty = null;

            if (fghf != null) {


                if (DApplication.numberDetector() >= 3) {

                    fghf.startActivity(new Intent(fghf, ExtraActivity.class));
                    fghf.finish();
                } else if (DApplication.numberDetector() >= 2) {

                    fghf.startActivity(new Intent(fghf, LanguageActivity.class));
                    fghf.finish();
                } else if (DApplication.numberDetector() >= 1) {
                    fghf.startActivity(new Intent(fghf, StartScreenActivity.class));
                    fghf.finish();
                } else {
                    fghf.startActivity(new Intent(fghf, HOmeActvitiy.class));
                    fghf.finish();
                }


            }

        } else {
            if (Splasviddecgtmty != null) {


                if (DApplication.numberDetector() >= 3) {

                    Splasviddecgtmty.startActivity(new Intent(Splasviddecgtmty, ExtraActivity.class));
                    Splasviddecgtmty.finish();
                } else if (DApplication.numberDetector() >= 2) {

                    Splasviddecgtmty.startActivity(new Intent(Splasviddecgtmty, LanguageActivity.class));
                    Splasviddecgtmty.finish();
                } else if (DApplication.numberDetector() >= 1) {
                    Splasviddecgtmty.startActivity(new Intent(Splasviddecgtmty, StartScreenActivity.class));
                    Splasviddecgtmty.finish();
                } else {
                    Splasviddecgtmty.startActivity(new Intent(Splasviddecgtmty, HOmeActvitiy.class));
                    Splasviddecgtmty.finish();
                }

            }
        }
    }


    private boolean isNetworkAvailable() {
        ConnectivityManager manager = (ConnectivityManager) myApplication.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        boolean isAvailable = false;
        if (networkInfo != null && networkInfo.isConnected()) {
            isAvailable = true;
        }
        return isAvailable;
    }


    private boolean internetConnectionAvailable(int timeOut) {
        InetAddress inetAddress = null;
        try {
            Future<InetAddress> future = Executors.newSingleThreadExecutor().submit(new Callable<InetAddress>() {
                @Override
                public InetAddress call() {
                    try {
                        return InetAddress.getByName("google.com");
                    } catch (UnknownHostException e) {
                        return null;
                    }
                }
            });
            inetAddress = future.get(timeOut, TimeUnit.MILLISECONDS);
            future.cancel(true);
        } catch (InterruptedException e) {
        } catch (ExecutionException e) {
        } catch (TimeoutException e) {
        }
        return inetAddress != null && !inetAddress.equals("");
    }

    @OnLifecycleEvent(ON_START)
    public void onStart() {
        dfgd();
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle bundle) {
        if (activity.toString().contains(DApplication.b)) {
            fghf = activity;
        } else {
            th = false;
        }
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {

    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        if (!activity.toString().contains(DApplication.b)) {
            fghf = activity;
        }
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle bundle) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        fghf = null;
    }
}
