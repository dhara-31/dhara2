package com.apptools.payal_mywahtrecorder.Jayservice;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.content.Intent;

import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_Recorder_activity;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class OpenAppService extends IntentService {
    public OpenAppService() {
        super("OpenAppService");
    }

    @SuppressLint("WrongConstant")
    public void onHandleIntent(Intent intent) {
        if (intent != null) {
            Intent intent2 = new Intent(DApplication.getContext(), JayHome_Recorder_activity.class); //6
            intent2.setFlags(268435456);
            DApplication.getContext().startActivity(intent2);
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);


    }
}
