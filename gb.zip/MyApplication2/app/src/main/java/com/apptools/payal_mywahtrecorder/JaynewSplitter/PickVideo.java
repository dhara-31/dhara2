package com.apptools.payal_mywahtrecorder.JaynewSplitter;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.LoadingVideos;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jaymodel.allVideo_Model;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.BasePermissionActivity;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.PermissionClass;

import java.io.File;
import java.util.ArrayList;

public class PickVideo extends BasePermissionActivity {

    RecyclerView rv_PickVideo;
    ArrayList<allVideo_Model> allVideoArrayList = new ArrayList();
    allVideo_Adapter adapter;
    LoadingVideos loadingVideos;
    private TextView permissionButton;
    private View mainLayout;
    private View emptyLayout;
    private View permissionLayout;


    @Override
    public void onResumePermission() {

    }

    PickVideo activity;

    @Override
    public void onCreatePermission(@Nullable Bundle savedInstanceState) {

        ArrayList<String> permission = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission.add(Manifest.permission.READ_MEDIA_VIDEO);
            permission.add(Manifest.permission.READ_MEDIA_IMAGES);
        } else {
            permission.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            permission.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        setPermissions(permission);

        setContentView(R.layout.activity_pick_video);

        activity = this;
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        permissionLayout = findViewById(R.id.permissionLayoutForPickVideo);
        emptyLayout = findViewById(R.id.emptyLayout);
        mainLayout = findViewById(R.id.mainLayoutForPickVideo);
        permissionButton = findViewById(R.id.permissionButtonForPickVideo);

        rv_PickVideo = findViewById(R.id.rv_PickVideo);

        loadingVideos = new LoadingVideos(PickVideo.this);
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        rv_PickVideo.setLayoutManager(new GridLayoutManager(this, 3));
        rv_PickVideo.setItemAnimator(new DefaultItemAnimator());
        allVideoArrayList = new ArrayList<>();

        findViewById(R.id.video_show_back_img).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        permissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PermissionClass permissionHelper = getPermissionHelper();
                if (permissionHelper != null) {
                    permissionHelper.askPermission(activity, true);
                }
            }
        });

    }

    @Override
    public void forceToOpenSetting(boolean need) {
        if (need) {
            permissionButton.setText("Open Setting");
        } else {
            permissionButton.setText("Permission Grant");
        }
    }

    boolean done = false;

    @Override
    public void permissionAllowCallBack(boolean permissionAllowed) {

        mainLayout.setVisibility(View.GONE);
        permissionLayout.setVisibility(View.VISIBLE);

        if (permissionAllowed) {
            mainLayout.setVisibility(View.VISIBLE);
            permissionLayout.setVisibility(View.GONE);
            if (done) {
                return;
            }
            done = true;
            MyTask myTask = new MyTask();
            myTask.execute("");
        }
    }

    private class MyTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loadingVideos.showDialog();
        }

        @Override
        protected String doInBackground(String... strings) {

            ContentResolver contentResolver = getApplicationContext().getContentResolver();
            Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

            Cursor cursor = contentResolver.query(uri, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    try {
                        @SuppressLint("Range") String data = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DATA));
                        @SuppressLint("Range") String duration = cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DURATION));
                        allVideo_Model videoModel = new allVideo_Model();
                        videoModel.setVideoUri(Uri.parse(data));
                        videoModel.setDuration(Long.parseLong(duration));
                        if (data.endsWith(".mp4")) {
                            if ((Integer.parseInt(duration) > (11 * 1000)) && (Integer.parseInt(duration) < (30 * (60 * 1000)))) {
                                allVideoArrayList.add(videoModel);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } while (cursor.moveToNext());
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            if (allVideoArrayList != null) {
                loadingVideos.hideDialog();
                adapter = new allVideo_Adapter(PickVideo.this, allVideoArrayList);
                if (allVideoArrayList.size() == 0) {
                    emptyLayout.setVisibility(View.VISIBLE);
                    rv_PickVideo.setVisibility(View.GONE);
                } else {
                    emptyLayout.setVisibility(View.GONE);
                    rv_PickVideo.setVisibility(View.VISIBLE);
                }
                rv_PickVideo.setAdapter(adapter);
            } else {
                loadingVideos.showDialog();
            }
        }
    }


}

class allVideo_Adapter extends RecyclerView.Adapter<allVideo_Adapter.ViewHolder> {

    Activity context1;
    ArrayList<allVideo_Model> videoArrayList = new ArrayList<>();

    public allVideo_Adapter(Activity context1, ArrayList<allVideo_Model> videoArrayList) {
        this.context1 = context1;
        this.videoArrayList = videoArrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context1).inflate(R.layout.adapter_allvideotools, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        File myvideoFile = new File(videoArrayList.get(position).getVideoUri().getPath());
        holder.tv_VideoName.setText(myvideoFile.getName());
        holder.tv_VideoName.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        holder.tv_VideoName.setSelected(true);

        holder.tv_Videodur.setText(formatMilis(videoArrayList.get(position).getDuration()));

        Uri Path = videoArrayList.get(position).getVideoUri();
        File file = new File(Path.getPath());
        Glide.with(context1).load(file).placeholder(R.drawable.select_video_img).override(200, 200).into(holder.iv_VideoThumbnail);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(context1, true, msg -> {
                    Intent intent = new Intent(context1, SelectSplitter.class);
                    intent.putExtra("VideoUrl", videoArrayList.get(position).getVideoUri().toString());
                    intent.putExtra("duration", videoArrayList.get(position).getDuration());
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context1.startActivity(intent);
                });



            }
        });

    }

    public static String formatMilis(long time) {
        final int totalSeconds = Math.abs((int) time / 1000);
        final int seconds = totalSeconds % 60;
        final int minutes = totalSeconds % 3600 / 60;
        final int hours = totalSeconds / 3600;

        return (hours > 0 ? String.format("%d:%02d:%02d", hours, minutes, seconds) : String.format("%02d:%02d", minutes, seconds));
    }

    @Override
    public int getItemCount() {
        return videoArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_VideoThumbnail;
        TextView tv_VideoName, tv_Videodur;

        public ViewHolder(View itemView) {
            super(itemView);

            tv_VideoName = itemView.findViewById(R.id.tv_VideoName);
            tv_Videodur = itemView.findViewById(R.id.tv_Videodur);
            iv_VideoThumbnail = itemView.findViewById(R.id.iv_VideoThumbnail);

        }
    }

}