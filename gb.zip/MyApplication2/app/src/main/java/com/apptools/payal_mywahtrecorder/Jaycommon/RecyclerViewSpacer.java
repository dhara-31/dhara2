package com.apptools.payal_mywahtrecorder.Jaycommon;

import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewSpacer extends RecyclerView.ItemDecoration {
    private int space;

    public RecyclerViewSpacer(int i) {
        this.space = i;
    }

    @Override
    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        rect.bottom = this.space;
    }

}
