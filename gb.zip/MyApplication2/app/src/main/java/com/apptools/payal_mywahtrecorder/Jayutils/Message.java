package com.apptools.payal_mywahtrecorder.Jayutils;

public class Message {
    public static final String ADD_BGM = "com.eaglemobi.gamerecorder.addbgm";
    public static final String ADD_VIDEO = "com.eaglemobi.gamerecorder.addvideo";
    public static final String CHANGE_STATE = "com.eaglemobi.gamerecorder.changestate";
    public static final String CLOSE_APP = "com.eaglemobi.gamerecorder.closeapp";
    public static final String COMPLETE_MIX = "com.eaglemobi.gamerecorder.completemix";
    public static final String DELETE_VIDEO = "com.eaglemobi.gamerecorder.deletevideo";
    public static final String EDIT_VIDEO = "com.eaglemobi.gamerecorder.editvideo";
    public static final String GET_OVER_LAY_PROMISSION = "com.eaglemobi.gamerecorder.getoverlaypromition";
    public static final String GET_SCREEN_PROJECTION = "com.eaglemobi.gamerecorder.getscreenprojection";
    public static final String PLAY_VIDEO = "com.eaglemobi.gamerecorder.playvideo";
    public static final String RECORD_UPDATED = "com.eaglemobi.gamerecorder.recordupdated";
    public static final String REJECT_SCREEN_PROJECTION = "com.eaglemobi.gamerecorder.rejectscreenprojection";
    public static final String REMOVE_MIX_PROGRESS = "com.eaglemobi.gamerecorder.removemixprogress";
    public static final String RENAME_VIDEO = "com.eaglemobi.gamerecorder.renamevideo";
    public static final String REQUEST_CAPTURE_FAIL = "com.eaglemobi.gamerecorder.requestcapturefail";
    public static final String REQUEST_CAPTURE_OK = "com.eaglemobi.gamerecorder.requestcaptureok";
    public static final String SELECTE_APP = "com.eaglemobi.gamerecorder.selectapp";
    public static final String SELECTE_MUSIC = "com.eaglemobi.gamerecorder.selectemusic";
    public static final String SHARE_VIDEO = "com.eaglemobi.gamerecorder.sharevideo";
    public static final String SHOW_FACEBOOK = "com.eaglemobi.gamerecorder.showfacebook";
    public static final String SHOW_RATE = "com.eaglemobi.gamerecorder.showrate";
    public static final String SHOW_RECORD_BUTTON = "com.eaglemobi.gamerecorder.showrecordbutton";
    public static final String UPDATE_MIX_PROGRESS = "com.eaglemobi.gamerecorder.updatemixprogress";

}
