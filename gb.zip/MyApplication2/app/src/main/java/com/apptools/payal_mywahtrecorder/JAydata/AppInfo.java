package com.apptools.payal_mywahtrecorder.JAydata;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

public class AppInfo {
    public boolean isSystem;
    public String name;
    public String pkg;
    public PackageInfo pkgInfo;
    public PackageManager pkgManager;
    public int tag = 0;
    public AppInfoType type;
}
