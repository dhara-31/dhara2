package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.apptools.payal_mywahtrecorder.R;

public class NotificationActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_notification);
    }
}
