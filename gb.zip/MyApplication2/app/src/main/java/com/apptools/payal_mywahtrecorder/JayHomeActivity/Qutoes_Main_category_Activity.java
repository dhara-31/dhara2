package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;


import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class Qutoes_Main_category_Activity extends AppCompatActivity {

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qutoes_main_categorytools);

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        findViewById(R.id.buttonClickCat1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",1));
                });




            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        findViewById(R.id.buttonClickCat2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",2));
                });




            }
        });
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);

        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }
        findViewById(R.id.buttonClickCat3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",3));
                });




            }
        });
        findViewById(R.id.buttonClickCat4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",4));
                });




            }
        });
        findViewById(R.id.buttonClickCat5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",5));
                });




            }
        });


        ImageView buttonClickCat6 = findViewById(R.id.buttonClickCat6);
        ImageView buttonClickCat7 = findViewById(R.id.buttonClickCat7);
        ImageView buttonClickCat8 = findViewById(R.id.buttonClickCat8);
        ImageView buttonClickCat9 = findViewById(R.id.buttonClickCat9);
        ImageView buttonClickCat10 = findViewById(R.id.buttonClickCat10);


        buttonClickCat6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",6));
                });




            }
        });

        buttonClickCat7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",7));
                });




            }
        });
        buttonClickCat8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",8));
                });




            }
        });
        buttonClickCat9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",9));
                });




            }
        });
        buttonClickCat10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(Qutoes_Main_category_Activity.this, true, msg -> {
                    startActivity(new Intent(Qutoes_Main_category_Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",10));
                });




            }
        });



    }

    @Override
    public void onBackPressed() {
        finish();
        InterAdCall.callForAniimation(this);
    }
}