package com.apptools.payal_mywahtrecorder.JAydata;

import android.os.Parcel;
import android.os.Parcelable;

public class MusicData implements Parcelable {
    public static final Creator<MusicData> CREATOR = new Creator<MusicData>() {

        @Override
        public MusicData createFromParcel(Parcel parcel) {
            MusicData musicData = new MusicData();
            musicData.id = parcel.readInt();
            musicData.name = parcel.readString();
            musicData.duration = parcel.readInt();
            musicData.artist = parcel.readString();
            musicData.path = parcel.readString();
            return musicData;
        }

        @Override
        public MusicData[] newArray(int i) {
            return new MusicData[i];
        }
    };
    public String artist;
    public int duration;
    public int id;
    public String name;
    public String path;

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.id);
        parcel.writeString(this.name);
        parcel.writeInt(this.duration);
        parcel.writeString(this.artist);
        parcel.writeString(this.path);
    }
}
