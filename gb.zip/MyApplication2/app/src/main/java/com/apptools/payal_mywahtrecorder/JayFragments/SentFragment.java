package com.apptools.payal_mywahtrecorder.JayFragments;

import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.file_set_int;
import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.selectedPos;
import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.size_path_log;
import static com.apptools.payal_mywahtrecorder.JayFragments.ReceivedFragment.list_recevi;
import static com.apptools.payal_mywahtrecorder.JayFragments.ReceivedFragment.size_rece_set;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_doc_sent;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_file_sent;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent;
import com.apptools.payal_mywahtrecorder.JAydata.Savers;
import com.apptools.payal_mywahtrecorder.Jayutils.FileCleanerUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;

import java.io.File;
import java.util.ArrayList;


public class SentFragment extends Fragment {

    private static final String TAG = "fatTAG";
    TextView text_select_item_nub_sent;
    RecyclerView recyclre_sent;
    TextView text_set_sent_no_data;
    ImageView imd_delete_sent;
    MyAdapterSent myAdapterSent;
    public static ArrayList<Savers> list_sent = new ArrayList<>();

    static PreferenceUtil preferenceUtil;
    boolean select_all = false;
    String name;
    private Dialog alert_select;
    private Dialog dialog;

    ImageView img_sent_all_select_an, img_sent_all_select;
    RelativeLayout realti_sent_select;
    public static long size_sent_set = 0;
    ArrayList<Savers> temp = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_senttools, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        preferenceUtil = new PreferenceUtil(requireActivity());
        name = preferenceUtil.getString(PreferenceUtil.SET_NIIK_TITAL, "");


        text_select_item_nub_sent = view.findViewById(R.id.text_select_item_nub_sent);
        recyclre_sent = view.findViewById(R.id.recyclre_sent);
        text_set_sent_no_data = view.findViewById(R.id.text_set_sent_no_data);
        imd_delete_sent = view.findViewById(R.id.imd_delete_sent);

        img_sent_all_select_an = view.findViewById(R.id.img_sent_all_select_an);
        img_sent_all_select = view.findViewById(R.id.img_sent_all_select);
        realti_sent_select = view.findViewById(R.id.realti_sent_select);

        img_sent_all_select_an.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                img_sent_all_select.setVisibility(View.VISIBLE);
                img_sent_all_select_an.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= 30) {

                    if (!select_all) {
                        list_select_doc_sent.clear();
                        for (Savers saver : list_sent) {
                            list_select_doc_sent.add(saver.getDocumentFile());
                        }
                        select_all = true;

                    }

                    onclick(list_select_doc_sent.size());
                } else {

                    if (!select_all) {
                        list_select_file_sent.clear();
                        for (Savers saver : list_sent) {
                            list_select_file_sent.add(saver.getFile());
                        }
                        select_all = true;

                    }


                    onclick(list_select_file_sent.size());
                }
                if (myAdapterSent != null) {
                    myAdapterSent.updatelist(list_sent);
                    myAdapterSent.updatelistfile(list_select_file_sent);
                    myAdapterSent.updatelistdoc(list_select_doc_sent);
                }

            }
        });
        img_sent_all_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img_sent_all_select.setVisibility(View.GONE);
                img_sent_all_select_an.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 30) {

                    if (select_all) {

                        select_all = false;
                        list_select_doc_sent.clear();
                    }

                    onclick(list_select_doc_sent.size());
                } else {

                    if (select_all) {

                        select_all = false;
                        list_select_file_sent.clear();
                    }


                    onclick(list_select_file_sent.size());
                }
                if (myAdapterSent != null) {
                    myAdapterSent.updatelist(list_sent);
                    myAdapterSent.updatelistfile(list_select_file_sent);
                    myAdapterSent.updatelistdoc(list_select_doc_sent);
                }
            }
        });


        imd_delete_sent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (list_select_doc_sent.size() != 0 || list_select_file_sent.size() != 0) {

                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(requireActivity());
                    final View customLayout = LayoutInflater.from(requireActivity()).inflate(R.layout.delete_dilog, null, false);
                    alertDialog.setView(customLayout);


                    ImageView Cancel_status_dilog = customLayout.findViewById(R.id.Cancel_status_dilog);
                    ImageView ok_status_dilog = customLayout.findViewById(R.id.ok_status_dilog);
                    Cancel_status_dilog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alert_select.dismiss();

                        }
                    });
                    ok_status_dilog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alert_select.dismiss();
                            long size = 0;
                            if (Build.VERSION.SDK_INT >= 30) {

                                for (DocumentFile d : list_select_doc_sent) {
                                    size += d.length();
                                    new DELETE_DOC_11_Sent().execute(d);
                                }
                                file_set_int[selectedPos] = file_set_int[selectedPos] - list_select_doc_sent.size();
                                deldete11uyp();
                                list_select_doc_sent.clear();
                                onclick(list_select_doc_sent.size());


                            } else {
                               for (File f : list_select_file_sent) {
                                    size += f.length();
                                    checkdatafile(f);
                                }

                                file_set_int[selectedPos] = file_set_int[selectedPos] - list_select_file_sent.size();
                                list_select_file_sent.clear();
                                onclick(list_select_file_sent.size());

                                if (dialog != null && dialog.isShowing()) {
                                    dialog.dismiss();
                                }

                            }


                        }
                    });
                    alert_select = alertDialog.create();
                    alert_select.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    alert_select.show();
                }

            }
        });


        text_select_item_nub_sent.setText("Selected " + name + " (" + 0 + ")");

        if (name.equals("Images") || name.equals("Gifs") || name.equals("Stickers")) {

            recyclre_sent.setLayoutManager(new GridLayoutManager(requireActivity(), 3));

        } else {
            recyclre_sent.setLayoutManager(new GridLayoutManager(requireActivity(), 1));
        }


        recyclre_sent.setHasFixedSize(true);
        myAdapterSent = new MyAdapterSent(requireActivity(), list_sent, name, this::onclick);
        recyclre_sent.setAdapter(myAdapterSent);


        String path = preferenceUtil.getString(PreferenceUtil.SET_SELECT_ITME, "");
        if (Build.VERSION.SDK_INT >= 30) {
            new Datelist11upSent().execute(path);

        } else {

            new Datalist10dowSent().execute(new File(path, "sent"));
        }


    }


    private void checkdatafile(File f) {

        ArrayList<Savers> temp = new ArrayList<>();
        size_path_log[selectedPos] = size_path_log[selectedPos] - f.length();
        for (Savers saver : list_sent) {
            if (!saver.getFile().toString().equals(f.toString())) {
                temp.add(saver);
            }
        }
        f.delete();
        list_sent = temp;
        if (myAdapterSent != null) {
            if (list_sent.size() == 0) {
                realti_sent_select.setVisibility(View.GONE);
                text_select_item_nub_sent.setVisibility(View.GONE);
                recyclre_sent.setVisibility(View.GONE);
                text_set_sent_no_data.setVisibility(View.VISIBLE);
                imd_delete_sent.setVisibility(View.GONE);
            } else {
                realti_sent_select.setVisibility(View.VISIBLE);
                text_select_item_nub_sent.setVisibility(View.VISIBLE);
                recyclre_sent.setVisibility(View.VISIBLE);
                text_set_sent_no_data.setVisibility(View.GONE);
                imd_delete_sent.setVisibility(View.VISIBLE);
            }
            myAdapterSent.updatelist(list_sent);
        }
    }


    private void onclick(int i) {
        if (i == 0) {

            img_sent_all_select.setVisibility(View.GONE);
            img_sent_all_select_an.setVisibility(View.VISIBLE);
            imd_delete_sent.setImageResource(R.drawable.delete_an);

        } else if (list_sent.size() == i) {
            img_sent_all_select.setVisibility(View.VISIBLE);
            img_sent_all_select_an.setVisibility(View.GONE);
            imd_delete_sent.setImageResource(R.drawable.delete_se);
            select_all = true;
        } else if (i >= 1) {
            img_sent_all_select.setVisibility(View.GONE);
            img_sent_all_select_an.setVisibility(View.VISIBLE);
            imd_delete_sent.setImageResource(R.drawable.delete_se);
            select_all = false;

        }
        text_select_item_nub_sent.setText("Selected " + name + " (" + i + ")");
    }


    class Datalist10dowSent extends AsyncTask<File, Void, ArrayList<Savers>> {
        @Override
        protected ArrayList<Savers> doInBackground(File... files) {
            size_sent_set = 0;
            if (files[0].canExecute()) {
                File[] statusFiles;
                statusFiles = files[0].listFiles();
                list_sent.clear();


                for (File file : statusFiles) {
                    if (!file.getName().contains(".nomedia") && !file.getName().equals(".DS_Store")) {
                        if (file.isDirectory()) {

                            File[] files_list;
                            files_list = file.listFiles();
                            for (File file1 : files_list) {
                                if (!file1.getName().contains(".nomedia") && !file1.getName().equals(".DS_Store")) {
                                    Savers saver2 = new Savers(file1, file1.getName(), file1.getAbsolutePath(), file1.length());
                                    if (saver2.getFile().exists() && saver2.getFile().length() > 0) {
                                        list_sent.add(saver2);
                                        size_sent_set += file1.length();
                                    }
                                }
                            }

                        } else {

                            Savers saver = new Savers(file, file.getName(), file.getAbsolutePath(), file.length());
                            if (saver.getFile().exists() && saver.getFile().length() > 0) {
                                list_sent.add(saver);
                                size_sent_set += file.length();

                            }
                        }
                    }
                }
            }
            return list_sent;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<Savers> savers) {
            super.onPostExecute(savers);

            int aa = list_recevi.size() + list_sent.size();
            long size_ = size_rece_set + size_sent_set;
            if (file_set_int[selectedPos] != aa) {
                file_set_int[selectedPos] = aa;
                size_path_log[selectedPos] = size_;
            }


            myAdapterSent.updatelist(list_sent);
            if (myAdapterSent.getItemCount() == 0) {
                realti_sent_select.setVisibility(View.GONE);
                text_select_item_nub_sent.setVisibility(View.GONE);
                recyclre_sent.setVisibility(View.GONE);
                text_set_sent_no_data.setVisibility(View.VISIBLE);
                imd_delete_sent.setVisibility(View.GONE);
            } else {
                realti_sent_select.setVisibility(View.VISIBLE);
                text_select_item_nub_sent.setVisibility(View.VISIBLE);
                recyclre_sent.setVisibility(View.VISIBLE);
                text_set_sent_no_data.setVisibility(View.GONE);
                imd_delete_sent.setVisibility(View.VISIBLE);
            }
        }
    }

    class Datelist11upSent extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {
            try {
                list_sent.clear();
                size_sent_set = 0;

                String val = preferenceUtil.getString(PreferenceUtil.KeyUseThisFolder, "");


                String path_data = preferenceUtil.getString(PreferenceUtil.SET_SELECT_ITME, "");

                DocumentFile document = DocumentFile.fromSingleUri(requireActivity(), Uri.parse(path_data));
                DocumentFile documentFile = null;
                String data = preferenceUtil.getString(PreferenceUtil.SELECT_WHAZ, "");
                if (data.equals("waz_w4b")) {
                    documentFile = DocumentFile.fromTreeUri(requireActivity(), Uri.parse(val)).findFile("com.whatsapp.w4b").findFile("WhatsApp Business").findFile("Media").findFile(document.getName()).findFile("Sent");
                } else if (data.equals("whaz_nor")) {
                    documentFile = DocumentFile.fromTreeUri(requireActivity(), Uri.parse(val)).findFile("com.whatsapp").findFile("WhatsApp").findFile("Media").findFile(document.getName()).findFile("Sent");
                }


                try {
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                } catch (Exception e) {
                    e.printStackTrace();
                }
                try {
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (documentFile.exists()) {

                    if (documentFile.isDirectory()) {

                        for (DocumentFile f : documentFile.listFiles()) {

                            if (!f.getUri().toString().contains(".nomedia") && !f.getName().equals(".DS_Store")) {

                                if (DocumentFile.isDocumentUri(requireActivity(), f.getUri())) {

                                    if (f.isDirectory()) {
                                        for (DocumentFile f2 : f.listFiles()) {
                                            if (!f2.getUri().toString().contains(".nomedia") && !f2.getName().equals(".DS_Store")) {
                                                File filePath = FileCleanerUtils.getFile(requireActivity(), f2.getUri());
                                                Savers saver = new Savers(filePath, filePath.getName(), filePath.getAbsolutePath(), f2.getUri(), f2.length(), f2);
                                                list_sent.add(saver);
                                                size_sent_set += f2.length();
                                            }
                                        }
                                    } else {
                                        File filePath = FileCleanerUtils.getFile(requireActivity(), f.getUri());
                                        Savers saver = new Savers(filePath, filePath.getName(), filePath.getAbsolutePath(), f.getUri(), f.length(), f);
                                        list_sent.add(saver);
                                        size_sent_set += f.length();

                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            diloagshowmoth();
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);


            int aa = list_recevi.size() + list_sent.size();
            long size_ = size_rece_set + size_sent_set;


            if (file_set_int[selectedPos] != aa) {
                file_set_int[selectedPos] = aa;
                size_path_log[selectedPos] = size_;
            }


            myAdapterSent.updatelist(list_sent);
            if (myAdapterSent.getItemCount() == 0) {
                realti_sent_select.setVisibility(View.GONE);
                text_select_item_nub_sent.setVisibility(View.GONE);
                recyclre_sent.setVisibility(View.GONE);
                text_set_sent_no_data.setVisibility(View.VISIBLE);
                imd_delete_sent.setVisibility(View.GONE);
            } else {
                realti_sent_select.setVisibility(View.VISIBLE);
                text_select_item_nub_sent.setVisibility(View.VISIBLE);
                recyclre_sent.setVisibility(View.VISIBLE);
                text_set_sent_no_data.setVisibility(View.GONE);
                imd_delete_sent.setVisibility(View.VISIBLE);
            }
            dialog.dismiss();
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if (Build.VERSION.SDK_INT >= 30) {
            onclick(list_select_doc_sent.size());
        } else {
            onclick(list_select_file_sent.size());
        }
        select_all = false;
        if (myAdapterSent != null) {
            if (list_sent.size() == 0) {
                realti_sent_select.setVisibility(View.GONE);
                text_select_item_nub_sent.setVisibility(View.GONE);
                recyclre_sent.setVisibility(View.GONE);
                text_set_sent_no_data.setVisibility(View.VISIBLE);
                imd_delete_sent.setVisibility(View.GONE);
            } else {
                realti_sent_select.setVisibility(View.VISIBLE);
                text_select_item_nub_sent.setVisibility(View.VISIBLE);
                recyclre_sent.setVisibility(View.VISIBLE);
                text_set_sent_no_data.setVisibility(View.GONE);
                imd_delete_sent.setVisibility(View.VISIBLE);
            }
            myAdapterSent.updatelist(list_sent);
        }


    }

    private void diloagshowmoth() {

        dialog = new Dialog(requireActivity());
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View v = LayoutInflater.from(requireActivity()).inflate(R.layout.dialog_loader, null);

        dialog.setContentView(v);
        dialog.show();
    }

    class DELETE_DOC_11_Sent extends AsyncTask<DocumentFile, Void, ArrayList<Savers>> {
        int cun = 1;

        @Override
        protected ArrayList<Savers> doInBackground(DocumentFile... documentFiles) {


            size_path_log[selectedPos] = size_path_log[selectedPos] - documentFiles[0].length();
            documentFiles[0].delete();
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<Savers> savers) {
            super.onPostExecute(savers);


        }


    }

    private void deldete11uyp() {

        for (int i = 0; i < list_select_doc_sent.size(); i++) {
            for (int j = 0; j < list_sent.size(); j++) {


                if (list_select_doc_sent.get(i).toString().contains(list_sent.get(j).getDocumentFile().toString())) {
                    list_sent.remove(j);
                    break;
                }

            }
        }
        if (myAdapterSent != null) {

            if (list_sent.size() == 0) {
                realti_sent_select.setVisibility(View.GONE);
                text_select_item_nub_sent.setVisibility(View.GONE);
                recyclre_sent.setVisibility(View.GONE);
                text_set_sent_no_data.setVisibility(View.VISIBLE);
                imd_delete_sent.setVisibility(View.GONE);
            } else {
                realti_sent_select.setVisibility(View.VISIBLE);
                text_select_item_nub_sent.setVisibility(View.VISIBLE);
                recyclre_sent.setVisibility(View.VISIBLE);
                text_set_sent_no_data.setVisibility(View.GONE);
                imd_delete_sent.setVisibility(View.VISIBLE);
            }
            myAdapterSent.updatelist(list_sent);
        }
    }

}