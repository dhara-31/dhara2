package com.apptools.payal_mywahtrecorder.JayHomeActivity;


import static android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT;
import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.file_set_int;
import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.selectedPos;
import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.size_path_log;
import static com.apptools.payal_mywahtrecorder.JayFragments.ReceivedFragment.list_recevi;
import static com.apptools.payal_mywahtrecorder.JayFragments.SentFragment.list_sent;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterRecevi.list_select_doc;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterRecevi.list_select_file;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_doc_sent;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_file_sent;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;
import java.io.IOException;

public class JayHome_CleanerPriviewActivity extends AppCompatActivity implements AudioManager.OnAudioFocusChangeListener {

    public static DocumentFile documentFile;
    public static File file;
    private ImageView img_back_btn;
    private TextView activity_name_text;

    PreferenceUtil preferenceUtil;

    String name_nike;


    ConstraintLayout relati_set_pl_pau;
    RelativeLayout realti_video_seek_set;
    VideoView videoView;
    ImageView img_set_priview_img, playPauseBtn;
    ImageView image_delete_preivew, image_shara_preivew;

    int selcete_frg_item = 0;
    int pos_select_se = 0;
    ConstraintLayout constraint;
    private Handler handler;
    private Runnable runnable;

    int videoPosition = 0;
    int audioPosition = 0;


    private TextView rightTime, leftTime;
    SeekBar seek_bar;


    TextView rightTime_audio, leftTime_audio;
    SeekBar audio_vios_seekbar;
    ImageView image_paly_puse_set_audio;


    RelativeLayout realti_audio_vios;

    private AudioManager am;
    private MediaPlayer mediaPlayervideo, mediaPlayer_audio;
    private boolean isPaused;
    private String time1;
    private boolean isPaused_audio;
    private Dialog alert_select;
    private Activity activity;
    private long mLastClickTime = 0L;
    private static final long CLICK_TIME_INTERVAL = 700;
    boolean isResume = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cleaner_priviewtools);
        activity = this;

        preferenceUtil = new PreferenceUtil(this);
        name_nike = preferenceUtil.getString(PreferenceUtil.SET_NIIK_TITAL, "");

        img_back_btn = findViewById(R.id.img_back_btn);
        activity_name_text = findViewById(R.id.activity_name_text);
        activity_name_text.setText(JemsProviderKt.getMyString(activity, R.string.preview));
        img_back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));

        selcete_frg_item = getIntent().getIntExtra("SELECT_SENT_REVE", 0);
        pos_select_se = getIntent().getIntExtra("select_pos", 0);

        img_set_priview_img = findViewById(R.id.image_sel_set_pre);
        relati_set_pl_pau = findViewById(R.id.constraint);
        videoView = findViewById(R.id.video_view);
        playPauseBtn = findViewById(R.id.image_paly_puse_set_video);
        realti_video_seek_set = findViewById(R.id.realti_video_seek_set);
        constraint = findViewById(R.id.constraint);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        realti_audio_vios = findViewById(R.id.realti_audio_vios);

        rightTime = findViewById(R.id.rightTime);
        leftTime = findViewById(R.id.leftTime);
        seek_bar = findViewById(R.id.chat_header_size_seekbar);

        rightTime_audio = findViewById(R.id.rightTime_audio);
        leftTime_audio = findViewById(R.id.leftTime_audio);
        audio_vios_seekbar = findViewById(R.id.audio_vios_seekbar);
        image_paly_puse_set_audio = findViewById(R.id.image_paly_puse_set_audio);


        image_delete_preivew = findViewById(R.id.image_delete_preivew);
        image_shara_preivew = findViewById(R.id.image_shara_preivew);
        playPauseBtn.setVisibility(View.GONE);

        if (name_nike.equals("Videos")) {
            playPauseBtn.setVisibility(View.VISIBLE);
            realti_video_seek_set.setVisibility(View.VISIBLE);
            constraint.setVisibility(View.VISIBLE);
        }


        list_select_file.clear();
        list_select_doc.clear();
        list_select_file_sent.clear();
        list_select_doc_sent.clear();


        if (name_nike.equals("Images") || name_nike.equals("Stickers")) {
            videoView.setVisibility(View.GONE);
            realti_video_seek_set.setVisibility(View.GONE);
            img_set_priview_img.setVisibility(View.VISIBLE);

            if (file != null) {
                Glide.with(this).load(Uri.fromFile(file)).into(img_set_priview_img);
            } else {
                Glide.with(this).load(documentFile.getUri()).into(img_set_priview_img);
            }
        } else if (name_nike.equals("Videos") || name_nike.equals("Gifs")) {
            videoView.setVisibility(View.VISIBLE);
            if (file != null) {

                videoView.setVideoURI(Uri.fromFile(file));
                mediaPlayervideo = MediaPlayer.create(getApplicationContext(), Uri.fromFile(file));
                String endTime = createTime(mediaPlayervideo.getDuration());
                rightTime.setText(endTime);
            } else {

                videoView.setVideoURI(documentFile.getUri());
                mediaPlayervideo = MediaPlayer.create(getApplicationContext(), documentFile.getUri());
                String endTime = createTime(mediaPlayervideo.getDuration());
                rightTime.setText(endTime);
            }


            videoView.setOnPreparedListener(mp -> {

                if (isResume) {

                    playPauseBtn.setImageResource(R.drawable.icon_pause);

                    am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    am.requestAudioFocus(JayHome_CleanerPriviewActivity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                    videoView.start();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            playPauseBtn.setVisibility(View.GONE);
                        }
                    }, 100);

                }
                mediaPlayervideo = mp;
                seek_bar.setMax(videoView.getDuration());

            });
            setUpVideoProgress();

        } else {
            constraint.setVisibility(View.GONE);
            realti_audio_vios.setVisibility(View.VISIBLE);
            realti_video_seek_set.setVisibility(View.GONE);
            constraint.setVisibility(View.GONE);
            mediaPlayer_audio = new MediaPlayer();

            Uri uri = null;
            if (mediaPlayer_audio != null) {
                am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                am.requestAudioFocus(JayHome_CleanerPriviewActivity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                if (file != null) {

                    uri = Uri.fromFile(file);
                } else {
                    uri = documentFile.getUri();
                }


                try {
                    mediaPlayer_audio.setDataSource(JayHome_CleanerPriviewActivity.this, uri);
                    mediaPlayer_audio.prepare();
                    audio_vios_seekbar.setMax(mediaPlayer_audio.getDuration());
                    time1 = createTime(mediaPlayer_audio.getDuration());
                    image_paly_puse_set_audio.setImageResource(R.drawable.icon_pause_au);
                    rightTime_audio.setText(time1);
                    leftTime_audio.setText("00:00");
                    setUpAudioProgress();
                    mediaPlayer_audio.start();

                } catch (IOException e) {
                    e.printStackTrace();
                }


                mediaPlayer_audio.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                        am.requestAudioFocus(JayHome_CleanerPriviewActivity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

                        mediaPlayer_audio.seekTo(0);
                        seek_bar.setProgress(0);
                        mediaPlayer_audio.pause();

                        image_paly_puse_set_audio.setImageResource(R.drawable.icon_play_au);
                    }
                });
            }


        }
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        relati_set_pl_pau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (videoView.isPlaying()) {
                    playPauseBtn.setVisibility(View.VISIBLE);
                    playPauseBtn.setImageResource(R.drawable.icon_play);
                    videoView.pause();
                    isPaused = true;
                } else {
                    playPauseBtn.setImageResource(R.drawable.icon_pause);


                    videoView.start();

                    isPaused = false;
                    final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            playPauseBtn.setVisibility(View.GONE);
                        }
                    }, 100);
                }
            }
        });

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {

                am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                am.requestAudioFocus(JayHome_CleanerPriviewActivity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

                videoView.seekTo(0);
                seek_bar.setProgress(0);
                videoView.pause();
                playPauseBtn.setVisibility(View.VISIBLE);
                playPauseBtn.setImageResource(R.drawable.icon_play);

            }
        });
        image_paly_puse_set_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer_audio != null) {
                    am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

                    am.requestAudioFocus(JayHome_CleanerPriviewActivity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                    if (mediaPlayer_audio.isPlaying()) {
                        mediaPlayer_audio.pause();
                        image_paly_puse_set_audio.setImageResource(R.drawable.icon_play_au);
                        isPaused_audio = true;
                    } else {

                        mediaPlayer_audio.start();
                        setUpAudioProgress();
                        image_paly_puse_set_audio.setImageResource(R.drawable.icon_pause_au);
                        isPaused_audio = false;
                    }
                }


            }
        });

        image_shara_preivew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }
                mLastClickTime = now;

                Uri uri = null;
                if (Build.VERSION.SDK_INT >= 30) {
                    uri = documentFile.getUri();
                } else {
                    uri = FileProvider.getUriForFile(JayHome_CleanerPriviewActivity.this, JayHome_CleanerPriviewActivity.this.getApplicationContext().getPackageName() + ".provider", file);
                }

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                startActivity(Intent.createChooser(intent, "choseFile"));
            }
        });

        image_delete_preivew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(JayHome_CleanerPriviewActivity.this);
                final View customLayout = LayoutInflater.from(JayHome_CleanerPriviewActivity.this).inflate(R.layout.delete_dilog, null, false);
                alertDialog.setView(customLayout);


                ImageView Cancel_status_dilog = customLayout.findViewById(R.id.Cancel_status_dilog);
                ImageView ok_status_dilog = customLayout.findViewById(R.id.ok_status_dilog);
                Cancel_status_dilog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alert_select.dismiss();

                    }
                });
                ok_status_dilog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (Build.VERSION.SDK_INT >= 30) {


                            file_set_int[selectedPos] = file_set_int[selectedPos] - 1;
                            size_path_log[selectedPos] = size_path_log[selectedPos] - documentFile.length();

                            documentFile.delete();

                        } else {


                            file_set_int[selectedPos] = file_set_int[selectedPos] - 1;
                            size_path_log[selectedPos] = size_path_log[selectedPos] - file.length();
                            file.delete();
                        }

                        if (selcete_frg_item == 11) {

                            list_recevi.remove(pos_select_se);
                        } else {
                            list_sent.remove(pos_select_se);
                        }
                        alert_select.dismiss();
                        finish();


                    }
                });
                alert_select = alertDialog.create();
                alert_select.setCanceledOnTouchOutside(false);
                alert_select.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                alert_select.show();


            }
        });


        audio_vios_seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    audio_vios_seekbar.setProgress(progress);
                    if (mediaPlayer_audio != null) {
                        mediaPlayer_audio.seekTo(progress);
                    }
                }
                String currentTime = createTime(mediaPlayer_audio.getCurrentPosition());
                leftTime_audio.setText(currentTime);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                try {
                    if (mediaPlayer_audio != null) {
                        mediaPlayer_audio.pause();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                try {

                    if (mediaPlayer_audio != null) {
                        if (isPaused_audio) {
                            mediaPlayer_audio.pause();
                        } else {
                            mediaPlayer_audio.start();

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        seek_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    seek_bar.setProgress(progress);
                    if (mediaPlayervideo != null) {
                        videoView.seekTo(progress);
                    }
                }
                String currentTime = createTime(videoView.getCurrentPosition());
                leftTime.setText(currentTime);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                try {
                    if (mediaPlayervideo != null) {
                        videoView.pause();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                try {

                    if (mediaPlayervideo != null) {
                        if (isPaused) {
                            videoView.pause();
                        } else {
                            videoView.start();

                        }


                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


    }

    private void setUpAudioProgress() {
        handler = new Handler();

        runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    if (mediaPlayer_audio.isPlaying()) {

                        audio_vios_seekbar.setProgress(mediaPlayer_audio.getCurrentPosition());

                    }

                    handler.postDelayed(this, 250);

                } catch (IllegalStateException ed) {
                    ed.printStackTrace();
                }
            }
        };
        handler.postDelayed(runnable, 0);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        try {
            if (videoView != null) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                }
            }

        }catch (Exception e){

        }

try {
    if (mediaPlayer_audio != null) {
        if (mediaPlayer_audio.isPlaying()) {
            mediaPlayer_audio.pause();
        }
    }
}catch (Exception e){

}

        InterAdCall.callForAniimation(this);

        if (handler != null) handler.removeCallbacks(runnable);
    }


    public void setUpVideoProgress() {


        handler = new Handler();

        runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    if (videoView.isPlaying()) {

                        seek_bar.setProgress(mediaPlayervideo.getCurrentPosition());

                    }

                    handler.postDelayed(this, 250);

                } catch (IllegalStateException ed) {
                    ed.printStackTrace();
                }
            }
        };
        handler.postDelayed(runnable, 0);
    }

    public String createTime(int duration) {

        String time = "";
        int min = duration / 1000 / 60;
        int sec = duration / 1000 % 60;

        time += min + ":";

        if (sec < 10) {

            time += "0";
        }

        time += sec;

        return time;
    }

    int duration;

    @Override
    protected void onPause() {
        isResume = false;
        duration = videoView.getCurrentPosition();
        super.onPause();
    }


    @Override
    protected void onResume() {

        if (name_nike.equals("Videos") || name_nike.equals("Gifs")) {
            try {
                videoView.seekTo(duration);
                videoView.pause();
                playPauseBtn.setVisibility(View.VISIBLE);
                playPauseBtn.setImageResource(R.drawable.icon_play);

                am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                am.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                videoPosition = videoView.getCurrentPosition();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (name_nike.equals("Audio")) {
            if (mediaPlayer_audio != null) {
                if (!mediaPlayer_audio.isPlaying()) {
                    audioPosition = mediaPlayer_audio.getCurrentPosition();
                    mediaPlayer_audio.seekTo(audioPosition);
                    mediaPlayer_audio.pause();
                    image_paly_puse_set_audio.setImageResource(R.drawable.icon_play_au);

                    am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    am.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

                }
            }
        }
        super.onResume();


    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange) {

            case AudioManager.AUDIOFOCUS_GAIN:
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                break;
            case AUDIOFOCUS_LOSS_TRANSIENT:

                if (videoView.isPlaying()) {
                    videoView.pause();
                    playPauseBtn.setImageResource(R.drawable.icon_play);
                }
                if (mediaPlayer_audio != null) {
                    if (mediaPlayer_audio.isPlaying()) {
                        mediaPlayer_audio.pause();
                        image_paly_puse_set_audio.setImageResource(R.drawable.icon_play_au);
                    }
                }

                break;
            case AudioManager.AUDIOFOCUS_LOSS:

                if (videoView.isPlaying()) {
                    videoView.pause();
                    playPauseBtn.setImageResource(R.drawable.icon_play);
                }
                if (mediaPlayer_audio != null) {
                    if (mediaPlayer_audio.isPlaying()) {
                        mediaPlayer_audio.pause();
                        image_paly_puse_set_audio.setImageResource(R.drawable.icon_play_au);
                    }
                }
                break;
        }
    }


}