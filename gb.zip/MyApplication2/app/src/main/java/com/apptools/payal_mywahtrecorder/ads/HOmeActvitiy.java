package com.apptools.payal_mywahtrecorder.ads;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_Direct_chat_Activity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_EmptyText_Activity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_ExitActivity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_GuideDrawOverActivity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_MoreTools3Activity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_TextRepeatActivity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_TextToEmojiActivity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.Quotes_sub_Activity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.Qutoes_Main_category_Activity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.Shake_open_Activity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.VS_Fancy_Text_Open_Activity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.StatusSaverActivity;

public class HOmeActvitiy extends AppCompatActivity {

    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screentools);

        activity = this;

        RelativeLayout itemClick_Fancy = findViewById(R.id.itemClick_Fancy);

        itemClick_Fancy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    Intent intent = new Intent(HOmeActvitiy.this, VS_Fancy_Text_Open_Activity.class);
                    startActivity(intent);
                });

            }
        });

        LinearLayout itemClick_TextShow = findViewById(R.id.itemClick_TextShow);
        itemClick_TextShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(HOmeActvitiy.this, JayHome_TextRepeatActivity.class));
                });

            }
        });

        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        findViewById(R.id.texttoemoji).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(activity, JayHome_TextToEmojiActivity.class));
                });

            }
        });

        findViewById(R.id.itemClick_Saver).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    Intent intent = new Intent(activity, StatusSaverActivity.class);
                    intent.putExtra("wa_value", 1);
                    startActivity(intent);
                });

            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));


        findViewById(R.id.love).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(HOmeActvitiy.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",4));
                });
            }
        });
        findViewById(R.id.cute).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(HOmeActvitiy.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",3));
                });

            }
        });
        findViewById(R.id.funny).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(HOmeActvitiy.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",6));
                });


            }
        });

        findViewById(R.id.plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(activity, Qutoes_Main_category_Activity.class));
                });


            }
        });

        findViewById(R.id.itemClick_EmptyText).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(HOmeActvitiy.this, JayHome_EmptyText_Activity.class));
                });

            }
        });

        LinearLayout itemClick_ShakeOpen = findViewById(R.id.itemClick_ShakeOpen);
        itemClick_ShakeOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (Settings.canDrawOverlays(HOmeActvitiy.this)) {

                        InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                            startActivity(new Intent(HOmeActvitiy.this, Shake_open_Activity.class));
                        });

                    } else {
                        InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                            startActivity(new Intent(HOmeActvitiy.this, JayHome_GuideDrawOverActivity.class).putExtra("key_screen_rec", false));
                        });

                    }

                } else {
                    InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                        startActivity(new Intent(HOmeActvitiy.this, Shake_open_Activity.class));
                    });


                }


            }
        });



        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);

        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {

            Log.e("natuce", "onCreate: 111" );
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            Log.e("natuce", "onCreate: 222" );
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

        // FirstTimeBannersLay.fillMeAlone(this, findViewById(R.id.relQbanner1), findViewById(R.id.frameQbanner1));
        findViewById(R.id.rl_ems).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(activity, JayHome_Direct_chat_Activity.class));
                });

            }
        });


        findViewById(R.id.itemClick_more).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(HOmeActvitiy.this, true, msg -> {
                    startActivity(new Intent(activity, JayHome_MoreTools3Activity.class));
                });


            }
        });


    }

    @Override
    public void onBackPressed() {
        if (DApplication.numberDetector() >= 1) {
            finish();
        } else {
            startActivity(new Intent(HOmeActvitiy.this, JayHome_ExitActivity.class));
        }
    }
}