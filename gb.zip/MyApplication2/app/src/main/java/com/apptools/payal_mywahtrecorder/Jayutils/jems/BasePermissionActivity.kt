package com.apptools.payal_mywahtrecorder.Jayutils.jems

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

abstract class BasePermissionActivity : AppCompatActivity() {
    var permissions = ArrayList<String>()
    private var checkPermissionOnResume = false
    var permissionHelper: PermissionClass? = null

    abstract fun onResumePermission()
    override fun onResume() {
        super.onResume()

        if (checkPermissionOnResume) {
            if (permissionHelper == null) {
                preparePermissionClass()
            } else {
                permissionHelper?.checkPermission(this)
            }
        }
        checkPermissionOnResume = true

        onResumePermission()
    }

    abstract fun onCreatePermission(savedInstanceState: Bundle?)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onCreatePermission(savedInstanceState)
        preparePermissionClass {
            it.checkPermission(this)
        }
    }


    abstract fun forceToOpenSetting(need: Boolean)
    abstract fun permissionAllowCallBack(permissionAllowed: Boolean)
    private fun preparePermissionClass(callback: (PermissionClass) -> Unit = {}) {
        permissionHelper = PermissionClass(this, permissions, permissionAllowCallBack = {
            permissionAllowCallBack(it)
        }, forceToOpenSetting = {
            forceToOpenSetting(it)
        })
        permissionHelper?.apply {
            callback(this)
        }
    }
}