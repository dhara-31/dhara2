package com.apptools.payal_mywahtrecorder.Jayutils;

import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.os.AsyncTask;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.apptools.payal_mywahtrecorder.JayHomeadapter.VideoListAdapter;
import com.apptools.payal_mywahtrecorder.JAydata.RecordData;
import com.apptools.payal_mywahtrecorder.JAydata.VideoData;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class CatchUtils {
    private static CatchUtils instance;
    private Map<String, Drawable> iconCatch;
    private PackageManager pkgManager;
    public Map<Long, VideoData> videoPreviewCatch;


    public class LoadVideoTask extends AsyncTask<VideoListAdapter.VideoHolder, Integer, Boolean> {
        private RecordData recordData;
        private VideoData videoData;
        private VideoListAdapter.VideoHolder videoHolder;

        LoadVideoTask() {
        }

        public Boolean doInBackground(VideoListAdapter.VideoHolder... videoHolderArr) {
            try {
                this.videoHolder = videoHolderArr[0];
                this.recordData = this.videoHolder.getRecordData();
                this.videoData = new VideoData();
                this.videoData.id = this.recordData.id;
                this.videoData.path = this.recordData.path;
                MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
                mediaMetadataRetriever.setDataSource(this.recordData.path);
                this.videoData.preview = mediaMetadataRetriever.getFrameAtTime();
                this.videoData.duration = FileUtils.getVideoDurationMs(mediaMetadataRetriever);
                this.videoData.durationDesc = FileUtils.getVidoeDuration(mediaMetadataRetriever);
                this.videoData.size = FileUtils.getFileSize(this.recordData.path);
                VideoData videoData2 = this.videoData;
                videoData2.sizeDesc = FileUtils.convertByteToMB(videoData2.size);
                mediaMetadataRetriever.release();
            } catch (Exception e) {
                try {
                    File filed = new File(videoData.path);
                    if (filed.exists()) {
                        filed.delete();
                    }
                } catch (Exception e2) {

                }
            }
            return true;
        }

        public void onPreExecute() {
            super.onPreExecute();
        }

        public void onPostExecute(Boolean bool) {
            super.onPostExecute(bool);
            CatchUtils.this.videoPreviewCatch.put(Long.valueOf(this.videoData.id), this.videoData);
            this.videoHolder.updateVideoData(this.videoData);
        }

        public void onProgressUpdate(Integer... numArr) {
            super.onProgressUpdate(numArr);
        }

        public void onCancelled(Boolean bool) {
            super.onCancelled(bool);
        }

        public void onCancelled() {
            super.onCancelled();
        }
    }

    public CatchUtils() {
        if (instance == null) {
            this.iconCatch = new HashMap();
            this.videoPreviewCatch = new HashMap();
            this.pkgManager = DApplication.getContext().getPackageManager();
            return;
        }
        throw new Error("CatchUtils is Singleton");
    }

    public static CatchUtils getInstance() {
        if (instance == null) {
            instance = new CatchUtils();
        }
        return instance;
    }

    public Drawable getAppIcon(String str) {
        Drawable drawable = this.iconCatch.get(str);
        if (drawable != null) {
            return drawable;
        }
        Drawable loadIcon = AppUtils.getAppInfo(str).pkgInfo.applicationInfo.loadIcon(this.pkgManager);
        this.iconCatch.put(str, loadIcon);
        return loadIcon;
    }

    public VideoData getVideoData(RecordData recordData, VideoListAdapter.VideoHolder videoHolder) {
        VideoData videoData = this.videoPreviewCatch.get(Long.valueOf(recordData.id));
        if (videoData != null) {
            return videoData;
        }
        new LoadVideoTask().execute(videoHolder);
        return null;
    }

    public void clearVideoData(Long l) {
        this.videoPreviewCatch.remove(l);
    }
}
