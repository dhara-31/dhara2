package com.apptools.payal_mywahtrecorder.Jaycommon;

import android.media.MediaPlayer;

import com.apptools.payal_mywahtrecorder.JAydata.MusicData;

import java.io.IOException;

public class MusicPlayer {
    public MusicData[] musicList;
    public int playIndex = 0;
    private MediaPlayer player = new MediaPlayer();
    private boolean playing = false;
    private int roundDuration = 0;
    private int seekTime = -1;

    public MusicPlayer() {
        this.player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {


            public void onCompletion(MediaPlayer mediaPlayer) {
                mediaPlayer.reset();
                MusicPlayer.this.playIndex++;
                if (MusicPlayer.this.playIndex >= MusicPlayer.this.musicList.length) {
                    MusicPlayer.this.playIndex = 0;
                }
                MusicPlayer.this.playNextMusic();
            }
        });
    }

    public void setMusicList(MusicData[] musicDataArr) {
        this.musicList = musicDataArr;
        if (musicDataArr != null && musicDataArr.length > 0) {
            this.roundDuration = 0;
            int length = musicDataArr.length;
            for (int i = 0; i < length; i++) {
                this.roundDuration += musicDataArr[i].duration;
            }
        }
    }

    public boolean canPlay() {
        MusicData[] musicDataArr = this.musicList;
        return musicDataArr != null && musicDataArr.length > 0;
    }

    public void play() {
        if (canPlay()) {
            this.playIndex = 0;
            playNextMusic();
            this.playing = true;
            return;
        }

    }

    public void stop() {
        this.player.reset();
        this.playing = false;
    }

    public boolean isPlaying() {
        return this.playing;
    }

    public void pause() {
        if (this.player.isPlaying()) {
            this.player.pause();
        }
    }

    public void resume() {
        if (this.playing) {
            int i = this.seekTime;
            if (i != -1) {
                this.seekTime = i % this.roundDuration;
                int i2 = 0;
                int i3 = 0;
                while (true) {
                    MusicData[] musicDataArr = this.musicList;
                    if (i2 >= musicDataArr.length) {
                        break;
                    }
                    MusicData musicData = musicDataArr[i2];
                    int i4 = this.seekTime;
                    if (i4 < i3 || i4 >= musicData.duration + i3) {
                        i3 += musicData.duration;
                        i2++;
                    } else {
                        if (i2 != this.playIndex) {
                            this.player.reset();
                            this.playIndex = i2;
                            try {
                                this.player.setDataSource(musicData.path);
                                this.player.prepare();
                            } catch (IOException e) {

                            }
                        }
                        this.player.seekTo(this.seekTime - i3);
                        this.seekTime = -1;
                    }
                }
                this.seekTime = -1;
            }
            this.player.start();
        }
    }

    public void seekTo(int i) {
        this.seekTime = i;
    }

    public void playNextMusic() {
        try {
            this.player.setDataSource(this.musicList[this.playIndex].path);
            this.player.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.player.start();
    }

    public void release() {
        this.player.release();
    }
}
