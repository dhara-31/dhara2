package com.apptools.payal_mywahtrecorder.Jayservice;

import android.app.IntentService;
import android.content.Intent;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;

public class ChangeStateService extends IntentService {
    public ChangeStateService() {
        super("ChangeStateService");
    }

    public void onHandleIntent(Intent intent) {
        if (intent != null) {
            DApplication.getBm().sendBroadcast(new Intent(Message.CHANGE_STATE));
        }
    }
}
