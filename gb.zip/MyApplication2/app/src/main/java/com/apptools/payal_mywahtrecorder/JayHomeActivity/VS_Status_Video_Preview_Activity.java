package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.SaveSS;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.copyFile;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.statusSaverActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;

public class VS_Status_Video_Preview_Activity extends AppCompatActivity implements AudioManager.OnAudioFocusChangeListener {

    VideoView videoView;
    TextView video_preview_txt;

    ImageView status_delete_img, status_share_img, status_download, playBtn;

    String video_path;

    ImageView video_preview_back_img;

    boolean check_playing = false;
    int duration = 100;
    boolean showDownload;

    AudioManager am;
    private Activity activity;
    private long mLastClickTime = 0L;
    private static final long CLICK_TIME_INTERVAL = 700;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vs_status_video_preview);

        activity = this;

        Intent intent = getIntent();
        video_path = intent.getStringExtra("video_file_path");
        showDownload = intent.getBooleanExtra("show_download", true);

        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        videoView = findViewById(R.id.video_view_preview_img);
        playBtn = findViewById(R.id.v_p_play_img);
        video_preview_txt = findViewById(R.id.folder_name);
        status_delete_img = findViewById(R.id.status_delete_img);
        status_share_img = findViewById(R.id.status_share_img);
        status_download = findViewById(R.id.status_download);

        video_preview_back_img = findViewById(R.id.video_preview_back_img);

        checkDownload();
        status_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (video_path.contains("%2F")) {
                    SaveSS(video_path, Constants.getFileNameFromUri(activity, Uri.parse(video_path)), activity, (statusSaverActivity.isStatusAppPresent) ? statusSaverActivity.APP_DIR_WA : statusSaverActivity.APP_DIR_WAB);
                } else {
                    copyFile(new File(video_path), activity, (statusSaverActivity.isStatusAppPresent) ? statusSaverActivity.APP_DIR_WA : statusSaverActivity.APP_DIR_WAB);
                }
                checkDownload();
            }
        });

        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        videoView.setVideoPath(video_path);
        try {
            videoView.start();
            am.requestAudioFocus(VS_Status_Video_Preview_Activity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        } catch (Exception e) {
            e.printStackTrace();
        }
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                playBtn.setVisibility(View.VISIBLE);
            }
        });

        videoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    if (videoView.isPlaying()) {
                        try {
                            am.requestAudioFocus(VS_Status_Video_Preview_Activity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                        } catch (Exception e) {

                        }

                        videoView.pause();
                        playBtn.setVisibility(View.VISIBLE);
                    } else {
                        am.requestAudioFocus(VS_Status_Video_Preview_Activity.this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

                        videoView.start();
                        playBtn.setVisibility(View.GONE);

                    }
                } catch (Exception e) {

                }


            }
        });


        status_delete_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                open_dialog_for_delete();


            }
        });

        status_share_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }
                mLastClickTime = now;
                Uri picUri = FileProvider.getUriForFile(VS_Status_Video_Preview_Activity.this, getPackageName() + ".provider", new File(video_path));

                Intent intent = new Intent(Intent.ACTION_SEND);

                intent.putExtra(Intent.EXTRA_STREAM, picUri);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                intent.setType("video/*");
                startActivity(Intent.createChooser(intent, "Share Via"));

            }
        });

        video_preview_back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    private void checkDownload() {
        status_download.setVisibility(View.GONE);
        status_share_img.setVisibility(View.GONE);
        status_delete_img.setVisibility(View.GONE);
        Constants.scanBothAppFile(this, video_path, new Constants.CallBackOfListFiles() {
            @Override
            public void checkFile(String selectedFilePath) {
                if (selectedFilePath.isEmpty()) {
                    status_download.setVisibility(View.VISIBLE);
                    status_share_img.setVisibility(View.GONE);
                    status_delete_img.setVisibility(View.GONE);
                } else {
                    status_download.setVisibility(View.GONE);
                    status_share_img.setVisibility(View.VISIBLE);
                    if (showDownload) {
                        status_delete_img.setVisibility(View.VISIBLE);
                    }
                    video_path = selectedFilePath;
                }

            }
        });

    }


    private void open_dialog_for_delete() {

        final AlertDialog.Builder alert = new AlertDialog.Builder(VS_Status_Video_Preview_Activity.this);

        View mView = LayoutInflater.from(VS_Status_Video_Preview_Activity.this).inflate(R.layout.status_item_delete_dialog_layout, null);

        TextView delete_dialog_cancel_txt = (TextView) mView.findViewById(R.id.delete_dialog_cancel_txt);
        TextView delete_dialog_okay_txt = (TextView) mView.findViewById(R.id.delete_dialog_okay_txt);

        alert.setView(mView);
        final AlertDialog alertDialog = alert.create();
        alertDialog.setCanceledOnTouchOutside(false);

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        delete_dialog_cancel_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        delete_dialog_okay_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File file = new File(video_path);
                if (file.delete()) {
                    finish();
                    Toast.makeText(VS_Status_Video_Preview_Activity.this, JemsProviderKt.getMyString(activity, R.string.successfully_deleted), Toast.LENGTH_SHORT).show();
                    alertDialog.dismiss();
                }
                MediaScannerConnection.scanFile(VS_Status_Video_Preview_Activity.this, new String[]{file.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {

                    }
                });

            }
        });


        alertDialog.show();

    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (check_playing) {
                videoView.pause();
                playBtn.setVisibility(View.VISIBLE);
            }
            videoView.seekTo(duration);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onPause() {
        super.onPause();

        check_playing = videoView.isPlaying();

        try {
            duration = videoView.getCurrentPosition();
            if (check_playing) {
                videoView.pause();
                playBtn.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange) {

            case AudioManager.AUDIOFOCUS_GAIN:
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:

                if (videoView.isPlaying()) {
                    videoView.pause();
                    playBtn.setVisibility(View.VISIBLE);
                }

                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                if (videoView.isPlaying()) {
                    videoView.pause();
                    playBtn.setVisibility(View.VISIBLE);
                }

                break;
        }

    }
}