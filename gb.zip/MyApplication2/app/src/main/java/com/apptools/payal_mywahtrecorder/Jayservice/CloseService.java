package com.apptools.payal_mywahtrecorder.Jayservice;

import android.app.IntentService;
import android.content.Intent;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;

public class CloseService extends IntentService {
    public CloseService() {
        super("CloseService");
    }

    public void onHandleIntent(Intent intent) {
        DApplication.getBm().sendBroadcast(new Intent(Message.CLOSE_APP));
    }
}
