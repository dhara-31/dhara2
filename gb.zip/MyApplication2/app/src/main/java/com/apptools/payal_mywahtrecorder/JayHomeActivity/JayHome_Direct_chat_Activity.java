
package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.hbb20.CountryCodePicker;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import org.jetbrains.annotations.NotNull;

public class JayHome_Direct_chat_Activity extends AppCompatActivity {
    CountryCodePicker ccPicker;
    EditText etEnterMessage;
    EditText etTextMobileNumber;


    @Override
    protected void onResume() {
        super.onResume();


        try {
            etEnterMessage.clearFocus();
        } catch (Exception e) {

        }
        try {
            etTextMobileNumber.clearFocus();
        } catch (Exception e) {

        }
    }

    private Activity activity;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direct_chat);
        activity = this;

        etEnterMessage = findViewById(R.id.etEnterMessage);
        etTextMobileNumber = findViewById(R.id.etTextMobileNumber);

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        ccPicker = findViewById(R.id.ccPicker);
        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        findViewById(R.id.buttonClickSendToDirect).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }
                mLastClickTime = now;

                String messageStr = etEnterMessage.getText().toString().trim();
                String etNumberStr = etTextMobileNumber.getText().toString().trim();
                if (TextUtils.isEmpty(etNumberStr)) {
                    etTextMobileNumber.setError(JemsProviderKt.getMyString(activity, R.string.mobile_number_can_not_empty));
                } else if (etNumberStr.length() < 10) {
                    etTextMobileNumber.setError(JemsProviderKt.getMyString(activity, R.string.mobile_number_not_valid));
                } else if (TextUtils.isEmpty(messageStr)) {
                    etEnterMessage.setError(JemsProviderKt.getMyString(activity, R.string.message_can_not_empty));
                } else {

                    hideKeyboard(JayHome_Direct_chat_Activity.this);
                    etNumberStr = etNumberStr.replace(" ", "");
                    etNumberStr = ccPicker.getSelectedCountryCode() + etNumberStr;
                    etNumberStr = etNumberStr.replace("+", "");

                    if (isAppInstalled(Constants.app1) && isAppInstalled(Constants.app2)) {
                        openBothDialog(etTextMobileNumber, etEnterMessage, etNumberStr, messageStr);
                    } else if (isAppInstalled(Constants.app1)) {
                        try {
                            Intent intent = new Intent(Intent.ACTION_MAIN);
                            intent.setAction(Intent.ACTION_VIEW);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.setPackage(Constants.app1);
                            intent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + etNumberStr + "&text=" + messageStr));
                            startActivity(intent);

                            etTextMobileNumber.setText("");
                            etEnterMessage.setText("");

                        } catch (Exception e) {
                            Toast.makeText(JayHome_Direct_chat_Activity.this, JemsProviderKt.getMyString(activity, R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                        }
                    } else if (isAppInstalled(Constants.app2)) {

                        try {
                            Intent intent = new Intent(Intent.ACTION_MAIN);
                            intent.setAction(Intent.ACTION_VIEW);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.setPackage(Constants.app2);
                            intent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + etNumberStr + "&text=" + messageStr));
                            startActivity(intent);

                            etTextMobileNumber.setText("");
                            etEnterMessage.setText("");
                        } catch (Exception e) {
                            Toast.makeText(JayHome_Direct_chat_Activity.this, JemsProviderKt.getMyString(activity, R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(JayHome_Direct_chat_Activity.this, JemsProviderKt.getMyString(activity, R.string.app_not_installed), Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        etEnterMessage.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (etEnterMessage.hasFocus()) {
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    switch (event.getAction() & MotionEvent.ACTION_MASK){
                        case MotionEvent.ACTION_SCROLL:
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            return true;
                    }
                }
                return false;
            }
        });
        BannerAdLayout.fillMeAlone(this, findViewById(R.id.relQbanner1), findViewById(R.id.frameQbanner1));
    }


    @Override
    protected void onPause() {
        super.onPause();


     /*   if (ccPicker.isShown()) {
            ccPicker.jemsDismissDialog();
        }*/
    }

    public void openBothDialog(EditText etTextMobileNumber, EditText etEnterMessage, String etNumberStr, String messageStr) {
        Dialog alertDialog = new Dialog(JayHome_Direct_chat_Activity.this);
        final View customLayout = LayoutInflater.from(JayHome_Direct_chat_Activity.this).inflate(R.layout.dialog_selcte_whaz_set, null, false);
        alertDialog.setContentView(customLayout);

        Window window = alertDialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.addFlags(2);
        window.setDimAmount(0.82f);
        window.setAttributes(attributes);

        TextView img_btn_dilog_set_wtsapp = customLayout.findViewById(R.id.btn_dilog_set_whaz);
        TextView img_btn_dilog_set_wtsapp_buess = customLayout.findViewById(R.id.btn_dilog_set_whaz_w4b);
        TextView text_select2 = customLayout.findViewById(R.id.text_select2);
        text_select2.setText(JemsProviderKt.getMyString(activity, R.string.please_select_from_below_you_want_send_message));

        img_btn_dilog_set_wtsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setPackage(Constants.app1);
                    intent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + etNumberStr + "&text=" + messageStr));
                    startActivity(intent);

                    etTextMobileNumber.setText("");
                    etEnterMessage.setText("");

                } catch (Exception e) {
                    Toast.makeText(JayHome_Direct_chat_Activity.this, JemsProviderKt.getMyString(activity, R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                }

                alertDialog.dismiss();
            }
        });

        img_btn_dilog_set_wtsapp_buess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setPackage(Constants.app2);
                    intent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" + etNumberStr + "&text=" + messageStr));
                    startActivity(intent);

                    etTextMobileNumber.setText("");
                    etEnterMessage.setText("");
                } catch (Exception e) {
                    Toast.makeText(JayHome_Direct_chat_Activity.this, JemsProviderKt.getMyString(activity, R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                }

                alertDialog.dismiss();

            }
        });
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);

        View view = activity.getCurrentFocus();

        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private long mLastClickTime = 0;
    private static final long CLICK_TIME_INTERVAL = 1200;

    private boolean isAppInstalled(String packageName) {
        PackageManager pm = getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull @NotNull String[] permissions, @NonNull @NotNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {

        finish();
        InterAdCall.callForAniimation(this);
    }

}
