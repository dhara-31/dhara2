package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

public class JayHomeCaptureActivity extends Activity {

    private MediaProjection mediaProjection;
    private MediaProjectionManager projectionManager;

    Activity activity;

    @SuppressLint("WrongConstant")
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_capturetools);

        activity = this;

        this.projectionManager = (MediaProjectionManager) getSystemService("media_projection");
        startActivityForResult(this.projectionManager.createScreenCaptureIntent(), 101);

    }

    public void onDestroy() {
        super.onDestroy();

    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 101) {
            DApplication.screenProjection = null;
            if (i2 == -1) {
                this.mediaProjection = this.projectionManager.getMediaProjection(i2, intent);
                DApplication.screenProjection = this.mediaProjection;
                DApplication.getBm().sendBroadcast(new Intent(Message.GET_SCREEN_PROJECTION));
                DApplication.recordService.initReceiver();
            }
            finish();
       }
    }


    @SuppressLint("WrongConstant")
    private void rerequest() {


        Toast.makeText(this, JemsProviderKt.getMyString(activity, R.string.click_on_start_now), Toast.LENGTH_SHORT).show();
        this.projectionManager = (MediaProjectionManager) getSystemService("media_projection");
        startActivityForResult(this.projectionManager.createScreenCaptureIntent(), 101);

    }
}
