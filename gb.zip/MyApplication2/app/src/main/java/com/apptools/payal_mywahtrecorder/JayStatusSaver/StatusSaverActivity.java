package com.apptools.payal_mywahtrecorder.JayStatusSaver;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.app1;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.app2;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.isAppInstalled;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.statusSaverActivity;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.waImageFragment;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.waVideoFragment;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.apptools.payal_mywahtrecorder.JayHomeActivity.Status_Download_Open_Activity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.BasePermissionActivity;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.PermissionClass;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;

import java.util.ArrayList;

public class StatusSaverActivity extends BasePermissionActivity {

    private MyFragmentAdapter adapter;
    public ViewPager viewPager;

    public String APP_DIR_WA;
    public String APP_DIR_WAB;
    public boolean isStatusAppPresent;

    ImageView changeWaWb;
    ProgressBar progress;
    ImageView status_download_img;
    TextView tab_video_txt, tab_image_txt, permissionButtonForStatusSaver, permissionDescForStatusSaver;

    View permissionLayoutForStatusSaver, mainLayoutForStatusSaver;


    @Override
    public void onResumePermission() {
         Constants.scanBothAppFile(this, "", new Constants.CallBackOfListFiles() {
            @Override
            public void checkFile(String selectedFilePath) {
                try {
                    if (waVideoFragment != null) {
                        try {
                            waVideoFragment.videoListAdapter11.notifyDataSetChanged();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            waVideoFragment.videoListAdapter.notifyDataSetChanged();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    if (waImageFragment != null) {
                        try {
                            waImageFragment.imageListAdapter.notifyDataSetChanged();
                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                        try {
                            waImageFragment.imageListAdapter11.notifyDataSetChanged();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } catch (Exception e) {
                   e.printStackTrace();
                }
            }
        });


    }

    @Override
    public void onCreatePermission(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.activity_vs_status_saver_open);

        ArrayList<String> permission = new ArrayList<>();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            permission.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            permission.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        setPermissions(permission);


        Constants.statusSaverActivity = this;

        APP_DIR_WA = JemsProviderKt.getWAPath(this);

        APP_DIR_WAB = JemsProviderKt.getWABPath(this);

        permissionLayoutForStatusSaver = findViewById(R.id.permissionLayoutForStatusSaver);
        mainLayoutForStatusSaver = findViewById(R.id.mainLayoutForStatusSaver);
        permissionButtonForStatusSaver = findViewById(R.id.permissionButtonForStatusSaver);
        permissionDescForStatusSaver = findViewById(R.id.permissionDescForStatusSaver);
        progress = findViewById(R.id.progress);
        changeWaWb = findViewById(R.id.changeWaWb);
        status_download_img = findViewById(R.id.status_download_img);
        viewPager = findViewById(R.id.video_viewPager);
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        tab_video_txt = findViewById(R.id.tab_video_txt);
        tab_image_txt = findViewById(R.id.tab_image_txt);

        findViewById(R.id.status_main_back_img).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        if (isAppInstalled(StatusSaverActivity.this, app1) && isAppInstalled(StatusSaverActivity.this, app2)) {
            changeWaWb.setVisibility(VISIBLE);
            isStatusAppPresent = true;
        } else if (isAppInstalled(StatusSaverActivity.this, app1)) {
            changeWaWb.setVisibility(GONE);
            isStatusAppPresent = true;
        } else if (isAppInstalled(StatusSaverActivity.this, app2)) {
            changeWaWb.setVisibility(GONE);
            isStatusAppPresent = false;
        }

        changeWaWb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupWindow window = popupWindowForSelectApp();
                window.showAsDropDown(changeWaWb, 40, 18);
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                if (position == 0) {

                    tab_image_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));
                    tab_video_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));

                } else if (position == 1) {

                    tab_image_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));
                    tab_video_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));

                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        tab_image_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                viewPager.setCurrentItem(0);

                tab_image_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));
                tab_video_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));

            }
        });

        tab_video_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPager.setCurrentItem(1);
                tab_image_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));
                tab_video_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));
            }
        });
        status_download_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(StatusSaverActivity.this, true, msg -> {
                    Intent intent = new Intent(StatusSaverActivity.this, Status_Download_Open_Activity.class);
                    startActivity(intent);
                });


            }
        });
        permissionButtonForStatusSaver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PermissionClass permissionHelper = getPermissionHelper();
                if (permissionHelper != null) {
                    permissionHelper.askPermission(StatusSaverActivity.this, true);
                }
            }
        });

        adapter = new MyFragmentAdapter(getSupportFragmentManager());

        adapter.add(new WAImageFragment(), "Image");
        adapter.add(new WAVideoFragment(), "Video");

        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(adapter.getCount());
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    @Override
    public void forceToOpenSetting(boolean need) {
        if (need) {
            permissionButtonForStatusSaver.setText("Open Setting");
        } else {
            permissionButtonForStatusSaver.setText("Permission Grant");
        }
    }

    boolean isRunning = false;

    @Override
    public void permissionAllowCallBack(boolean permissionAllowed) {

        changeWaWb.setVisibility(GONE);
        mainLayoutForStatusSaver.setVisibility(GONE);
        permissionLayoutForStatusSaver.setVisibility(VISIBLE);

        if (asyncTaskRunner != null) {
            asyncTaskRunner.cancel(true);
            asyncTaskRunner = null;
        }

        if (permissionAllowed) {
            if (JemsProviderKt.isStatusPermissionAllow(this)) {
                permissionLayoutForStatusSaver.setVisibility(GONE);
                mainLayoutForStatusSaver.setVisibility(VISIBLE);
                if (isAppInstalled(StatusSaverActivity.this, app1) && isAppInstalled(StatusSaverActivity.this, app2)) {
                    changeWaWb.setVisibility(VISIBLE);
                    isStatusAppPresent = true;
                } else if (isAppInstalled(StatusSaverActivity.this, app1)) {
                    changeWaWb.setVisibility(GONE);
                    isStatusAppPresent = true;
                } else if (isAppInstalled(StatusSaverActivity.this, app2)) {
                    changeWaWb.setVisibility(GONE);
                    isStatusAppPresent = false;
                }

                if (isRunning) {
                    return;
                }
                isRunning = true;

                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        scanMedia();

                    }
                }, 500);

            } else {
                permissionDescForStatusSaver.setText("We need some basic permission for read Image and Video from your app data.");
                permissionButtonForStatusSaver.setText("Allow");
                permissionButtonForStatusSaver.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent;
                        StorageManager sm = (StorageManager) getApplicationContext().getSystemService(STORAGE_SERVICE);
                        String statusDir = "Android%2Fmedia";
                        String str = "android.provider.extra.INITIAL_URI";

                        if (Build.VERSION.SDK_INT >= 30) {
                            intent = sm.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
                            String scheme = ((Uri) intent.getParcelableExtra(str)).toString().replace("/root/", "/document/");
                            String stringBuilder = scheme + "%3A" + statusDir;
                            intent.putExtra(str, Uri.parse(stringBuilder));
                        } else {
                            intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                            intent.putExtra(str, Uri.parse(statusDir));
                        }
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                        startActivityForResult(intent, 111);
                    }
                });
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 111 && resultCode == Activity.RESULT_OK) {
            try {
                Uri uri;
                if (data != null) {
                    uri = data.getData();
                    if (uri != null) {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        if (uri.toString().endsWith("Android%2Fmedia")) {
                            new PreferenceUtil(this).putString(PreferenceUtil.KeyUseThisFolder, uri.toString());
                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    isRunning = false;
                                    permissionAllowCallBack(true);
                                }
                            }, 500);

                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }


    }

    AsyncTaskRunner asyncTaskRunner = null;

    public void scanMedia() {
        if (asyncTaskRunner == null) {
            asyncTaskRunner = new AsyncTaskRunner();
            asyncTaskRunner.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            asyncTaskRunner.cancel(true);
            asyncTaskRunner = null;
            new Handler(Looper.getMainLooper()).post(this::scanMedia);
        }
    }


    private class AsyncTaskRunner extends AsyncTask<Void, Void, Void> {
        public AsyncTaskRunner() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress.setVisibility(VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
          try {

                if (waVideoFragment != null) {
                    waVideoFragment.getVideoList();
                }
                if (waImageFragment != null) {
                    waImageFragment.getImageList();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
           return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);

            Constants.scanBothAppFile(statusSaverActivity, "", new Constants.CallBackOfListFiles() {
                @Override
                public void checkFile(String selectedFilePath) {
                    try {
                        if (waVideoFragment != null) {
                            waVideoFragment.checkData();
                        }
                        if (waImageFragment != null) {
                            waImageFragment.checkData();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    progress.setVisibility(GONE);
                }
            });


        }

        @Override
        protected void onCancelled(Void unused) {
            super.onCancelled(unused);
            progress.setVisibility(GONE);
        }


    }

    public PopupWindow popupWindowForSelectApp() {

        final PopupWindow popupWindow = new PopupWindow(StatusSaverActivity.this);


        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.more_layout, null);

        LinearLayout ll_wa = view.findViewById(R.id.ll_wa);
        LinearLayout ll_wab = view.findViewById(R.id.ll_wab);
        TextView tv_wa = view.findViewById(R.id.tv_wa);
        TextView tv_wab = view.findViewById(R.id.tv_wab);


        if (isStatusAppPresent) {
            tv_wa.setTextColor(Color.parseColor("#019553"));
            tv_wab.setTextColor(Color.parseColor("#000000"));
        } else {
            tv_wa.setTextColor(Color.parseColor("#000000"));
            tv_wab.setTextColor(Color.parseColor("#019553"));
        }

        ll_wa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isStatusAppPresent) {
                    isStatusAppPresent = true;
                    tv_wa.setTextColor(Color.parseColor("#019553"));
                    tv_wab.setTextColor(Color.parseColor("#FFFFFF"));

                    changeWaWb.setImageResource((isStatusAppPresent) ? R.drawable.wahts : R.drawable.buziness_);

                    scanMedia();

                }
                popupWindow.dismiss();
            }
        });

        ll_wab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isStatusAppPresent) {
                    isStatusAppPresent = false;
                    tv_wa.setTextColor(Color.parseColor("#FFFFFF"));
                    tv_wab.setTextColor(Color.parseColor("#019553"));
                    changeWaWb.setImageResource((isStatusAppPresent) ? R.drawable.wahts : R.drawable.buziness_);
                    scanMedia();
                }
                popupWindow.dismiss();
            }
        });

        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.setWidth(WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setContentView(view);

        return popupWindow;
    }


}