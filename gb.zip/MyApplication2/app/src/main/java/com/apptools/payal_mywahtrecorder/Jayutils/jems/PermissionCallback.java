package com.apptools.payal_mywahtrecorder.Jayutils.jems;

public interface PermissionCallback {
    default void onPermissionRequestFailed(){}
    default void onPermRequested(){}
    void onSuccess();
    default void onPermNotGranted(){}
}

