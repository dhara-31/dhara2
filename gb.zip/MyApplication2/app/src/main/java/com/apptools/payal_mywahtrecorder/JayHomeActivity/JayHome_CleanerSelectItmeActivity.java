package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.apptools.payal_mywahtrecorder.JayFragments.ReceivedFragment;
import com.apptools.payal_mywahtrecorder.JayFragments.SentFragment;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.JayHomeadapter.ViewPagerAdapter;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;
import com.apptools.payal_mywahtrecorder.Jayutils.ScrViewPager;


public class JayHome_CleanerSelectItmeActivity extends AppCompatActivity {

    PreferenceUtil preferenceUtil;
    private TextView text_tool_tital_set;
    ImageView image_set_back_tool;

    TextView text_received, text_sent;
    View view_recevi, view_sent;
    ScrViewPager viewpager_stus;
    ViewPagerAdapter viewPagerAdapter;
    RelativeLayout relative_tabLayout_stus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cleaner_select_itmetools);


        preferenceUtil = new PreferenceUtil(this);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        text_tool_tital_set = findViewById(R.id.activity_name_text);
        image_set_back_tool = findViewById(R.id.img_back_btn);
        text_tool_tital_set.setText(preferenceUtil.getString(PreferenceUtil.SET_SELECT_TITAL, ""));
        image_set_back_tool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        text_received = findViewById(R.id.text_received);
        text_sent = findViewById(R.id.text_sent);
        view_recevi = findViewById(R.id.view_recevi);
        view_sent = findViewById(R.id.view_sent);
        viewpager_stus = findViewById(R.id.viewpager_stus);
        relative_tabLayout_stus = findViewById(R.id.relative_tabLayout_stus);


        String nike_name = preferenceUtil.getString(PreferenceUtil.SET_NIIK_TITAL, "");
        if (nike_name.equals("Stickers") || nike_name.equals("Backups") || nike_name.equals("Voice")) {

            relative_tabLayout_stus.setVisibility(View.GONE);
            viewpager_stus.setCanScroll(false);

        } else {

            relative_tabLayout_stus.setVisibility(View.VISIBLE);
            viewpager_stus.setCanScroll(true);

        }

        text_received.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                viewpager_stus.setCurrentItem(0);

                view_recevi.setVisibility(View.VISIBLE);
                view_sent.setVisibility(View.INVISIBLE);
            }
        });
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        text_sent.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                viewpager_stus.setCurrentItem(1);
                view_sent.setVisibility(View.VISIBLE);
                view_recevi.setVisibility(View.INVISIBLE);
            }
        });


        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        viewPagerAdapter.add(new ReceivedFragment());
        viewPagerAdapter.add(new SentFragment());
        viewpager_stus.setOffscreenPageLimit(0);
        viewpager_stus.setAdapter(viewPagerAdapter);
        viewpager_stus.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @SuppressLint("ResourceAsColor")
            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    view_recevi.setVisibility(View.VISIBLE);
                    view_sent.setVisibility(View.INVISIBLE);

                } else {
                    view_sent.setVisibility(View.VISIBLE);
                    view_recevi.setVisibility(View.INVISIBLE);
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    @Override
    protected void onResume() {
        super.onResume();


    }
}