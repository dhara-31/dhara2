package com.apptools.payal_mywahtrecorder.ads;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;

import android.app.Activity;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeAdView;
import com.facebook.ads.NativeAdViewAttributes;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jaymodel.MixerBannerModel;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.nativead.MediaView;

import java.util.ArrayList;

public class BigNativeAd {
    private static int[] preList = new int[]{R.drawable.qurekanative1, R.drawable.qurekanative2};

    private static int positionH = 0;
    public static com.google.android.gms.ads.nativead.NativeAd fhgfg;

    public static Integer ergt = 0;

    private static void attachNativeMSize(Activity activity, RelativeLayout xNewRelate, FrameLayout frameLayout) {


        try {

            if (fhgfg != null) {
                fhf(xNewRelate, activity);
                fhgfg = null;
                loadNatviddecgtm1(activity);
            } else {
                nativeDefaultLoad(activity, frameLayout, xNewRelate);
                if (fhgfg == null) {
                    ergt++;
                    if (ergt >= 5) {
                        ergt = 0;
                        fhgfg = null;
                        loadNatviddecgtm1(activity);
                    }
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    public static void nativeDefaultLoad(Activity activity, FrameLayout f1, RelativeLayout xNewRelate) {
        AppDetail appDetail = DApplication.getInstance().getAppDetails();
        if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                    boolean isDestroyed = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }

                    com.google.android.gms.ads.nativead.NativeAd banernativeAd_Default1 = null;
                    if (banernativeAd_Default1 != null) {
                        banernativeAd_Default1.destroy();
                    }
                    banernativeAd_Default1 = nativeAd;

                    xNewRelate.setVisibility(View.VISIBLE);

                    com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.ad_unified, null);
                    populateNativeAdView(banernativeAd_Default1, adView);
                    xNewRelate.removeAllViews();
                    xNewRelate.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(
                            new AdListener() {
                                @Override
                                public void onAdFailedToLoad(LoadAdError loadAdError) {

                                    Log.e("dtr", "onAdFailedToLoad: " + loadAdError.getMessage());
                                    attachNativeMSize1(activity, xNewRelate, f1);
                                }
                            })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            Log.e("dtr", "elsee: " );

            attachNativeMSize1(activity, xNewRelate, f1);

        }
    }

    public static void loadNatviddecgtm1(Activity activity) {
        AppDetail adidget = DApplication.getInstance().getAppDetails();
        if (adidget != null && adidget.getAdmobnative() != null && !TextUtils.isEmpty(adidget.getAdmobnative()) && adidget.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, adidget.getAdmobnative());

            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                    if (fhgfg != null) {
                        fhgfg.destroy();
                    }
                    fhgfg = null;
                    ergt = 0;
                    fhgfg = nativeAd;
                }
            });

            AdLoader adLoader = builder.withAdListener(
                            new AdListener() {
                                @Override
                                public void onAdFailedToLoad(LoadAdError loadAdError) {


                                }
                            })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        }


    }

    public static void populateNativeAdView(com.google.android.gms.ads.nativead.NativeAd nativeAd, com.google.android.gms.ads.nativead.NativeAdView adView) {

        adView.setMediaView((MediaView) adView.findViewById(R.id.ad_media));
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));

        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
        adView.getMediaView().setMediaContent(nativeAd.getMediaContent());


        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.GONE);
        } else {
            ((RatingBar) adView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.GONE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getMediaContent().getVideoController();

        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        } else {
        }
    }


    public static void fhf(RelativeLayout frameLayout, Activity activity) {
        frameLayout.setVisibility(View.VISIBLE);
        com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.ad_unified, null);
        populateNativeAdView(fhgfg, adView);
        frameLayout.removeAllViews();
        frameLayout.addView(adView);
    }


    private static void attachNativeMSize1(Activity activity, RelativeLayout xNewRelate, FrameLayout yOld) {
        try {
            if (DApplication.checkNetworkAvailable(activity)) {
                yOld.removeAllViews();
                yOld.setVisibility(View.VISIBLE);
                xNewRelate.setVisibility(View.VISIBLE);
                final float scale = activity.getResources().getDisplayMetrics().density;
                int dpCust = (int) (265 * scale);
                View viewHere = activity.getLayoutInflater().inflate(R.layout.layout_native_qureka, null, true);
                FrameLayout.LayoutParams parameFrames = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dpCust);
                yOld.addView(viewHere, parameFrames);
                ArrayList<MixerBannerModel> mixerBannerModels = new ArrayList<>();
                try {
                    if (DApplication.getSizeWay() == 1) {
                        for (int resourceId : preList) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 1);
                            mixerBannerModels.add(model);
                        }
                    } else if (DApplication.getSizeWay() == 2) {
                        for (int resourceId : unifiedMediaList) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 2);
                            mixerBannerModels.add(model);
                        }
                    } else {
                        mixerBannerModels = new ArrayList<>(unifiedMediaList.length + preList.length);
                        int newLsng = Math.min(unifiedMediaList.length, preList.length);
                        int posMizx = 0;
                        for (int i = 0; i < newLsng; i++) {
                            MixerBannerModel modelgame = new MixerBannerModel(unifiedMediaList[i], 2);
                            mixerBannerModels.add(posMizx++, modelgame);

                            MixerBannerModel modelqur = new MixerBannerModel(preList[i], 1);
                            mixerBannerModels.add(posMizx++, modelqur);
                        }
                        if (unifiedMediaList.length > preList.length) {
                            int newlength = unifiedMediaList.length - newLsng;
                            for (int i = 0; i < newlength; i++) {
                                MixerBannerModel mdelgame = new MixerBannerModel(unifiedMediaList[newLsng + i], 2);
                                mixerBannerModels.add(posMizx++, mdelgame);
                            }
                        } else {
                            int newlenght = preList.length - newLsng;
                            for (int i = 0; i < newlenght; i++) {
                                MixerBannerModel modelqur = new MixerBannerModel(preList[newLsng + i], 1);
                                mixerBannerModels.add(posMizx++, modelqur);
                            }
                        }
                    }
                } catch (Exception e) {
                    for (int resourceId : unifiedMediaList) {
                        MixerBannerModel mmixerBannerModeldel = new MixerBannerModel(resourceId, 2);
                        mixerBannerModels.add(mmixerBannerModeldel);
                    }
                }

                String sysysmtCa = "";
                try {
                    if (DApplication.getSizeWay() == 1 && !DApplication.getTwoUrk()) {
                        sysysmtCa = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                    } else if (DApplication.getSizeWay() == 2 && !DApplication.fourNativeUrl()) {
                        sysysmtCa = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                    } else {
                        if (mixerBannerModels.get(positionH).getQurOrGame() == 1 && !DApplication.getTwoUrk()) {
                            sysysmtCa = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                        } else if (!DApplication.fourNativeUrl()) {
                            sysysmtCa = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                        }
                    }
                } catch (Exception e) {

                }


                if (sysysmtCa != null && !TextUtils.isEmpty(sysysmtCa)) {
                    ImageView imgNewBannerQka = viewHere.findViewById(R.id.imgNewBannerQka);
                    try {
                        imgNewBannerQka.setImageResource(mixerBannerModels.get(positionH).getBannername());
                    } catch (Exception e) {
                        imgNewBannerQka.setImageResource(unifiedMediaList[0]);
                    }
                    positionH++;
                    try {
                        if (positionH >= mixerBannerModels.size()) {
                            positionH = 0;
                        }
                    } catch (Exception e) {
                        positionH = 0;
                    }

                    String finalLastURlToG = sysysmtCa;
                    imgNewBannerQka.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            DApplication.tabToIntent(activity, finalLastURlToG);
                        }
                    });
                } else {
                    yOld.setVisibility(View.INVISIBLE);
                    xNewRelate.setVisibility(View.GONE);
                }

            } else {
                yOld.setVisibility(View.INVISIBLE);
                xNewRelate.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }

    }

    public static void bignative(Activity activity, RelativeLayout relative, FrameLayout xFrame) {
        try {
            relative.setVisibility(View.VISIBLE);
            if (DApplication.getMeVcallApplication().adMainStateOfLive()) {
                relative.setVisibility(View.GONE);
                return;
            }
            if (!InterAdCall.checkConnection(activity)) {
                relative.setVisibility(View.GONE);
                return;
            }
            LayoutInflater inflater = LayoutInflater.from(activity);
            LinearLayout linearMainLoader = (LinearLayout) inflater.inflate(R.layout.item_loader_nbanner, xFrame, false);
            xFrame.addView(linearMainLoader);
            xFrame.setVisibility(View.VISIBLE);
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelper != null && myModelHelper.getFbnative() != null && !TextUtils.isEmpty(myModelHelper.getFbnative())) {
                NativeAd nativeView = new NativeAd(activity, myModelHelper.getFbnative());
                nativeView.loadAd(nativeView.buildLoadAdConfig().withAdListener(new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {

                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                        linearMainLoader.setVisibility(View.GONE);
                        attachNativeMSize(activity, relative, xFrame);
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        if (nativeView == null || nativeView != ad) {
                            return;
                        }
                        relative.setVisibility(View.VISIBLE);
                        xFrame.setVisibility(View.VISIBLE);
                        linearMainLoader.setVisibility(View.GONE);
                        if (nativeView.isAdLoaded() && !nativeView.isAdInvalidated()) {
                            xFrame.removeAllViews();
                            NativeAdViewAttributes attributes = new NativeAdViewAttributes(activity);
                            View mAdView = NativeAdView.render(activity, nativeView, attributes);
                            xFrame.addView(mAdView, new ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT));
                        }
                    }

                    @Override
                    public void onAdClicked(Ad ad) {

                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {

                    }
                }).build());
            } else {
                linearMainLoader.setVisibility(View.GONE);
                Log.e("dtr", "bignative: 111" );
                attachNativeMSize(activity, relative, xFrame);
            }
        } catch (Exception e) {

        }
    }

    private static int[] unifiedMediaList = new int[]{R.drawable.gamebanner1, R.drawable.gamebanner2, R.drawable.gamebanner3, R.drawable.gamebanner4, R.drawable.gamebanner5, R.drawable.gamebanner6, R.drawable.gamebanner7};


}