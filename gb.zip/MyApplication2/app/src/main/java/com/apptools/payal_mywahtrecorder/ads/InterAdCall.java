package com.apptools.payal_mywahtrecorder.ads;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayTokandata.RecorderTimer;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class InterAdCall {


    public static int myInterDetector = 0;

    public void callintermethod(Activity activity, boolean indictMe, OnCallbackExitFromInterad exitFromInterad) {

        Log.e("inter", "----: ---");
    /*    long now = System.currentTimeMillis();
        if (now - currentCa < oUtils) {
            Log.e("inter", "----: iff111111---");
            return;

        }*/
        // currentCa = now;
        onCallbackExitFromInterad = exitFromInterad;
        if (DApplication.getMeVcallApplication().bigForShowIfAvail() && DApplication.getUrlOne() && DApplication.getZopIntert()) {
            Log.e("inter", "cvalll: ---");
            if (onCallbackExitFromInterad != null) {
                onCallbackExitFromInterad.setOnInteradExitListener("");
                onCallbackExitFromInterad = null;
            }
            return;
        }
        if (!checkConnection(activity)) {
            Log.e("inter", "----: 3333333333333333333333333333---");
            if (onCallbackExitFromInterad != null) {
                onCallbackExitFromInterad.setOnInteradExitListener("");
                onCallbackExitFromInterad = null;
            }
            return;
        }
        if (DApplication.wholeInterCountdown() > 1) {


            Log.e("inter", "callintermethod: iff---" + myInterDetector + "== " + DApplication.wholeInterCountdown());
            if (DApplication.wholeInterCountdown() == myInterDetector) {
                myInterDetector = 1;
                runCounter(activity, indictMe);
                Log.e("inter", "callintermethod: 222---" + myInterDetector);
            } else {

                AppDetail adIdDetail = DApplication.getInstance().getAppDetails();
                if (adIdDetail != null && adIdDetail.getAdstatus().equalsIgnoreCase("1") && adIdDetail.getAppstatus() != null && !TextUtils.isEmpty(adIdDetail.getAppstatus()) &&  adIdDetail.getAppstatus().equalsIgnoreCase("1")) {
                    showQurekaorNextCall1(activity, true);
                    Log.e("inter", "callintermethod: 333---" + myInterDetector);
                   myInterDetector++;
                } else {
                    if (onCallbackExitFromInterad != null) {
                        onCallbackExitFromInterad.setOnInteradExitListener("");
                        onCallbackExitFromInterad = null;
                    }
                    myInterDetector++;
                }
                Log.e("inter", "callintermethod: 444---" + myInterDetector);
            }
        } else {
            Log.e("inter", "callintermethod: elseee" + myInterDetector);
            runCounter(activity, indictMe);
        }
    }


    public static boolean remixCoutn = true;

    public void showQurekaorNextCall(Activity activity, boolean viewWithCon) {

        if (mInterstitialAviddecgtm1 != null) {
            mInterstitialAviddecgtm1.show(activity);
        } else {
            showQurekaorNextCall1(activity, viewWithCon);
        }
    }

    public com.google.android.gms.ads.interstitial.InterstitialAd mInterstitialAviddecgtm1;

    public void loadviddecgtm(final Activity context) {
        AdRequest adRequest = new AdRequest.Builder().build();
        Log.e("TAG", "cc111: ");

        AppDetail adIdDetail = DApplication.getInstance().getAppDetails();
        if (adIdDetail != null) {
            Log.e("TAG", "cc: ");

            if (adIdDetail != null && adIdDetail.getAdstatus().equalsIgnoreCase("1") && adIdDetail.getAdmobinter() != null && !TextUtils.isEmpty(adIdDetail.getAdmobinter())) {
                com.google.android.gms.ads.interstitial.InterstitialAd.load(context, adIdDetail.getAdmobinter(), adRequest, new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd) {
                        mInterstitialAviddecgtm1 = interstitialAd;

                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {

                                mInterstitialAviddecgtm1 = null;
                                loadviddecgtm(context);
                                if (onCallbackExitFromInterad != null) {
                                    onCallbackExitFromInterad.setOnInteradExitListener("");
                                    onCallbackExitFromInterad = null;
                                }

                                // SplashActivity.apgtDopenD = true;
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                                mInterstitialAviddecgtm1 = null;
                                ///  SplashActivity.apgtDopenD = true;
                                if (onCallbackExitFromInterad != null) {
                                    onCallbackExitFromInterad.setOnInteradExitListener("");
                                    onCallbackExitFromInterad = null;
                                }

                            }

                            @Override
                            public void onAdShowedFullScreenContent() {

                                //SplashActivity.apgtDopenD = false;
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        mInterstitialAviddecgtm1 = null;
                        Log.e("TAG", "faill: ");

                    }
                });
            }
        }
    }

    public void showQurekaorNextCall1(Activity activity, boolean viewWithCon) {
        pauseRunDialog();

        if (!viewWithCon) {
            Log.e("inter", "showQurekaorNextCall1: -11--" );
            if (onCallbackExitFromInterad != null) {
                onCallbackExitFromInterad.setOnInteradExitListener("");
                onCallbackExitFromInterad = null;
            }
            return;
        }

        if (DApplication.getUrlOne() && DApplication.getZopIntert()) {

            Log.e("inter", "showQurekaorNextCall1: ---" );
            if (onCallbackExitFromInterad != null) {
                onCallbackExitFromInterad.setOnInteradExitListener("");
                onCallbackExitFromInterad = null;
            }
            return;
        }

        if (onCallbackExitFromInterad != null) {
            onCallbackExitFromInterad.setOnInteradExitListener("");
            onCallbackExitFromInterad = null;
        }

        String oneExplicit = "";
        String implicitInter = "";
        String cHelp = "";


        try {
            oneExplicit = DApplication.getMeVcallApplication().getAppDetails().getQurekaurl();
        } catch (Exception e) {

        }


        Log.e("inter", "nnn: ---" + oneExplicit);
        try {
            implicitInter = DApplication.getMeVcallApplication().getAppDetails().getAdmob3interstitial();
        } catch (Exception e) {

        }
        Log.e("inter", "9999: ---" + implicitInter);
        if (!TextUtils.isEmpty(oneExplicit) && !TextUtils.isEmpty(implicitInter)) {
            if (remixCoutn) {
                cHelp = implicitInter;
            } else {
                cHelp = oneExplicit;
            }
            remixCoutn = !remixCoutn;
            Log.e("inter", "mmmm: ---" + cHelp);
        } else if (!TextUtils.isEmpty(oneExplicit)) {
            cHelp = oneExplicit;
            Log.e("inter", "aaa: ---" + cHelp);
        } else if (!TextUtils.isEmpty(implicitInter)) {
            cHelp = implicitInter;
            Log.e("inter", "zzzz: ---" + cHelp);
        }

        Log.e("inter", "z: ---" + cHelp);
        try {
            if (!TextUtils.isEmpty(cHelp)) {

                Log.e("inter", "showQurekaorNextCall1: -callll--" + cHelp);
                CustomTabsIntent.Builder intent = new CustomTabsIntent.Builder();
                intent.setToolbarColor(ContextCompat.getColor(activity, R.color.white));
                CustomTabsIntent intentCustomTabs = intent.build();
                intentCustomTabs.intent.setPackage("com.android.chrome");
                intentCustomTabs.launchUrl(activity, Uri.parse(cHelp));
            }
        } catch (Exception e) {
            Log.e("inter", "showQurekaorNextCall1: -catchhh--" + e.getLocalizedMessage());
        }

    }

    public Dialog dialogHelpIndicate;

    public static InterAdCall getHelpIndicatorExplicit() {
        if (helpIndicatorExplicit == null) {
            helpIndicatorExplicit = new InterAdCall();
        }
        return helpIndicatorExplicit;

    }


    public interface OnCallbackExitFromInterad {
        void setOnInteradExitListener(String msg);
    }

    /*   public long currentCa = System.currentTimeMillis();
       private long oUtils = 700;*/
    OnCallbackExitFromInterad onCallbackExitFromInterad;


    public static boolean checkConnection(Activity activity) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            boolean isAvailableToCheck = false;
            if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                isAvailableToCheck = true;
            }
            return isAvailableToCheck;
        } catch (Exception e) {
            return false;
        }
    }


    private static InterstitialAd interRun;
    public static boolean isloadingOne = false;

    public void pauseRunDialog() {
        try {
            if (dialogHelpIndicate != null && dialogHelpIndicate.isShowing()) {
                dialogHelpIndicate.dismiss();
            }
        } catch (Exception e) {

        }
    }

    public static int qcounter = 1;

    public void showLadeodfe(Activity activity) {
        pauseRunDialog();

        dialogHelpIndicate = new Dialog(activity);
        dialogHelpIndicate.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialogHelpIndicate.requestWindowFeature(1);
        dialogHelpIndicate.setContentView(R.layout.dialog_loadingtools);
        dialogHelpIndicate.setCancelable(false);
        Window window = dialogHelpIndicate.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        dialogHelpIndicate.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.addFlags(2);
        window.setDimAmount(0.82f);
        window.setAttributes(attributes);
        try {
            if (!activity.isFinishing()) {
                dialogHelpIndicate.show();
            }
        } catch (Exception e) {

        }

    }

    public static void callForAniimation(Activity newactivity) {
        try {
            if (!InterAdCall.checkConnection(newactivity)) {
                return;
            }
            if (DApplication.getUrlOne() && DApplication.getZopIntert()) {
                return;
            }
            if (qcounter >= DApplication.newcountdon()) {
                qcounter = 1;
            } else {
                qcounter++;
                return;
            }
            if (DApplication.getMeVcallApplication() != null && DApplication.getMeVcallApplication().getAppDetails() != null &&
                    DApplication.getMeVcallApplication().getAppDetails().getInterstitialbackpress() != null &&
                    !TextUtils.isEmpty(DApplication.getMeVcallApplication().getAppDetails().getInterstitialbackpress()) &&
                    DApplication.getMeVcallApplication().getAppDetails().getInterstitialbackpress().equalsIgnoreCase("1")) {

                String urlToMe = "";
                String customUrk = "";
                String systemUrl = "";
                try {
                    urlToMe = DApplication.getMeVcallApplication().getAppDetails().getQurekaurl();
                } catch (Exception e) {

                }
                try {
                    customUrk = DApplication.getMeVcallApplication().getAppDetails().getAdmob3interstitial();
                } catch (Exception e) {

                }
                if (!TextUtils.isEmpty(urlToMe) && !TextUtils.isEmpty(customUrk)) {
                    if (remixCoutn) {
                        systemUrl = customUrk;
                    } else {
                        systemUrl = urlToMe;
                    }
                    remixCoutn = !remixCoutn;

                } else if (!TextUtils.isEmpty(urlToMe)) {
                    systemUrl = urlToMe;
                } else if (!TextUtils.isEmpty(customUrk)) {
                    systemUrl = customUrk;
                }

                try {
                    if (!TextUtils.isEmpty(systemUrl)) {
                        CustomTabsIntent.Builder intent = new CustomTabsIntent.Builder();
                        intent.setToolbarColor(ContextCompat.getColor(newactivity, R.color.white));
                        CustomTabsIntent customTabsIntent = intent.build();
                        customTabsIntent.intent.setPackage("com.android.chrome");
                        customTabsIntent.launchUrl(newactivity, Uri.parse(systemUrl));
                    }
                } catch (Exception e) {

                }
            }
        } catch (Exception e) {

        }

    }

    public RecorderTimer recorderTimer;

    public void loadMainIntersd(Activity activity) {
        if (!checkConnection(activity)) {
            return;
        }
        if (isloadingOne) {
            return;
        }
        isloadingOne = true;
        try {
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();

            if (myModelHelper != null && myModelHelper.getAdstatus() != null && !TextUtils.isEmpty(myModelHelper.getAdstatus()) && myModelHelper.getAdstatus().equalsIgnoreCase("1") && myModelHelper.getFbinter() != null && !TextUtils.isEmpty(myModelHelper.getFbinter())) {
                if (interRun == null || (!interRun.isAdLoaded() || interRun.isAdInvalidated())) {
                    interRun = new InterstitialAd(activity, myModelHelper.getFbinter());
                    InterstitialAd.InterstitialLoadAdConfig loadAdConfig = interRun.buildLoadAdConfig().withAdListener(new InterstitialAdListener() {
                        @Override
                        public void onInterstitialDisplayed(Ad ad) {

                        }

                        @Override
                        public void onInterstitialDismissed(Ad ad) {
                            if (interRun != null) {
                                interRun.destroy();
                            }
                            interRun = null;

                            if (onCallbackExitFromInterad != null) {
                                onCallbackExitFromInterad.setOnInteradExitListener("");
                                onCallbackExitFromInterad = null;
                            }

                          /*  if (MyVcallApplication.statusAfterCloseIntermediate()) {
                                loadMainIntersd(activity);
                            }*/
                        }

                        @Override
                        public void onError(Ad ad, AdError adError) {
                            isloadingOne = false;
                            if (interRun != null) {
                                interRun.destroy();
                            }
                            interRun = null;

                            if (onCallbackExitFromInterad != null) {
                                try {
                                    if (dialogHelpIndicate != null && dialogHelpIndicate.isShowing()) {
                                        try {
                                            if (recorderTimer != null) {
                                                recorderTimer.pause();
                                                recorderTimer.cancel();
                                            }
                                        } catch (Exception e) {
                                        }
                                        pauseRunDialog();
                                       // myInterDetector = DApplication.wholeInterCountdown();

                                        showQurekaorNextCall(activity, true);
                                    }
                                } catch (Exception e) {

                                }
                            }
                        }

                        @Override
                        public void onAdLoaded(Ad ad) {
                            isloadingOne = false;
                        }

                        @Override
                        public void onAdClicked(Ad ad) {

                        }

                        @Override
                        public void onLoggingImpression(Ad ad) {

                        }
                    }).build();
                    interRun.loadAd(loadAdConfig);

                } else {
                    isloadingOne = false;
                }

            } else {
                isloadingOne = false;
            }

        } catch (Exception e) {

        }

    }

    public void runCounter(Activity activity, boolean isshowinter) {
        try {
            if (recorderTimer != null) {
                recorderTimer.pause();
                recorderTimer.cancel();
            }
        } catch (Exception e) {
        }

        if (DApplication.getMeVcallApplication().bigForShowIfAvail()) {
            showQurekaorNextCall(activity, isshowinter);
            return;
        }

        if (interRun == null) {
            loadMainIntersd(activity);
        }
        showLadeodfe(activity);

        recorderTimer = new RecorderTimer(5000, 1000, true) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (millisUntilFinished <= 4200) {
                    // currentCa = System.currentTimeMillis();
                    if (interRun == null || !interRun.isAdLoaded() || interRun.isAdInvalidated()) {
                    } else {
                        try {
                            if (recorderTimer != null) {
                                recorderTimer.pause();
                                recorderTimer.cancel();
                            }
                        } catch (Exception e) {
                        }
                        pauseRunDialog();
                        interRun.show();
                    }
                }
            }

            @Override
            public void onFinish() {
                // currentCa = System.currentTimeMillis();
                pauseRunDialog();
                if (interRun == null || !interRun.isAdLoaded() || interRun.isAdInvalidated()) {
                   // myInterDetector = DApplication.wholeInterCountdown();
                    showQurekaorNextCall(activity, isshowinter);
                } else {
                    interRun.show();
                }
            }
        };
        recorderTimer.create();

    }


    public static InterAdCall helpIndicatorExplicit;


}
