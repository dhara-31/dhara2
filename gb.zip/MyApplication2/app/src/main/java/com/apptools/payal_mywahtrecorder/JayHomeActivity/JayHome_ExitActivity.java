package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class JayHome_ExitActivity extends AppCompatActivity {

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exittools);

        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon3), findViewById(R.id.frameQicon3));
        findViewById(R.id.no).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

        findViewById(R.id.yes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
    }

    @Override
    public void onBackPressed() {

        finish();


    }
}