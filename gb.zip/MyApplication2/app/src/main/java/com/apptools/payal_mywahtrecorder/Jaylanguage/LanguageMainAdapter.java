package com.apptools.payal_mywahtrecorder.Jaylanguage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.R;

import java.util.ArrayList;
import java.util.List;


public class LanguageMainAdapter extends RecyclerView.Adapter<LanguageMainAdapter.ViewHolder> implements Filterable {
    private Context context;
    private IClickLanguageMain iClickLanguage;
    private ArrayList<LanguageMainModel> listFilter;
    private List<LanguageMainModel> lists;

    public LanguageMainAdapter(Context context, ArrayList<LanguageMainModel> arrayList, IClickLanguageMain iClickLanguageMain) {
        this.context = context;
        this.lists = arrayList;
        this.listFilter = arrayList;
        this.iClickLanguage = iClickLanguageMain;
    }

    @Override 
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_language_main, viewGroup, false));
    }

    @Override 
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        final LanguageMainModel languageMainModel = this.lists.get(i);
        viewHolder.bind(languageMainModel);
        viewHolder.rlItem.setOnClickListener(new View.OnClickListener() { 
            @Override 
            public void onClick(View view) {
                LanguageMainAdapter.this.iClickLanguage.onClick(languageMainModel);
            }
        });
        Glide.with(this.context).load(Integer.valueOf(languageMainModel.getImage())).into(viewHolder.ivLang);
        if (languageMainModel.getCheck().booleanValue()) {
            viewHolder.ivSelect.setVisibility(View.VISIBLE);
        } else {
            viewHolder.ivSelect.setVisibility(View.GONE);
        }
    }

    @Override 
    public int getItemCount() {
        List<LanguageMainModel> list = this.lists;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    @Override 
    public Filter getFilter() {
        return new Filter() { 
            @Override 
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charSequence2 = charSequence.toString();
                if (charSequence2.isEmpty()) {
                    LanguageMainAdapter languageMainAdapter = LanguageMainAdapter.this;
                    languageMainAdapter.lists = languageMainAdapter.listFilter;
                } else {
                    ArrayList<LanguageMainModel> arrayList = new ArrayList<>();
                    for (LanguageMainModel languageMainModel : LanguageMainAdapter.this.listFilter) {
                        if (languageMainModel.getLanguageName().toLowerCase().contains(charSequence2.toLowerCase())) {
                            arrayList.add(new LanguageMainModel(languageMainModel.getLanguageName(), languageMainModel.getIsoLanguage(), languageMainModel.getCheck(), languageMainModel.getImage()));
                        }
                    }
                    LanguageMainAdapter.this.lists = arrayList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = LanguageMainAdapter.this.lists;
                return filterResults;
            }

            @SuppressLint("NotifyDataSetChanged")
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                LanguageMainAdapter.this.lists = (ArrayList<LanguageMainModel>) filterResults.values;
                LanguageMainAdapter.this.notifyDataSetChanged();
            }
        };
    }

    
    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivLang;
        ImageView ivSelect;
        RelativeLayout rlItem;
        TextView tvName;

        public ViewHolder(View view) {
            super(view);
            this.rlItem = (RelativeLayout) view.findViewById(R.id.rl_item_main);
            this.ivLang = (ImageView) view.findViewById(R.id.iv_lang_main);
            this.ivSelect = (ImageView) view.findViewById(R.id.iv_select);
            this.tvName = (TextView) view.findViewById(R.id.tv_name_main);
        }

        public void bind(LanguageMainModel languageMainModel) {
            this.tvName.setText(languageMainModel.getLanguageName());
        }
    }

    public void setSelectLanguage(LanguageMainModel languageMainModel) {
        for (LanguageMainModel model : this.lists) {
            model.setCheck(model.getLanguageName().equals(languageMainModel.getLanguageName()));
        }
        notifyDataSetChanged();
    }
}
