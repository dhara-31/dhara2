package com.apptools.payal_mywahtrecorder.JayHomeadapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerPriviewActivity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.JAydata.Savers;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;
import com.apptools.payal_mywahtrecorder.Jayutils.Utils;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;
import java.util.ArrayList;

public class MyAdapterSent extends RecyclerView.Adapter<MyAdapterSent.Dateviewsent> {

    Activity context;
    ArrayList<Savers> list_sent;
    String name;
    ClickSelect clickSelect;
    public static ArrayList<File> list_select_file_sent = new ArrayList<>();
    public static ArrayList<DocumentFile> list_select_doc_sent = new ArrayList<>();
    PreferenceUtil preferenceUtil;

    public MyAdapterSent(Activity requireActivity, ArrayList<Savers> list_sent, String name, ClickSelect clickSelect) {
        context = requireActivity;
        this.list_sent = list_sent;
        this.name = name;
        this.clickSelect = clickSelect;
        preferenceUtil = new PreferenceUtil(context);
        if (Build.VERSION.SDK_INT >= 30) {
            list_select_doc_sent = new ArrayList<>();
        } else {
            list_select_file_sent = new ArrayList<>();
        }
    }

    @NonNull
    @Override
    public Dateviewsent onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Dateviewsent(LayoutInflater.from(context).inflate(R.layout.item_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Dateviewsent holder, @SuppressLint("RecyclerView") int position) {
        if (Build.VERSION.SDK_INT >= 30) {
            handleSelectionForDocumentFile(holder, list_sent.get(position).getDocumentFile());
        } else {
            handleSelectionForFile(holder, list_sent.get(position).getFile());
        }
        switch (name) {
            case "Images":
            case "Gifs":
            case "Stickers": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._8sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._8sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.item_image_date_realti.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 30) {
                    Glide.with(context).load(list_sent.get(position).getUri()).into(holder.item_image);
                } else {
                    Glide.with(context).load(list_sent.get(position).getFile()).into(holder.item_image);
                }
                break;
            }
            case "Videos": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_video_item.setVisibility(View.VISIBLE);
                holder.item_text_item_name.setText(list_sent.get(position).getTitle());
                holder.item_text_item_size.setText(JemsProviderKt.getMyString(context, R.string.size) + " " + Utils.readableFileSize(list_sent.get(position).getSize()));
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        Glide.with(context).load(list_sent.get(position).getUri()).into(holder.img_set_select_video);
                    } else {
                        Glide.with(context).load(list_sent.get(position).getFile()).into(holder.img_set_select_video);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                break;
            }
            case "Documents": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_sent.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.icon_documents_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(context, R.string.size) + " " + Utils.readableFileSize(list_sent.get(position).getSize()));


                break;
            }
            case "Audio": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_sent.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.icon_audio_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(context, R.string.size) + " " + Utils.readableFileSize(list_sent.get(position).getSize()));

                break;
            }
            case "Voice": {
                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_sent.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.voice_notes_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(context, R.string.size) + " " + Utils.readableFileSize(list_sent.get(position).getSize()));

                break;
            }
            case "Backups": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_sent.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.icon_backup_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(context, R.string.size) + " " + Utils.readableFileSize(list_sent.get(position).getSize()));

                break;
            }
        }
        holder.img_check_un.setOnClickListener(v -> {
            holder.img_check_un.setVisibility(View.GONE);
            holder.img_check_ed.setVisibility(View.VISIBLE);


            if (Build.VERSION.SDK_INT >= 30) {

                if (list_select_doc_sent.size() == 0) {
                    list_select_doc_sent = new ArrayList<>();
                    list_select_doc_sent.add(list_sent.get(position).getDocumentFile());
                } else {
                    list_select_doc_sent.add(list_sent.get(position).getDocumentFile());
                }

                clickSelect.onclickdata(list_select_doc_sent.size());

            } else {
                if (list_select_file_sent.size() == 0) {
                    list_select_file_sent = new ArrayList<>();
                    list_select_file_sent.add(list_sent.get(position).getFile());

                } else {
                    list_select_file_sent.add(list_sent.get(position).getFile());
                }

                clickSelect.onclickdata(list_select_file_sent.size());
            }


        });
        holder.img_check_ed.setOnClickListener(v -> {
            holder.img_check_un.setVisibility(View.VISIBLE);
            holder.img_check_ed.setVisibility(View.GONE);

            if (Build.VERSION.SDK_INT >= 30) {
                for (int i = 0; i < list_select_doc_sent.size(); i++) {

                    if (list_select_doc_sent.get(i).equals(list_sent.get(position).getDocumentFile())) {
                        list_select_doc_sent.remove(i);
                    }
                }

                clickSelect.onclickdata(list_select_doc_sent.size());

            } else {
                for (int i = 0; i < list_select_file_sent.size(); i++) {

                    if (list_select_file_sent.get(i).equals(list_sent.get(position).getFile())) {
                        list_select_file_sent.remove(i);
                    }
                }

                clickSelect.onclickdata(list_select_file_sent.size());
            }

        });
        holder.itemView.setOnClickListener(v -> {


            if (Build.VERSION.SDK_INT >= 30) {

                JayHome_CleanerPriviewActivity.documentFile = list_sent.get(position).getDocumentFile();

            } else {

                JayHome_CleanerPriviewActivity.file = list_sent.get(position).getFile();
            }

            if (name.equals("Images") || name.equals("Videos") || name.equals("Audio") || name.equals("Stickers") || name.equals("Gifs")) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(context, true, msg -> {
                    Intent intent = new Intent(context, JayHome_CleanerPriviewActivity.class);
                    intent.putExtra("SELECT_SENT_REVE", 22);
                    intent.putExtra("select_pos", position);
                    context.startActivity(intent);
                });



            } else if (name.equals("Documents")) {
                Uri outputFileUri = null;
                if (Build.VERSION.SDK_INT < 30) {
                    outputFileUri = FileProvider.getUriForFile(context, context.getPackageName() + ".provider", list_sent.get(position).getFile());
                } else {
                    outputFileUri = list_sent.get(position).getDocumentFile().getUri();
                }

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setDataAndType(outputFileUri, Utils.isFileType(list_sent.get(position).getPath()));
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    context.startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(context, "No App Found For Preview", Toast.LENGTH_LONG).show();
                }

            } else {

                if (name.equals("Voice")) {
                    Toast.makeText(context, "Voice file not open", Toast.LENGTH_LONG).show();

                } else {

                    Toast.makeText(context, "Backup file not open", Toast.LENGTH_LONG).show();
                }
            }


        });


    }

    private void handleSelectionForDocumentFile(Dateviewsent holder, DocumentFile documentFile) {
        for (DocumentFile selectedDoc : list_select_doc_sent) {
            if (documentFile.toString().equals(selectedDoc.toString())) {
                showSelected(holder);
                return;
            }
        }
        showUnselected(holder);
    }

    private void handleSelectionForFile(Dateviewsent holder, File file) {
        for (File selectedFile : list_select_file_sent) {
            if (file.toString().equals(selectedFile.toString())) {
                showSelected(holder);
                return;
            }
        }
        showUnselected(holder);
    }

    private void showSelected(Dateviewsent holder) {
        holder.img_check_ed.setVisibility(View.VISIBLE);
        holder.img_check_un.setVisibility(View.GONE);
    }

    private void showUnselected(Dateviewsent holder) {
        holder.img_check_ed.setVisibility(View.GONE);
        holder.img_check_un.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return list_sent.size();
    }

    public void updatelist(ArrayList<Savers> list_sent) {
        this.list_sent = list_sent;

        notifyDataSetChanged();

    }

    public void updatelistdoc(ArrayList<DocumentFile> list_select_doc_sent) {
        this.list_select_doc_sent = list_select_doc_sent;
        notifyDataSetChanged();
    }

    public void updatelistfile(ArrayList<File> list_select_file_sent) {
        this.list_select_file_sent = list_select_file_sent;
        notifyDataSetChanged();
    }

    public interface ClickSelect {
        void onclickdata(int total);
    }

    class Dateviewsent extends RecyclerView.ViewHolder {

        ImageView item_image, img_set_select_video, img_set_select_icon;
        RelativeLayout realti_video_item, realti_set_select_last;
        CardView item_image_date_realti;
        TextView item_text_item_name, item_text_item_size,
                item_text_item_name_select, item_text_item_size_audo, item_text_item_time_dures_audo;

        RelativeLayout realti_check_box_an_ed;
        ImageView img_check_un, img_check_ed;

        public Dateviewsent(@NonNull View itemView) {
            super(itemView);

            item_image = itemView.findViewById(R.id.item_image);
            img_set_select_video = itemView.findViewById(R.id.img_set_select_video);
            realti_video_item = itemView.findViewById(R.id.realti_video_item);
            item_image_date_realti = itemView.findViewById(R.id.item_image_date_realti);
            item_text_item_name = itemView.findViewById(R.id.item_text_item_name);
            item_text_item_size = itemView.findViewById(R.id.item_text_item_size);
            item_text_item_name_select = itemView.findViewById(R.id.item_text_item_name_select);
            realti_set_select_last = itemView.findViewById(R.id.realti_set_select_last);
            img_set_select_icon = itemView.findViewById(R.id.img_set_select_icon);
            item_text_item_time_dures_audo = itemView.findViewById(R.id.item_text_item_time_dures_audo);
            item_text_item_size_audo = itemView.findViewById(R.id.item_text_item_size_audo);

            realti_check_box_an_ed = itemView.findViewById(R.id.realti_check_box_an_ed);
            img_check_un = itemView.findViewById(R.id.img_check_un);
            img_check_ed = itemView.findViewById(R.id.img_check_ed);
        }
    }
}
