package com.apptools.payal_mywahtrecorder.JAydata;

public class PerferencedName {
    public static final String RECORD_MODE = "record_mode";
}
