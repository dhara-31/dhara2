package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.JayTokandata.Glob;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

public class Quotes_sub_Activity extends AppCompatActivity {


    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quotes_sub);
        
        activity = this;

        RecyclerView rvQuotesText = findViewById(R.id.rvQuotesText);
        String[] quotesMainCategoryListArray = Glob.quotesCategoryList1Main(this);


        Intent onintent = getIntent();
        int categoryItemClick_key = onintent.getIntExtra("categoryItemClick_key", 1);
        TextView titleQuotes = findViewById(R.id.titleQuotes);
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        if (categoryItemClick_key == 1) {
            titleQuotes.setText(Glob.quotesCategoryList[0] + "Quotes");
            quotesMainCategoryListArray = Glob.quotesCategoryList1Main(this);
        } else {
            if (categoryItemClick_key == 2) {
                titleQuotes.setText(Glob.quotesCategoryList[1] + "Quotes");
                quotesMainCategoryListArray = Glob.quotesCategoryList2Main(this);
            } else {
                if (categoryItemClick_key == 3) {
                    titleQuotes.setText(Glob.quotesCategoryList[2] + "Quotes");
                    quotesMainCategoryListArray = Glob.quotesCategoryList3Main(this);
                } else if (categoryItemClick_key == 4) {
                    titleQuotes.setText(Glob.quotesCategoryList[3] + "Quotes");
                    quotesMainCategoryListArray = Glob.quotesCategoryList4Main(this);
                } else if (categoryItemClick_key == 5) {
                    titleQuotes.setText(Glob.quotesCategoryList[4] + "Quotes");
                    quotesMainCategoryListArray = Glob.quotesCategoryList5Main(this);
                } else if (categoryItemClick_key == 6) {
                    titleQuotes.setText(Glob.quotesCategoryList[5] + "Quotes");
                    quotesMainCategoryListArray = Glob.quotesCategoryList6Main(this);
                } else if (categoryItemClick_key == 7) {
                    titleQuotes.setText(Glob.quotesCategoryList[6] + "Quotes");
                    quotesMainCategoryListArray = Glob.quotesCategoryList7Main(this);
                } else {
                    if (categoryItemClick_key == 8) {
                        titleQuotes.setText(Glob.quotesCategoryList[7] + "Quotes");
                        quotesMainCategoryListArray = Glob.quotesCategoryList8Main(this);
                    } else if (categoryItemClick_key == 9) {

                        titleQuotes.setText(Glob.quotesCategoryList[8] + "Quotes");
                        quotesMainCategoryListArray = Glob.quotesCategoryList9Main(this);
                    } else {
                        titleQuotes.setText(Glob.quotesCategoryList[9] + "Quotes");
                        quotesMainCategoryListArray = Glob.quotesCategoryList10Main(this);
                    }
                }
            }
        }

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        QuotesSubCategoryAdapter quotesSubCategoryAdapter = new QuotesSubCategoryAdapter(quotesMainCategoryListArray);
        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }
        rvQuotesText.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        rvQuotesText.setItemAnimator(new DefaultItemAnimator());
        rvQuotesText.setAdapter(quotesSubCategoryAdapter);

    }

    private long mLastClickTime = 0;
    private static final long CLICK_TIME_INTERVAL = 1100;

    public class QuotesSubCategoryAdapter extends RecyclerView.Adapter<QuotesSubCategoryAdapter.MyViewHolder> {

        private String[] quotesMainCatArry;


        public QuotesSubCategoryAdapter(String[] quotesMainCatArry) {
            this.quotesMainCatArry = quotesMainCatArry;
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_quotes, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            try {
                holder.titleTextQuotesItem.setText(quotesMainCatArry[position].toString());
            } catch (Exception e) {

            }

            holder.buttonClickItemCopy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                        return;
                    }
                    mLastClickTime = now;


                    try {
                        if (!TextUtils.isEmpty(holder.titleTextQuotesItem.getText().toString().trim())) {
                            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            clipboardManager.setPrimaryClip(ClipData.newPlainText("text", holder.titleTextQuotesItem.getText().toString()));
                            Toast.makeText(activity, JemsProviderKt.getMyString(activity,R.string.text_copied_successfully), Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(activity, JemsProviderKt.getMyString(activity, R.string.quotes_not_found), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                    }

                }
            });

            holder.buttonClickItemShare.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                        return;
                    }
                    mLastClickTime = now;

                    try {
                        if (!TextUtils.isEmpty(holder.titleTextQuotesItem.getText().toString().trim())) {
                            Intent intent = new Intent(Intent.ACTION_SEND);
                            intent.setType("text/plain");
                            intent.putExtra(Intent.EXTRA_TEXT, holder.titleTextQuotesItem.getText().toString());
                            startActivity(Intent.createChooser(intent, "share_using"));
                        } else {
                            Toast.makeText(activity, JemsProviderKt.getMyString(activity,R.string.quotes_not_found), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {

                    }
                }
            });
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {

            TextView titleTextQuotesItem;
            ImageView buttonClickItemCopy;
            ImageView buttonClickItemShare;

            public MyViewHolder(View view) {
                super(view);
                titleTextQuotesItem = view.findViewById(R.id.titleTextQuotesItem);
                buttonClickItemCopy = view.findViewById(R.id.buttonClickItemCopy);
                buttonClickItemShare = view.findViewById(R.id.buttonClickItemShare);

            }
        }

        @Override
        public int getItemCount() {
            return quotesMainCatArry.length;
        }
    }

    @Override
    public void onBackPressed() {
        finish();
        InterAdCall.callForAniimation(this);
    }
}