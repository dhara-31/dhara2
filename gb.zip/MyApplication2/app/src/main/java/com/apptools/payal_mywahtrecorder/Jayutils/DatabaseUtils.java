package com.apptools.payal_mywahtrecorder.Jayutils;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaScannerConnection;
import android.net.Uri;

import com.apptools.payal_mywahtrecorder.JAydata.AppData;
import com.apptools.payal_mywahtrecorder.JAydata.AppInfo;
import com.apptools.payal_mywahtrecorder.JAydata.RecordData;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DatabaseUtils extends SQLiteOpenHelper {
    public static final String CREATE_TABLE_APPS = "create table Apps (id integer primary key autoincrement, packageName text)";
    public static final String CREATE_TABLE_RECORDS = "create table Records (id integer primary key autoincrement, packageName text, name text, path text, recordTime integer)";
    public static final String DB_NAME = "core_data.db";
    public static final int DB_VERSION = 1;
    public static final String TABLE_APPS = "Apps";
    public static final String TABLE_RECORDS = "Records";
    public static DatabaseUtils instance;
    public boolean checkedAppTabel;
    public boolean checkedVideoTabel;
    public SQLiteDatabase db;



    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public DatabaseUtils() {
        super(DApplication.getContext(), DB_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        this.checkedVideoTabel = false;
        this.checkedAppTabel = false;
        if (instance == null) {
            this.db = getWritableDatabase();
            return;
        }
        throw new Error("Singleton!");
    }


    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(CREATE_TABLE_APPS);
        sQLiteDatabase.execSQL(CREATE_TABLE_RECORDS);
        this.db = sQLiteDatabase;
        checkHotGames();
    }

    public List<AppData> getAppsList() {
        Cursor query = this.db.query(TABLE_APPS, null, null, null, null, null, null);
        ArrayList<AppData> arrayList = new ArrayList<>();
        if (query.moveToFirst()) {
            do {
                arrayList.add(AppData.create(query));
            } while (query.moveToNext());
        }
        return arrayList;
    }

    public void addApp(String str) {
        this.db.insert(TABLE_APPS, null, AppData.create(str).getValues());
    }


    public List<RecordData> getRecordList() {
        Cursor query = this.db.query(TABLE_RECORDS, null, null, null, null, null, null);
        ArrayList<RecordData> arrayList = new ArrayList<RecordData>();
        ArrayList<RecordData> arrayList2 = new ArrayList<RecordData>();
        if (query.moveToFirst()) {
            do {
                RecordData create = RecordData.create(query);
                if (this.checkedVideoTabel || new File(create.path).exists()) {
                    arrayList.add(create);
                } else {
                    arrayList2.add(create);
                }
            } while (query.moveToNext());
            this.checkedVideoTabel = true;
        }
        if (arrayList2.size() > 0) {
            for (int i = 0; i < arrayList2.size(); i++) {
                removeRecord(arrayList2.get(i));
            }
        }
        return arrayList;
    }

    public long addRecord(RecordData recordData) {
        MediaScannerConnection.scanFile(DApplication.getContext(), new String[]{recordData.path}, null, new MediaScannerConnection.MediaScannerConnectionClient() {
            @Override
            public void onMediaScannerConnected() {

            }

            @Override
            public void onScanCompleted(String path, Uri uri) {

            }
        });


        return this.db.insert(TABLE_RECORDS, null, recordData.getValues());

    }

    public void removeRecord(RecordData recordData) {
        this.db.delete(TABLE_RECORDS, "id=?", new String[]{recordData.id + ""});
    }

    public static DatabaseUtils getInstance() {
        if (instance == null) {
            instance = new DatabaseUtils();
        }
        return instance;
    }

    private void checkHotGames() {
        HashMap<String, Boolean> hashMap = new HashMap<>();
        hashMap.put("com.mojang.minecraftpe", true);
        hashMap.put("com.nintendo.zara", true);
        hashMap.put("com.supercell.clashroyale", true);
        hashMap.put("com.nianticlabs.pokemongo", true);
        hashMap.put("com.kleientertainment.doNotStarvePocket", true);
        hashMap.put("com.king.candycrushsodasaga", true);
        hashMap.put("com.ea.games.nfs13_na", true);
        hashMap.put("com.t2ksports.nba2k17android", true);
        hashMap.put("com.ninjakiwi.bloonstd5", true);
        hashMap.put("com.cmplay.tiles2", true);
        hashMap.put("com.machinezone.gow", true);
        hashMap.put("com.king.candycrushsaga", true);
        hashMap.put("com.supercell.clashofclans", true);
        hashMap.put("com.gameloft.android.ANMP.GloftDMHM", true);
        hashMap.put("com.kiloo.subwaysurf", true);
        hashMap.put("air.com.hypah.io.slither", true);
        hashMap.put("com.sega.sonic1px", true);
        List<AppInfo> installedAppList = AppUtils.getInstalledAppList();
        for (int i = 0; i < installedAppList.size(); i++) {
            AppInfo appInfo = installedAppList.get(i);

            if (hashMap.containsKey(appInfo.pkg)) {
                addApp(appInfo.pkg);
            }
        }
    }
}
