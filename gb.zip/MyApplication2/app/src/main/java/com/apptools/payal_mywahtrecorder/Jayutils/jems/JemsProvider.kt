package com.apptools.payal_mywahtrecorder.Jayutils.jems

import android.Manifest
import android.Manifest.permission
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil
import java.io.File
import java.util.Locale


fun Context.getSharedPreference(): SharedPreferences {
    return this.getSharedPreferences("app", 0)
}

fun Context.getMyString(int: Int): String {
    return try {
        getMyResource().getString(int)
    } catch (e: Exception) {
        ""
    }
}

fun Context.getMyResource(): Resources {
    val languageCode = getSharedPreferences("MY_PRE", 0).getString("KEY_LANGUAGE", "") ?: ""
    val locale = Locale(languageCode)
    Locale.setDefault(locale)
    val configuration = resources.configuration
    configuration.setLocale(locale)
    return createConfigurationContext(configuration).resources
}

fun Context.needTranslateAdContent(): Boolean {
    return false
}

fun Context.languageFlag(): Boolean {
    return true
}

fun Context.isNeedToShowLanguage(): Boolean {
    return getSharedPreference().getBoolean("Language", true)
}

fun Context.languageDone() {
    getSharedPreference().edit().putBoolean("Language", false).apply()
}

fun Int?.orZero(): Int {
    return this ?: 0
}

fun simpleReadWritePermission(): ArrayList<String> {
    val list = java.util.ArrayList<String>()
 
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        list.add(permission.READ_MEDIA_VIDEO)
        list.add(permission.READ_MEDIA_IMAGES)
    }else{
        list.add(permission.READ_EXTERNAL_STORAGE)
        list.add(permission.WRITE_EXTERNAL_STORAGE)
    }
    return list;
}

fun readVideoOrExternalPermission(): String {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
}

fun Context.isStatusPermissionAllow(): Boolean {
    val strUri = PreferenceUtil(this).getString(PreferenceUtil.KeyUseThisFolder, "")
    return if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
        strUri.isNotEmpty()
    } else {
        checkSelfPermission(readVideoOrExternalPermission()) == PackageManager.PERMISSION_GRANTED
    }
}

fun Context.getWABPath(): String {
    return if (Build.VERSION.SDK_INT < 30) {
        Environment.getExternalStorageDirectory().path + File.separator + "VideoCallRecorder/StatusWAB"
    } else {
        filesDir.toString() + File.separator + "VideoCallRecorder/StatusWAB"
    }
}
fun isScreenOn(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager?
    return pm?.isScreenOn ?: false
}

fun Context.getWAPath(): String {
    return if (Build.VERSION.SDK_INT < 30) {
       Environment.getExternalStorageDirectory().getPath() + File.separator + "VideoCallRecorder/StatusWA";
    } else {
       getFilesDir().toString() + File.separator + "VideoCallRecorder/StatusWA";
    }
}

public interface SimpleCallBack {
    
    fun callBack()
}