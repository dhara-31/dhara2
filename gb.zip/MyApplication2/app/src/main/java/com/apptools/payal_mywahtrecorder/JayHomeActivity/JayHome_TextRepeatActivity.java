package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

public class JayHome_TextRepeatActivity extends AppCompatActivity {
    EditText etTextRepetition;
    LinearLayout result;
    EditText etMessageText;
    NestedScrollView textNested;


    @Override
    protected void onPause() {
        super.onPause();
        etMessageText.clearFocus();
        etTextRepetition.clearFocus();
    }

    private Activity activity;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_show);
        activity = this;

        initBackView();

        TextView etPreviewText = findViewById(R.id.etPreviewText);
        LinearLayout layWantNextLine = findViewById(R.id.layWantNextLine);
        LinearLayout layWantSpace = findViewById(R.id.layWantSpace);
        etTextRepetition = findViewById(R.id.etTextRepetition);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        etMessageText = findViewById(R.id.etMessageText);
        ImageView switchButtonLine = findViewById(R.id.switchButtonLine);
        ImageView switchButtonSpace = findViewById(R.id.switchButtonSpace);
        textNested = findViewById(R.id.textNested);


        result = findViewById(R.id.result);
        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

        etMessageText.setOnTouchListener((v, event) -> {
            if (etMessageText.hasFocus()) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_SCROLL:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        return true;
                }
            }
            return false;
        });
        textNested.setOnTouchListener((v, event) -> {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            switch (event.getAction() & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_SCROLL:
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
            }
            return false;
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        buttonClickGenerateMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard(JayHome_TextRepeatActivity.this);


                String varMessage = etMessageText.getText().toString().trim();
                String varRepetition = etTextRepetition.getText().toString().trim();
                if (TextUtils.isEmpty(varMessage)) {
                    etMessageText.setError(JemsProviderKt.getMyString(activity, R.string.please_enter_message));
                } else if (TextUtils.isEmpty(varRepetition)) {
                    etTextRepetition.setError(JemsProviderKt.getMyString(activity, R.string.please_enter_repetition));
                } else if (etTextRepetition.getText().toString().length() < 1) {
                    etTextRepetition.setError(JemsProviderKt.getMyString(activity, R.string.enter_valid_numbers));
                } else {
                    result.setVisibility(View.VISIBLE);
                    int repeatNumber = 0;
                    try {
                        repeatNumber = Integer.parseInt(varRepetition);
                    } catch (Exception e) {

                    }
                    if (repeatNumber < 1) {
                        etTextRepetition.setError(JemsProviderKt.getMyString(activity, R.string.enter_valid_numbers));
                    } else if (repeatNumber > 300) {
                        etTextRepetition.setError(JemsProviderKt.getMyString(activity, R.string.enter_less_than_300));
                    } else {
                        try {
                            StringBuilder sBuilder = new StringBuilder();

                            for (int i = 0; i < repeatNumber; i++) {
                                sBuilder.append(etMessageText.getText().toString());
                                if (wanSpace) {
                                    sBuilder.append(" ");
                                }
                                if (wantNextLine) {
                                    sBuilder.append("\n");
                                }
                            }
                            hideKeyboard(JayHome_TextRepeatActivity.this);
                            etPreviewText.setText(sBuilder.toString());
                        } catch (Exception e) {

                        }
                    }

                }
            }
        });
        BannerAdLayout.fillMeAlone(this, findViewById(R.id.relQbanner1), findViewById(R.id.frameQbanner1));
        setDefaultRepetition(etPreviewText);
        layWantNextLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (wantNextLine) {
                    wantNextLine = false;
                    switchButtonLine.setImageResource(R.drawable.ic_switch_uncheck);

                } else {
                    switchButtonLine.setImageResource(R.drawable.ic_switch_check);
                    wantNextLine = true;
                }

            }
        });
        layWantSpace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (wanSpace) {
                    wanSpace = false;
                    switchButtonSpace.setImageResource(R.drawable.ic_switch_uncheck);
                } else {
                    wanSpace = true;
                    switchButtonSpace.setImageResource(R.drawable.ic_switch_check);
                }
            }
        });
        buttonClickResetText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPreviewText.setText("");
                etPreviewText.clearFocus();
                etPreviewText.setError(null);
                etMessageText.setText("");
                etMessageText.clearFocus();
                etMessageText.setError(null);
                etTextRepetition.setText("");
                etTextRepetition.clearFocus();
                etTextRepetition.setError(null);
                result.setVisibility(View.GONE);
            }
        });
        buttonClickCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - lastTime < CLICK_INTERVAL) {
                    return;
                }
                lastTime = now;

                if (!TextUtils.isEmpty(etPreviewText.getText().toString().trim())) {
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    clipboardManager.setPrimaryClip(ClipData.newPlainText("text", etPreviewText.getText().toString()));

                    Toast toast = Toast.makeText(JayHome_TextRepeatActivity.this, "Text copied successfully.", Toast.LENGTH_SHORT);
                    toast.show();

                } else {
                    Toast.makeText(JayHome_TextRepeatActivity.this, JemsProviderKt.getMyString(activity, R.string.quotes_not_found), Toast.LENGTH_SHORT).show();
                }
            }
        });
        buttonClickShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - lastTime < CLICK_INTERVAL) {
                    return;
                }
                lastTime = now;

                String varPreviewStr = etPreviewText.getText().toString().trim();

                if (!TextUtils.isEmpty(varPreviewStr.trim())) {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TEXT, varPreviewStr);
                    startActivity(Intent.createChooser(intent, "share using"));
                } else {
                    Toast.makeText(JayHome_TextRepeatActivity.this, JemsProviderKt.getMyString(activity, R.string.error_while_share_please_try_again), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private long lastTime = 0l;
    private static final long CLICK_INTERVAL = 1000L;

    @Override
    public void onBackPressed() {
        finish();
        InterAdCall.callForAniimation(this);
    }

    private void setDefaultRepetition(TextView etPreviewText) {
        try {
            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < 5; i++) {
                sBuilder.append(etMessageText.getText().toString());
                if (wanSpace) {
                    sBuilder.append(" ");
                }
                if (wantNextLine) {
                    sBuilder.append("\n");
                }
            }
            hideKeyboard(JayHome_TextRepeatActivity.this);
            etPreviewText.setText(sBuilder.toString());
        } catch (Exception e) {

        }
    }

    Button buttonClickGenerateMessage;
    Button buttonClickResetText;
    ImageView buttonClickCopy;
    ImageView buttonClickShare;

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);

        View view = activity.getCurrentFocus();

        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    boolean wantNextLine = true;
    boolean wanSpace = false;


    private void initBackView() {
        buttonClickGenerateMessage = findViewById(R.id.buttonClickGenerateMessage);
        buttonClickResetText = findViewById(R.id.buttonClickResetText);
        buttonClickCopy = findViewById(R.id.buttonClickCopy);
        buttonClickShare = findViewById(R.id.buttonClickShare);
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}