package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

public class JayHome_EmptyText_Activity extends AppCompatActivity {

    Activity activity;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty_texttools);
        
        activity = this;
        
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        findViewById(R.id.buttonClickSend).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }
                mLastClickTime = now;

                if (isAppInstalled(Constants.app1) && isAppInstalled(Constants.app2)) {
                    openBothDialog();
                } else if (isAppInstalled(Constants.app1)) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.setAction(Intent.ACTION_SEND);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra(Intent.EXTRA_TEXT, "\u200F\u200F\u200E\u200F\u200F\u200E");
                        intent.setPackage(Constants.app1);
                        intent.setType("text/plain");
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(activity, JemsProviderKt.getMyString(activity,R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                    }
                } else if (isAppInstalled(Constants.app2)) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.setAction(Intent.ACTION_SEND);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra(Intent.EXTRA_TEXT, "\u200F\u200F\u200E\u200F\u200F\u200E");
                        intent.setPackage(Constants.app2);
                        intent.setType("text/plain");
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(activity, JemsProviderKt.getMyString(activity,R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(activity, JemsProviderKt.getMyString(activity,R.string.app_not_installed), Toast.LENGTH_SHORT).show();
                }

            }
        });
        BannerAdLayout.fillMeAlone(this, findViewById(R.id.relQbanner1), findViewById(R.id.frameQbanner1));




        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);

        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    public void openBothDialog() {
        Dialog alertDialog = new Dialog(activity);
        final View customLayout = LayoutInflater.from(activity).inflate(R.layout.dialog_selcte_whaz_set, null, false);
        alertDialog.setContentView(customLayout);

        Window window = alertDialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.addFlags(2);
        window.setDimAmount(0.82f);
        window.setAttributes(attributes);

        TextView img_btn_dilog_set_wtsapp = customLayout.findViewById(R.id.btn_dilog_set_whaz);
        TextView img_btn_dilog_set_wtsapp_buess = customLayout.findViewById(R.id.btn_dilog_set_whaz_w4b);
        TextView text_select2 = customLayout.findViewById(R.id.text_select2);
        text_select2.setText(JemsProviderKt.getMyString(activity,R.string.please_select_from_below_you_want_send_message));

        img_btn_dilog_set_wtsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.setAction(Intent.ACTION_SEND);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra(Intent.EXTRA_TEXT, "\u200F\u200F\u200E\u200F\u200F\u200E");
                    intent.setPackage(Constants.app1);
                    intent.setType("text/plain");
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(activity, JemsProviderKt.getMyString(activity,R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                }

                alertDialog.dismiss();
            }
        });

        img_btn_dilog_set_wtsapp_buess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.setAction(Intent.ACTION_SEND);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra(Intent.EXTRA_TEXT, "\u200F\u200F\u200E\u200F\u200F\u200E");
                    intent.setPackage(Constants.app2);
                    intent.setType("text/plain");
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(activity, JemsProviderKt.getMyString(activity,R.string.cant_send_message_please_try_again), Toast.LENGTH_SHORT).show();
                }

                alertDialog.dismiss();

            }
        });
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();
    }

    private long mLastClickTime = 0;
    private static final long CLICK_TIME_INTERVAL = 1200;

    @Override
    public void onBackPressed() {
        finish();
        InterAdCall.callForAniimation(this);
    }

    private boolean isAppInstalled(String packageName) {
        PackageManager pm = getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

}