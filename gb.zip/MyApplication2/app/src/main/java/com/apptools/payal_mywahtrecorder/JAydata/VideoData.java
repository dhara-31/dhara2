package com.apptools.payal_mywahtrecorder.JAydata;

import android.graphics.Bitmap;

public class VideoData {
    public int duration;
    public String durationDesc;
    public long id;
    public String path;
    public Bitmap preview;
    public long size;
    public String sizeDesc;
}
