package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.JayHomeadapter.VideoListAdapter;
import com.apptools.payal_mywahtrecorder.Jaycommon.RecyclerViewSpacer;
import com.apptools.payal_mywahtrecorder.JAydata.RecordData;
import com.apptools.payal_mywahtrecorder.Jayutils.DatabaseUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

import java.io.File;

public class JayHome_VideoListActivity extends AppCompatActivity {
    public VideoListAdapter adapter;
    private BroadcastReceiver receiver;
    private RecyclerView videoList;

    TextView novideo;

    public static JayHome_VideoListActivity videoListActivity;

    @Override
    protected void onResume() {
        super.onResume();


    }

    private long mLastClickTime = 0L;
    private static final long CLICK_TIME_INTERVAL = 700;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_video_list);

        videoListActivity = this;

        this.videoList = (RecyclerView) findViewById(R.id.activity_video_list);
        this.adapter = new VideoListAdapter(this, DatabaseUtils.getInstance().getRecordList(), getIntent().getBooleanExtra("openFirst", false));
        this.videoList.setAdapter(this.adapter);
        this.videoList.setLayoutManager(new LinearLayoutManager(this));
        this.videoList.addItemDecoration(new RecyclerViewSpacer(dpToPx(this, 10.0f)));
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), true);

        novideo = findViewById(R.id.novideo);
        updatelist();
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        this.receiver = new BroadcastReceiver() {


            @SuppressLint("WrongConstant")
            public void onReceive(Context context, Intent intent) {
                char c;
                String action = intent.getAction();
                switch (action.hashCode()) {
                    case -768051081:
                        if (action.equals(Message.PLAY_VIDEO)) {
                            c = 0;
                            break;
                        }
                    case -756552863:
                        if (action.equals(Message.EDIT_VIDEO)) {
                            c = 2;
                            break;
                        }
                    case 453598714:
                        if (action.equals(Message.RECORD_UPDATED)) {
                            c = 5;
                            break;
                        }
                    case 1325040736:
                        if (action.equals(Message.DELETE_VIDEO)) {
                            c = 4;
                            break;
                        }
                    case 1913429836:
                        if (action.equals(Message.SHARE_VIDEO)) {
                            c = 1;
                            break;
                        }
                    case 2145334218:
                        if (action.equals(Message.ADD_VIDEO)) {
                            c = 3;
                            break;
                        }
                    default:
                        c = 65535;
                        break;
                }
                if (c == 5) {
                    JayHome_VideoListActivity.this.adapter.updateVideo(RecordData.create(intent));
                } else if (c == 0) {

                    Intent intent2 = new Intent(JayHome_VideoListActivity.this, VideoPreviewActivity.class);
                    intent2.putExtra("videoPath", intent.getStringExtra("path"));
                    JayHome_VideoListActivity.this.startActivity(intent2);


                } else if (c == 1) {
                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                        return;
                    }
                    mLastClickTime = now;
                    Uri uriForFile = FileProvider.getUriForFile(JayHome_VideoListActivity.this, getPackageName() + ".provider", new File(intent.getStringExtra("path")));
                    Intent intent3 = new Intent("android.intent.action.SEND");
                    intent3.setType("video/mp4");
                    intent3.putExtra("android.intent.extra.STREAM", uriForFile);
                    intent3.addFlags(1);
                    intent3.addFlags(2);
                    intent3.addFlags(64);
                    intent3.addFlags(128);
                    JayHome_VideoListActivity videoListActivity = JayHome_VideoListActivity.this;
                    videoListActivity.startActivity(Intent.createChooser(intent3, videoListActivity.getResources().getString(R.string.label_share_to)));
                } else if (c == 2) {

                } else if (c == 3) {
                    JayHome_VideoListActivity.this.adapter.addVideo(RecordData.create(intent));
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Message.PLAY_VIDEO);
        intentFilter.addAction(Message.SHARE_VIDEO);
        intentFilter.addAction(Message.RENAME_VIDEO);
        intentFilter.addAction(Message.EDIT_VIDEO);
        intentFilter.addAction(Message.SHARE_VIDEO);
        intentFilter.addAction(Message.ADD_VIDEO);
        intentFilter.addAction(Message.DELETE_VIDEO);
        intentFilter.addAction(Message.RECORD_UPDATED);
        DApplication.getBm().registerReceiver(this.receiver, intentFilter);
    }

    public static int dpToPx(Context context, float f) {
        return (int) ((f * context.getResources().getDisplayMetrics().density) + 0.5f);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        DApplication.getBm().unregisterReceiver(this.receiver);

    }

    public void updatelist() {
        if (DatabaseUtils.getInstance().getRecordList().size() > 0) {
            if (novideo != null) {
                novideo.setVisibility(View.GONE);
                videoList.setVisibility(View.VISIBLE);
            }
        } else {
            if (novideo != null) {
                videoList.setVisibility(View.GONE);
                novideo.setVisibility(View.VISIBLE);
            }

        }

    }

    @Override
    public void onBackPressed() {


        startActivity(new Intent(this, JayHome_Recorder_activity.class));
        overridePendingTransition(0, 0);
        finish();


    }

}
