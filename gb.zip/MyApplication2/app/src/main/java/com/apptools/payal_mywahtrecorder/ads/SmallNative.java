package com.apptools.payal_mywahtrecorder.ads;

import static com.apptools.payal_mywahtrecorder.ads.BigNativeAd.ergt;
import static com.apptools.payal_mywahtrecorder.ads.BigNativeAd.fhgfg;
import static com.apptools.payal_mywahtrecorder.ads.BigNativeAd.loadNatviddecgtm1;

import android.app.Activity;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAdListener;
import com.facebook.ads.NativeBannerAd;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jaymodel.MixerBannerModel;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import java.util.ArrayList;
import java.util.List;

public class SmallNative {

    public void smallnative(Activity activity, RelativeLayout relative, FrameLayout frames, com.facebook.ads.NativeAdLayout advanceNew) {
        try {
            relative.setVisibility(View.VISIBLE);

            if (DApplication.getMeVcallApplication().adMainStateOfLive()) {
                relative.setVisibility(View.GONE);
                return;
            }
            if (!InterAdCall.checkConnection(activity)) {
                relative.setVisibility(View.GONE);
                return;
            }
            LayoutInflater layoutInflater = LayoutInflater.from(activity);
            LinearLayout layoutPopup = (LinearLayout) layoutInflater.inflate(R.layout.item_loader_nbanner, frames, false);
            frames.addView(layoutPopup);
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();
            if (myModelHelper != null && myModelHelper.getFbnativebanner() != null && !TextUtils.isEmpty(myModelHelper.getFbnativebanner())) {
                NativeBannerAd nativeBanners = new NativeBannerAd(activity, myModelHelper.getFbnativebanner());
                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                        layoutPopup.setVisibility(View.GONE);
                        fbfailmethod(activity, relative, frames);
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        if (nativeBanners == null || nativeBanners != ad) {
                            return;
                        }
                        relative.setVisibility(View.VISIBLE);
                        layoutPopup.setVisibility(View.GONE);
                        initializeAllViewUnified(activity, nativeBanners, advanceNew);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                nativeBanners.loadAd(nativeBanners.buildLoadAdConfig().withAdListener(nativeAdListener).build());
            } else {
                layoutPopup.setVisibility(View.GONE);
                fbfailmethod(activity, relative, frames);
            }
        } catch (Exception e) {

        }
    }


    private void initializeAllViewUnified(Activity activity, NativeBannerAd nativeBannerAd, com.facebook.ads.NativeAdLayout nativeAdLayout) {
        try {
            nativeBannerAd.unregisterView();
            LayoutInflater inflater = LayoutInflater.from(activity);
            LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.layout_native_fb_banner_ad_unittools, nativeAdLayout, false);
            nativeAdLayout.addView(adView);
            RelativeLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
            AdOptionsView adOptionsView = new AdOptionsView(activity, nativeBannerAd, nativeAdLayout);
            adChoicesContainer.removeAllViews();
            adChoicesContainer.addView(adOptionsView, 0);
            TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
            TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
            TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
            MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
            Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);
            nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
            nativeAdCallToAction.setVisibility(nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
            nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
            nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());
            sponsoredLabel.setText(nativeBannerAd.getSponsoredTranslation());
            List<View> clickableViews = new ArrayList<>();
            clickableViews.add(nativeAdTitle);
            clickableViews.add(nativeAdCallToAction);
            nativeBannerAd.registerViewForInteraction(adView, nativeAdIconView, clickableViews);
        } catch (Exception e) {

        }
    }

    private static void fbfailmethod(Activity activity, RelativeLayout yRelative, FrameLayout xFrame) {



        try {

            if (fhgfg != null) {
                fhf(yRelative, activity);
                fhgfg = null;
                loadNatviddecgtm1(activity);
            } else {
                nativeDefaultLoad(activity, xFrame, yRelative);
                if (fhgfg == null) {
                    ergt++;
                    if (ergt >= 5) {
                        ergt = 0;
                        fhgfg = null;
                        loadNatviddecgtm1(activity);
                    }
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }



       // attachOfflineBanner1(activity, yRelative, xFrame);

    }

    public static void fhf(RelativeLayout frameLayout, Activity activity) {
        frameLayout.setVisibility(View.VISIBLE);
        com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_small, null);

        populatbanner(fhgfg,adView);
        frameLayout.removeAllViews();
        frameLayout.addView(adView);
    }

    public static void nativeDefaultLoad(Activity activity, FrameLayout f1, RelativeLayout xNewRelate) {
        AppDetail appDetail = DApplication.getInstance().getAppDetails();
        if (appDetail != null && appDetail.getAdmobnative() != null && !TextUtils.isEmpty(appDetail.getAdmobnative()) && appDetail.getAdstatus().equals("1")) {
            AdLoader.Builder builder = new AdLoader.Builder(activity, appDetail.getAdmobnative());
            builder.forNativeAd(new com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener() {

                @Override
                public void onNativeAdLoaded(com.google.android.gms.ads.nativead.NativeAd nativeAd) {
                    boolean isDestroyed = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        isDestroyed = activity.isDestroyed();
                    }
                    if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
                        nativeAd.destroy();
                        return;
                    }

                    com.google.android.gms.ads.nativead.NativeAd banernativeAd_Default1 = null;
                    if (banernativeAd_Default1 != null) {
                        banernativeAd_Default1.destroy();
                    }
                    banernativeAd_Default1 = nativeAd;

                    xNewRelate.setVisibility(View.VISIBLE);

                    com.google.android.gms.ads.nativead.NativeAdView adView = (com.google.android.gms.ads.nativead.NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_small, null);
                    populatbanner(banernativeAd_Default1,adView);
                    xNewRelate.removeAllViews();
                    xNewRelate.addView(adView);
                }
            });

            AdLoader adLoader = builder.withAdListener(
                            new AdListener() {
                                @Override
                                public void onAdFailedToLoad(LoadAdError loadAdError) {

                                    Log.e("dtr", "onAdFailedToLoad: " + loadAdError.getMessage());
                                    attachOfflineBanner1(activity, xNewRelate, f1);
                                }
                            })
                    .build();

            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            Log.e("dtr", "elsee: " );

            attachOfflineBanner1(activity, xNewRelate, f1);

        }
    }

    public static void populatbanner(NativeAd nativeAd, NativeAdView adView) {

        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));

        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());


        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);
        VideoController vc = nativeAd.getMediaContent().getVideoController();

        if (vc.hasVideoContent()) {
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        } else {
        }
    }


    private static void attachOfflineBanner1(Activity activity, RelativeLayout yRelative, FrameLayout xFrame) {
        try {
            if (DApplication.checkNetworkAvailable(activity)) {
                xFrame.removeAllViews();
                xFrame.setVisibility(View.VISIBLE);
                yRelative.setVisibility(View.VISIBLE);
                final float scale = activity.getResources().getDisplayMetrics().density;
                int dp112 = (int) (112 * scale);
                int dp8 = (int) (8 * scale);
                View custombannerLayout = activity.getLayoutInflater().inflate(R.layout.layout_nbanner_qureka, null, true);
                FrameLayout.LayoutParams paramsFrame = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp112);
                xFrame.addView(custombannerLayout, paramsFrame);
                RelativeLayout.LayoutParams paramsParent = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                paramsParent.setMargins(dp8, dp8, dp8, dp8);
                yRelative.setLayoutParams(paramsParent);

                ArrayList<MixerBannerModel> mixModelList = new ArrayList<>();
                try {
                    if (DApplication.getSizeWay() == 1) {
                        for (int resourceId : historyList) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 1);
                            mixModelList.add(model);
                        }
                    } else if (DApplication.getSizeWay() == 2) {
                        for (int resourceId : nZopNativeList) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 2);
                            mixModelList.add(model);
                        }
                    } else {
                        mixModelList = new ArrayList<>(nZopNativeList.length + historyList.length);

                        int totalSizeSmall = Math.min(nZopNativeList.length, historyList.length);

                        int index = 0;
                        for (int i = 0; i < totalSizeSmall; i++) {
                            MixerBannerModel modelgame = new MixerBannerModel(nZopNativeList[i], 2);
                            mixModelList.add(index++, modelgame);

                            MixerBannerModel modelqur = new MixerBannerModel(historyList[i], 1);
                            mixModelList.add(index++, modelqur);
                        }
                        if (nZopNativeList.length > historyList.length) {
                            int newlength = nZopNativeList.length - totalSizeSmall;
                            for (int i = 0; i < newlength; i++) {
                                MixerBannerModel mdelgame = new MixerBannerModel(nZopNativeList[totalSizeSmall + i], 2);
                                mixModelList.add(index++, mdelgame);
                            }
                        } else {
                            int newlenght = historyList.length - totalSizeSmall;
                            for (int i = 0; i < newlenght; i++) {
                                MixerBannerModel modelqur = new MixerBannerModel(historyList[totalSizeSmall + i], 1);
                                mixModelList.add(index++, modelqur);
                            }
                        }
                    }
                } catch (Exception e) {
                    for (int resourceId : nZopNativeList) {
                        MixerBannerModel model = new MixerBannerModel(resourceId, 2);
                        mixModelList.add(model);
                    }
                }

                String customBaUrl = "";
                try {
                    if (DApplication.getSizeWay() == 1 && !DApplication.getTwoUrk()) {
                        customBaUrl = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                    } else if (DApplication.getSizeWay() == 2 && !DApplication.fourNativeUrl()) {
                        customBaUrl = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                    } else {
                        if (mixModelList.get(positionNeo).getQurOrGame() == 1 && !DApplication.getTwoUrk()) {
                            customBaUrl = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                        } else if (!DApplication.fourNativeUrl()) {
                            customBaUrl = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                        }
                    }
                } catch (Exception e) {

                }

                if (customBaUrl != null && !TextUtils.isEmpty(customBaUrl)) {
                    ImageView imgNewBannerQka = custombannerLayout.findViewById(R.id.imgNewBannerQka);
                    try {
                        imgNewBannerQka.setImageResource(mixModelList.get(positionNeo).getBannername());
                    } catch (Exception e) {
                        imgNewBannerQka.setImageResource(nZopNativeList[0]);
                    }
                    positionNeo++;
                    try {
                        if (positionNeo >= mixModelList.size()) {
                            positionNeo = 0;
                        }
                    } catch (Exception e) {
                        positionNeo = 0;
                    }

                    String finalLay = customBaUrl;
                    imgNewBannerQka.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            DApplication.tabToIntent(activity, finalLay);
                        }
                    });
                } else {
                    xFrame.setVisibility(View.INVISIBLE);
                    yRelative.setVisibility(View.GONE);
                }

            } else {
                xFrame.setVisibility(View.INVISIBLE);
                yRelative.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }

    }


    private static int[] historyList = new int[]{R.drawable.qurekanativebn1, R.drawable.qurekanativebn2, R.drawable.qurekanativebn3};

    private static int[] nZopNativeList = new int[]{R.drawable.gamenativebn1_1, R.drawable.gamenativebn1_2, R.drawable.gamenativebn1_3, R.drawable.gamenativebn1_4, R.drawable.gamenativebn1_5, R.drawable.gamenativebn1_6, R.drawable.gamenativebn1_7, R.drawable.gamenativebn4, R.drawable.gamenativebn6};

    private static int positionNeo = 0;

    private static SmallNative nonLayoutBottom;

    public static SmallNative getNonLayoutBottom() {
        if (nonLayoutBottom == null) {
            nonLayoutBottom = new SmallNative();
        }
        return nonLayoutBottom;
    }


}
