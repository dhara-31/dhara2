package com.apptools.payal_mywahtrecorder.JAydata;

import java.util.HashMap;
import java.util.Map;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class RecordMode {
    private static Map<Integer, RecordModeFunction> functionMap;

    public static RecordModeFunction getFunction() {
        int i = DApplication.sP.getInt(PerferencedName.RECORD_MODE, 1);
        if (functionMap == null) {
            functionMap = new HashMap();
            functionMap.put(1, new RecordModeFunction(false, true));
            functionMap.put(2, new RecordModeFunction(true, true));
            functionMap.put(3, new RecordModeFunction(false, false));
        }
        return functionMap.get(Integer.valueOf(i));
    }
}
