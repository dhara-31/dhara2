package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jayutils.AppPref;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;

public class JayHome_TextToEmojiActivity extends AppCompatActivity {


    private final ArrayList<String> emojis = new ArrayList<>();
    public String conver_value;
    EditText inputEditText, emojiEd;
    TextView showEmoji;
    ImageView btnClear;
    int i;
    SwitchCompat cb;
    CardView cd_op;
    private boolean aBoolean;
    private boolean isOn = false;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_to_emoji);


        context = this;

        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }


        emojiEd = findViewById(R.id.pickemo);
        inputEditText = findViewById(R.id.inputEditText);
        showEmoji = findViewById(R.id.text_TV);

        btnClear = findViewById(R.id.iv_cancle);
        cb = findViewById(R.id.show_thinckness);
        cd_op = findViewById(R.id.cd_op);


        emojiEd.setSelection(emojiEd.getText().length());
        inputEditText.setSelection(inputEditText.getText().length());


        InputFilter filter = (source, start, end, dest, dstart, dend) -> {
            for (int i = start; i < end; i++) {
                int type = Character.getType(source.charAt(i));
                if (Character.isWhitespace(source.charAt(i))) {
                    return "";
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    if (Character.isAlphabetic(source.charAt(i))) {
                        String aa = emojiEd.getText().toString();
                        emojiEd.setText("");
                        emojiEd.setText(aa);
                        emojiEd.setSelection(emojiEd.getText().length());
                        return "";
                    } else if (type != Character.SURROGATE) {
                        return "";
                    }
                }
            }
            return null;
        };
        emojiEd.setFilters(new InputFilter[]{filter});

        showEmoji.setCursorVisible(false);
        showEmoji.setLongClickable(false);
        showEmoji.setClickable(false);
        showEmoji.setFocusable(false);
        showEmoji.setSelected(false);
        showEmoji.setKeyListener(null);
        showEmoji.setBackgroundResource(android.R.color.transparent);


        cb.setChecked(AppPref.isthincness(context));
        AppPref.setthincness(this, cb.isChecked());
        convert_data();

        onClicks();
    }

    private void onClicks() {


        findViewById(R.id.iv_share).setOnClickListener(v -> {
            String clipD = showEmoji.getText().toString().trim();

            if(!clipD.isEmpty()){
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, clipD);
                startActivity(Intent.createChooser(i, "Share"));
            }else {
                Toast.makeText(this, "Cant Share Empty text", Toast.LENGTH_SHORT).show();
            }


        });

        findViewById(R.id.iv_copy).setOnClickListener(v -> {

            String clipD = showEmoji.getText().toString().trim();

            if(!clipD.isEmpty()){
                ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData data = ClipData.newPlainText("label", clipD);
                manager.setPrimaryClip(data);
                Toast.makeText(this, "Text Copied to Clipboard", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this, "Cant Copy Empty text", Toast.LENGTH_SHORT).show();

            }

        });

        findViewById(R.id.iv_back).setOnClickListener(v -> onBackPressed());

        btnClear.setOnClickListener(v -> {
            inputEditText.setText("");
            emojiEd.setText("");
            showEmoji.setText("");

        });

        cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AppPref.setthincness(JayHome_TextToEmojiActivity.this, cb.isChecked());
                convert_data();
            }
        });


        inputEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (inputEditText.getText().toString().trim().isEmpty()) {
                    inputEditText.setError("Enter text!");
                } else if (emojiEd.getText().toString().trim().isEmpty()) {
                    emojiEd.setError("Enter Emoji!");
                }

                convert_data();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        emojiEd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (inputEditText.getText().toString().trim().isEmpty()) {
                    inputEditText.setError("Enter text!");
                } else if (emojiEd.getText().toString().trim().isEmpty()) {
                    emojiEd.setError("Enter Emoji!");
                }
                convert_data();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        inputEditText.setText("Hello");



    }

    @SuppressLint("WrongConstant")
    public String convertToEmoji(String[] strArr) {
        String obj = emojiEd.getText().toString();
        String substring = obj.substring(obj.length() - 2);

        if (substring.matches("[\\x00-\\x7F]+")) {

            Toast.makeText(this, "Choose emoji here.", 0).show();
        } else {

            emojis_method(emojiEd.getText().toString());
        }

        StringBuilder sb = new StringBuilder();
        int i = 0;
        int i2 = -1;
        while (i < strArr.length) {
            StringBuilder sb2 = new StringBuilder();
            String str = strArr[i];
            StringBuilder sb3 = sb2;

            int i3 = i2;
            for (int i4 = 0; i4 < str.length(); i4++) {
                String valueOf = String.valueOf(str.charAt(i4));

                if (valueOf.equals("*")) {
                    i3++;
                    if (emojis.size() == i3) {
                        sb3.append("printvalue is at last index so now 0 : ");
                        sb3.append(0);
                        i3 = 0;
                    } else {

                    }

                    valueOf = valueOf.replace("*", emojis.get(i3));
                } else if (valueOf.equals("#")) {
                    valueOf = valueOf.replace("#", "");
                }

                if (i4 == str.length() - 1) {
                    sb3 = new StringBuilder();
                    sb3.append(valueOf);
                    sb3.append("\n");
                    sb.append(sb3.toString());
                } else {
                    sb.append(valueOf);
                }
            }
            i++;
            i2 = i3;
        }
        return sb.toString();
    }

    public void emojis_method(String str) {
        emojis.clear();
        int i = 0;
        while (i < str.length()) {
            StringBuilder sb = new StringBuilder();
            sb.append("here : ");
            int i2 = i + 2;
            sb.append(str.substring(i, i2));
            emojis.add(str.substring(i, i2));
            i = i2;
        }

        Collections.shuffle(this.emojis);
    }

    public void convert_data() {
        InputStream inputStream;
        InputStream inputStream2;
        InputStream inputStream3;
        InputStream inputStream4;
        InputStream inputStream5;
        InputStream inputStream6;
        InputStream inputStream7;
        InputStream inputStream8;
        InputStream inputStream9;
        InputStream inputStream10;
        InputStream inputStream11;
        InputStream inputStream12;
        InputStream inputStream13;
        InputStream inputStream14;
        InputStream inputStream15;
        InputStream inputStream16;
        InputStream inputStream17;
        InputStream inputStream18;
        InputStream inputStream19;
        InputStream inputStream20;
        InputStream inputStream21;
        InputStream inputStream22;
        InputStream inputStream23;
        InputStream inputStream24;

        if (!emojiEd.getText().toString().trim().isEmpty() &&  !inputEditText.getText().toString().trim().isEmpty()) {
            cd_op.setVisibility(View.VISIBLE);
        } else {
            cd_op.setVisibility(View.GONE);
        }

        try {
            i = 0;
            showEmoji.setText("\n");
            for (char c : this.inputEditText.getText().toString().toCharArray()) {
                i++;
                conver_value = "";
                if (aBoolean) {
                    aBoolean = false;
                } else if (c == '?') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream24 = getAssets().open("double/ques.txt");
                        } else {
                            inputStream24 = getAssets().open("single/ques.txt");
                        }
                        byte[] bArr = new byte[inputStream24.available()];
                        inputStream24.read(bArr);
                        inputStream24.close();
                        conver_value = convertToEmoji(new String(bArr).split("[\\r?\\n]"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '#') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream23 = getAssets().open("double/hash.txt");
                        } else {
                            inputStream23 = getAssets().open("single/hash.txt");
                        }
                        byte[] bArr2 = new byte[inputStream23.available()];
                        inputStream23.read(bArr2);
                        inputStream23.close();
                        conver_value = convertToEmoji(new String(bArr2).split("[\\r?\\n]"));
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '$') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream22 = getAssets().open("double/dollar.txt");
                        } else {
                            inputStream22 = getAssets().open("single/dollar.txt");
                        }
                        byte[] bArr3 = new byte[inputStream22.available()];
                        inputStream22.read(bArr3);
                        inputStream22.close();
                        conver_value = convertToEmoji(new String(bArr3).split("[\\r?\\n]"));
                    } catch (IOException e3) {
                        e3.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '%') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream21 = getAssets().open("double/modulo.txt");
                        } else {
                            inputStream21 = getAssets().open("single/modulo.txt");
                        }
                        byte[] bArr4 = new byte[inputStream21.available()];
                        inputStream21.read(bArr4);
                        inputStream21.close();
                        conver_value = convertToEmoji(new String(bArr4).split("[\\r?\\n]"));
                    } catch (IOException e4) {
                        e4.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '&') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream20 = getAssets().open("double/ampersand.txt");
                        } else {
                            inputStream20 = getAssets().open("single/ampersand.txt");
                        }
                        byte[] bArr5 = new byte[inputStream20.available()];
                        inputStream20.read(bArr5);
                        inputStream20.close();
                        conver_value = convertToEmoji(new String(bArr5).split("[\\r?\\n]"));
                    } catch (IOException e5) {
                        e5.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '-') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream19 = getAssets().open("double/minus.txt");
                        } else {
                            inputStream19 = getAssets().open("single/minus.txt");
                        }
                        byte[] bArr6 = new byte[inputStream19.available()];
                        inputStream19.read(bArr6);
                        inputStream19.close();
                        conver_value = convertToEmoji(new String(bArr6).split("[\\r?\\n]"));
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '+') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream18 = getAssets().open("double/plus.txt");
                        } else {
                            inputStream18 = getAssets().open("single/plus.txt");
                        }
                        byte[] bArr7 = new byte[inputStream18.available()];
                        inputStream18.read(bArr7);
                        inputStream18.close();
                        conver_value = convertToEmoji(new String(bArr7).split("[\\r?\\n]"));
                    } catch (IOException e7) {
                        e7.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '=') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream17 = getAssets().open("double/equals.txt");
                        } else {
                            inputStream17 = getAssets().open("single/equals.txt");
                        }
                        byte[] bArr8 = new byte[inputStream17.available()];
                        inputStream17.read(bArr8);
                        inputStream17.close();
                        conver_value = convertToEmoji(new String(bArr8).split("[\\r?\\n]"));
                    } catch (IOException e8) {
                        e8.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '(') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream16 = getAssets().open("double/leftround.txt");
                        } else {
                            inputStream16 = getAssets().open("single/leftround.txt");
                        }
                        byte[] bArr9 = new byte[inputStream16.available()];
                        inputStream16.read(bArr9);
                        inputStream16.close();
                        conver_value = convertToEmoji(new String(bArr9).split("[\\r?\\n]"));
                    } catch (IOException e9) {
                        e9.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == ')') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream15 = getAssets().open("double/rightround.txt");
                        } else {
                            inputStream15 = getAssets().open("single/rightround.txt");
                        }
                        byte[] bArr10 = new byte[inputStream15.available()];
                        inputStream15.read(bArr10);
                        inputStream15.close();
                        conver_value = convertToEmoji(new String(bArr10).split("[\\r?\\n]"));
                    } catch (IOException e10) {
                        e10.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '*') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream14 = getAssets().open("double/star.txt");
                        } else {
                            inputStream14 = getAssets().open("single/star.txt");
                        }
                        byte[] bArr11 = new byte[inputStream14.available()];
                        inputStream14.read(bArr11);
                        inputStream14.close();
                        conver_value = convertToEmoji(new String(bArr11).split("[\\r?\\n]"));
                    } catch (IOException e11) {
                        e11.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '<') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream13 = getAssets().open("double/lessthan.txt");
                        } else {
                            inputStream13 = getAssets().open("single/lessthan.txt");
                        }
                        byte[] bArr12 = new byte[inputStream13.available()];
                        inputStream13.read(bArr12);
                        inputStream13.close();
                        conver_value = convertToEmoji(new String(bArr12).split("[\\r?\\n]"));
                    } catch (IOException e12) {
                        e12.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '>') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream12 = getAssets().open("double/greater.txt");
                        } else {
                            inputStream12 = getAssets().open("single/greater.txt");
                        }
                        byte[] bArr13 = new byte[inputStream12.available()];
                        inputStream12.read(bArr13);
                        inputStream12.close();
                        conver_value = convertToEmoji(new String(bArr13).split("[\\r?\\n]"));
                    } catch (IOException e13) {
                        e13.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '\"') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream11 = getAssets().open("double/doublequotes.txt");
                        } else {
                            inputStream11 = getAssets().open("single/doublequotes.txt");
                        }
                        byte[] bArr14 = new byte[inputStream11.available()];
                        inputStream11.read(bArr14);
                        inputStream11.close();
                        conver_value = convertToEmoji(new String(bArr14).split("[\\r?\\n]"));
                    } catch (IOException e14) {
                        e14.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '\'') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream10 = getAssets().open("double/singlequote.txt");
                        } else {
                            inputStream10 = getAssets().open("single/singlequote.txt");
                        }
                        byte[] bArr15 = new byte[inputStream10.available()];
                        inputStream10.read(bArr15);
                        inputStream10.close();
                        conver_value = convertToEmoji(new String(bArr15).split("[\\r?\\n]"));
                    } catch (IOException e15) {
                        e15.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == ';') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream9 = getAssets().open("double/semicolon.txt");
                        } else {
                            inputStream9 = getAssets().open("single/semicolon.txt");
                        }
                        byte[] bArr16 = new byte[inputStream9.available()];
                        inputStream9.read(bArr16);
                        inputStream9.close();
                        conver_value = convertToEmoji(new String(bArr16).split("[\\r?\\n]"));
                    } catch (IOException e16) {
                        e16.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '!') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream8 = getAssets().open("double/exclamation.txt");
                        } else {
                            inputStream8 = getAssets().open("single/exclamation.txt");
                        }
                        byte[] bArr17 = new byte[inputStream8.available()];
                        inputStream8.read(bArr17);
                        inputStream8.close();
                        conver_value = convertToEmoji(new String(bArr17).split("[\\r?\\n]"));
                    } catch (IOException e17) {
                        e17.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '\\') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream7 = getAssets().open("double/backwardslash.txt");
                        } else {
                            inputStream7 = getAssets().open("single/backwardslash.txt");
                        }
                        byte[] bArr18 = new byte[inputStream7.available()];
                        inputStream7.read(bArr18);
                        inputStream7.close();
                        conver_value = convertToEmoji(new String(bArr18).split("[\\r?\\n]"));
                    } catch (IOException e18) {
                        e18.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == '/') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream6 = getAssets().open("double/forwardslash.txt");
                        } else {
                            inputStream6 = getAssets().open("single/forwardslash.txt");
                        }
                        byte[] bArr19 = new byte[inputStream6.available()];
                        inputStream6.read(bArr19);
                        inputStream6.close();
                        conver_value = convertToEmoji(new String(bArr19).split("[\\r?\\n]"));
                    } catch (IOException e19) {
                        e19.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else if (c == ',') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream5 = getAssets().open("double/comma.txt");
                        } else {
                            inputStream5 = getAssets().open("single/comma.txt");
                        }
                        byte[] bArr20 = new byte[inputStream5.available()];
                        inputStream5.read(bArr20);
                        inputStream5.close();
                        conver_value = convertToEmoji(new String(bArr20).split("[\\r?\\n]"));
                    } catch (IOException e20) {
                        e20.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == '_') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream4 = getAssets().open("double/underscore.txt");
                        } else {
                            inputStream4 = getAssets().open("single/underscore.txt");
                        }
                        byte[] bArr21 = new byte[inputStream4.available()];
                        inputStream4.read(bArr21);
                        inputStream4.close();
                        conver_value = convertToEmoji(new String(bArr21).split("[\\r?\\n]"));
                    } catch (IOException e21) {
                        e21.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                } else if (c == ':') {
                    try {
                        if (AppPref.isthincness(context)) {
                            inputStream3 = getAssets().open("double/colon.txt");
                        } else {
                            inputStream3 = getAssets().open("single/colon.txt");
                        }
                        byte[] bArr22 = new byte[inputStream3.available()];
                        inputStream3.read(bArr22);
                        inputStream3.close();
                        conver_value = convertToEmoji(new String(bArr22).split("[\\r?\\n]"));
                    } catch (IOException e22) {
                        e22.printStackTrace();
                    }
                    showEmoji.append(conver_value + "\n\n");
                    conver_value = "";
                    aBoolean = true;
                } else {
                    if (c != ((char) (c & '_'))) {
                        if (!Character.isDigit(c)) {
                            try {
                                if (AppPref.isthincness(context)) {
                                    inputStream2 = getAssets().open("double/sml" + c + ".txt");
                                } else {
                                    inputStream2 = getAssets().open("single/sml" + c + ".txt");
                                }
                                byte[] bArr23 = new byte[inputStream2.available()];
                                inputStream2.read(bArr23);
                                inputStream2.close();
                                conver_value = convertToEmoji(new String(bArr23).split("[\\r?\\n]"));
                            } catch (IOException e23) {
                                e23.printStackTrace();
                            }
                            showEmoji.append(conver_value + "\n\n");
                        }
                    }
                    try {

                        if (AppPref.isthincness(context)) {
                            inputStream = getAssets().open("double/" + c + ".txt");
                        } else {
                            inputStream = getAssets().open("single/" + c + ".txt");
                        }
                        byte[] bArr24 = new byte[inputStream.available()];
                        inputStream.read(bArr24);
                        inputStream.close();
                        conver_value = convertToEmoji(new String(bArr24).split("[\\r?\\n]"));
                        showEmoji.append(conver_value + "\n\n");
                    } catch (IOException e24) {
                        e24.printStackTrace();
                    }
                }
            }



        } catch (Exception e25) {
            e25.printStackTrace();
        }
    }
}