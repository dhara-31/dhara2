package com.apptools.payal_mywahtrecorder.JayHomeadapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JAydata.OptionData;
import com.apptools.payal_mywahtrecorder.JAydata.OptionMenuBuilder;
import com.apptools.payal_mywahtrecorder.JAydata.PerferencedName;
import com.apptools.payal_mywahtrecorder.Jayservice.ChangeModeService;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

import java.util.ArrayList;
import java.util.List;

public class OptionListAdapter extends RecyclerView.Adapter<OptionListAdapter.OptionHolder> {
    public Context context;
    private List<OptionData> optionList = new ArrayList();

    private long mLastClickTime = 0;
    private static final long CLICK_TIME_INTERVAL = 700;

    AlertDialog.Builder temp = null;

    public class OptionHolder extends RecyclerView.ViewHolder {
        public OptionData data;
        private ImageView imgArrow;
        private ImageView imgIcon;
        private TextView txtDesc;
        private TextView txtInfo;
        private TextView txtTitle;

        ImageView inms_img_normal, inms_img_speak;


        public OptionHolder(View view, int i) {
            super(view);
            if (i == 101) {
                this.txtTitle = (TextView) view.findViewById(R.id.iot_txt_title);
                return;
            } else if (i == 102) {
                this.txtTitle = (TextView) view.findViewById(R.id.ioi_txt_title);
                this.txtDesc = (TextView) view.findViewById(R.id.ioi_txt_desc);
                this.txtInfo = (TextView) view.findViewById(R.id.ioi_txt_info);
                this.imgIcon = (ImageView) view.findViewById(R.id.ioi_img_icon);
                this.imgArrow = (ImageView) view.findViewById(R.id.ioi_img_arrow);


                view.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View view) {

                        long now = System.currentTimeMillis();
                        if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                            return;
                        }
                        mLastClickTime = now;

                        if (temp != null && temp.create().isShowing()) {
                            temp.create().dismiss();
                            temp = null;
                        }

                        AlertDialog.Builder builder = OptionMenuBuilder.getBuilder(OptionListAdapter.this.context, OptionHolder.this.data.option, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialogInterface, int i) {
                                OptionMenuBuilder.setOption(OptionHolder.this.data.option, i);
                                OptionHolder.this.updateInfo();
                            }
                        });
                        if (builder != null) {
                            builder.show();
                            temp = builder;
                        } else if (OptionHolder.this.data.option == 3) {
                            DApplication.getBm().sendBroadcast(new Intent(Message.SHOW_RATE));
                        } else if (OptionHolder.this.data.option == 5) {
                            DApplication.getBm().sendBroadcast(new Intent(Message.SHOW_FACEBOOK));
                        }
                    }


                });

            } else if (i == 103) {
                this.inms_img_normal = (ImageView) view.findViewById(R.id.inms_img_normal);
                this.inms_img_speak = (ImageView) view.findViewById(R.id.inms_img_speak);


                inms_img_normal.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        updateMode(1);
                        inms_img_normal.setImageResource(R.drawable.ic_notice_normal_active);
                        inms_img_speak.setImageResource(R.drawable.ic_notice_speak);

                        return;
                    }
                });

                inms_img_speak.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        updateMode(2);
                        inms_img_normal.setImageResource(R.drawable.ic_notice_normal);
                        inms_img_speak.setImageResource(R.drawable.ic_notice_speak_active);

                        return;
                    }
                });


            }

        }

        @SuppressLint("WrongConstant")
        public void setData(OptionData optionData) {
            this.data = optionData;
            ImageView imageView = this.imgIcon;
            if (imageView != null) {
                imageView.setImageResource(optionData.iconId);
                if (data.title.equals("Bitrate")) {
                    imageView.setPadding(8, 8, 8, 8);
                }
            }
            this.txtTitle.setText(optionData.title);
            if (optionData.type == 102) {
                if (optionData.desc != null) {
                    this.txtDesc.setText(optionData.desc);
                    this.txtDesc.setVisibility(0);
                } else {
                    this.txtDesc.setVisibility(8);
                }
                updateInfo();
            }
        }

        public void updateInfo() {
            int[] option = OptionMenuBuilder.getOption(this.data.option);
            if (option != null) {
                this.txtInfo.setText(option[0]);
            } else {
                this.txtInfo.setText("");
            }
        }
    }

    public OptionListAdapter(Context context2) {
        this.context = context2;
        this.optionList.add(new OptionData(101, 0, context2.getString(R.string.label_video_setting), null, false, 0));
        this.optionList.add(new OptionData(102, 0, context2.getString(R.string.label_resolution), context2.getString(R.string.label_resolution_desc), true, R.drawable.ic_resolution));
        this.optionList.add(new OptionData(102, 1, context2.getString(R.string.label_fps), context2.getString(R.string.label_fps_desc), true, R.drawable.ic_fps));
        this.optionList.add(new OptionData(102, 2, context2.getString(R.string.label_bitrate), context2.getString(R.string.label_bitrate_desc), true, R.drawable.ic_bitrate));
        this.optionList.add(new OptionData(102, 6, context2.getString(R.string.label_countdown), context2.getString(R.string.label_countdown_desc), true, R.drawable.ic_time));
    }

    @Override
    public OptionHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view;
        if (i == 102) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_option_info, viewGroup, false);
        } else if (i == 103) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_setting_audio, viewGroup, false);

        } else {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_option_titletools, viewGroup, false);
        }

        return new OptionHolder(view, i);
    }

    public void onBindViewHolder(OptionHolder optionHolder, int i) {
        if (optionList.get(i).type != 103) {
            optionHolder.setData(this.optionList.get(i));
        } else {


            int ii = DApplication.sP.getInt(PerferencedName.RECORD_MODE, 0);
            if (ii == 0 || ii == 1) {
                optionHolder.inms_img_normal.setImageResource(R.drawable.ic_notice_normal_active);
                optionHolder.inms_img_speak.setImageResource(R.drawable.ic_notice_speak);


            } else if (ii == 2) {
                optionHolder.inms_img_normal.setImageResource(R.drawable.ic_notice_normal);
                optionHolder.inms_img_speak.setImageResource(R.drawable.ic_notice_speak_active);

            } else if (ii == 3) {
                optionHolder.inms_img_normal.setImageResource(R.drawable.ic_notice_normal);
                optionHolder.inms_img_speak.setImageResource(R.drawable.ic_notice_speak);

            }
        }

    }

    @Override
    public int getItemViewType(int i) {
        return this.optionList.get(i).type;
    }

    @Override
    public int getItemCount() {
        return this.optionList.size();
    }

    private void updateMode(int i) {
        Intent intent = new Intent(context, ChangeModeService.class);
        intent.putExtra("mode", i);
        context.startService(intent);
    }
}
