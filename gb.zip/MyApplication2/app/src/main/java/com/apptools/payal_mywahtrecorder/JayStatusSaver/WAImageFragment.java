package com.apptools.payal_mywahtrecorder.JayStatusSaver;

import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.SaveSS;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.copyFile;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.getFromSdcard;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.getListFiles;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.statusSaverActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.VS_Status_Image_Preview_Activity;
import com.apptools.payal_mywahtrecorder.R;

import java.io.File;
import java.util.ArrayList;

public class WAImageFragment extends Fragment {

    RecyclerView rv_wa_image;
    TextView tv_nothing_to_display;

    ArrayList<File> imageList = new ArrayList<>();

    ArrayList<Status> imageStatues11 = new ArrayList<>();

    public ImageListAdapter imageListAdapter;
    public ImageListAdapter11 imageListAdapter11;

    public WAImageFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Constants.waImageFragment = this;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_images__status_, container, false);
      rv_wa_image = view.findViewById(R.id.image_Recycler);
        tv_nothing_to_display = view.findViewById(R.id.textNot);

        rv_wa_image.setLayoutManager(new GridLayoutManager(requireActivity(), 2));
        if (Build.VERSION.SDK_INT < 30) {
            imageListAdapter = new ImageListAdapter(statusSaverActivity);
            rv_wa_image.setAdapter(imageListAdapter);
        } else {
            imageListAdapter11 = new ImageListAdapter11(statusSaverActivity);
            rv_wa_image.setAdapter(imageListAdapter11);
        }

        getImageList();

        return view;
    }


    @Override
    public void onResume() {
        super.onResume();

    }

    public void getImageList() {

        try {
            imageList = new ArrayList<>();


            if (Build.VERSION.SDK_INT < 30) {
                File S_DIRECTORY;
                if (statusSaverActivity.isStatusAppPresent) {

                    String waStatus = (Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp/WhatsApp/Media/.Statuses");

                    S_DIRECTORY = new File(Environment.getExternalStorageDirectory() + File.separator + "WhatsApp/Media/.Statuses");

                    if (!S_DIRECTORY.exists()) {
                        S_DIRECTORY = new File(waStatus);
                    }
                } else {
                    String wStatusB = (Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses");

                    S_DIRECTORY = new File(Environment.getExternalStorageDirectory() + File.separator + "WhatsApp Business/Media/.Statuses");

                    if (!S_DIRECTORY.exists()) {
                        S_DIRECTORY = new File(wStatusB);
                    }

                }

                if (S_DIRECTORY.exists()) {
                    imageList = getListFiles(S_DIRECTORY, "image");
                } else {
                    imageList = new ArrayList<>();
                }


            } else {

                imageStatues11 = new ArrayList<>();

                DocumentFile[] documentFiles = getFromSdcard(statusSaverActivity);
                if (documentFiles == null) {
                    return;
                }

                if (statusSaverActivity.isStatusAppPresent) {
                    for (DocumentFile documentFile : documentFiles) {
                        File file = FileUtil.getFile(statusSaverActivity, documentFile.getUri());
                        if (!documentFile.getUri().toString().endsWith(".nomedia")) {
                            if (documentFile.getUri().toString().toLowerCase().endsWith(".jpg") || documentFile.getUri().toString().toLowerCase().endsWith(".png")) {
                                imageStatues11.add(new Status(file, documentFile.getName(), documentFile.getUri().toString()));
                            }
                        }
                    }
                } else {
                    for (DocumentFile documentFile : documentFiles) {
                        File file = FileUtil.getFile(statusSaverActivity, documentFile.getUri());
                        if (!documentFile.getUri().toString().endsWith(".nomedia")) {
                            if (documentFile.getUri().toString().toLowerCase().endsWith(".jpg") || documentFile.getUri().toString().toLowerCase().endsWith(".png")) {
                                imageStatues11.add(new Status(file, documentFile.getName(), documentFile.getUri().toString()));
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {

        }

    }

    public void checkData() {
        try {
            if (Build.VERSION.SDK_INT < 30) {
                imageListAdapter.updateList(imageList);
                if (imageList.size() == 0) {
                    tv_nothing_to_display.setVisibility(View.VISIBLE);
                } else {
                    tv_nothing_to_display.setVisibility(View.GONE);
                }
            } else {
                imageListAdapter11.updateList11(imageStatues11);
                if (imageStatues11.size() == 0) {
                    tv_nothing_to_display.setVisibility(View.VISIBLE);
                } else {
                    tv_nothing_to_display.setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {

        }

    }

    public class ImageListAdapter extends RecyclerView.Adapter<ImageListAdapter.ViewHolder> {

        Context context;
        ArrayList<File> imageStatusList = new ArrayList<>();

        public ImageListAdapter(Context context) {
            this.context = context;
        }

        public void updateList(ArrayList<File> imageStatusList) {
            this.imageStatusList = imageStatusList;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.status_item_layout_new, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
            File file = imageStatusList.get(position);


            holder.iv_play.setVisibility(View.GONE);
            holder.iv_download.setVisibility(Constants.isDownloaded(file.getName()) ? View.GONE : View.VISIBLE);


            holder.iv_play.setVisibility(View.GONE);
            Glide.with(context).load(file.getAbsoluteFile()).into(holder.iv_image_status);

            holder.iv_download.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    copyFile(file, context, (statusSaverActivity.isStatusAppPresent) ? statusSaverActivity.APP_DIR_WA : statusSaverActivity.APP_DIR_WAB);
                    Constants.scanBothAppFile(context, "", new Constants.CallBackOfListFiles() {
                        @Override
                        public void checkFile(String selectedFilePath) {
                            notifyItemChanged(position);
                        }
                    });

                }
            });

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    InterAdCall.getHelpIndicatorExplicit().callintermethod(getActivity(), true, msg -> {
                        Intent intent = new Intent(context, VS_Status_Image_Preview_Activity.class);
                        intent.putExtra("image_show", String.valueOf(file.getAbsolutePath()));
                        intent.putExtra("preview_value", 1);
                        intent.putExtra("show_download", false);
                        context.startActivity(intent);
                    });


                }
            });


        }

        @Override
        public int getItemCount() {
            return imageStatusList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView iv_image_status;
            ImageView iv_play;
            ImageView iv_download;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                iv_image_status = itemView.findViewById(R.id.main_item_image);
                iv_play = itemView.findViewById(R.id.play_button);
                iv_download = itemView.findViewById(R.id.status_item_down_img);
            }
        }
    }

    public class ImageListAdapter11 extends RecyclerView.Adapter<ImageListAdapter11.ViewHolder> {

        Context context;
        ArrayList<Status> imageStatusList11 = new ArrayList<>();

        public ImageListAdapter11(Context context) {
            this.context = context;
        }


        public void updateList11(ArrayList<Status> imageStatusList11) {
            this.imageStatusList11 = imageStatusList11;
            if (this.imageStatusList11.size() == 0) {
                tv_nothing_to_display.setVisibility(View.VISIBLE);
            } else {
                tv_nothing_to_display.setVisibility(View.GONE);
            }


            notifyDataSetChanged();

        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.status_item_layout_new, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

            Status status = imageStatusList11.get(position);



            holder.iv_play.setVisibility(View.GONE);

            holder.iv_download.setVisibility(Constants.isDownloaded(status.getTitle()) ? View.GONE : View.VISIBLE);

            holder.iv_play.setVisibility(View.GONE);

            Glide.with(context).load(status.getPath()).into(holder.iv_image_status);

            holder.iv_download.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    SaveSS(status.getPath(), status.getTitle(), context, (statusSaverActivity.isStatusAppPresent) ? statusSaverActivity.APP_DIR_WA : statusSaverActivity.APP_DIR_WAB);
                    Constants.scanBothAppFile(context, "", new Constants.CallBackOfListFiles() {
                        @Override
                        public void checkFile(String selectedFilePath) {
                            notifyItemChanged(position);
                        }
                    });
                }
            });

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    InterAdCall.getHelpIndicatorExplicit().callintermethod(requireActivity(), true, msg -> {
                        Intent intent = new Intent(context, VS_Status_Image_Preview_Activity.class);
                        intent.putExtra("image_show", String.valueOf(status.getPath()));
                        intent.putExtra("preview_value", 1);
                        intent.putExtra("show_download", false);
                        context.startActivity(intent);
                    });


                }
            });

        }

        @Override
        public int getItemCount() {
            return imageStatusList11.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView iv_image_status;
            ImageView iv_play;
            ImageView iv_download;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                iv_image_status = itemView.findViewById(R.id.main_item_image);
                iv_play = itemView.findViewById(R.id.play_button);
                iv_download = itemView.findViewById(R.id.status_item_down_img);
            }
        }
    }

}