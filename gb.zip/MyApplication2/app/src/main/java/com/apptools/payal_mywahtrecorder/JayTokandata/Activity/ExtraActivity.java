package com.apptools.payal_mywahtrecorder.JayTokandata.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_ExitActivity;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.Jaylanguage.LanguageActivity;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.R;

public class ExtraActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.extra3);


        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        findViewById(R.id.start2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(ExtraActivity.this, true, msg -> {
                    startActivity(new Intent(ExtraActivity.this, LanguageActivity.class));
                });


            }
        });

    }


    @Override
    public void onBackPressed() {

        startActivity(new Intent(ExtraActivity.this, JayHome_ExitActivity.class));

    }


}
