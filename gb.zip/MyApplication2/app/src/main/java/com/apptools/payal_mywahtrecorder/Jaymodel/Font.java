package com.apptools.payal_mywahtrecorder.Jaymodel;

public class Font {

    private String[] texts;


    public Font(String[] strArr) {

        this.texts = strArr;
    }


    public String[] getTexts() {
        return this.texts;
    }

    public void setTexts(String[] strArr) {
        this.texts = strArr;
    }
}
