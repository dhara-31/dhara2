package com.apptools.payal_mywahtrecorder.JayHomeActivity;


import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.apptools.payal_mywahtrecorder.JayFragments.ReceivedFragment.list_recevi;
import static com.apptools.payal_mywahtrecorder.JayFragments.SentFragment.list_sent;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterRecevi.list_select_doc;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterRecevi.list_select_file;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_doc_sent;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_file_sent;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.storage.StorageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;

import com.apptools.payal_mywahtrecorder.JayFragments.ReceivedFragment;
import com.apptools.payal_mywahtrecorder.JayFragments.SentFragment;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;
import com.apptools.payal_mywahtrecorder.Jayutils.Utils;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.BasePermissionActivity;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.PermissionClass;

import java.io.File;
import java.util.ArrayList;

public class JayHome_CleanerHomeMediaActivity extends BasePermissionActivity {


    PreferenceUtil preferenceUtil;
    ImageView img_back_btn;
    TextView activity_name_text;
    LinearLayout rela_img, rela_vid, rela_aud, rela_doc, rela_voi, rela_sti, rela_bac, rela_gif;
    TextView text_img_total, text_vid_total, text_aud_total, text_doc_total, text_voi_total, text_sti_total, text_bac_total, text_gif_total, text_size_k_m_g_set;
    ImageView btn_all_data_clean;
    TextView txt_total_size, txt_file_found;
    private String select_w;
    private String path_ex_set;
    private String uir_11_path;
    public static Long[] size_path_log;
    public static Integer[] file_set_int;
    private int counter = 0;
    public String[] tital_set = {"Images", "Videos", "Audio", "Documents", "Voice", "Stickers", "Gifs", "Backups"};
    public static String[] path_set = {"WhatsApp Images", "WhatsApp Video", "WhatsApp Audio", "WhatsApp Documents", "WhatsApp Voice Notes", "WhatsApp Stickers", "WhatsApp Animated Gifs", "Backups"};
    public static String[] path_set_w4b = {"WhatsApp Business Images", "WhatsApp Business Video", "WhatsApp Business Audio", "WhatsApp Business Documents", "WhatsApp Business Voice Notes", "WhatsApp Business Stickers", "WhatsApp Business Animated Gifs", "Backups"};
    public static int selectedPos = 0;
    private AlertDialog alert_select;
    private Dialog dialog;

    ImageView ivd_img_play;

    Activity activity;

    View permissionLayoutForCleaner, mainLayoutForCleaner;
    TextView permissionButtonForCleaner, permissionDescForCleaner;

    private long mLastClickTime = 0;
    final long CLICK_TIME_INTERVAL = 800;
    final long CLICK_TIME_INTERVAL2 = 800;


    @Override
    public void onResumePermission() {
        setsizetext(true);
    }

    @Override
    public void onCreatePermission(@Nullable Bundle savedInstanceState) {


        ArrayList<String> permission = new ArrayList<>();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            permission.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            permission.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        setPermissions(permission);

        setContentView(R.layout.activity_cleaner_home_mediatools);


        preferenceUtil = new PreferenceUtil(this);

        activity = this;

        BannerAdLayout.fillMeAlone(this, findViewById(R.id.relQbanner1), findViewById(R.id.frameQbanner1));
        permissionLayoutForCleaner = findViewById(R.id.permissionLayoutForCleaner);
        mainLayoutForCleaner = findViewById(R.id.mainLayoutForCleaner);
        permissionButtonForCleaner = findViewById(R.id.permissionButtonForCleaner);
        permissionDescForCleaner = findViewById(R.id.permissionDescForCleaner);

        img_back_btn = findViewById(R.id.img_back_btn);
        activity_name_text = findViewById(R.id.activity_name_text);
        ivd_img_play = findViewById(R.id.ivd_img_play);
        activity_name_text.setText(JemsProviderKt.getMyString(activity, R.string.media_cleaner));
        img_back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        size_path_log = new Long[]{0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L};
        file_set_int = new Integer[]{0, 0, 0, 0, 0, 0, 0, 0};

        txt_total_size = findViewById(R.id.txt_total_size);
        txt_file_found = findViewById(R.id.txt_file_found);
        text_size_k_m_g_set = findViewById(R.id.text_size_k_m_g_set);

        rela_img = findViewById(R.id.rela_img);
        rela_vid = findViewById(R.id.rela_vid);
        rela_aud = findViewById(R.id.rela_aud);
        rela_doc = findViewById(R.id.rela_doc);
        rela_voi = findViewById(R.id.rela_voi);
        rela_sti = findViewById(R.id.rela_sti);
        rela_bac = findViewById(R.id.rela_bac);
        rela_gif = findViewById(R.id.rela_gif);

        text_img_total = findViewById(R.id.text_img_total);
        text_vid_total = findViewById(R.id.text_vid_total);
        text_aud_total = findViewById(R.id.text_aud_total);
        text_doc_total = findViewById(R.id.text_doc_total);
        text_voi_total = findViewById(R.id.text_voi_total);
        text_sti_total = findViewById(R.id.text_sti_total);
        text_bac_total = findViewById(R.id.text_bac_total);
        text_gif_total = findViewById(R.id.text_gif_total);

        btn_all_data_clean = findViewById(R.id.btn_all_data_clean);


        btn_all_data_clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(activity);
                final View customLayout = LayoutInflater.from(activity).inflate(R.layout.delete_all_media_dilog, null, false);
                alertDialog.setView(customLayout);


                ImageView Cancel_status_dilog = customLayout.findViewById(R.id.Cancel_status_dilog);
                ImageView ok_status_dilog = customLayout.findViewById(R.id.ok_status_dilog);

                Cancel_status_dilog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alert_select.dismiss();

                    }
                });
                ok_status_dilog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        counter = 0;

                        if (select_w.equals("whaz_nor")) {

                            if (Build.VERSION.SDK_INT >= 30) {
                                new DELETE_DOC_11().execute(DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile("Media").findFile(path_set[counter]));
                            } else {
                                new DELETE_FILE_10().execute(new File(path_ex_set, path_set[0]));
                            }

                        } else {
                            if (Build.VERSION.SDK_INT >= 30) {
                                new DELETE_DOC_11().execute(DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile("Media").findFile(path_set_w4b[counter]));
                            } else {

                                new DELETE_FILE_10().execute(new File(path_ex_set, path_set_w4b[0]));
                            }
                        }
                        diloagshowmoth();
                        alert_select.dismiss();

                    }
                });
                alert_select = alertDialog.create();
                alert_select.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                if (alert_select.isShowing()) {
                    alert_select.dismiss();
                }
                alert_select.show();
            }
        });
        btn_all_data_clean.setClickable(false);

        rela_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 0;
                setselctitem(0);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.image_cleaner));
            }
        });
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);

        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

        rela_vid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 1;
                setselctitem(1);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.video_cleaner));
            }
        });
        rela_aud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 2;
                setselctitem(2);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.audio_cleaner));
            }
        });
        rela_doc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 3;
                setselctitem(3);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.document_cleaner));
            }
        });
        rela_voi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 4;
                setselctitem(4);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.voice_notes_cleaner));
            }
        });
        rela_sti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 5;
                setselctitem(5);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.stickers_cleaner));

            }
        });
        rela_bac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 7;
                setselctitem(7);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.backups_cleaner));
            }
        });
        rela_gif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPos = 6;
                setselctitem(6);
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_TITAL, JemsProviderKt.getMyString(activity, R.string.gif_cleaner));
            }
        });

        ivd_img_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupWindow popupWindow_obj = popupDisplay();
                popupWindow_obj.showAsDropDown(ivd_img_play, 40, 18);
                popupWindow_obj.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        });

        permissionButtonForCleaner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PermissionClass permissionHelper = getPermissionHelper();
                if (permissionHelper != null) {
                    permissionHelper.askPermission(activity, true);
                }
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    @Override
    public void forceToOpenSetting(boolean need) {
        if (need) {
            permissionButtonForCleaner.setText("Open Setting");
        } else {
            permissionButtonForCleaner.setText("Permission Grant");
        }
    }

    boolean isSet = false;

    @Override
    public void permissionAllowCallBack(boolean permissionAllowed) {

        ivd_img_play.setVisibility(GONE);
        mainLayoutForCleaner.setVisibility(GONE);
        permissionLayoutForCleaner.setVisibility(VISIBLE);


        if (permissionAllowed) {
            if (JemsProviderKt.isStatusPermissionAllow(this)) {
                permissionLayoutForCleaner.setVisibility(GONE);
                mainLayoutForCleaner.setVisibility(VISIBLE);
                ivd_img_play.setVisibility(VISIBLE);


                if (isSet) {
                    return;
                }
                isSet = true;

                try {
                    select_w = preferenceUtil.getString(PreferenceUtil.SELECT_WHAZ, "whaz_nor");
                    statusApp1 = select_w.equals("whaz_nor");
                    ivd_img_play.setImageResource((statusApp1) ? R.drawable.wahts : R.drawable.buziness_);
                    path_ex_set = Utils.checktogetpath10down(select_w);
                    uir_11_path = set11upgetpath(select_w);
                    setsizetext(true);

                    diloagshowmoth();
                    if (Build.VERSION.SDK_INT <= 29) {
                        new COUNT_DATA_10().execute(new File(path_ex_set, path_set[0]));
                    } else {
                        new COUNT_DATA_11().execute(DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile("Media").findFile(path_set[counter]));
                    }
                } catch (Exception e) {
                    setsizetext(true);
                }


            } else {
                permissionDescForCleaner.setText("We need some basic permission for read Image and Video from your app data.");
                permissionButtonForCleaner.setText("Allow");
                permissionButtonForCleaner.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent;
                        StorageManager sm = (StorageManager) getApplicationContext().getSystemService(STORAGE_SERVICE);
                        String statusDir = "Android%2Fmedia";
                        String str = "android.provider.extra.INITIAL_URI";

                        if (Build.VERSION.SDK_INT >= 30) {
                            intent = sm.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
                            String scheme = ((Uri) intent.getParcelableExtra(str)).toString().replace("/root/", "/document/");
                            String stringBuilder = scheme + "%3A" + statusDir;
                            intent.putExtra(str, Uri.parse(stringBuilder));
                        } else {
                            intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                            intent.putExtra(str, Uri.parse(statusDir));
                        }
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                        startActivityForResult(intent, 111);
                    }
                });
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 111 && resultCode == Activity.RESULT_OK) {
            try {
                Uri uri;
                if (data != null) {
                    uri = data.getData();
                    if (uri != null) {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        if (uri.toString().endsWith("Android%2Fmedia")) {
                            new PreferenceUtil(this).putString(PreferenceUtil.KeyUseThisFolder, uri.toString());
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }


    }


    boolean statusApp1 = true;

    PopupWindow popupWindow;

    public PopupWindow popupDisplay() {


        if (popupWindow == null) {
            popupWindow = new PopupWindow(activity);
        }


        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.more_layout, null);

        LinearLayout ll_wa = view.findViewById(R.id.ll_wa);
        LinearLayout ll_wab = view.findViewById(R.id.ll_wab);
        TextView tv_wa = view.findViewById(R.id.tv_wa);
        TextView tv_wab = view.findViewById(R.id.tv_wab);


        if (statusApp1) {
            tv_wa.setTextColor(Color.parseColor("#019553"));
            tv_wab.setTextColor(Color.parseColor("#000000"));
        } else {
            tv_wa.setTextColor(Color.parseColor("#000000"));
            tv_wab.setTextColor(Color.parseColor("#019553"));
        }

        ll_wa.setOnClickListener(view1 -> {
            long now = System.currentTimeMillis();
            if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                return;
            }
            mLastClickTime = now;
            if (!statusApp1) {
                statusApp1 = true;
                set11upgetpath("whaz_nor");
                preferenceUtil.putString(PreferenceUtil.SELECT_WHAZ, "whaz_nor");
                select_w = "whaz_nor";
                size_path_log = new Long[]{0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L};
                file_set_int = new Integer[]{0, 0, 0, 0, 0, 0, 0, 0};
                ivd_img_play.setImageResource((statusApp1) ? R.drawable.wahts : R.drawable.buziness_);
                try {
                    counter = 0;
                    if (Build.VERSION.SDK_INT <= 29) {

                        new COUNT_DATA_10().execute(new File(path_ex_set, path_set[0]));
                    } else {
                        new COUNT_DATA_11().execute(DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile("Media").findFile(path_set[counter]));
                    }
                    diloagshowmoth();
                } catch (Exception e) {
                    setsizetext(true);
                }
            }
            popupWindow.dismiss();
        });

        ll_wab.setOnClickListener(view12 -> {

            long now = System.currentTimeMillis();
            if (now - mLastClickTime < CLICK_TIME_INTERVAL2) {
                return;
            }
            mLastClickTime = now;

            if (statusApp1) {
                statusApp1 = false;
                set11upgetpath("waz_w4b");
                preferenceUtil.putString(PreferenceUtil.SELECT_WHAZ, "waz_w4b");
                select_w = "waz_w4b";
                size_path_log = new Long[]{0L, 0L, 0L, 0L, 0L, 0L, 0L, 0l};
                file_set_int = new Integer[]{0, 0, 0, 0, 0, 0, 0, 0};
                ivd_img_play.setImageResource((statusApp1) ? R.drawable.wahts : R.drawable.buziness_);

                try {
                    counter = 0;
                    if (Build.VERSION.SDK_INT <= 29) {
                        new COUNT_DATA_10().execute(new File(path_ex_set, path_set_w4b[0]));
                    } else {
                        new COUNT_DATA_11().execute(DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile("Media").findFile(path_set_w4b[counter]));
                    }
                    diloagshowmoth();
                } catch (Exception e) {
                    setsizetext(true);
                }
            }
            popupWindow.dismiss();
        });

        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.setWidth(WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        popupWindow.setContentView(view);

        return popupWindow;
    }


    private void setselctitem(int pos) {


        if (Build.VERSION.SDK_INT >= 30) {
            try {


                DocumentFile file_img = null;
                if (pos == 7) {
                    if (select_w.equals("whaz_nor")) {
                        file_img = DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile(path_set[pos]);

                    } else if (select_w.equals("waz_w4b")) {
                        file_img = DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile(path_set_w4b[pos]);
                    }


                } else {
                    if (select_w.equals("whaz_nor")) {
                        file_img = DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile("Media").findFile(path_set[pos]);
                    } else if (select_w.equals("waz_w4b")) {
                        file_img = DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile("Media").findFile(path_set_w4b[pos]);
                    }
                }
                if (file_img != null && file_img.exists()) {
                    preferenceUtil.putString(PreferenceUtil.SET_SELECT_ITME, file_img.getUri().toString());
                }


            } catch (Exception e) {
                preferenceUtil.putString(PreferenceUtil.SET_SELECT_ITME, uir_11_path);
            }

        } else {
            File file = null;
            if (pos == 7) {

                File file1 = new File(path_ex_set);
                file = new File(file1.getParent(), path_set[pos]);

            } else {

                if (select_w.equals("whaz_nor")) {
                    file = new File(path_ex_set, path_set[pos]);


                } else if (select_w.equals("waz_w4b")) {
                    file = new File(path_ex_set, path_set_w4b[pos]);
                }
            }

            preferenceUtil.putString(PreferenceUtil.SET_SELECT_ITME, file.getAbsolutePath());
        }


        preferenceUtil.putString(PreferenceUtil.SET_NIIK_TITAL, tital_set[pos]);


        list_recevi.clear();
        list_sent.clear();
        list_select_file_sent.clear();
        list_select_doc_sent.clear();
        list_select_file.clear();
        list_select_doc.clear();
        SentFragment.size_sent_set = 0;
        ReceivedFragment.size_rece_set = 0;

        InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_CleanerHomeMediaActivity.this, true, msg -> {
            Intent intent = new Intent(activity, JayHome_CleanerSelectItmeActivity.class);
            startActivity(intent);
        });


    }

    private void diloagshowmoth() {
        if (dialog != null) {
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
        }
        dialog = new Dialog(activity);
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        View v = LayoutInflater.from(activity).inflate(R.layout.dialog_loader, null);
        dialog.setContentView(v);
        if (dialog.isShowing()) {
            dialog.dismiss();
        }
        dialog.show();
    }

    public String set11upgetpath(String select_w) {
        preferenceUtil.putString(PreferenceUtil.SELECT_WHAZ, select_w);
        return preferenceUtil.getString(PreferenceUtil.KeyUseThisFolder, "");

    }


    private void setsizetext(boolean b) {


        long sum_size = 0;
        int sum_file = 0;
        int i = 0;
        int a = 0;
        for (long l : size_path_log) {

            sum_size = sum_size + l;
            i++;
        }


        for (int l : file_set_int) {

            sum_file = sum_file + l;
            a++;
        }
        if (sum_size == 0) {
            btn_all_data_clean.setVisibility(View.GONE);
        } else {
            btn_all_data_clean.setVisibility(View.VISIBLE);
        }
        String size = Utils.readableFileSize(sum_size);
        String[] sizea1 = size.split(" ");

        txt_total_size.setText(sizea1[0]);
        text_size_k_m_g_set.setText(sizea1[1]);
        txt_file_found.setText(sum_file + " " + JemsProviderKt.getMyString(activity, R.string.files_found));

        text_img_total.setText(file_set_int[0] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[0]));
        text_vid_total.setText(file_set_int[1] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[1]));
        text_aud_total.setText(file_set_int[2] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[2]));
        text_doc_total.setText(file_set_int[3] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[3]));
        text_voi_total.setText(file_set_int[4] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[4]));
        text_sti_total.setText(file_set_int[5] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[5]));
        text_bac_total.setText(file_set_int[7] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[7]));
        text_gif_total.setText(file_set_int[6] + " " + JemsProviderKt.getMyString(activity, R.string.files) + "\n" + Utils.readableFileSize(size_path_log[6]));

    }


    class COUNT_DATA_11 extends AsyncTask<DocumentFile, Void, Long> {
        int totalSizeNumber = 0;
        String tital = "";
        long size = 0;


        @Override
        protected Long doInBackground(DocumentFile... documentFiles) {
            try {
                if (documentFiles[0] != null && documentFiles[0].exists()) {
                    tital = documentFiles[0].getName();
                    return getfiltsizelong(documentFiles[0]);
                } else {
                    return 0L;
                }
            } catch (Exception e) {
                return 0L;
            }

        }

        private long getfiltsizelong(DocumentFile file) {

            DocumentFile[] files = file.listFiles();
            for (DocumentFile file1 : files) {
                if (file1.exists() && !file1.getName().contains(".nomedia")) {
                    if (file1.isFile()) {


                        size += file1.length();
                        totalSizeNumber++;


                    } else {
                        if (file1.getName().equals("Private")) {
                        } else {
                            size = getfiltsizelong(file1);
                        }
                    }
                }
            }

            return size;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            if (counter == 1) {
                dialog.dismiss();
                rela_vid.setClickable(false);
                rela_aud.setClickable(false);
                rela_doc.setClickable(false);
                rela_voi.setClickable(false);
                rela_sti.setClickable(false);
                rela_bac.setClickable(false);
                rela_gif.setClickable(false);
            } else if (counter == 2) {
                rela_vid.setClickable(true);
            } else if (counter == 3) {
                rela_aud.setClickable(true);
            } else if (counter == 4) {
                rela_doc.setClickable(true);

            } else if (counter == 5) {
                rela_voi.setClickable(true);

            } else if (counter == 6) {
                rela_sti.setClickable(true);

            } else if (counter == 7) {
                rela_bac.setClickable(true);
                btn_all_data_clean.setClickable(true);
            } else {
                rela_vid.setClickable(true);
                rela_aud.setClickable(true);
                rela_doc.setClickable(true);
                rela_voi.setClickable(true);
                rela_sti.setClickable(true);
                rela_bac.setClickable(true);
                rela_gif.setClickable(true);
            }
        }

        @Override
        protected void onPostExecute(Long aLong) {
            super.onPostExecute(aLong);
            try {
                if (select_w.equals("whaz_nor")) {
                    if (tital.equals(path_set[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                } else {
                    if (tital.equals(path_set_w4b[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            counter++;
            if (counter <= 6) {
                try {
                    new COUNT_DATA_11().execute((select_w.equals("whaz_nor")) ? DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile("Media").findFile(path_set[counter]) : DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile("Media").findFile(path_set_w4b[counter]));
                } catch (Exception e) {
                }
            } else if (counter == 7) {
                try {
                    new COUNT_DATA_11().execute((select_w.equals("whaz_nor")) ? DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile(path_set[counter]) : DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile(path_set_w4b[counter]));
                } catch (Exception e) {
                }

            } else {
                rela_gif.setClickable(true);
                btn_all_data_clean.setClickable(true);
            }
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
            setsizetext(true);
        }
    }

    class COUNT_DATA_10 extends AsyncTask<File, Void, Long> {
        int totalSizeNumber = 0;
        String tital = "";
        long size = 0;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            if (counter == 1) {
                dialog.dismiss();
                rela_vid.setClickable(false);
                rela_aud.setClickable(false);
                rela_doc.setClickable(false);
                rela_voi.setClickable(false);
                rela_sti.setClickable(false);
                rela_bac.setClickable(false);
                rela_gif.setClickable(false);
            } else if (counter == 2) {
                rela_vid.setClickable(true);
            } else if (counter == 3) {
                rela_aud.setClickable(true);
            } else if (counter == 4) {
                rela_doc.setClickable(true);

            } else if (counter == 5) {
                rela_voi.setClickable(true);

            } else if (counter == 6) {
                rela_sti.setClickable(true);

            } else if (counter == 7) {
                rela_bac.setClickable(true);
            } else {
                rela_vid.setClickable(true);
                rela_aud.setClickable(true);
                rela_doc.setClickable(true);
                rela_voi.setClickable(true);
                rela_sti.setClickable(true);
                rela_bac.setClickable(true);
                rela_gif.setClickable(true);
            }
        }

        @Override
        protected Long doInBackground(File... files) {
            if (files[0] != null && files[0].exists()) {
                tital = files[0].getName();
                return getFolderSize(files[0]);
            } else {
                return 0L;
            }

        }

        private Long getFolderSize(File file) {


            File[] files = file.listFiles();
            for (File file1 : files) {
                if (!file1.getName().contains(".nomedia")) {
                    if (file1.isFile()) {

                        size += file1.length();
                        totalSizeNumber++;
                    } else {
                        if (file1.getName().equals("Private")) {
                        } else {
                            size = getFolderSize(file1);
                        }
                    }
                }
            }
            return size;

        }

        @Override
        protected void onPostExecute(Long aLong) {
            super.onPostExecute(aLong);

            try {
                if (select_w.equals("whaz_nor")) {
                    if (tital.equals(path_set[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                } else {
                    if (tital.equals(path_set_w4b[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            counter++;
            if (counter <= 6) {
                new COUNT_DATA_10().execute((select_w.equals("whaz_nor")) ? new File(path_ex_set, path_set[counter]) : new File(path_ex_set, path_set_w4b[counter]));

            } else if (counter == 7) {
                File file = new File(path_ex_set);
                new COUNT_DATA_10().execute((select_w.equals("whaz_nor")) ? new File(file.getParent(), path_set[counter]) : new File(file.getParent(), path_set_w4b[counter]));

            } else {
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
                rela_gif.setClickable(true);
                btn_all_data_clean.setClickable(true);
            }
            setsizetext(true);
        }

    }


    class DELETE_DOC_11 extends AsyncTask<DocumentFile, Void, Long> {
        int totalSizeNumber = 0;
        String tital = "";
        long size = 0;

        @Override
        protected Long doInBackground(DocumentFile... documentFiles) {

            if (documentFiles[0] != null && documentFiles[0].exists()) {
                tital = documentFiles[0].getName();
                return getsize0set(documentFiles[0]);
            }

            return 0L;

        }

        private Long getsize0set(DocumentFile documentFile) {
            DocumentFile[] files = documentFile.listFiles();
            for (DocumentFile file1 : files) {
                if (file1.exists() && !file1.getName().contains(".nomedia")) {
                    if (file1.isFile()) {
                        file1.delete();

                    } else {
                        size = getsize0set(file1);
                    }
                }
            }
            totalSizeNumber = 0;
            return 0L;
        }

        @Override
        protected void onPostExecute(Long aLong) {
            super.onPostExecute(aLong);

            try {
                if (select_w.equals("whaz_nor")) {
                    if (tital.equals(path_set[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                } else {
                    if (tital.equals(path_set_w4b[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                }
            } catch (Exception e) {

            }
            counter++;

            if (counter <= 6) {
                new DELETE_DOC_11().execute((select_w.equals("whaz_nor")) ? DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile("Media").findFile(path_set[counter]) : DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile("Media").findFile(path_set_w4b[counter]));

            } else if (counter == 7) {

                new DELETE_DOC_11().execute((select_w.equals("whaz_nor")) ? DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app1).findFile("WhatsApp").findFile(path_set[counter]) : DocumentFile.fromTreeUri(activity, Uri.parse(uir_11_path)).findFile(Constants.app2).findFile("WhatsApp Business").findFile(path_set_w4b[counter]));
            } else {

                setsizetext(false);
                dialog.dismiss();


            }


        }
    }

    class DELETE_FILE_10 extends AsyncTask<File, Void, Long> {

        int totalSizeNumber = 0;
        String tital = "";
        long size = 0;


        @Override
        protected Long doInBackground(File... files) {

            if (files[0] != null && files[0].exists()) {
                tital = files[0].getName();
                getfile0Size(files[0]);
            }

            return 0L;
        }

        private Long getfile0Size(File file) {
            File[] files = file.listFiles();
            for (File file1 : files) {
                if (!file1.getName().contains(".nomedia")) {
                    if (file1.isFile()) {
                        file1.delete();

                    } else {
                        size = getfile0Size(file1);
                    }
                }
            }
            totalSizeNumber = 0;
            return size;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onPostExecute(Long aLong) {
            super.onPostExecute(aLong);

            try {
                if (select_w.equals("whaz_nor")) {
                    if (tital.equals(path_set[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                } else {
                    if (tital.equals(path_set_w4b[counter])) {
                        size_path_log[counter] = aLong;
                        file_set_int[counter] = totalSizeNumber;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            counter++;


            if (counter <= 6) {
                new DELETE_FILE_10().execute((select_w.equals("whaz_nor")) ? new File(path_ex_set, path_set[counter]) : new File(path_ex_set, path_set_w4b[counter]));

            } else if (counter == 7) {
                File file = new File(path_ex_set);
                new DELETE_FILE_10().execute((select_w.equals("whaz_nor")) ? new File(file.getParent(), path_set[counter]) : new File(file.getParent(), path_set_w4b[counter]));
            } else {


                setsizetext(false);
                dialog.dismiss();

            }
        }
    }


}