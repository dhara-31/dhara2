package com.apptools.payal_mywahtrecorder.JayFragments;

import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.getListFiles;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.VS_Status_Image_Preview_Activity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.VS_Status_Video_Preview_Activity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.Jaymodel.my_Item_Interface;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;
import java.util.ArrayList;

public class Download_w4b_Fragment extends Fragment {

    RecyclerView download_w4b_Recycler;
    ArrayList<File> downloadList = new ArrayList<>();

    DownloadAdapter downloadAdapter;
    TextView w4b_txt_not_found;

    public static int value;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_download_w4b_,
                container, false);

        download_w4b_Recycler = rootView.findViewById(R.id.download_w4b_Recycler);
        w4b_txt_not_found = rootView.findViewById(R.id.w4b_txt_not_found);

        download_w4b_Recycler.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        downloadAdapter = new DownloadAdapter(downloadList, getActivity(), new my_Item_Interface() {
            @Override
            public void itemList(int position) {
                getDownloadList();
            }
        });
        download_w4b_Recycler.setAdapter(downloadAdapter);

        return rootView;

    }

    public static Download_w4b_Fragment newInstance(int text) {

        value = text;

        Download_w4b_Fragment f = new Download_w4b_Fragment();

        return f;
    }

    public void getDownloadList() {


            downloadList = getListFiles(new File(JemsProviderKt.getWABPath(requireActivity())), "all");

        downloadAdapter.updateList(downloadList);

        if (downloadList.size() == 0) {
            w4b_txt_not_found.setVisibility(View.VISIBLE);
        } else {
            w4b_txt_not_found.setVisibility(View.GONE);
        }
    }

    public class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.ViewHolder> {

        private ArrayList<File> videoList;
        Activity activity;
        my_Item_Interface fvdItemInterface;
        int itemPos;


        public DownloadAdapter(ArrayList<File> videoList, Activity activity, my_Item_Interface fvdItemInterface) {
            this.videoList = videoList;
            this.activity = activity;
            this.fvdItemInterface = fvdItemInterface;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_download_item_layout, parent, false);
            return new ViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {


            File item = videoList.get(position);


            if (item.getPath().endsWith(".mp4")) {

                holder.play_button.setVisibility(View.VISIBLE);

            } else {

                holder.play_button.setVisibility(View.GONE);
            }


            Glide.with(activity).load(item.getAbsoluteFile()).into(holder.main_item_image);

            holder.main_item_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    if (videoList.get(position).getAbsolutePath().endsWith(".mp4")) {


                        InterAdCall.getHelpIndicatorExplicit().callintermethod(activity, true, msg -> {
                            Intent intent = new Intent(activity, VS_Status_Video_Preview_Activity.class);
                            intent.putExtra("video_file_path", videoList.get(position).getAbsolutePath());
                            intent.putExtra("preview_value", 2);

                            activity.startActivity(intent);

                            fvdItemInterface.itemList(position);
                        });

                    } else {

                        InterAdCall.getHelpIndicatorExplicit().callintermethod(activity, true, msg -> {
                            Intent intent = new Intent(activity, VS_Status_Image_Preview_Activity.class);
                            intent.putExtra("image_show", videoList.get(position).getPath());
                            intent.putExtra("preview_value", 2);
                            activity.startActivity(intent);

                            fvdItemInterface.itemList(position);
                        });



                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return videoList.size();
        }

        public void updateList(ArrayList<File> videoList) {
            this.videoList = videoList;
            notifyDataSetChanged();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            public ImageView main_item_image, play_button;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);


                main_item_image = itemView.findViewById(R.id.main_item_image);
                play_button = itemView.findViewById(R.id.play_button);


            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getDownloadList();
    }
}