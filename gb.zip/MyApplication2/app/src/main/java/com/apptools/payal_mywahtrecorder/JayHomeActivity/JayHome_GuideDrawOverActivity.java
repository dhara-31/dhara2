package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;

public class JayHome_GuideDrawOverActivity extends AppCompatActivity {
    public Handler handler = new Handler();
    public ImageView imgHand;
    public ImageView imgTagle;

    public Runnable playAnime = new Runnable() {

        public void run() {
            imgTagle.setImageResource(R.drawable.switch_off);
            ScaleAnimation scaleAnimation = new ScaleAnimation(1.5f, 1.0f, 1.5f, 1.0f, 0.1f, 0.1f);
            scaleAnimation.setFillBefore(true);
            scaleAnimation.setFillAfter(true);
            scaleAnimation.setStartOffset(500);
            scaleAnimation.setDuration(500);
            scaleAnimation.setAnimationListener(new Animation.AnimationListener() {

                public void onAnimationRepeat(Animation animation) {
                }

                public void onAnimationStart(Animation animation) {
                }

                public void onAnimationEnd(Animation animation) {
                    imgTagle.setImageResource(R.drawable.switch_on);
                    handler.postDelayed(playAnime, 2000);
                }
            });
            imgHand.startAnimation(scaleAnimation);
        }
    };
    boolean key_screen_rec;

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_guide_draw_over);
        this.imgHand = (ImageView) findViewById(R.id.agdo_img_hand);
        this.imgTagle = (ImageView) findViewById(R.id.agdo_img_tagle);

        key_screen_rec = getIntent().getBooleanExtra("key_screen_rec", true);

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        findViewById(R.id.agdo_btn_got).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(JayHome_GuideDrawOverActivity.this)) {
                        if (key_screen_rec) {
                            InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_GuideDrawOverActivity.this, true, msg -> {
                                startActivity(new Intent(JayHome_GuideDrawOverActivity.this, JayHome_Recorder_activity.class));
                                finish();
                            });

                        } else {
                            InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_GuideDrawOverActivity.this, true, msg -> {
                                startActivity(new Intent(JayHome_GuideDrawOverActivity.this, Shake_open_Activity.class));
                                finish();
                            });

                        }
                    } else {

                        showPermissionDialog();
                    }
                } else {
                    if (key_screen_rec) {
                        InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_GuideDrawOverActivity.this, true, msg -> {
                            startActivity(new Intent(JayHome_GuideDrawOverActivity.this, JayHome_Recorder_activity.class)); //2
                            finish();
                        });



                    } else {
                        InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_GuideDrawOverActivity.this, true, msg -> {
                            startActivity(new Intent(JayHome_GuideDrawOverActivity.this, Shake_open_Activity.class));
                            finish();
                        });



                    }

                }

            }
        });

        playAnime.run();
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));

    }

    private void showPermissionDialog() {

        Dialog alertDialog = new Dialog(JayHome_GuideDrawOverActivity.this);
        final View customLayout = LayoutInflater.from(JayHome_GuideDrawOverActivity.this).inflate(R.layout.permis_dialog, null, false);
        alertDialog.setContentView(customLayout);
        Window window = alertDialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        TextView text_Allow_btn_set_dilog = customLayout.findViewById(R.id.text_Allow_btn_set_dilog);
        TextView text_deni_btn_set_dilog = customLayout.findViewById(R.id.text_deni_btn_set_dilog);
        text_Allow_btn_set_dilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 43);

            }
        });

        text_deni_btn_set_dilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        alertDialog.show();

    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 43 && Build.VERSION.SDK_INT >= 23) {
            if (Settings.canDrawOverlays(this)) {
                if (key_screen_rec) {
                    startActivity(new Intent(JayHome_GuideDrawOverActivity.this, JayHome_Recorder_activity.class)); //3
                    finish();
                } else {
                    startActivity(new Intent(JayHome_GuideDrawOverActivity.this, Shake_open_Activity.class));
                    finish();
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
