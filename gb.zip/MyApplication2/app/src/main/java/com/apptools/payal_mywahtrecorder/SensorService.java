package com.apptools.payal_mywahtrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

public class SensorService extends Service implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private float mAccel;
    private float mAccelCurrent;
    private float mAccelLast;
    public static boolean isServiceRunning;
    Context context;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        context = this;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotification();
        } else {
            startForeground(12, new Notification());
        }
        isServiceRunning = true;


    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_UI, new Handler());
        return START_STICKY;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];
        mAccelLast = mAccelCurrent;
        mAccelCurrent = (float) Math.sqrt((double) (x * x + y * y + z * z));
        float delta = mAccelCurrent - mAccelLast;
        mAccel = mAccel * 0.9f + delta;
        SharedPreferences SharedPref;
        SharedPref = getSharedPreferences("ShakePRef", Context.MODE_MULTI_PROCESS);
        if (mAccel > 13) {

            if (SharedPref.getBoolean("shake_on_off_switch_key", false) && JemsProviderKt.isScreenOn(this)) {
                try {
                    if (waInstalledOrNot(Constants.app1) && waInstalledOrNot(Constants.app2)) {
                        if (SharedPref.getString("Wshap", "wa").equals("wa")) {
                            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(Constants.app1);
                            startActivity(launchIntent);
                        } else {
                            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(Constants.app2);
                            startActivity(launchIntent);
                        }
                    } else if (waInstalledOrNot(Constants.app1)) {
                        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(Constants.app1);
                        startActivity(launchIntent);
                    } else if (waInstalledOrNot(Constants.app2)) {
                        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(Constants.app2);
                        startActivity(launchIntent);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public static class ShakeDetector implements SensorEventListener {


        private static final float SHAKE_THRESHOLD_GRAVITY = 2.7F;
        private static final int SHAKE_SLOP_TIME_MS = 200;
        private static final int SHAKE_COUNT_RESET_TIME_MS = 2000;

        private OnShakeListener mListener;
        private long mShakeTimestamp;
        private int mShakeCount;

        public void setOnShakeListener(OnShakeListener listener) {
            this.mListener = listener;
        }

        public interface OnShakeListener {
            public void onShake(int count);
        }

        public static float getShakeThresholdGravity() {
            return SHAKE_THRESHOLD_GRAVITY;
        }


        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }

        @Override
        public void onSensorChanged(SensorEvent event) {


            if (mListener != null) {
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];

                float gX = x / SensorManager.GRAVITY_EARTH;
                float gY = y / SensorManager.GRAVITY_EARTH;
                float gZ = z / SensorManager.GRAVITY_EARTH;


                float gForce = (float) Math.sqrt(gX * gX + gY * gY + gZ * gZ);

                if (gForce > SHAKE_THRESHOLD_GRAVITY) {
                    final long now = System.currentTimeMillis();
                    if (mShakeTimestamp + SHAKE_SLOP_TIME_MS > now) {
                        return;
                    }


                    if (mShakeTimestamp + SHAKE_COUNT_RESET_TIME_MS < now) {
                        mShakeCount = 0;
                    }

                    mShakeTimestamp = now;
                    mShakeCount++;

                    mListener.onShake(mShakeCount);
                }
            }
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public void createNotification() {

        String NOTIFICATION_CHANNEL_ID = "example.permanence";
        String channelName = "Background Service";
        NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_HIGH);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        assert mNotificationManager != null;
        mNotificationManager.createNotificationChannel(notificationChannel);


        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);

        if (Build.VERSION.SDK_INT <= 29) {
            mBuilder.setSmallIcon(R.drawable.icon_shakeic);
        } else {
            mBuilder.setSmallIcon(R.drawable.icon_shake);
        }

        Notification notification = mBuilder.setOngoing(true).setContentTitle("ShakeService running").setOngoing(false).setPriority(NotificationManager.IMPORTANCE_MAX).setCategory(Notification.CATEGORY_SERVICE).build();
        startForeground(12, notification);


    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onDestroy() {

        try {
            SharedPreferences SharedPref;
            SharedPref = getSharedPreferences("ShakePRef", Context.MODE_MULTI_PROCESS);
            if (SharedPref.getBoolean("shake_on_off_switch_key", false)) {


            } else {
                if (mSensorManager != null) {
                    mSensorManager.unregisterListener((SensorEventListener) this, mAccelerometer);
                    mSensorManager = null;
                }
                stopSelf();
            }
        } catch (Exception e) {

        }


        super.onDestroy();

    }


    private boolean waInstalledOrNot(String str) {
        try {
            this.getPackageManager().getPackageInfo(str, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

}
