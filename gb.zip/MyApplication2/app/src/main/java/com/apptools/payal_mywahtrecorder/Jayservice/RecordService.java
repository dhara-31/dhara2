package com.apptools.payal_mywahtrecorder.Jayservice;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Point;
import android.hardware.display.VirtualDisplay;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RemoteViews;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHomeCaptureActivity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.NotificationActivity;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.ResultActivity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JAydata.OptionMenuBuilder;
import com.apptools.payal_mywahtrecorder.JAydata.PerferencedName;
import com.apptools.payal_mywahtrecorder.JAydata.RecordData;
import com.apptools.payal_mywahtrecorder.JAydata.RecordMode;
import com.apptools.payal_mywahtrecorder.JAydata.RecordModeFunction;
import com.apptools.payal_mywahtrecorder.Jayutils.DatabaseUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.FileUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class RecordService extends Service {
    public static final String GUIDE_KEY = "confirm_record_guide";

    public Runnable checkSpace = new Runnable() {


        public void run() {
            if (RecordService.this.running) {
                if (RecordService.this.hasEnoughSpace()) {
                    RecordService.this.recordHandler.postDelayed(RecordService.this.checkSpace, 5000);
                    return;
                }
                RecordService.this.stopRecord(false);
                AlertDialog.Builder builder = new AlertDialog.Builder(RecordService.this);
                builder.setMessage(R.string.tips_no_freespace);
                builder.setTitle(R.string.tips);
                builder.setPositiveButton(R.string.tips_ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        RecordService.this.showResultActivity();
                    }
                });
                AlertDialog create = builder.create();
                create.getWindow().setType(2003);
                create.show();
            }
        }
    };
    private boolean confirmGuide = false;
    private Runnable countDown = new Runnable() {


        public void run() {
            if (RecordService.this.mediaProjection == null) {
                RecordService.this.recordHandler.postDelayed(RecordService.this.countDown, 200);
                return;
            }
            RecordService.this.leftCountdown--;
            if (RecordService.this.leftCountdown > 0) {
                RecordService.this.txtCountdown.setText(RecordService.this.leftCountdown + "");
                if (RecordService.this.txtCountdown.getParent() == null) {
                    int i = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
                    new WindowManager.LayoutParams();
                    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, i, 8, -3);
                    layoutParams.format = 1;
                    layoutParams.gravity = Gravity.CENTER;
                    RecordService.this.windowManager.addView(RecordService.this.txtCountdown, layoutParams);
                }
                RecordService.this.recordHandler.postDelayed(RecordService.this.countDown, 1000);
                return;
            }
            if (RecordService.this.txtCountdown.getParent() != null) {
                RecordService.this.windowManager.removeView(RecordService.this.txtCountdown);
            }
            RecordService.this.checkToBeginRecord();
        }
    };
    public RelativeLayout floatLayout;
    public ImageView imgDelete;
    public ImageView imgRecord;
    public boolean isDestroys = false;
    public boolean isFloatViewCreated = false;
    public boolean isPreparing = false;
    public boolean isRequestingCapture = false;
    public FrameLayout layGuide;
    public int leftCountdown = 0;
    public NotificationManager manager;
    public MediaProjection mediaProjection;
    public RecordModeFunction modeFunction;
    public int originVolume;
    public MediaProjectionManager projectionManager;
    public BroadcastReceiver receiver;
    public long recordBeginTime = 0;
    public Handler recordHandler = new Handler();
    public boolean recordInDelete = false;
    public MediaRecorder recorder;
    public boolean running;
    public int touchMoveTime = 0;
    public boolean touchMoved = false;
    public TextView txtCountdown;
    public VirtualDisplay virtualDisplay;
    public WindowManager windowManager;

    @SuppressLint("WrongConstant")
    public int onStartCommand(Intent intent, int i, int i2) {
        return 1;
    }

    public class RecordBinder extends Binder {
        public RecordBinder() {
        }

        public RecordService getRecordService() {
            return RecordService.this;
        }
    }

    @SuppressLint("WrongConstant")
    public void onCreate() {
        super.onCreate();

        DApplication.recordService = this;
        this.running = false;
        this.projectionManager = (MediaProjectionManager) getSystemService("media_projection");
        this.confirmGuide = DApplication.sP.getBoolean(GUIDE_KEY, false);
        showNotification();
        initReceiver();
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.running) {
            stopRecord(false);
        }
        ImageView imageView = this.imgRecord;
        if (!(imageView == null || imageView.getParent() == null)) {
            this.windowManager.removeView(this.imgRecord);
            this.imgRecord = null;
        }
        ImageView imageView2 = this.imgDelete;
        if (!(imageView2 == null || imageView2.getParent() == null)) {
            this.windowManager.removeView(this.imgDelete);
            this.imgDelete = null;
        }
        FrameLayout frameLayout = this.layGuide;
        if (!(frameLayout == null || frameLayout.getParent() == null)) {
            this.windowManager.removeView(this.layGuide);
            this.layGuide = null;
        }
        MediaProjection mediaProjection2 = this.mediaProjection;
        if (mediaProjection2 != null) {
            mediaProjection2.stop();
        }
        removeNotification();
        DApplication.getBm().unregisterReceiver(this.receiver);
        DApplication.recordService = null;
        this.isDestroys = true;
    }

    public IBinder onBind(Intent intent) {
        return new RecordBinder();
    }

    @SuppressLint("WrongConstant")
    private void requestCaptureScreen() {
        if (!this.isRequestingCapture) {

            this.isRequestingCapture = true;
            Intent intent = new Intent(this, JayHomeCaptureActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);


        }
    }

    public void initReceiver() {
        this.receiver = new BroadcastReceiver() {


            @SuppressLint("WrongConstant")
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                switch (action.hashCode()) {
                    case -148268886:
                        if (action.equals(Message.REJECT_SCREEN_PROJECTION)) {
                            RecordService recordService = RecordService.this;
                            recordService.isRequestingCapture = false;
                            Toast.makeText(recordService.getApplicationContext(), (int) R.string.tips_no_permision, 0).show();
                            return;
                        }
                        return;
                    case 158110841:
                        if (action.equals(Message.CLOSE_APP)) {
                            RecordService.this.closeApp();
                            return;
                        }
                        return;
                    case 406686145:
                        if (action.equals(Message.GET_SCREEN_PROJECTION)) {
                            RecordService.this.mediaProjection = DApplication.screenProjection;
                            RecordService recordService2 = RecordService.this;
                            recordService2.isRequestingCapture = false;
                            recordService2.checkToBeginRecord();
                            return;
                        }
                        return;
                    case 789946769:
                        if (!action.equals(Message.CHANGE_STATE)) {
                            return;
                        }
                        if (RecordService.this.running) {
                            RecordService.this.stopRecord(true);
                            return;
                        } else {
                            RecordService.this.startRecord();
                            return;
                        }
                    case 1130210704:
                        if (action.equals(Message.SHOW_RECORD_BUTTON)) {
                            RecordService.this.showRecord();
                            return;
                        }
                        return;
                    case 1141611347:
                        if (action.equals(Message.GET_OVER_LAY_PROMISSION)) {
                            RecordService.this.createFloatView();
                            return;
                        }
                        return;
                    default:
                        return;
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Message.GET_OVER_LAY_PROMISSION);
        intentFilter.addAction(Message.GET_SCREEN_PROJECTION);
        intentFilter.addAction(Message.REJECT_SCREEN_PROJECTION);
        intentFilter.addAction(Message.CHANGE_STATE);
        intentFilter.addAction(Message.CLOSE_APP);
        intentFilter.addAction(Message.SHOW_RECORD_BUTTON);
        DApplication.getBm().registerReceiver(this.receiver, intentFilter);
        if (DApplication.getOverlayPermision) {
            createFloatView();
        }
    }

    @SuppressLint("WrongConstant")
    private void hideRecord() {
        this.imgRecord.setVisibility(4);
        FrameLayout frameLayout = this.layGuide;
        if (frameLayout != null) {
            frameLayout.setVisibility(4);
        }
    }


    @SuppressLint("WrongConstant")
    private void showRecord() {

        this.imgRecord.setVisibility(0);
        FrameLayout frameLayout = this.layGuide;
        if (frameLayout != null) {
            frameLayout.setVisibility(0);
        }
    }


    private boolean hasEnoughSpace() {
        return FileUtils.getFreeSpaceInMB() > 100;
    }

    private void showNotification() {
        @SuppressLint("WrongConstant") NotificationManager notificationManager = (NotificationManager) getSystemService("notification");

        PendingIntent.getActivity(this, 0, new Intent(this, NotificationActivity.class), PendingIntent.FLAG_MUTABLE);
        RemoteViews remoteViews = new RemoteViews(getPackageName(), (int) R.layout.item_notification_menu);
        RemoteViews remoteViews2 = new RemoteViews(getPackageName(), (int) R.layout.item_notification_menu_small);
        Intent intent = new Intent(this, ChangeModeService.class);
        intent.putExtra("mode", 1);
        PendingIntent service = PendingIntent.getService(this, 1, intent, PendingIntent.FLAG_MUTABLE);
        remoteViews.setOnClickPendingIntent(R.id.inm_img_normal, service);
        remoteViews2.setOnClickPendingIntent(R.id.inms_img_normal, service);
        Intent intent2 = new Intent(this, ChangeModeService.class);
        intent2.putExtra("mode", 2);
        PendingIntent service2 = PendingIntent.getService(this, 2, intent2, PendingIntent.FLAG_MUTABLE);
        remoteViews.setOnClickPendingIntent(R.id.inm_img_speak, service2);
        remoteViews2.setOnClickPendingIntent(R.id.inms_img_speak, service2);
        Intent intent3 = new Intent(this, ChangeModeService.class);
        intent3.putExtra("mode", 3);
        PendingIntent service3 = PendingIntent.getService(this, 3, intent3, PendingIntent.FLAG_MUTABLE);


        int i = DApplication.sP.getInt(PerferencedName.RECORD_MODE, 0);
        if (i == 0 || i == 1) {
            remoteViews.setImageViewResource(R.id.inm_img_normal, R.drawable.ic_notice_normal_active);
            remoteViews.setImageViewResource(R.id.inm_img_speak, R.drawable.ic_notice_speak);

            remoteViews2.setImageViewResource(R.id.inms_img_normal, R.drawable.ic_notice_normal_active);
            remoteViews2.setImageViewResource(R.id.inms_img_speak, R.drawable.ic_notice_speak);

        } else if (i == 2) {
            remoteViews.setImageViewResource(R.id.inm_img_normal, R.drawable.ic_notice_normal);
            remoteViews.setImageViewResource(R.id.inm_img_speak, R.drawable.ic_notice_speak_active);

            remoteViews2.setImageViewResource(R.id.inms_img_normal, R.drawable.ic_notice_normal);
            remoteViews2.setImageViewResource(R.id.inms_img_speak, R.drawable.ic_notice_speak_active);

        } else if (i == 3) {
            remoteViews.setImageViewResource(R.id.inm_img_normal, R.drawable.ic_notice_normal);
            remoteViews.setImageViewResource(R.id.inm_img_speak, R.drawable.ic_notice_speak);

            remoteViews2.setImageViewResource(R.id.inms_img_normal, R.drawable.ic_notice_normal);
            remoteViews2.setImageViewResource(R.id.inms_img_speak, R.drawable.ic_notice_speak);

        }

        PendingIntent service4 = PendingIntent.getService(this, 101, new Intent(this, ChangeStateService.class), PendingIntent.FLAG_MUTABLE);
        remoteViews.setOnClickPendingIntent(R.id.inm_img_record, service4);
        remoteViews2.setOnClickPendingIntent(R.id.inms_img_record, service4);
        PendingIntent service5 = PendingIntent.getService(this, 102, new Intent(this, CloseService.class), PendingIntent.FLAG_MUTABLE);
        remoteViews.setOnClickPendingIntent(R.id.inm_img_close, service5);
        remoteViews2.setOnClickPendingIntent(R.id.inms_img_close, service5);
        PendingIntent service6 = PendingIntent.getService(this, 103, new Intent(this, OpenAppService.class), PendingIntent.FLAG_MUTABLE);
        remoteViews.setOnClickPendingIntent(R.id.inm_img_icon, service6);
        remoteViews2.setOnClickPendingIntent(R.id.inms_img_icon, service6);
        remoteViews.setImageViewResource(R.id.inm_img_record, R.drawable.ic_notice_record);
        remoteViews2.setImageViewResource(R.id.inms_img_record, R.drawable.ic_notice_record);
        remoteViews.setImageViewResource(R.id.inm_img_close, R.drawable.ic_notice_close);
        remoteViews2.setImageViewResource(R.id.inms_img_close, R.drawable.ic_notice_close);
        DApplication.notificationMenu = remoteViews;
        DApplication.notificationMenuSmall = remoteViews2;

        if (Build.VERSION.SDK_INT >= 26) {
            @SuppressLint("WrongConstant") NotificationChannel notificationChannel = new NotificationChannel("default", "default", NotificationManager.IMPORTANCE_LOW);
            getManager().createNotificationChannel(notificationChannel);
            @SuppressLint("WrongConstant") Notification build = new Notification.Builder(this, notificationChannel.getId()).setSmallIcon(R.drawable.ic_icon_notification_small).setContent(remoteViews2).setCustomBigContentView(remoteViews).setPriority(Notification.PRIORITY_LOW).setVibrate(new long[0]).setSound(null).setOngoing(true).build();
            DApplication.notification = build;
            startForeground(1, build);
            return;
        }
        Notification build2 = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.ic_icon_notification_small).setContent(remoteViews2).setCustomBigContentView(remoteViews).setPriority(2).setOngoing(true).build();
        DApplication.notification = build2;
        startForeground(1, build2);
    }

    @SuppressLint("WrongConstant")
    private NotificationManager getManager() {
        if (this.manager == null) {
            this.manager = (NotificationManager) getSystemService("notification");
        }
        return this.manager;
    }

    @SuppressLint("WrongConstant")
    private void removeNotification() {
        stopForeground(true);
        ((NotificationManager) getSystemService("notification")).cancel(1);
    }


    @SuppressLint("WrongConstant")
    private void showResultActivity() {

        if (ResultActivity.getInstance() != null) {
            ResultActivity.getInstance().finish();
        }

        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("path", DApplication.currRecord.path);
        intent.setFlags(268435456);
        startActivity(intent);
    }

    @SuppressLint("WrongConstant")
    private void createFloatView() {

        if (!this.isFloatViewCreated) {
            this.windowManager = (WindowManager) getSystemService("window");
            this.floatLayout = (RelativeLayout) LayoutInflater.from(getApplication()).inflate(R.layout.service_float, (ViewGroup) null);
            this.floatLayout.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
            this.txtCountdown = (TextView) this.floatLayout.findViewById(R.id.sf_txt_countdown);
            this.floatLayout.removeView(this.txtCountdown);
            this.imgDelete = (ImageView) this.floatLayout.findViewById(R.id.sf_img_delete);
            this.floatLayout.removeView(this.imgDelete);
            int i = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
            new WindowManager.LayoutParams();
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, i, 8, -3);
            layoutParams.format = 1;
            layoutParams.gravity = 49;
            layoutParams.verticalMargin = 0.6f;
            layoutParams.width = -2;
            layoutParams.height = -2;
            this.windowManager.addView(this.imgDelete, layoutParams);
            this.imgDelete.setVisibility(4);
            this.isFloatViewCreated = true;
            WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams();
            layoutParams2.type = i;
            layoutParams2.format = 1;
            layoutParams2.flags = 8;
            layoutParams2.gravity = 51;
            layoutParams2.verticalMargin = 0.5f;
            layoutParams2.horizontalMargin = 1.0f;
            layoutParams2.width = -2;
            layoutParams2.height = -2;
            this.imgRecord = (ImageView) this.floatLayout.findViewById(R.id.sf_img_record);
            this.imgRecord.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {

                    if (RecordService.this.touchMoved) {
                        RecordService.this.touchMoved = false;
                    } else if (RecordService.this.running) {
                        RecordService.this.stopRecord(true);
                    } else {
                        RecordService.this.startRecord();
                    }
                }
            });
            this.imgRecord.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    int action = motionEvent.getAction();
                    if (action != 0) {
                        if (action != 1) {
                            if (action == 2) {
                                RecordService.this.touchMoveTime++;
                                if (RecordService.this.touchMoveTime > 10) {
                                    WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) RecordService.this.imgRecord.getLayoutParams();
                                    Point point = new Point();
                                    RecordService.this.windowManager.getDefaultDisplay().getRealSize(point);
                                    float width = (float) RecordService.this.imgRecord.getWidth();
                                    float height = (float) RecordService.this.imgRecord.getHeight();
                                    float f = (float) point.x;
                                    float f2 = (float) point.y;
                                    float rawX = (motionEvent.getRawX() - (width / 2.0f)) / f;
                                    float rawY = (motionEvent.getRawY() - (height / 2.0f)) / f2;
                                    float f3 = (f - width) / f;
                                    float f4 = (f2 - height) / f2;
                                    if (rawX < 0.0f) {
                                        f3 = 0.0f;
                                    } else if (rawX <= f3) {
                                        f3 = rawX;
                                    }
                                    if (rawY < 0.0f) {
                                        rawY = 0.0f;
                                    } else if (rawY > f4) {
                                        rawY = f4;
                                    }
                                    layoutParams.horizontalMargin = f3;
                                    layoutParams.verticalMargin = rawY;
                                    RecordService.this.windowManager.updateViewLayout(RecordService.this.imgRecord, layoutParams);
                                    if (!RecordService.this.running && !RecordService.this.isPreparing) {
                                        RecordService.this.imgDelete.setVisibility(0);
                                        if (!RecordService.this.isRecordInRemove(point)) {
                                            if (RecordService.this.recordInDelete) {
                                                RecordService recordService = RecordService.this;
                                                recordService.recordInDelete = false;

                                            }
                                        } else if (!RecordService.this.recordInDelete) {
                                            RecordService recordService2 = RecordService.this;
                                            recordService2.recordInDelete = true;

                                        }
                                    }
                                    layoutParams.horizontalMargin = f3;
                                    layoutParams.verticalMargin = rawY;
                                }
                            } else if (action != 3) {
                            }
                            return false;
                        }
                    } else if (!(RecordService.this.layGuide == null || RecordService.this.layGuide.getParent() == null)) {
                        RecordService.this.windowManager.removeView(RecordService.this.layGuide);
                        RecordService recordService3 = RecordService.this;
                        recordService3.layGuide = null;
                        recordService3.confirmGuide = true;
                        DApplication.sP.edit().putBoolean(RecordService.GUIDE_KEY, true).apply();
                        return false;
                    }
                    if (RecordService.this.touchMoveTime > 10) {
                        RecordService.this.touchMoved = true;
                    }
                    RecordService recordService4 = RecordService.this;
                    recordService4.touchMoveTime = 0;
                    if (!recordService4.recordInDelete) {
                        RecordService.this.imgDelete.setVisibility(8);
                        return false;
                    }
                    if (RecordService.this.running) {
                        RecordService.this.stopRecord(false);
                    }
                    RecordService.this.closeApp();
                    RecordService.this.recordInDelete = false;
                    return true;
                }
            });
            this.floatLayout.removeView(this.imgRecord);
            this.windowManager.addView(this.imgRecord, layoutParams2);
            if (!this.confirmGuide) {
                this.layGuide = (FrameLayout) this.floatLayout.findViewById(R.id.sf_lay_guide);
                this.floatLayout.removeView(this.layGuide);
                WindowManager.LayoutParams layoutParams3 = new WindowManager.LayoutParams();
                layoutParams3.type = i;
                layoutParams3.format = 1;
                layoutParams3.flags = 8;
                layoutParams3.gravity = 53;
                layoutParams3.verticalMargin = 0.45f;
                layoutParams3.horizontalMargin = 0.05f;
                layoutParams3.width = -2;
                layoutParams3.height = -2;
                this.windowManager.addView(this.layGuide, layoutParams3);
            }
            hideRecord();
        }
    }


    private void closeApp() {
       stopSelf();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);

   }

    private boolean isRecordInRemove(Point point) {
        WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) this.imgRecord.getLayoutParams();
        double width = (double) this.imgRecord.getWidth();
        double width2 = (double) this.imgDelete.getWidth();
        Double.isNaN(width);
        Double.isNaN(width);
        double d = (double) point.x;
        double d2 = (double) layoutParams.horizontalMargin;
        Double.isNaN(d);
        Double.isNaN(d2);
        Double.isNaN(d);
        Double.isNaN(d2);
        Double.isNaN(width2);
        Double.isNaN(width2);
        double d3 = (double) point.x;
        Double.isNaN(d3);
        Double.isNaN(width2);
        Double.isNaN(d3);
        Double.isNaN(width2);
        double pow = Math.pow(((width / 2.0d) + (d * d2)) - ((width2 / 2.0d) + ((d3 - width2) / 2.0d)), 2.0d);
        double height = (double) this.imgRecord.getHeight();
        Double.isNaN(height);
        Double.isNaN(height);
        double d4 = (double) point.y;
        double d5 = (double) layoutParams.verticalMargin;
        Double.isNaN(d4);
        Double.isNaN(d5);
        Double.isNaN(d4);
        Double.isNaN(d5);
        double d6 = (height / 2.0d) + (d4 * d5);
        double height2 = (double) this.imgDelete.getHeight();
        Double.isNaN(height2);
        Double.isNaN(height2);
        double d7 = (double) point.y;
        double d8 = (double) ((WindowManager.LayoutParams) this.imgDelete.getLayoutParams()).verticalMargin;
        Double.isNaN(d7);
        Double.isNaN(d8);
        Double.isNaN(d7);
        Double.isNaN(d8);
        double sqrt = Math.sqrt(pow + Math.pow(d6 - ((height2 / 2.0d) + (d7 * d8)), 2.0d));
        Double.isNaN(width);
        Double.isNaN(width2);
        Double.isNaN(width);
        Double.isNaN(width2);
        return sqrt <= (width + width2) / 2.0d;
    }

    private void createVirtualDisplay() {

        try {
            Surface surface = this.recorder.getSurface();
            int i = getApplicationContext().getResources().getConfiguration().orientation;
            int[] option = OptionMenuBuilder.getOption(0);
            int i2 = option[2];
            int i3 = option[1];
            double d = (double) DApplication.screenDpi;
            double d2 = (double) DApplication.screenWidth;
            Double.isNaN(d);
            Double.isNaN(d2);
            Double.isNaN(d);
            Double.isNaN(d2);
            double d3 = d / d2;
            double d4 = (double) i2;
            Double.isNaN(d4);
            Double.isNaN(d4);
            int i4 = (int) (d3 * d4);
            if (i == 2) {
                this.virtualDisplay = this.mediaProjection.createVirtualDisplay("MainScreen", i3, i2, i4, 16, surface, null, null);
            } else {
                this.virtualDisplay = this.mediaProjection.createVirtualDisplay("MainScreen", i2, i3, i4, 16, surface, null, null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            this.isRequestingCapture = true;
            Intent intent = new Intent(this, JayHomeCaptureActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        }
    }

    @SuppressLint("WrongConstant")
    private void createRecorder() {
        try {
            if (this.recorder == null) {
                this.recorder = new MediaRecorder();


                boolean z = this.modeFunction.enableMic;
                if (z) {
                    this.recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                }

                this.recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
                this.recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);


                if (z) {
                    this.recorder.setAudioEncoder(3);
                }
                this.recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
                    Environment.getExternalStorageDirectory();
                Calendar.getInstance().setTime(new Date());
                String pathFolder;
                if (Build.VERSION.SDK_INT >= 30) {
                    pathFolder = FileUtils.getSave11Directory(this) + new SimpleDateFormat("MMMM_dd_HH_mm", Locale.US).format(new Date());
                } else {
                    pathFolder = FileUtils.getSaveDirectory(this) + new SimpleDateFormat("MMMM_dd_HH_mm", Locale.US).format(new Date());
                }

                if (new File(pathFolder + ".mp4").exists()) {
                    int i = 1;
                    while (true) {
                        if (!new File(pathFolder + "(" + i + ").mp4").exists()) {
                            break;
                        }
                        i++;
                    }
                    pathFolder = pathFolder + "(" + i + ")";
                }

                int i2 = getApplicationContext().getResources().getConfiguration().orientation;
                int[] option = OptionMenuBuilder.getOption(0);
                if (i2 == 2) {
                    this.recorder.setVideoSize(option[1], option[2]);
                } else {
                    this.recorder.setVideoSize(option[2], option[1]);
                }
                this.recorder.setVideoFrameRate(OptionMenuBuilder.getOption(1)[1]);

                String str2 = pathFolder + ".mp4";
                DApplication.currRecord.path = str2;
                DApplication.currRecord.recordTime = System.currentTimeMillis();
                this.recorder.setOutputFile(str2);
                if (z) {
                    this.recorder.setAudioEncodingBitRate(128000);
                    this.recorder.setAudioSamplingRate(44100);
                    this.recorder.setAudioChannels(1);
                }

                int[] option2 = OptionMenuBuilder.getOption(2);
                if (option2[1] != 0) {
                    this.recorder.setVideoEncodingBitRate(option2[1]);
                } else {
                    this.recorder.setVideoEncodingBitRate(option[3]);
                }


                try {
                    this.recorder.prepare();
                } catch (IOException e) {

                } catch (Exception e) {

                }
            }
        } catch (Exception e) {
        }

    }

    public void startRecord() {
        if (!this.isPreparing) {
            FrameLayout frameLayout = this.layGuide;
            if (!(frameLayout == null || frameLayout.getParent() == null)) {
                this.windowManager.removeView(this.layGuide);
                this.layGuide = null;
            }
            if (hasEnoughSpace()) {
                this.isPreparing = true;

                if (this.mediaProjection == null) {
                    isRequestingCapture = false;
                    requestCaptureScreen();
                }
                this.modeFunction = RecordMode.getFunction();
                if (this.modeFunction.muteAudio) {
                    muteMusic();
                }
                this.leftCountdown = OptionMenuBuilder.getOption(6)[1];
                int i = this.leftCountdown;
                if (i > 0) {
                    this.leftCountdown = i + 1;
                    this.countDown.run();
                }
                checkToBeginRecord();
                return;
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.tips_no_freespace);
            builder.setTitle(R.string.tips);
            builder.setPositiveButton(R.string.tips_ok, new DialogInterface.OnClickListener() {


                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            AlertDialog create = builder.create();
            create.getWindow().setType(2003);
            create.show();
        }
    }


    long cLastClickTime2 = System.currentTimeMillis();
    public static final long CLICK_TIME_INTERVAL2 = 1300;


    @SuppressLint("WrongConstant")
    public void checkToBeginRecord() {
        try {
            long now = System.currentTimeMillis();
            if (now - cLastClickTime2 < CLICK_TIME_INTERVAL2) {
                return;
            }
            if (this.mediaProjection != null && this.leftCountdown == 0 && !this.isDestroys) {
                this.isPreparing = false;
                createRecorder();
                createVirtualDisplay();
                this.recorder.start();
                this.imgRecord.setImageResource(R.drawable.ic_stop);
                this.imgRecord.setAlpha(0.3f);
                if (DApplication.currRecord.packageName != null) {
                    Bundle bundle = new Bundle();
                    bundle.putString("item_id", DApplication.currRecord.packageName);
                    bundle.putString("content_type", DApplication.currRecord.packageName);
                }
                this.recordHandler.postDelayed(this.checkSpace, 5000);
                DApplication.notificationMenu.setImageViewResource(R.id.inm_img_record, R.drawable.ic_notice_stop);
                DApplication.notificationMenuSmall.setImageViewResource(R.id.inms_img_record, R.drawable.ic_notice_stop);
                ((NotificationManager) getSystemService("notification")).notify(1, DApplication.notification);
                this.running = true;
                this.recordBeginTime = System.currentTimeMillis();
            } else {

                mediaProjection = DApplication.screenProjection;

            }
        } catch (Exception e) {
            e.printStackTrace();
              }

    }

    long cLastClickTime = System.currentTimeMillis();
    public static final long CLICK_TIME_INTERVAL = 1300;

    @SuppressLint("WrongConstant")
    public void stopRecord(boolean z) {

        long now = System.currentTimeMillis();
        if (now - cLastClickTime < CLICK_TIME_INTERVAL) {
            return;
        }

        if (this.recorder != null && System.currentTimeMillis() - this.recordBeginTime >= 1000) {
            try {
                this.recorder.setOnErrorListener(null);
                this.recorder.setOnInfoListener(null);
                this.recorder.setPreviewDisplay(null);
                this.recorder.stop();
            } catch (Throwable th) {

            }


            cLastClickTime = now;

            this.recorder.release();
            this.virtualDisplay.release();
            RecordData recordData = DApplication.currRecord;
            recordData.id = DatabaseUtils.getInstance().addRecord(recordData);
            Intent intent = new Intent(Message.ADD_VIDEO);
            recordData.setIntentExtra(intent);
            DApplication.getBm().sendBroadcast(intent);
            recordData.id = -1;
            this.running = false;
            this.imgRecord.setImageResource(R.drawable.ic_record);
            imgRecord.setMinimumWidth(40);
            imgRecord.setMinimumHeight(40);
            this.imgRecord.setAlpha(1.0f);
            hideRecord();
            DApplication.notificationMenu.setImageViewResource(R.id.inm_img_record, R.drawable.ic_notice_record);
            DApplication.notificationMenuSmall.setImageViewResource(R.id.inms_img_record, R.drawable.ic_notice_record);
            ((NotificationManager) getSystemService("notification")).notify(1, DApplication.notification);
            this.recorder = null;
            if (this.modeFunction.muteAudio) {
                unmuteMusic();
            }
            if (z) {
                showResultActivity();
            }
        }
    }


    private void muteMusic() {
        @SuppressLint("WrongConstant") AudioManager audioManager = (AudioManager) getSystemService("audio");
        audioManager.getStreamMaxVolume(3);
        this.originVolume = audioManager.getStreamVolume(3);
        if (this.originVolume > 0) {
            audioManager.setStreamVolume(3, 0, 0);
        }
    }

    @SuppressLint("WrongConstant")
    private void unmuteMusic() {
        if (this.originVolume > 0) {
            ((AudioManager) getSystemService("audio")).setStreamVolume(3, this.originVolume, 0);
        }
    }
}
