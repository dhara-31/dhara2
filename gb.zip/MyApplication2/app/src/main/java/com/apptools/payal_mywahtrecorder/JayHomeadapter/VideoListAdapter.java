package com.apptools.payal_mywahtrecorder.JayHomeadapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_VideoListActivity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JAydata.RecordData;
import com.apptools.payal_mywahtrecorder.JAydata.VideoData;
import com.apptools.payal_mywahtrecorder.Jayutils.AppUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.CatchUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.DatabaseUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.FileUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.StringUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class VideoListAdapter extends RecyclerView.Adapter<VideoListAdapter.VideoHolder> {
    private Context context;
    private List<TabData> mainList;
    private int openingIndex = -1;


    public class TabData implements Comparable<TabData> {
        String packageName;
        List<RecordData> recordList;

        public TabData(String str, List<RecordData> list) {
            this.packageName = str;
            this.recordList = list;
        }

        public int compareTo(TabData tabData) {
            if (size() <= 0 || tabData.size() <= 0) {
                return tabData.size() - size();
            }
            return (int) (tabData.recordList.get(0).recordTime - this.recordList.get(0).recordTime);
        }

        public int size() {
            return this.recordList.size();
        }
    }

    private long mLastClickTime = 0;
    private static final long CLICK_TIME_INTERVAL = 1300;
    public class VideoHolder extends RecyclerView.ViewHolder {
        RelativeLayout btnBgm;
        RelativeLayout btnDel;
        RelativeLayout btnShare;
        private ImageView imgPlay;
        private ImageView imgPreview;
        private ImageView imgTabArrow;
        private ImageView imgTabIcon;
        private boolean opening;
        private RecordData recordData;
        private TabData tabData;
        private TextView txtDuration;
        private TextView txtName;
        private TextView txtSize;
        private TextView txtTabCount;
        private TextView txtTabName;
        private int type;


        public VideoHolder(View view, int i) {
            super(view);
            this.type = i;
            if (i == 1) {
                this.imgTabIcon = (ImageView) view.findViewById(R.id.ivt_img_app);
                this.txtTabName = (TextView) view.findViewById(R.id.ivt_txt_name);
                this.txtTabCount = (TextView) view.findViewById(R.id.ivt_txt_count);
                this.imgTabArrow = (ImageView) view.findViewById(R.id.ivt_img_state);
                view.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        VideoListAdapter.this.onMainItemClick(VideoHolder.this);
                    }
                });

                VideoListAdapter.this.onMainItemClick(VideoHolder.this);
                return;
            }
            this.imgPreview = (ImageView) view.findViewById(R.id.ivd_img_preview);
            this.imgPlay = (ImageView) view.findViewById(R.id.ivd_img_play);
            this.txtDuration = (TextView) view.findViewById(R.id.ivd_txt_duration);
            this.btnShare = (RelativeLayout) view.findViewById(R.id.ivd_lay_share);
            this.btnBgm = (RelativeLayout) view.findViewById(R.id.ivd_lay_bgm);
            this.btnDel = (RelativeLayout) view.findViewById(R.id.ivd_lay_del);
            this.txtSize = (TextView) view.findViewById(R.id.ivd_txt_size);
            this.txtName = (TextView) view.findViewById(R.id.ivd_txtName);
            this.imgPreview.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (VideoHolder.this.checkVideoExist()) {
                        Intent intent = new Intent(Message.PLAY_VIDEO);
                        intent.putExtra("path", VideoHolder.this.recordData.path);
                        DApplication.getBm().sendBroadcast(intent);
                        return;
                    }
                    VideoListAdapter.this.removeVideo(VideoHolder.this.recordData);
                }
            });

            this.btnShare.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                        return;
                    }
                    mLastClickTime = now;

                    if (VideoHolder.this.checkVideoExist()) {
                        Intent intent = new Intent(Message.SHARE_VIDEO);
                        intent.putExtra("path", VideoHolder.this.recordData.path);
                        DApplication.getBm().sendBroadcast(intent);
                        return;
                    }
                    VideoListAdapter.this.removeVideo(VideoHolder.this.recordData);
                }
            });
            this.btnBgm.setOnClickListener(new View.OnClickListener() {


                public void onClick(View view) {
                    if (VideoHolder.this.checkVideoExist()) {
                        Intent intent = new Intent(Message.EDIT_VIDEO);
                        VideoHolder.this.recordData.setIntentExtra(intent);
                        DApplication.getBm().sendBroadcast(intent);
                        return;
                    }
                    VideoListAdapter.this.removeVideo(VideoHolder.this.recordData);
                }
            });
            this.btnDel.setOnClickListener(new View.OnClickListener() {


                public void onClick(View view) {
                    if (VideoHolder.this.checkVideoExist()) {
                        VideoHolder.this.showDeleteAlert();
                    } else {
                        VideoListAdapter.this.removeVideo(VideoHolder.this.recordData);
                    }
                }
            });
        }



        @SuppressLint("WrongConstant")
        private boolean checkVideoExist() {
            if (new File(this.recordData.path).exists()) {
                return true;
            }
            Toast.makeText(VideoListAdapter.this.context, (int) R.string.tips_video_has_removed, 1).show();
            return false;
        }



        private void showDeleteAlert() {
            AlertDialog.Builder builder = new AlertDialog.Builder(VideoListAdapter.this.context);
            builder.setMessage(R.string.tips_confirm_remove_record);
            builder.setTitle("Delete Video");
            builder.setNegativeButton(R.string.tips_no, new DialogInterface.OnClickListener() {


                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.setPositiveButton(R.string.tips_yes, new DialogInterface.OnClickListener() {


                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    Intent intent = new Intent(Message.DELETE_VIDEO);
                    intent.putExtra("path", VideoHolder.this.recordData.path);
                    File file = new File(VideoHolder.this.recordData.path);
                    if (file.exists()) {
                        file.delete();
                    }
                    DatabaseUtils.getInstance().removeRecord(VideoHolder.this.recordData);
                    VideoListAdapter.this.removeVideo(VideoHolder.this.recordData);
                    CatchUtils.getInstance().clearVideoData(Long.valueOf(VideoHolder.this.recordData.id));
                    DApplication.getBm().sendBroadcast(intent);
                    if (JayHome_VideoListActivity.videoListActivity!=null)
                    {
                        JayHome_VideoListActivity.videoListActivity.updatelist();
                    }
                }
            });
            builder.create().show();
        }

        @SuppressLint("SetTextI18n")
        public void setTabData(TabData tabData2) {
            this.tabData = tabData2;
            if (tabData2.packageName != null) {
                this.imgTabIcon.setImageDrawable(CatchUtils.getInstance().getAppIcon(tabData2.packageName));
                this.txtTabName.setText(AppUtils.getAppName(tabData2.packageName));
            } else {
                this.imgTabIcon.setImageResource(R.drawable.ic_desktop);
                this.txtTabName.setText(JemsProviderKt.getMyString(context,R.string.recorded_video));
            }
            TextView textView = this.txtTabCount;
            textView.setText(tabData2.size() + " Videos");
        }

        public void setRecordData(RecordData recordData2) {
            VideoData videoData;
            this.recordData = recordData2;
            this.txtName.setText(FileUtils.getFileName(recordData2.path));
            if (new File(recordData2.path).exists() && (videoData = CatchUtils.getInstance().getVideoData(recordData2, this)) != null) {
                updateVideoData(videoData);
            }
        }

        public RecordData getRecordData() {
            return this.recordData;
        }

        public void updateVideoData(VideoData videoData) {
            if (videoData.id == this.recordData.id) {
                this.imgPreview.setImageBitmap(videoData.preview);
                this.txtDuration.setText(videoData.durationDesc);
                this.txtSize.setText(videoData.sizeDesc);
            }
        }

        public void setOpenState(Boolean bool) {
            if (bool.booleanValue()) {
                this.imgTabArrow.setImageResource(R.drawable.ic_hide);
            } else {
                this.imgTabArrow.setImageResource(R.drawable.ic_show);
            }
        }
    }

    public VideoListAdapter(Context context2, List<RecordData> list, boolean z) {
        this.context = context2;
        int size = list.size();
        HashMap<String, TabData> hashMap = new HashMap<>();
        List<TabData> tabDatahash=new ArrayList<>();
        for (int i = 0; i < size; i++) {
            RecordData recordData = list.get(i);
            TabData tabData = hashMap.get(recordData.packageName);
            if (tabData == null) {
                tabData = new TabData(recordData.packageName, new ArrayList<>());
                hashMap.put(recordData.packageName, tabData);
                tabDatahash.add(tabData);
            }
            try {
                if (new File(recordData.path).exists()){
                    tabData.recordList.add(recordData);
                }
            }catch (Exception e){
                tabData.recordList.add(recordData);
            }

        }
        this.mainList = new ArrayList<>();
        for (TabData entry : tabDatahash) {
            Collections.sort(entry.recordList);
            this.mainList.add(entry);
        }
        Collections.sort(this.mainList);
        if (z && this.mainList.size() > 0) {
            this.openingIndex = 0;
        }
    }

    public void updateVideo(RecordData recordData) {
        notifyItemRangeRemoved(0, getItemCount());
        for (int i = 0; i < this.mainList.size(); i++) {
            TabData tabData = this.mainList.get(i);
            if (StringUtils.equals(tabData.packageName, recordData.packageName)) {
                int i2 = 0;
                while (true) {
                    if (i2 >= tabData.recordList.size()) {
                        break;
                    }
                    RecordData recordData2 = tabData.recordList.get(i2);
                    if (recordData2.id == recordData.id) {
                        recordData2.update(recordData);
                        break;
                    }
                    i2++;
                }
                Collections.sort(tabData.recordList);
            }
        }
        Collections.sort(this.mainList);
        if (this.mainList.size() > 0) {
            this.openingIndex = 0;
        }
        notifyItemRangeInserted(0, getItemCount());
    }

    public void addVideo(RecordData recordData) {
        notifyItemRangeRemoved(0, getItemCount());
        for (int i = 0; i < this.mainList.size(); i++) {
            TabData tabData = this.mainList.get(i);
            if (StringUtils.equals(tabData.packageName, recordData.packageName)) {
                tabData.recordList.add(0, recordData);
                if (i != 0) {
                    this.mainList.remove(i);
                    this.mainList.add(0, tabData);
                }
                if (tabData == null) {
                    this.mainList.add(0, new TabData(recordData.packageName, new ArrayList<>()));
                }
                this.openingIndex = 0;
                notifyItemRangeInserted(0, getItemCount());
            }
        }
        this.openingIndex = 0;
        notifyItemRangeInserted(0, getItemCount());
    }

    public void removeVideo(RecordData recordData) {
        String str = recordData.packageName;
        for (int i = 0; i < this.mainList.size(); i++) {
            TabData tabData = this.mainList.get(i);
            if (StringUtils.equals(tabData.packageName, str)) {
                int indexOf = tabData.recordList.indexOf(recordData);
                if (indexOf != -1) {
                    tabData.recordList.remove(indexOf);
                    int i2 = this.openingIndex;
                    if (i2 == i) {
                        notifyItemRemoved(i2 + indexOf + 1);
                    }
                    if (tabData.recordList.size() == 0) {
                        this.mainList.remove(i);
                        notifyItemRemoved(i);
                        if (this.openingIndex == i) {
                            this.openingIndex = -1;
                            return;
                        }
                        return;
                    }
                    notifyItemChanged(i);
                    return;
                }
                return;
            }
        }
    }


    public void onMainItemClick(VideoHolder videoHolder) {
        int indexOf = this.mainList.indexOf(videoHolder.tabData);
        if (indexOf == -1) {

            return;
        }
        int i = this.openingIndex;
        if (i == -1) {
            this.openingIndex = indexOf;
            notifyItemChanged(indexOf);
            notifyItemRangeInserted(indexOf + 1, this.mainList.get(indexOf).size());
            videoHolder.setOpenState(true);
        } else if (i == indexOf) {
            this.openingIndex = -1;
            notifyItemChanged(indexOf);
            notifyItemRangeRemoved(indexOf + 1, this.mainList.get(indexOf).size());
            videoHolder.setOpenState(false);
        } else {
            this.openingIndex = indexOf;
            notifyItemChanged(i);
            notifyItemRangeRemoved(i + 1, this.mainList.get(i).size());
            notifyItemChanged(indexOf);
            notifyItemRangeInserted(indexOf + 1, this.mainList.get(indexOf).size());
            videoHolder.setOpenState(true);
        }
    }

    @Override
    public VideoHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new VideoHolder(LayoutInflater.from(viewGroup.getContext()).inflate(i == 1 ? R.layout.item_video_title : R.layout.item_video_detailtools, viewGroup, false), i);
    }

    public void onBindViewHolder(VideoHolder videoHolder, int i) {
        boolean z = true;
        if (videoHolder.type == 1) {
            TabData tabdata = getTabdata(i);
            videoHolder.setTabData(tabdata);
            if (this.mainList.indexOf(tabdata) != this.openingIndex) {
                z = false;
            }
            videoHolder.setOpenState(Boolean.valueOf(z));
        } else if (videoHolder.type == 2) {
            videoHolder.setRecordData(getRecordData(i));
        }
    }

    private TabData getTabdata(int i) {
        return (TabData) findData(i);
    }

    private RecordData getRecordData(int i) {
        return (RecordData) findData(i);
    }

    private Object findData(int i) {
        int i2 = this.openingIndex;
        if (i2 == -1) {
            return this.mainList.get(i);
        }
        TabData tabData = this.mainList.get(i2);
        int i3 = this.openingIndex;
        if (i <= i3) {
            return this.mainList.get(i);
        }
        if (i <= i3 + tabData.size()) {
            return tabData.recordList.get((i - this.openingIndex) - 1);
        }
        return this.mainList.get(i - tabData.size());
    }

    @Override
    public int getItemViewType(int i) {
        int i2 = this.openingIndex;
        return (i2 == -1 || i <= i2 || i > this.mainList.get(i2).size() + this.openingIndex) ? 1 : 2;
    }

    @Override
    public int getItemCount() {
        int i = this.openingIndex;
        if (i == -1) {
            return this.mainList.size();
        }
        return this.mainList.get(i).size() + this.mainList.size();
    }
}
