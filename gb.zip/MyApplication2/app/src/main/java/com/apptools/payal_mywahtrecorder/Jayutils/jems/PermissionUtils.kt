package com.apptools.payal_mywahtrecorder.Jayutils.jems

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class PermissionClass(
    private var activity: Activity,
    private var permissionList: ArrayList<String>,
    val permissionAllowCallBack: (Boolean) -> Unit,
    val forceToOpenSetting: (Boolean) -> Unit,
) {
    
    private var needOpenSetting = false
    private var permissionResultLauncher: ActivityResultLauncher<Array<String>>
    private var permissionDenyList: ArrayList<String> = ArrayList()
    
    init {
        permissionResultLauncher =
            (activity as AppCompatActivity).activityResultRegistry.register("102",
                ActivityResultContracts.RequestMultiplePermissions(),
                ActivityResultCallback { it ->
                    val tempPermissionDenyList = ArrayList<String>()
                    
                    it.keys.forEach {
                        if (activity.isPermissionDeny(it)) {
                            tempPermissionDenyList.add(it)
                        }
                    }
                    
                    if (tempPermissionDenyList.isEmpty()) {
                        it.keys.forEach {
                            activity.setPermissionWrite(it, true)
                        }
                        permissionAllowCallBack(true)
                        return@ActivityResultCallback
                    } else {
                        permissionAllowCallBack(false)
                    }
                    val checkList = ArrayList<String>()
                    it.keys.forEach { permission ->
                        checkList.add(permission)
                    }
                    activity.checkShouldPermission(checkList)

                })
        permissionAllowCallBack(activity.checkAnyDeny(permissionList))
    }
    
    fun checkPermission(activity: Activity ) {
        permissionDenyList = ArrayList()
        for (permission: String in permissionList) {
            if (activity.isPermissionDeny(permission)) {
                permissionDenyList.add(permission)
            }
        }
        permissionAllowCallBack(permissionDenyList.size == 0)
        if (permissionDenyList.isNotEmpty()) {
            activity.checkShouldPermission(permissionDenyList)
        }
    }
    
    companion object {
        fun Context.checkAnyDeny(permissionList: ArrayList<String>): Boolean {
            val permissionDenyList = ArrayList<String>()
            permissionList.forEach { permission ->
                if (isPermissionDeny(permission)) {
                    permissionDenyList.add(permission)
                } else if (isPermissionGranted(permission)) {
                    setPermissionWrite(permission, true)
                }
            }
        
            return permissionDenyList.size == 0
        }
        
        var justClicked = false
        var handler = Handler(Looper.getMainLooper())
        var runnable: Runnable? = null
    }
    
    
    fun Activity.askPermission(openSetting: Boolean = true) {
        if (justClicked) {
            return
        }
        justClicked = true
        permissionDenyList = ArrayList()
        permissionList.forEach {
            if (isPermissionDeny(it)) {
                permissionDenyList.add(it)
            }
        }
        Log.w("fatTAG", "askPermission: NEED REQUEST --> "+(needOpenSetting && openSetting))
        if (needOpenSetting && openSetting) {
            activity.startActivity(
                Intent(
                    "android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts(
                        "package", activity.packageName, null
                    )
                )
            )
        } else {
            permissionResultLauncher.launch(permissionDenyList.toTypedArray())
        }
        if (runnable != null) {
            runnable?.apply {
                handler.removeCallbacks(this)
            }
            runnable = null
        }
        runnable = Runnable {
            justClicked = false
        }.apply {
            handler.postDelayed(this, 500)
        }
    }
    
    private fun Activity.checkShouldPermission(permissionList: ArrayList<String>) {
        val tempListShould = ArrayList<String>()
        permissionList.forEach { permission ->
            if (isPermissionRational(permission)) {
                setPermissionWrite(permission, true)
            } else {
                if (getPermissionWrite(permission)) {
                    tempListShould.add(permission)
                }
            }
        }
        
        if (tempListShould.size > 0) {
            tempListShould.forEach {
                setPermissionWrite(it, true)
            }
            if (needOpenSetting.not()) {
                needOpenSetting = true
            }
        }
        forceToOpenSetting(needOpenSetting)
    }
    
    
}



fun Context.isPermissionDeny(permission: String): Boolean {
    return ContextCompat.checkSelfPermission(
        this, permission
    ) != PackageManager.PERMISSION_GRANTED
}

fun Context.isPermissionGranted(permission: String): Boolean {
    return ContextCompat.checkSelfPermission(
        this, permission
    ) == PackageManager.PERMISSION_GRANTED
}

fun Activity.isPermissionRational(permission: String): Boolean {
    return ActivityCompat.shouldShowRequestPermissionRationale(this, permission)
}

fun Context.setPermissionWrite(permission: String, values: Boolean) {
    getPreference().edit().putBoolean(permission, values).apply()
}

fun Context.getPreference(): SharedPreferences {
    return getSharedPreferences("PrefData", Context.MODE_PRIVATE)
}

fun Context.getPermissionWrite(permission: String): Boolean {
    return getPreference().getBoolean(permission, false)
}