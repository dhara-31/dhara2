package com.apptools.payal_mywahtrecorder.Jaylanguage;

public class LanguageMainModel {
    int image;
    Boolean isCheck;
    String isoLanguage;
    String languageName;

    public LanguageMainModel(String languageName, String isoLanguage, Boolean isCheck, int image) {
        this.languageName = languageName;
        this.isoLanguage = isoLanguage;
        this.isCheck = isCheck;
        this.image = image;
    }

    public String getLanguageName() {
        return this.languageName;
    }

    public void setLanguageName(String str) {
        this.languageName = str;
    }

    public String getIsoLanguage() {
        return this.isoLanguage;
    }

    public void setIsoLanguage(String isoLanguage) {
        this.isoLanguage = isoLanguage;
    }

    public Boolean getCheck() {
        return this.isCheck;
    }

    public void setCheck(Boolean bool) {
        this.isCheck = bool;
    }

    public int getImage() {
        return this.image;
    }

    public void setImage(int i) {
        this.image = i;
    }
}
