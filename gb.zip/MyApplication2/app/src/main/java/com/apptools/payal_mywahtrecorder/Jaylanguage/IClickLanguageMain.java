package com.apptools.payal_mywahtrecorder.Jaylanguage;

public interface IClickLanguageMain {
    void onClick(LanguageMainModel languageMainModel);
}
