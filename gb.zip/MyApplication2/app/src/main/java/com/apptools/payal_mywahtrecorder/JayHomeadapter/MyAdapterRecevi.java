package com.apptools.payal_mywahtrecorder.JayHomeadapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerPriviewActivity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.JAydata.Savers;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;
import com.apptools.payal_mywahtrecorder.Jayutils.Utils;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;
import java.util.ArrayList;

public class MyAdapterRecevi extends RecyclerView.Adapter<MyAdapterRecevi.Dataviewrecevi> {

    ArrayList<Savers> list_recevi;
    Activity context;
    String name;
    ClickSelectSet clickSelectSet;
    PreferenceUtil preferenceUtil;
    public static ArrayList<File> list_select_file = new ArrayList<>();
    public static ArrayList<DocumentFile> list_select_doc = new ArrayList<>();
    private final Activity activity;

    public MyAdapterRecevi(Activity fragmentActivity, ArrayList<Savers> list_recevi, String name, ClickSelectSet clickSelectSet) {
        activity = fragmentActivity;
        this.list_recevi = list_recevi;
        context = fragmentActivity;
        this.name = name;
        this.clickSelectSet = clickSelectSet;

        if (Build.VERSION.SDK_INT >= 30) {
            list_select_doc = new ArrayList<>();
        } else {
            list_select_file = new ArrayList<>();
        }
    }

    @NonNull
    @Override
    public Dataviewrecevi onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Dataviewrecevi(LayoutInflater.from(context).inflate(R.layout.item_view, parent, false));
    }


    @Override
    public void onBindViewHolder(@NonNull Dataviewrecevi holder, @SuppressLint("RecyclerView") int position) {
        if (Build.VERSION.SDK_INT >= 30) {
            handleSelectionForDocumentFile(holder, list_recevi.get(position).getDocumentFile());
        } else {
            handleSelectionForFile(holder, list_recevi.get(position).getFile());
        }

        switch (name) {
            case "Images":
            case "Gifs":
            case "Stickers": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._8sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._8sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.item_image_date_realti.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 30) {
                    Glide.with(context).load(list_recevi.get(position).getUri()).into(holder.item_image);
                } else {
                    Glide.with(context).load(list_recevi.get(position).getFile()).into(holder.item_image);
                }
                break;
            }
            case "Videos": {
                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_video_item.setVisibility(View.VISIBLE);
                holder.item_text_item_name.setText(list_recevi.get(position).getTitle());
                holder.item_text_item_size.setText(JemsProviderKt.getMyString(activity, R.string.size) + " " + Utils.readableFileSize(list_recevi.get(position).getSize()));
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        Glide.with(context).load(list_recevi.get(position).getUri()).into(holder.img_set_select_video);
                    } else {
                        Glide.with(context).load(list_recevi.get(position).getFile()).into(holder.img_set_select_video);
                    }

                } catch (Exception e) {

                }
                break;
            }
            case "Documents": {
                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_recevi.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.icon_documents_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(activity, R.string.size) + " " + Utils.readableFileSize(list_recevi.get(position).getSize()));


                break;
            }
            case "Audio": {
                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_recevi.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.icon_audio_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(activity, R.string.size) + " " + Utils.readableFileSize(list_recevi.get(position).getSize()));


                break;
            }
            case "Voice": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_recevi.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.voice_notes_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(activity, R.string.size) + " " + Utils.readableFileSize(list_recevi.get(position).getSize()));

                break;
            }
            case "Backups": {

                int margin_top = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._25sdp);
                int margin_rigth = context.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._10sdp);
                Utils.setMargins(holder.realti_check_box_an_ed, 0, margin_top, margin_rigth, 0);

                holder.realti_set_select_last.setVisibility(View.VISIBLE);
                holder.item_text_item_name_select.setText(list_recevi.get(position).getTitle());
                holder.img_set_select_icon.setImageResource(R.drawable.icon_backup_in);
                holder.item_text_item_time_dures_audo.setText(JemsProviderKt.getMyString(activity, R.string.size) + " " + Utils.readableFileSize(list_recevi.get(position).getSize()));

                break;
            }
        }


        holder.img_check_un.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.img_check_un.setVisibility(View.GONE);
                holder.img_check_ed.setVisibility(View.VISIBLE);

                if (Build.VERSION.SDK_INT >= 30) {

                    if (list_select_doc.size() == 0) {
                        list_select_doc = new ArrayList<>();
                        list_select_doc.add(list_recevi.get(position).getDocumentFile());
                    } else {
                        list_select_doc.add(list_recevi.get(position).getDocumentFile());
                    }

                    clickSelectSet.onclickdataset(list_select_doc.size());
                } else {
                    if (list_select_file.size() == 0) {
                        list_select_file = new ArrayList<>();
                        list_select_file.add(list_recevi.get(position).getFile());

                    } else {
                        list_select_file.add(list_recevi.get(position).getFile());
                    }

                    clickSelectSet.onclickdataset(list_select_file.size());
                }


            }
        });
        holder.img_check_ed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.img_check_un.setVisibility(View.VISIBLE);
                holder.img_check_ed.setVisibility(View.GONE);

                if (Build.VERSION.SDK_INT >= 30) {
                    for (int i = 0; i < list_select_doc.size(); i++) {

                        if (list_select_doc.get(i).equals(list_recevi.get(position).getDocumentFile())) {
                            list_select_doc.remove(i);
                        }
                    }

                    clickSelectSet.onclickdataset(list_select_doc.size());
                } else {
                    for (int i = 0; i < list_select_file.size(); i++) {

                        if (list_select_file.get(i).equals(list_recevi.get(position).getFile())) {
                            list_select_file.remove(i);
                        }
                    }

                    clickSelectSet.onclickdataset(list_select_file.size());
                }

            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (Build.VERSION.SDK_INT >= 30) {

                    JayHome_CleanerPriviewActivity.documentFile = list_recevi.get(position).getDocumentFile();

                } else {

                    JayHome_CleanerPriviewActivity.file = list_recevi.get(position).getFile();
                }
                if (name.equals("Images") || name.equals("Videos") || name.equals("Audio") || name.equals("Stickers") || name.equals("Gifs")) {


                    InterAdCall.getHelpIndicatorExplicit().callintermethod(context, true, msg -> {
                        Intent intent = new Intent(context, JayHome_CleanerPriviewActivity.class);
                        intent.putExtra("SELECT_SENT_REVE", 11);
                        intent.putExtra("select_pos", position);
                        context.startActivity(intent);
                    });



                } else if (name.equals("Documents")) {
                    Uri outputFileUri = null;
                    if (Build.VERSION.SDK_INT < 30) {
                        outputFileUri = FileProvider.getUriForFile(context, context.getPackageName() + ".provider", list_recevi.get(position).getFile());
                    } else {
                        outputFileUri = list_recevi.get(position).getDocumentFile().getUri();
                    }

                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_VIEW);
                    intent.setDataAndType(outputFileUri, Utils.isFileType(list_recevi.get(position).getPath()));
                    intent.setFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        context.startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(context, "No App Found For Preview", Toast.LENGTH_LONG).show();
                    }

                } else {
                    if (name.equals("Voice")) {
                        Toast.makeText(context, "Voice file not open", Toast.LENGTH_LONG).show();

                    } else {

                        Toast.makeText(context, "Backup file not open", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });


    }

    private void handleSelectionForDocumentFile(Dataviewrecevi holder, DocumentFile documentFile) {
        for (DocumentFile selectedDoc : list_select_doc) {
            if (documentFile.toString().equals(selectedDoc.toString())) {
                showSelected(holder);
                return;
            }
        }
        showUnselected(holder);
    }

    private void handleSelectionForFile(Dataviewrecevi holder, File file) {
        for (File selectedFile : list_select_file) {
            if (file.toString().equals(selectedFile.toString())) {
                showSelected(holder);
                return;
            }
        }
        showUnselected(holder);
    }

    private void showSelected(Dataviewrecevi holder) {
        holder.img_check_ed.setVisibility(View.VISIBLE);
        holder.img_check_un.setVisibility(View.GONE);
    }

    private void showUnselected(Dataviewrecevi holder) {
        holder.img_check_ed.setVisibility(View.GONE);
        holder.img_check_un.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return list_recevi.size();
    }

    public void updatelist(ArrayList<Savers> list_recevi) {
        this.list_recevi = list_recevi;


        notifyDataSetChanged();
    }

    public void updata11Doc(ArrayList<DocumentFile> list_select_doc) {
        MyAdapterRecevi.list_select_doc = list_select_doc;
        notifyDataSetChanged();
    }

    public void update11dow(ArrayList<File> list_select_file) {
        MyAdapterRecevi.list_select_file = list_select_file;
        notifyDataSetChanged();
    }

    public interface ClickSelectSet {
        void onclickdataset(int total);
    }

    class Dataviewrecevi extends RecyclerView.ViewHolder {

        ImageView item_image, img_set_select_video, img_set_select_icon;
        RelativeLayout realti_video_item, realti_set_select_last;
        CardView item_image_date_realti;
        TextView item_text_item_name, item_text_item_size,
                item_text_item_name_select, item_text_item_size_audo, item_text_item_time_dures_audo;
        RelativeLayout realti_check_box_an_ed;
        ImageView img_check_un, img_check_ed;


        public Dataviewrecevi(@NonNull View itemView) {
            super(itemView);

            item_image = itemView.findViewById(R.id.item_image);
            img_set_select_video = itemView.findViewById(R.id.img_set_select_video);
            realti_video_item = itemView.findViewById(R.id.realti_video_item);
            item_image_date_realti = itemView.findViewById(R.id.item_image_date_realti);
            item_text_item_name = itemView.findViewById(R.id.item_text_item_name);
            item_text_item_size = itemView.findViewById(R.id.item_text_item_size);
            item_text_item_name_select = itemView.findViewById(R.id.item_text_item_name_select);
            realti_set_select_last = itemView.findViewById(R.id.realti_set_select_last);
            img_set_select_icon = itemView.findViewById(R.id.img_set_select_icon);
            item_text_item_time_dures_audo = itemView.findViewById(R.id.item_text_item_time_dures_audo);
            item_text_item_size_audo = itemView.findViewById(R.id.item_text_item_size_audo);

            realti_check_box_an_ed = itemView.findViewById(R.id.realti_check_box_an_ed);
            img_check_un = itemView.findViewById(R.id.img_check_un);
            img_check_ed = itemView.findViewById(R.id.img_check_ed);

        }
    }
}
