package com.apptools.payal_mywahtrecorder.Jaycommon;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;

public class ShakeGestureReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent != null && intent.getAction().equals("key_shake_detector")) {
                SharedPreferences SharedPref = context.getSharedPreferences("ShakePRef", Context.MODE_MULTI_PROCESS);

                boolean isKeyOn = SharedPref.getBoolean("shake_on_off_switch_key", false);
                if (isKeyOn) {
                    if (isAppInstalled(context, Constants.app1) && isAppInstalled(context, Constants.app2)) {
                        String spname = SharedPref.getString("Wshap", "wa");
                        if (spname.equals("wb")) {
                            context.startActivity(context.getPackageManager().getLaunchIntentForPackage(Constants.app2));
                        } else {
                            context.startActivity(context.getPackageManager().getLaunchIntentForPackage(Constants.app1));
                        }
                    } else if (isAppInstalled(context, Constants.app1)) {
                        context.startActivity(context.getPackageManager().getLaunchIntentForPackage(Constants.app1));
                    } else if (isAppInstalled(context, Constants.app2)) {
                        context.startActivity(context.getPackageManager().getLaunchIntentForPackage(Constants.app2));
                    }
                }
            }
        } catch (Exception e) {

        }
    }

    private boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

}