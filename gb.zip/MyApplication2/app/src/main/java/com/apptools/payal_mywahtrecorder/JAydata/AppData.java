package com.apptools.payal_mywahtrecorder.JAydata;

import android.content.ContentValues;
import android.database.Cursor;

public class AppData {
    public int id = -1;
    public String packageName;

    public static AppData create(String str) {
        AppData appData = new AppData();
        appData.packageName = str;
        return appData;
    }

    public static AppData create(Cursor cursor) {
        AppData appData = new AppData();
        appData.id = cursor.getInt(cursor.getColumnIndex("id"));
        appData.packageName = cursor.getString(cursor.getColumnIndex("packageName"));
        return appData;
    }

    public ContentValues getValues() {
        ContentValues contentValues = new ContentValues();
        contentValues.put("packageName", this.packageName);
        int i = this.id;
        if (i != -1) {
            contentValues.put("id", Integer.valueOf(i));
        }
        return contentValues;
    }
}
