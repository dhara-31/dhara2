package com.apptools.payal_mywahtrecorder.ads;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jaymodel.MixerBannerModel;

import java.util.ArrayList;

public class MixerIconMerger {


    public static void showIconsHere(Activity activity, RelativeLayout laytouCommon, FrameLayout openGreenFrame) {
        try {
            if (DApplication.checkNetworkAvailable(activity)) {
                laytouCommon.setVisibility(View.VISIBLE);

                View viewOne = activity.getLayoutInflater().inflate(R.layout.layout_qureka_icon, null, true);
                openGreenFrame.addView(viewOne);

                ArrayList<MixerBannerModel> mixerBannerModels = new ArrayList<>();
                try {
                    if (DApplication.getSizeWay() == 1) {
                        for (int resourceId : setterIcoonList) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 1);
                            mixerBannerModels.add(model);
                        }
                    } else if (DApplication.getSizeWay() == 2) {
                        for (int resourceId : zipList) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 2);
                            mixerBannerModels.add(model);
                        }
                    } else {
                        mixerBannerModels = new ArrayList<>(zipList.length + setterIcoonList.length);

                        int smallSize = Math.min(zipList.length, setterIcoonList.length);

                        int index = 0;
                        for (int i = 0; i < smallSize; i++) {
                            MixerBannerModel modelgame = new MixerBannerModel(zipList[i], 2);
                            mixerBannerModels.add(index++, modelgame);

                            MixerBannerModel modelqur = new MixerBannerModel(setterIcoonList[i], 1);
                            mixerBannerModels.add(index++, modelqur);
                        }
                        if (zipList.length > setterIcoonList.length) {
                            int newlength = zipList.length - smallSize;
                            for (int i = 0; i < newlength; i++) {
                                MixerBannerModel mdelgame = new MixerBannerModel(zipList[smallSize + i], 2);
                                mixerBannerModels.add(index++, mdelgame);
                            }
                        } else {
                            int newlenght = setterIcoonList.length - smallSize;
                            for (int i = 0; i < newlenght; i++) {
                                MixerBannerModel modelqur = new MixerBannerModel(setterIcoonList[smallSize + i], 1);
                                mixerBannerModels.add(index++, modelqur);
                            }
                        }
                    }
                } catch (Exception e) {
                    for (int resourceId : zipList) {
                        MixerBannerModel bannerModel = new MixerBannerModel(resourceId, 2);
                        mixerBannerModels.add(bannerModel);
                    }
                }

                String urlNEw = "";
                try {
                    if (DApplication.getSizeWay() == 1 && !DApplication.getTwoUrk()) {
                        urlNEw = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                    } else if (DApplication.getSizeWay() == 2 && !DApplication.fourNativeUrl()) {
                        urlNEw = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                    } else {
                        if (mixerBannerModels.get(iconNew).getQurOrGame() == 1 && !DApplication.getTwoUrk()) {
                            urlNEw = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                        } else if (!DApplication.fourNativeUrl()) {
                            urlNEw = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                        }
                    }
                } catch (Exception e) {

                }

                if (urlNEw != null && !TextUtils.isEmpty(urlNEw)) {
                    ImageView imgNewBannerQka = viewOne.findViewById(R.id.imgNewBannerQka);
                    try {
                        Glide.with(activity).load(mixerBannerModels.get(iconNew).getBannername()).into(imgNewBannerQka);
                    } catch (Exception e) {
                        Glide.with(activity).load(zipList[0]).into(imgNewBannerQka);
                    }
                    iconNew++;
                    try {
                        if (iconNew >= mixerBannerModels.size()) {
                            iconNew = 0;
                        }
                    } catch (Exception e) {
                        iconNew = 0;
                    }
                    String finalLastURlToG = urlNEw;
                    imgNewBannerQka.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            DApplication.tabToIntent(activity, finalLastURlToG);
                        }
                    });
                } else {
                    laytouCommon.setVisibility(View.GONE);
                }

            } else {
                laytouCommon.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }

    }

    private static int[] zipList = new int[]{R.drawable.game_icon1, R.drawable.game_icon2, R.drawable.game_icon3, R.drawable.game_icon4, R.drawable.game_icon5, R.drawable.game_icon6,
            R.drawable.game_icon7, R.drawable.game_icon8, R.drawable.game_icon9, R.drawable.game_icon10};
    private static int[] setterIcoonList = new int[]{R.drawable.qureka_icon1, R.drawable.qureka_icon2, R.drawable.qureka_icon3, R.drawable.qureka_icon4, R.drawable.qureka_icon5,
            R.drawable.qureka_icon6, R.drawable.qureka_icon7, R.drawable.qureka_icon8};

    private static int iconNew = 0;

}
