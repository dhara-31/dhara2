package com.apptools.payal_mywahtrecorder.JayStatusSaver;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class Constants {

    public static String app1 = "com.whatsapp";
    public static String app2 = "com.whatsapp.w4b";

    public static StatusSaverActivity statusSaverActivity;
    public static WAImageFragment waImageFragment;
    public static WAVideoFragment waVideoFragment;


    public static DocumentFile[] getFromSdcard(Context context) {

        try {
            String pathFolder = new PreferenceUtil(context).getString(PreferenceUtil.KeyUseThisFolder, "");
            if (pathFolder.isEmpty()) {
                return null;
            } else {
                try {
                    DocumentFile fromTreeUri = DocumentFile.fromTreeUri(context, Uri.parse(pathFolder));
                    if (statusSaverActivity.isStatusAppPresent) {
                        return fromTreeUri.findFile(app1).findFile("WhatsApp").findFile("Media").findFile(".Statuses").listFiles();
                    } else {
                        return fromTreeUri.findFile(app2).findFile("WhatsApp Business").findFile("Media").findFile(".Statuses").listFiles();
                    }
                } catch (Exception e) {
                    return null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getFileNameFromUri(Context context, Uri uri) {
        String fileName = null;

        if (uri.getScheme().equals("content")) {
            String[] projection = {OpenableColumns.DISPLAY_NAME};
            try (Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    fileName = cursor.getString(columnIndex);
                }
            }
        } else if (uri.getScheme().equals("file")) {
           fileName = uri.getLastPathSegment();
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && DocumentsContract.isDocumentUri(context, uri)) {
           String documentId = DocumentsContract.getDocumentId(uri);
            String[] split = documentId.split(":");
            String type = split[0];

            Uri contentUri = null;
            switch (type) {
                case "image":
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    break;
                case "video":
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    break;
                case "audio":
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    break;
                case "download":
                    contentUri = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                    break;
            }

            String selection = "_id=?";
            String[] selectionArgs = new String[]{split[1]};

            try (Cursor cursor = context.getContentResolver().query(contentUri, null, selection, selectionArgs, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    fileName = cursor.getString(columnIndex);
                }
            }
        }

        return fileName;
    }

    public static void SaveSS(String uri, String name, Context context, String APP_DIR) {

        File folder;
        folder = new File(APP_DIR);

        if (!folder.exists()) {
            folder.mkdirs();
        }

        File file1 = new File(folder, name);

        try {
            InputStream inputStream = context.getContentResolver().openInputStream(Uri.parse(uri));

            File f = new File(file1.toString());
            f.setWritable(true, false);
            OutputStream outputStream = new FileOutputStream(f);
            byte buffer[] = new byte[1024];
            int length = 0;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public interface CallBackOfListFiles {
        void checkFile(String selectedFilePath);
    }

    public static ArrayList<String> fileNames = new ArrayList<>();

    public static Boolean isDownloaded(String fileName) {
        if (fileNames.isEmpty()) {
            return false;
        }
        for (String str : fileNames) {
            if (fileName.toLowerCase().endsWith(str.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    public static void scanBothAppFile(Context context, String pathhh, CallBackOfListFiles callBackOfListFiles) {
        fileNames = new ArrayList<>();
        ArrayList<File> files = getListFiles(new File(JemsProviderKt.getWABPath(context)), "all");
        files.addAll(getListFiles(new File(JemsProviderKt.getWAPath(context)), "all"));
        File currentFile = new File(pathhh);
        String path = "";
        for (File file : files) {
            fileNames.add(file.getName());
            if (currentFile.getName().toLowerCase().endsWith(file.getName().toLowerCase())) {
                path = file.getAbsolutePath();
            }
        }
        callBackOfListFiles.checkFile(path);
    }

    public static ArrayList<File> getListFiles(File parentDir, String video) {
        ArrayList<File> inFiles = new ArrayList<>();
        File[] files;
        files = parentDir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.exists()) {
                    if (!file.getName().equals(".nomedia")) {
                        if (!inFiles.contains(file)) {
                            if (video.equals("video")) {
                                if (file.getAbsolutePath().toLowerCase().endsWith("mp4")) {
                                    inFiles.add(file);
                                }
                            } else if (video.equals("image")) {
                                if (!file.getAbsolutePath().toLowerCase().endsWith("mp4")) {
                                    inFiles.add(file);
                                }
                            } else {
                                inFiles.add(file);
                            }
                        }
                    }
                }
            }
        }
        return inFiles;
    }


    public static void copyFile(File status, Context context, String APP_DIR) {

        File file = new File(APP_DIR);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Toast.makeText(context, JemsProviderKt.getMyString(context, R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
            }
        }

        File destFile = new File(file + File.separator + status.getName());

        try {

            FileUtils.copyFile(status.getAbsoluteFile(), destFile);
            destFile.setLastModified(System.currentTimeMillis());
            new SingleMediaScanner(context, file);

            try {
                if (statusSaverActivity != null && !statusSaverActivity.isDestroyed()) {

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }

}
