package com.apptools.payal_mywahtrecorder.JaynewSplitter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.daasuu.mp4compose.composer.Mp4Composer;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.apptools.payal_mywahtrecorder.JayHomeActivity.VS_Peview_Of_Video_Open_Activity;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jaymodel.allVideo_Model;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;
import java.util.ArrayList;

public class B_VSplitter extends AppCompatActivity {

    int startTime;
    int endTime;
    int increase;
    int videoNumber = 1;
    float videoPart;
    int totalPart;
    long duration;
    String selectedVideoUri;
    String fileName;
    String APP_DIR;

    RecyclerView rv_splitted_video;
    TextView tv_video_split_no;
    TextView tv_video_split_no_2;
    CircularProgressBar circularProgressBar;
    CircularProgressBar circularProgressBar_2;

    RelativeLayout rl_progress_2;
    RelativeLayout rl_progress;
    TextView tv_nothing_to_display;

    ImageView sharesplitvideo;

    VideoSplittedListAdapter videoSplittedListAdapter;
    Mp4Composer mp4Composer;

    Dialog dialog;
    TextView iv_okay, text_permi__log_text;
    TextView iv_cancel;
    ArrayList<allVideo_Model> splitVideoList;
    private Context activity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bvsplittertools);
        activity = this;

        increase = getIntent().getIntExtra("increase", 10000);
        duration = getIntent().getLongExtra("duration", 0);
        selectedVideoUri = getIntent().getStringExtra("VideoUrl");
        fileName = getIntent().getStringExtra("fileName");

        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        rv_splitted_video = findViewById(R.id.rv_splitted_video);
        tv_video_split_no = findViewById(R.id.tv_video_split_no);
        tv_video_split_no_2 = findViewById(R.id.tv_video_split_no_2);
        circularProgressBar = findViewById(R.id.circularProgressBar);
        circularProgressBar_2 = findViewById(R.id.circularProgressBar_2);
        rl_progress_2 = findViewById(R.id.rl_progress_2);
        tv_nothing_to_display = findViewById(R.id.tv_nothing_to_display);
        rl_progress = findViewById(R.id.rl_progress);
        sharesplitvideo = findViewById(R.id.sharesplitvideo);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        findViewById(R.id.video_show_back_img).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        if (Build.VERSION.SDK_INT < 30) {
            APP_DIR = Environment.getExternalStorageDirectory().getPath() + File.separator + "GBWahatzAps/videos";
        } else {
            APP_DIR = getFilesDir().toString() + File.separator + "GBWahatzAps/videos";
        }

        endTime = increase;
        videoPart = (Float.valueOf(duration) - 900.0f) / increase;
        totalPart = (int) videoPart;
        if (videoPart > totalPart) {
            totalPart++;
        }

        tv_video_split_no.setText(videoNumber + "/" + totalPart);
        tv_video_split_no_2.setText(videoNumber + "/" + totalPart);

        circularProgressBar.setProgressMax(100.0f);
        circularProgressBar_2.setProgressMax(100.0f);
        circularProgressBar.setProgress(0f);
        circularProgressBar_2.setProgress(0f);
        rl_progress.setVisibility(View.GONE);

        if (!new File(APP_DIR).exists()) {
            new File(APP_DIR).mkdirs();
        }

        splitVideoList = new ArrayList<>();
        startSplit();

    }

    public void getVideoFiles(String path) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    tv_nothing_to_display.setVisibility(View.GONE);
                    rl_progress_2.setVisibility(View.GONE);
                    rl_progress.setVisibility(View.VISIBLE);

                    MediaMetadataRetriever mmr = new MediaMetadataRetriever();

                    File file = new File(path);

                    String title = file.getName();
                    String url = file.getAbsolutePath();
                    long value = 0;
                    try {
                        mmr.setDataSource(file.getPath());
                        String duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                        value = (long) Double.parseDouble(duration);
                    } catch (Exception e) {
                    }

                    allVideo_Model model = new allVideo_Model();
                    model.setVideoTitle(title);
                    model.setVideoUri(Uri.parse(url));

                    splitVideoList.add(model);


                    if (videoSplittedListAdapter == null) {
                        rv_splitted_video.setLayoutManager(new GridLayoutManager(B_VSplitter.this, 2));
                        videoSplittedListAdapter = new VideoSplittedListAdapter(B_VSplitter.this, splitVideoList);
                        rv_splitted_video.setAdapter(videoSplittedListAdapter);
                    } else {
                        videoSplittedListAdapter.updateList(splitVideoList);
                    }

                } catch (Exception e) {
                    tv_nothing_to_display.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    int failCount = 0;

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void startSplit() {
        String videoPath = APP_DIR + File.separator + new File(selectedVideoUri).getName().toLowerCase().replace(".mp4", "") + "__" + videoNumber + ".mp4";

        if (videoNumber == totalPart) {
            endTime = Math.toIntExact((duration));
        }

        mp4Composer = new Mp4Composer(selectedVideoUri, videoPath).trim(startTime, endTime).listener(new Mp4Composer.Listener() {
            @Override
            public void onProgress(double progress) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (videoNumber == 1) {
                            circularProgressBar_2.setProgress((float) (progress * 100));
                        } else {
                            circularProgressBar.setProgress((float) (progress * 100));
                        }
                    }
                });

            }

            @Override
            public void onCurrentWrittenVideoTime(long timeUs) {

            }

            @Override
            public void onCompleted() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rl_progress_2.setVisibility(View.GONE);
                        rl_progress.setVisibility(View.VISIBLE);

                        getVideoFiles(videoPath);
                        tv_video_split_no.setText(videoNumber + "/" + totalPart);
                    }
                });
                if (totalPart == videoNumber) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            rl_progress.setVisibility(View.GONE);
                        }
                    });
                } else {
                    videoNumber++;
                    startTime = startTime + increase;
                    endTime = endTime + increase;
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startSplit();
                        }
                    }, 500);

                }
            }

            @Override
            public void onCanceled() {

            }

            @Override
            public void onFailed(Exception exception) {
                runOnUiThread(() -> {
                    failCount++;
                    if (failCount > 3) {
                        MyDialog();
                    } else {
                        startSplit();
                    }
                });
            }
        }).start();
    }

    private long mLastClickTime = 0l;
    private static final long CLICK_TIME_INTERVAL = 700;

    public void share(String statusUri) {
        long now = System.currentTimeMillis();
        if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
            return;
        }
        mLastClickTime = now;

        File file = new File(statusUri);
        Uri uri = FileProvider.getUriForFile(B_VSplitter.this, B_VSplitter.this.getPackageName() + ".fileProvider", file);
        final ShareCompat.IntentBuilder intentBuilder = ShareCompat.IntentBuilder.from((Activity) B_VSplitter.this);
        final Intent intent = intentBuilder.createChooserIntent();
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        Intent sharingIntent = new Intent(Intent.ACTION_SEND);


        if (statusUri.toLowerCase().endsWith(".mp4")) {
            sharingIntent.setType("video/*");
        } else {
            sharingIntent.setType("image/*");
        }

        sharingIntent.putExtra(Intent.EXTRA_STREAM, uri);
        startActivity(Intent.createChooser(sharingIntent, "Share using"));
    }

    void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) for (File child : fileOrDirectory.listFiles())
            deleteRecursive(child);

        fileOrDirectory.delete();
    }

    void MyDialog() {
        dialog = new Dialog(B_VSplitter.this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.video_delete_dialog_layout);
        dialog.setCancelable(false);

        Window window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.addFlags(2);
        window.setDimAmount(0.82f);
        window.setAttributes(attributes);

        iv_okay = dialog.findViewById(R.id.delete_dialog_okay_txt);
        iv_cancel = dialog.findViewById(R.id.delete_dialog_cancel_txt);
        text_permi__log_text = dialog.findViewById(R.id.text_permi__log_text);

        text_permi__log_text.setText(JemsProviderKt.getMyString(activity, R.string.something_thing_went_wrong_please_try_later));

        iv_okay.setVisibility(View.GONE);
        iv_cancel.setText(JemsProviderKt.getMyString(activity, R.string.tips_ok));

        iv_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });

        dialog.show();
    }

    @Override
    public void onBackPressed() {

        dialog = new Dialog(B_VSplitter.this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.video_delete_dialog_layout);
        dialog.setCancelable(false);

        Window window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.CENTER;
        window.addFlags(2);
        window.setDimAmount(0.82f);
        window.setAttributes(attributes);

        iv_okay = dialog.findViewById(R.id.delete_dialog_okay_txt);
        iv_cancel = dialog.findViewById(R.id.delete_dialog_cancel_txt);


        iv_okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rl_progress.getVisibility() == View.VISIBLE || rl_progress_2.getVisibility() == View.VISIBLE) {
                    mp4Composer.cancel();
                }
                finish();
                deleteRecursive(new File(APP_DIR));

                dialog.dismiss();
            }
        });

        iv_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public class VideoSplittedListAdapter extends RecyclerView.Adapter<VideoSplittedListAdapter.ViewHolder> {

        Context context;
        ArrayList<allVideo_Model> videoList = new ArrayList<>();

        public VideoSplittedListAdapter(Context context, ArrayList<allVideo_Model> videoList) {
            this.context = context;
            this.videoList = videoList;
        }

        public void updateList(ArrayList<allVideo_Model> videoList) {
            this.videoList = videoList;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video_silittools, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

            allVideo_Model videoModel = videoList.get(position);
            Glide.with(context).load(videoList.get(position).getVideoUri().toString()).override(200, 200).into(holder.iv_VideoThumbnail);
            holder.tv_VideoName.setText(videoModel.getVideoTitle());
            holder.tv_VideoName.setSelected(true);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    InterAdCall.getHelpIndicatorExplicit().callintermethod(B_VSplitter.this, true, msg -> {
                        Intent intent = new Intent(context, VS_Peview_Of_Video_Open_Activity.class);
                        intent.putExtra("position", position);
                        intent.putExtra("video_file_path", videoList.get(position).getVideoUri().toString());
                        intent.putExtra("SplitterVideoNM", videoList.get(position).getVideoTitle());
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    });



                }
            });

            holder.split_item_share_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                        return;
                    }
                    mLastClickTime = now;
                    File file_path = new File(videoList.get(position).getVideoUri().toString());

                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                    Uri uri = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".provider", file_path);

                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_STREAM, uri);
                    context.startActivity(Intent.createChooser(intent, "choseFile"));
                }
            });

        }

        @Override
        public int getItemCount() {
            return videoList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView tv_VideoName;
            ImageView iv_VideoThumbnail;
            ImageView split_item_share_img;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                tv_VideoName = itemView.findViewById(R.id.split_item_video_name_txt);
                iv_VideoThumbnail = itemView.findViewById(R.id.split_item_img);
                split_item_share_img = itemView.findViewById(R.id.split_item_share_img);

            }
        }
    }

}