package com.apptools.payal_mywahtrecorder.JAydata;

public class RecordModeFunction {
    public boolean enableMic;
    public boolean muteAudio;

    public RecordModeFunction(boolean z, boolean z2) {
        this.muteAudio = z;
        this.enableMic = z2;
    }
}
