package com.apptools.payal_mywahtrecorder.ads;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class AppDetail implements Serializable {
    private String appname, appstatus, adstatus, version, fbappname, fbbanner, fbnativebanner,
            fbnative, fbinter, fbreward, admobappname, admobbanner, admobnative, admobinter,
            admobreward, admobappid, admobnew, counter, bannerimg, bannerurl, privacy;

    private String facebookadstatus, fbcounter, admobadstatus, addmobcounter;

    private String admob2appname, admob2counter, admob2status, admob2appid, admob2banner, admob2interstitial,
            admob2native, admob2reward, admob2appopen, admob3appname, admob3counter, admob3status,
            admob3appid, admob3banner, admob3interstitial, admob3native, admob3reward, admob3appopen,
            qurekaurl, appscreennumber, appopeninsidestatus, appopenbackpress, nativebuttoncolor,
            backbuttonscreen, interstitialbackpress;

    @SerializedName("package")
    private String packageName;

    public String getAppname() {
        return appname;
    }

    public void setAppname(String appname) {
        this.appname = appname;
    }

    public String getAppstatus() {
        return appstatus;
    }

    public void setAppstatus(String appstatus) {
        this.appstatus = appstatus;
    }

    public String getAdstatus() {
        return adstatus;
    }

    public void setAdstatus(String adstatus) {
        this.adstatus = adstatus;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getFbappname() {
        return fbappname;
    }

    public void setFbappname(String fbappname) {
        this.fbappname = fbappname;
    }

    public String getFbbanner() {
        return fbbanner;
    }

    public void setFbbanner(String fbbanner) {
        this.fbbanner = fbbanner;
    }

    public String getFbnativebanner() {
        return fbnativebanner;
    }

    public void setFbnativebanner(String fbnativebanner) {
        this.fbnativebanner = fbnativebanner;
    }

    public String getFbnative() {
        return fbnative;
    }

    public void setFbnative(String fbnative) {
        this.fbnative = fbnative;
    }

    public String getFbinter() {
        return fbinter;
    }

    public void setFbinter(String fbinter) {
        this.fbinter = fbinter;
    }

    public String getFbreward() {
        return fbreward;
    }

    public void setFbreward(String fbreward) {
        this.fbreward = fbreward;
    }

    public String getFacebookadstatus() {
        return facebookadstatus;
    }

    public void setFacebookadstatus(String facebookadstatus) {
        this.facebookadstatus = facebookadstatus;
    }

    public String getFbcounter() {
        return fbcounter;
    }

    public void setFbcounter(String fbcounter) {
        this.fbcounter = fbcounter;
    }

    public String getAdmobappname() {
        return admobappname;
    }

    public void setAdmobappname(String admobappname) {
        this.admobappname = admobappname;
    }

    public String getAdmobbanner() {
        return admobbanner;
    }

    public void setAdmobbanner(String admobbanner) {
        this.admobbanner = admobbanner;
    }

    public String getAdmobnative() {
        return admobnative;
    }

    public void setAdmobnative(String admobnative) {
        this.admobnative = admobnative;
    }

    public String getAdmobinter() {
        return admobinter;
    }

    public void setAdmobinter(String admobinter) {
        this.admobinter = admobinter;
    }

    public String getAdmobreward() {
        return admobreward;
    }

    public void setAdmobreward(String admobreward) {
        this.admobreward = admobreward;
    }

    public String getAdmobappid() {
        return admobappid;
    }

    public void setAdmobappid(String admobappid) {
        this.admobappid = admobappid;
    }

    public String getAppopenAdmob() {
        return admobnew;
    }

    public void setAdmobnew(String admobnew) {
        this.admobnew = admobnew;
    }

    public String getAdmobadstatus() {
        return admobadstatus;
    }

    public void setAdmobadstatus(String admobadstatus) {
        this.admobadstatus = admobadstatus;
    }

    public String getAddmobcounter() {
        return addmobcounter;
    }

    public void setAddmobcounter(String addmobcounter) {
        this.addmobcounter = addmobcounter;
    }

    public String getAdmob2appname() {
        return admob2appname;
    }

    public void setAdmob2appname(String admob2appname) {
        this.admob2appname = admob2appname;
    }

    public String getAdmob2counter() {
        return admob2counter;
    }

    public void setAdmob2counter(String admob2counter) {
        this.admob2counter = admob2counter;
    }

    public String getAdmob2status() {
        return admob2status;
    }

    public void setAdmob2status(String admob2status) {
        this.admob2status = admob2status;
    }

    public String getAdmob2appid() {
        return admob2appid;
    }

    public void setAdmob2appid(String admob2appid) {
        this.admob2appid = admob2appid;
    }

    public String getAdmob2banner() {
        return admob2banner;
    }

    public void setAdmob2banner(String admob2banner) {
        this.admob2banner = admob2banner;
    }

    public String getAdmob2interstitial() {
        return admob2interstitial;
    }

    public void setAdmob2interstitial(String admob2interstitial) {
        this.admob2interstitial = admob2interstitial;
    }

    public String getAdmob2native() {
        return admob2native;
    }

    public void setAdmob2native(String admob2native) {
        this.admob2native = admob2native;
    }

    public String getAdmob2reward() {
        return admob2reward;
    }

    public void setAdmob2reward(String admob2reward) {
        this.admob2reward = admob2reward;
    }

    public String getAdmob2appopen() {
        return admob2appopen;
    }

    public void setAdmob2appopen(String admob2appopen) {
        this.admob2appopen = admob2appopen;
    }

    public String getAdmob3appname() {
        return admob3appname;
    }

    public void setAdmob3appname(String admob3appname) {
        this.admob3appname = admob3appname;
    }

    public String getAdmob3counter() {
        return admob3counter;
    }

    public void setAdmob3counter(String admob3counter) {
        this.admob3counter = admob3counter;
    }

    public String getAdmob3status() {
        return admob3status;
    }

    public void setAdmob3status(String admob3status) {
        this.admob3status = admob3status;
    }

    public String getAdmob3appid() {
        return admob3appid;
    }

    public void setAdmob3appid(String admob3appid) {
        this.admob3appid = admob3appid;
    }

    public String getAdmob3banner() {
        return admob3banner;
    }

    public void setAdmob3banner(String admob3banner) {
        this.admob3banner = admob3banner;
    }

    public String getAdmob3interstitial() {
        return admob3interstitial;
    }

    public void setAdmob3interstitial(String admob3interstitial) {
        this.admob3interstitial = admob3interstitial;
    }

    public String getAdmob3native() {
        return admob3native;
    }

    public void setAdmob3native(String admob3native) {
        this.admob3native = admob3native;
    }

    public String getAdmob3reward() {
        return admob3reward;
    }

    public void setAdmob3reward(String admob3reward) {
        this.admob3reward = admob3reward;
    }

    public String getAdmob3appopen() {
        return admob3appopen;
    }

    public void setAdmob3appopen(String admob3appopen) {
        this.admob3appopen = admob3appopen;
    }

    public String getQurekaurl() {
        return qurekaurl;
    }

    public void setQurekaurl(String qurekaurl) {
        this.qurekaurl = qurekaurl;
    }

    public String getAppscreennumber() {
        return appscreennumber;
    }

    public void setAppscreennumber(String appscreennumber) {
        this.appscreennumber = appscreennumber;
    }

    public String getAppopeninsidestatus() {
        return appopeninsidestatus;
    }

    public void setAppopeninsidestatus(String appopeninsidestatus) {
        this.appopeninsidestatus = appopeninsidestatus;
    }

    public String getAppopenbackpress() {
        return appopenbackpress;
    }

    public void setAppopenbackpress(String appopenbackpress) {
        this.appopenbackpress = appopenbackpress;
    }

    public String getNativebuttoncolor() {
        return nativebuttoncolor;
    }

    public void setNativebuttoncolor(String nativebuttoncolor) {
        this.nativebuttoncolor = nativebuttoncolor;
    }

    public String getBackbuttonscreen() {
        return backbuttonscreen;
    }

    public void setBackbuttonscreen(String backbuttonscreen) {
        this.backbuttonscreen = backbuttonscreen;
    }

    public String getInterstitialbackpress() {
        return interstitialbackpress;
    }

    public void setInterstitialbackpress(String interstitialbackpress) {
        this.interstitialbackpress = interstitialbackpress;
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

    public String getBannerimg() {
        return bannerimg;
    }

    public void setBannerimg(String bannerimg) {
        this.bannerimg = bannerimg;
    }

    public String getBannerurl() {
        return bannerurl;
    }

    public void setBannerurl(String bannerurl) {
        this.bannerurl = bannerurl;
    }

    public String getPrivacy() {
        return privacy;
    }

    public void setPrivacy(String privacy) {
        this.privacy = privacy;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }
}
