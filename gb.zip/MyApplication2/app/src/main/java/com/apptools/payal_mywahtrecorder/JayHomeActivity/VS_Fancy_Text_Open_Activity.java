package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jaymodel.Font;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.util.ArrayList;

public class VS_Fancy_Text_Open_Activity extends AppCompatActivity {


    ImageView fancy_remove_img, fancy_copy_img, fancy_txt_share_img;

    ArrayList<Font> fancy_txt_list = new ArrayList<>();

    String first_set_string = "Hello World";

    ImageView fancy_back_img, relative_back_img;

    EditText fancy_main_et;
    RecyclerView fancy_main_recycler;
    Fancy_Main_Adapter fancy_main_adapter;

    RelativeLayout feature_main_linear;

    TextView fancy_converted_txt;

    String converted_String;


    Animation top_to_bottom, bottom_to_top;

    public long mLastClickTime;
    public long CLICK_TIME_INTERVAL;
    private Activity activity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vs_fancy_text_opentools);


        activity = this;

        feature_main_linear = findViewById(R.id.feature_main_linear);

        fancy_back_img = findViewById(R.id.fancy_back_img);
        relative_back_img = findViewById(R.id.relative_back_img);

        fancy_main_et = findViewById(R.id.fancy_main_et);
        fancy_main_recycler = findViewById(R.id.fancy_main_recycler);
        fancy_remove_img = findViewById(R.id.fancy_remove_img);

        fancy_converted_txt = findViewById(R.id.fancy_converted_txt);
        fancy_copy_img = findViewById(R.id.fancy_copy_img);
        fancy_txt_share_img = findViewById(R.id.fancy_txt_share_img);

        get_fancy_all();

        top_to_bottom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.top_to_bottom_anim);
        bottom_to_top = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.bottom_to_top_anim);
        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }

        fancy_main_recycler.setLayoutManager(new LinearLayoutManager(this));
        fancy_main_recycler.setHasFixedSize(true);
        fancy_main_adapter = new Fancy_Main_Adapter(this, fancy_txt_list, first_set_string);
        fancy_main_recycler.setAdapter(fancy_main_adapter);
        fancy_remove_img.setEnabled(false);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        fancy_converted_txt.setMovementMethod(new ScrollingMovementMethod());

        fancy_main_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().trim().length() == 0) {

                    fancy_remove_img.setImageResource(R.drawable.fancy_cancel_blur_img);
                    fancy_main_adapter.set_first_string("Hello World");
                    fancy_remove_img.setEnabled(false);

                } else {

                    fancy_main_recycler.setVisibility(View.VISIBLE);
                    fancy_main_adapter.set_first_string(s.toString().trim());
                    fancy_remove_img.setImageResource(R.drawable.fancy_cancel_img);
                    fancy_remove_img.setEnabled(true);


                }
            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        fancy_remove_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fancy_main_et.setText("");
                fancy_main_et.setHint("Enter text");
                fancy_remove_img.setImageResource(R.drawable.fancy_cancel_blur_img);

            }
        });

        fancy_back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();

            }
        });

        relative_back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }

                feature_main_linear.startAnimation(top_to_bottom);

                feature_main_linear.setVisibility(View.GONE);

                mLastClickTime = System.currentTimeMillis();
                CLICK_TIME_INTERVAL = 1500;
            }
        });

        fancy_copy_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }

                ClipboardManager clipboardck = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipcopy = ClipData.newPlainText("fffff", converted_String);
                clipboardck.setPrimaryClip(clipcopy);

                Toast.makeText(VS_Fancy_Text_Open_Activity.this, JemsProviderKt.getMyString(activity, R.string.copied), Toast.LENGTH_SHORT).show();

                feature_main_linear.setVisibility(View.GONE);
                feature_main_linear.startAnimation(top_to_bottom);

                mLastClickTime = System.currentTimeMillis();
                CLICK_TIME_INTERVAL = 1500;


            }
        });

        fancy_txt_share_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }

                try {
                    Intent shareIntenttext = new Intent(Intent.ACTION_SEND);
                    shareIntenttext.setType("text/plain");
                    shareIntenttext.putExtra(Intent.EXTRA_TEXT, converted_String);
                    startActivity(Intent.createChooser(shareIntenttext, "choose single"));
                } catch (Exception e) {

                }

                feature_main_linear.setVisibility(View.GONE);
                feature_main_linear.startAnimation(top_to_bottom);

                mLastClickTime = System.currentTimeMillis();
                CLICK_TIME_INTERVAL = 1500;


            }
        });

        feature_main_linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }

                feature_main_linear.setVisibility(View.GONE);

                feature_main_linear.startAnimation(top_to_bottom);

                mLastClickTime = System.currentTimeMillis();
                CLICK_TIME_INTERVAL = 1500;


            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    private void get_fancy_all() {

        fancy_txt_list.add(new Font(new String[]{"ą", "ɓ", "ç", "d", "ę", "ƒ", "ɠ", "ђ", "į", "ʝ", "ķ", "ɭ", "ɱ", "ŋ", "ǫ", "ƥ", "ʠ", "ŗ", "ş", "ţ", "ų", "v", "w", "ҳ", "ƴ", "ʐ", "ą", "ɓ", "ç", "d", "ę", "ƒ", "ɠ", "ђ", "į", "ʝ", "ķ", "ɭ", "ɱ", "ŋ", "ǫ", "ƥ", "ʠ", "ŗ", "ş", "ţ", "ų", "v", "w", "ҳ", "ƴ", "ʐ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ꭿ", "Ᏸ", "Ꮸ", "Ꭰ", "Ꭼ", "Ꮀ", "Ꮆ", "Ꮋ", "Ꭸ", "Ꮰ", "Ꮶ", "Ꮭ", "Ꮇ", "Ꮑ", "Ꮎ", "Ꮲ", "Ꮕ", "Ꮢ", "Ꮥ", "Ꮏ", "Ꮼ", "Ꮙ", "Ꮿ", "Ꮂ", "Ꮍ", "Ꮓ", "Ꭿ", "Ᏸ", "Ꮸ", "Ꭰ", "Ꭼ", "Ꮀ", "Ꮆ", "Ꮋ", "Ꭸ", "Ꮰ", "Ꮶ", "Ꮭ", "Ꮇ", "Ꮑ", "Ꮎ", "Ꮲ", "Ꮕ", "Ꮢ", "Ꮥ", "Ꮏ", "Ꮼ", "Ꮙ", "Ꮿ", "Ꮂ", "Ꮍ", "Ꮓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A̸", "B̸", "C̸", "D̸", "E̸", "F̸", "G̸", "H̸", "I̸", "J̸", "K̸", "L̸", "M̸", "N̸", "O̸", "P̸", "Q̸", "R̸", "S̸", "T̸", "U̸", "V̸", "W̸", "X̸", "Y̸", "Z̸", "a̸", "b̸", "c̸", "d̸", "e̸", "f̸", "g̸", "h̸", "i̸", "j̸", "k̸", "l̸", "m̸", "n̸", "o̸", "p̸", "q̸", "r̸", "s̸", "t̸", "u̸", "v̸", "w̸", "x̸", "y̸", "z̸", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A̲̅", "B̲̅", "C̲̅", "D̲̅", "E̲̅", "F̲̅", "G̲̅", "H̲̅", "I̲̅", "J̲̅", "K̲̅", "L̲̅", "M̲̅", "N̲̅", "O̲̅", "P̲̅", "Q̲̅", "R̲̅", "S̲̅", "T̲̅", "U̲̅", "V̲̅", "W̲̅", "X̲̅", "Y̲̅", "Z̲̅", "a̲̅", "b̲̅", "c̲̅", "d̲̅", "e̲̅", "f̲̅", "g̲̅", "h̲̅", "i̲̅", "j̲̅", "k̲̅", "l̲̅", "m̲̅", "n̲̅", "o̲̅", "p̲̅", "q̲̅", "r̲̅", "s̲̅", "t̲̅", "u̲̅", "v̲̅", "w̲̅", "x̲̅", "y̲̅", "z̲̅", "0̲̅", "1̲̅", "2̲̅", "3̲̅", "4̲̅", "5̲̅", "6̲̅", "7̲̅", "8̲̅", "9̲̅"}));
        fancy_txt_list.add(new Font(new String[]{"ä̤", "b̤̈", "c̤̈", "d̤̈", "ë̤", "f̤̈", "g̤̈", "ḧ̤", "ï̤", "j̤̈", "k̤̈", "l̤̈", "m̤̈", "n̤̈", "ö̤", "p̤̈", "q̤̈", "r̤̈", "s̤̈", "ẗ̤", "ṳ̈", "v̤̈", "ẅ̤", "ẍ̤", "ÿ̤", "z̤̈", "ä̤", "b̤̈", "c̤̈", "d̤̈", "ë̤", "f̤̈", "g̤̈", "ḧ̤", "ï̤", "j̤̈", "k̤̈", "l̤̈", "m̤̈", "n̤̈", "ö̤", "p̤̈", "q̤̈", "r̤̈", "s̤̈", "ẗ̤", "ṳ̈", "v̤̈", "ẅ̤", "ẍ̤", "ÿ̤", "z̤̈", "0̤̈", "1̤̈", "2̤̈", "3̤̈", "4̤̈", "5̤̈", "6̤̈", "7̤̈", "8̤̈", "9̤̈"}));


        fancy_txt_list.add(new Font(new String[]{"Д", "B", "C", "D", "Є", "F", "G", "H", "Ї", "J", "К", "L", "M", "Й", "О", "P", "Ｑ", "Я", "$", "T", "Ц", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "Ш", "Ж", "У", "Z", "a", "в", "c", "d", "ё", "f", "g", "н", "ї", "j", "к", "l", "м", "п", "о", "p", "q", "я", "$", "т", "ц", "v", "щ", "ж", "у", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"∀", "฿", "☾", "Ð", "∃", "ℱ", "Ḡ", "Ħ", "ℐ", "J", "Ḱ", "Ḻ", "ℳ", "И", "Ⓞ", "ℙ", "ℚ", "ℝ", "Ꮥ", "✞", "Ü", "Ṽ", "Ш", "Ẍ", "Ẏ", "Ẑ", "@", "♭", "ḉ", "∂", "ε", "ḟ", "ℊ", "н", "ḯ", "ʝ", "ḱ", "ʟ", "ღ", "η", "ø", "℘", "ⓠ", "я", "﹩", "⊥", "ʊ", "ṽ", "ẘ", "✖", "¥", "ℨ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A̶", "B̶", "C̶", "D̶", "E̶", "F̶", "G̶", "H̶", "I̶", "J̶", "K̶", "L̶", "M̶", "N̶", "O̶", "P̶", "Q̶", "R̶", "S̶", "T̶", "U̶", "V̶", "W̶", "X̶", "Y̶", "Z̶", "a̶", "b̶", "c̶", "d̶", "e̶", "f̶", "g̶", "h̶", "i̶", "j̶", "k̶", "l̶", "m̶", "n̶", "o̶", "p̶", "q̶", "r̶", "s̶", "t̶", "u̶", "v̶", "w̶", "x̶", "y̶", "z̶", "0̶", "1̶", "2̶", "3̶", "4̶", "5̶", "6̶", "7̶", "8̶", "9̶"}));
        fancy_txt_list.add(new Font(new String[]{"ᗩ", "ᗷ", "ᑕ", "ↁ", "ᕮ", "ℱ", "𐌾", "ᕼ", "ᓮ", "ᒎ", "Ḱ", "ᒪ", "ᙢ", "ᘉ", "0", "ᖘ", "Ⴓ", "ᖇ", "ᔕ", "T", "ᕰ", "ᐯ", "ᗯ", "᙭", "Ꭹ", "ᔓ", "ᗩ", "ᕊ", "ᙅ", "ᖙ", "ᙓ", "ℱ", "𐌾", "ᖺ", "ᓮ", "ᒎ", "Ḱ", "ᒪ", "ᙢ", "ᘉ", "ᗝ", "ᕈ", "ᖳ", "ᖇ", "ᔕ", "t", "ᘎ", "Ⅴ", "ᙡ", "ჯ", "Ꭹ", "ᔓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ⓐ", "Ⓑ", "Ⓒ", "Ⓓ", "Ⓔ", "Ⓕ", "Ⓖ", "Ⓗ", "Ⓘ", "Ⓙ", "Ⓚ", "Ⓛ", "Ⓜ", "Ⓝ", "Ⓞ", "Ⓟ", "Ⓠ", "Ⓡ", "Ⓢ", "Ⓣ", "Ⓤ", "Ⓥ", "Ⓦ", "Ⓧ", "Ⓨ", "Ⓩ", "ⓐ", "ⓑ", "ⓒ", "ⓓ", "ⓔ", "ⓕ", "ⓖ", "ⓗ", "ⓘ", "ⓙ", "ⓚ", "ⓛ", "ⓜ", "ⓝ", "ⓞ", "ⓟ", "ⓠ", "ⓡ", "ⓢ", "ⓣ", "ⓤ", "ⓥ", "ⓦ", "ⓧ", "ⓨ", "ⓩ", "⓪", "➀", "➁", "➂", "➃", "➄", "➅", "➆", "➇", "➈"}));
        fancy_txt_list.add(new Font(new String[]{"Δ", "Β", "С", "D", "Ξ", "ᚫ", "Ǥ", "Η", "I", "Ј", "Ƙ", "Ꮣ", "Μ", "Ŋ", "Ѳ", "♇", "Θ", "Ɍ", "⟆", "Γ", "Ʊ", "Ɣ", "w", "χ", "Ψ", "Z", "α", "β", "ϲ", "δ", "ε", "ẜ", "ϑ", "հ", "ι", "յ", "Κ", "ℓ", "ʍ", "ƞ", "ɸ", "⅊", "θ", "ʀ", "ៜ", "τ", "υ", "⋎", "w", "ϰ", "ψ", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"𐀁", "β", "Ɔ", "Ɖ", "Є", "Ғ", "Ǥ", "Ħ", "Ɩ", "Ĵ", "Ƙ", "˩", "𐌼", "И", "Ѳ", "Ƥ", "Ǫ", "Я", "Ƨ", "Ƭ", "Ʋ", "Ѵ", "Ɯ", "χ", "Ƴ", "Ƶ", "α", "в", "c", "∂", "ɛ", "ғ", "ɢ", "н", "ι", "ʝ", "κ", "ℓ", "м", "и", "σ", "ρ", "զ", "я", "ƨ", "т", "ʋ", "ѵ", "ω", "ϰ", "ʏ", "ʓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Á", "B", "Č", "Ď", "É", "F", "Ġ", "Ĥ", "I", "J", "K", "Ĺ", "M", "Ń", "Ó", "P", "Q", "Ŕ", "Ś", "Ť", "Ú", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "Ŵ", "X", "Ŷ", "Ź", "á", "b", "ć", "ď", "È", "f", "ġ", "ĥ", "Ì", "j", "k", "l", "m", "ń", "ő", "p", "q", "ŕ", "ś", "ť", "ú", "v", "ŵ", "x", "ý", "ź", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ａ", "Ｂ", "Ｃ", "Ｄ", "Ｅ", "Ｆ", "Ｇ", "Ｈ", "Ｉ", "Ｊ", "Ｋ", "Ｌ", "Ｍ", "Ｎ", "Ｏ", "Ｐ", "Ｑ", "Ｒ", "Ｓ", "Ｔ", "Ｕ", "Ｖ", "Ｗ", "Ｘ", "Ｙ", "Ｚ", "ａ", "ｂ", "ｃ", "ｄ", "ｅ", "ｆ", "ｇ", "ｈ", "ｉ", "ｊ", "ｋ", "ｌ", "ｍ", "ｎ", "ｏ", "ｐ", "ｑ", "ｒ", "ｓ", "ｔ", "ｕ", "ｖ", "ｗ", "ｘ", "ｙ", "ｚ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));

        fancy_txt_list.add(new Font(new String[]{"ค", "ƅ", "ϲ", "Ԁ", "є", "Ŧ", "g", "ђ", "เ", "ן", "к", "l", "៣", "ภ", "๏", "ק", "ợ", "г", "ร", "t", "ย", "ṽ", "ฬ", "ж", "⑂", "z", "ค", "ƅ", "ϲ", "Ԁ", "є", "Ŧ", "g", "ђ", "เ", "ן", "к", "l", "៣", "ภ", "๏", "ק", "ợ", "г", "ร", "t", "ย", "ṽ", "ฬ", "ж", "⑂", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ꭿ", "ℬ", "ℂ", "ⅅ", "ℰ", "ℱ", "Ꮆ", "ℋ", "ℐ", "Ꭻ", "Ꮶ", "ℒ", "ℳ", "ℕ", "Ꮎ", "ℙ", "ℚ", "ℛ", "Ѕ", "𝒯", "U", "Ꮙ", "Ꮗ", "X", "Ꮍ", "ℤ", "Ꭿ", "ℬ", "ℂ", "ⅅ", "ℰ", "ℱ", "Ꮆ", "ℋ", "ℐ", "Ꭻ", "Ꮶ", "ℒ", "ℳ", "ℕ", "Ꮎ", "ℙ", "ℚ", "ℛ", "Ѕ", "𝒯", "U", "Ꮙ", "Ꮗ", "X", "Ꮍ", "ℤ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"α", "в", "¢", "∂", "є", "ƒ", "g", "н", "ι", "נ", "к", "ℓ", "м", "η", "σ", "ρ", "q", "я", "ѕ", "т", "υ", "ν", "ω", "χ", "у", "z", "α", "в", "¢", "∂", "є", "ƒ", "g", "н", "ι", "נ", "к", "ℓ", "м", "η", "σ", "ρ", "q", "я", "ѕ", "т", "υ", "ν", "ω", "χ", "у", "z", "0", "ı", ExifInterface.GPS_MEASUREMENT_2D, "ʓ", "4", "5", "б", "ך", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Λ", "ß", "Ƈ", "D", "Ɛ", "F", "Ɠ", "Ĥ", "Ī", "Ĵ", "Ҡ", "Ŀ", "M", "И", "Ꮎ", "Ṗ", "Ꮕ", "Ŕ", ExifInterface.LATITUDE_SOUTH, "Ŧ", "Ʊ", "√", "Ꮿ", "Ӿ", "Y", "Z", "Λ", "ß", "Ƈ", "D", "Ɛ", "F", "Ɠ", "Ĥ", "Ī", "Ĵ", "Ҡ", "Ŀ", "M", "И", "Ꮎ", "Ṗ", "Ꮕ", "Ŕ", ExifInterface.LATITUDE_SOUTH, "Ŧ", "Ʊ", "√", "Ꮿ", "Ӿ", "Y", "Z", "0", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"}));
        fancy_txt_list.add(new Font(new String[]{"ά", "в", "ς", "đ", "έ", "ғ", "ģ", "ħ", "ί", "ј", "ķ", "Ļ", "м", "ή", "ό", "ρ", "q", "ŕ", "ş", "ţ", "ù", "ν", "ώ", "x", "ч", "ž", "ά", "в", "ς", "đ", "έ", "ғ", "ģ", "ħ", "ί", "ј", "ķ", "Ļ", "м", "ή", "ό", "ρ", "q", "ŕ", "ş", "ţ", "ù", "ν", "ώ", "x", "ч", "ž", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Λ", "Б", "Ͼ", "Ð", "Ξ", "Ŧ", "G", "H", "ł", "J", "К", "Ł", "M", "Л", "Ф", "P", "Ǫ", "Я", ExifInterface.LATITUDE_SOUTH, "Т", "U", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "Ш", "Ж", "Џ", "Z", "Λ", "Б", "Ͼ", "Ð", "Ξ", "Ŧ", "G", "H", "ł", "J", "К", "Ł", "M", "Л", "Ф", "P", "Ǫ", "Я", ExifInterface.LATITUDE_SOUTH, "Т", "U", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "Ш", "Ж", "Џ", "Z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"[̲̅a̲̅]", "[̲̅b̲̅]", "[̲̅c̲̅]", "[̲̅d̲̅]", "[̲̅e̲̅]", "[̲̅f̲̅]", "[̲̅g̲̅]", "[̲̅h̲̅]", "[̲̅i̲̅]", "[̲̅j̲̅]", "[̲̅k̲̅]", "[̲̅l̲̅]", "[̲̅m̲̅]", "[̲̅n̲̅]", "[̲̅o̲̅]", "[̲̅p̲̅]", "[̲̅q̲̅]", "[̲̅r̲̅]", "[̲̅s̲̅]", "[̲̅t̲̅]", "[̲̅u̲̅]", "[̲̅v̲̅]", "[̲̅w̲̅]", "[̲̅x̲̅]", "[̲̅y̲̅]", "[̲̅z̲̅]", "[̲̅a̲̅]", "[̲̅b̲̅]", "[̲̅c̲̅]", "[̲̅d̲̅]", "[̲̅e̲̅]", "[̲̅f̲̅]", "[̲̅g̲̅]", "[̲̅h̲̅]", "[̲̅i̲̅]", "[̲̅j̲̅]", "[̲̅k̲̅]", "[̲̅l̲̅]", "[̲̅m̲̅]", "[̲̅n̲̅]", "[̲̅o̲̅]", "[̲̅p̲̅]", "[̲̅q̲̅]", "[̲̅r̲̅]", "[̲̅s̲̅]", "[̲̅t̲̅]", "[̲̅u̲̅]", "[̲̅v̲̅]", "[̲̅w̲̅]", "[̲̅x̲̅]", "[̲̅y̲̅]", "[̲̅z̲̅]", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ã̰", "b̰̃", "c̰̃", "d̰̃", "ḛ̃", "f̰̃", "g̰̃", "h̰̃", "ḭ̃", "j̰̃", "k̰̃", "l̰̃", "m̰̃", "ñ̰", "õ̰", "p̰̃", "q̰̃", "r̰̃", "s̰̃", "t̰̃", "ṵ̃", "ṽ̰", "w̰̃", "x̰̃", "ỹ̰", "z̰̃", "ã̰", "b̰̃", "c̰̃", "d̰̃", "ḛ̃", "f̰̃", "g̰̃", "h̰̃", "ḭ̃", "j̰̃", "k̰̃", "l̰̃", "m̰̃", "ñ̰", "õ̰", "p̰̃", "q̰̃", "r̰̃", "s̰̃", "t̰̃", "ṵ̃", "ṽ̰", "w̰̃", "x̰̃", "ỹ̰", "z̰̃", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"⒜", "⒝", "⒞", "⒟", "⒠", "⒡", "⒢", "⒣", "⒤", "⒥", "⒦", "⒧", "⒨", "⒩", "⒪", "⒫", "⒬", "⒭", "⒮", "⒯", "⒰", "⒱", "⒲", "⒳", "⒴", "⒵", "⒜", "⒝", "⒞", "⒟", "⒠", "⒡", "⒢", "⒣", "⒤", "⒥", "⒦", "⒧", "⒨", "⒩", "⒪", "⒫", "⒬", "⒭", "⒮", "⒯", "⒰", "⒱", "⒲", "⒳", "⒴", "⒵", "0", "⑴", "⑵", "⑶", "⑷", "⑸", "⑹", "⑺", "⑻", "⑼"}));
        fancy_txt_list.add(new Font(new String[]{"A͎", "B͎", "C͎", "D͎", "E͎", "F͎", "G͎", "H͎", "I͎", "J͎", "K͎", "L͎", "M͎", "N͎", "O͎", "P͎", "Q͎", "R͎", "S͎", "T͎", "U͎", "V͎", "W͎", "X͎", "Y͎", "Z͎", "a͎", "b͎", "c͎", "d͎", "e͎", "f͎", "g͎", "h͎", "i͎", "j͎", "k͎", "l͎", "m͎", "n͎", "o͎", "p͎", "q͎", "r͎", "s͎", "t͎", "u͎", "v͎", "w͎", "x͎", "y͎", "z͎", "0͎", "1͎", "2͎", "3͎", "4͎", "5͎", "6͎", "7͎", "8͎", "9͎"}));

        fancy_txt_list.add(new Font(new String[]{"ᵃ", "ᵇ", "ᶜ", "ᵈ", "ᵉ", "ᶠ", "ᵍ", "ʰ", "ⁱ", "ʲ", "ᵏ", "ˡ", "ᵐ", "ⁿ", "ᵒ", "ᵖ", "q", "ʳ", "ˢ", "ᵗ", "ᵘ", "ᵛ", "ʷ", "ˣ", "ʸ", "ᶻ", "ᵃ", "ᵇ", "ᶜ", "ᵈ", "ᵉ", "ᶠ", "ᵍ", "ʰ", "ⁱ", "ʲ", "ᵏ", "ˡ", "ᵐ", "ⁿ", "ᵒ", "ᵖ", "q", "ʳ", "ˢ", "ᵗ", "ᵘ", "ᵛ", "ʷ", "ˣ", "ʸ", "ᶻ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ል", "ጌ", "ር", "ዕ", "ቿ", "ቻ", "ኗ", "ዘ", "ጎ", "ጋ", "ጕ", "ረ", "ጠ", "ክ", "ዐ", "የ", "ዒ", "ዪ", "ነ", "ፕ", "ሁ", "ሀ", "ሠ", "ሸ", "ሃ", "ጊ", "ል", "ጌ", "ር", "ዕ", "ቿ", "ቻ", "ኗ", "ዘ", "ጎ", "ጋ", "ጕ", "ረ", "ጠ", "ክ", "ዐ", "የ", "ዒ", "ዪ", "ነ", "ፕ", "ሁ", "ሀ", "ሠ", "ሸ", "ሃ", "ጊ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ⱥ", "Ƀ", "Ȼ", "Đ", "Ɇ", "F", "Ǥ", "Ħ", "Ɨ", "Ɉ", "Ꝁ", "Ł", "M", "N", "Ø", "Ᵽ", "Ꝗ", "Ɍ", ExifInterface.LATITUDE_SOUTH, "Ŧ", "ᵾ", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, ExifInterface.LONGITUDE_WEST, "X", "Ɏ", "Ƶ", "Ⱥ", "Ƀ", "Ȼ", "Đ", "Ɇ", "F", "Ǥ", "Ħ", "Ɨ", "Ɉ", "Ꝁ", "Ł", "M", "N", "Ø", "Ᵽ", "Ꝗ", "Ɍ", ExifInterface.LATITUDE_SOUTH, "Ŧ", "ᵾ", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, ExifInterface.LONGITUDE_WEST, "X", "Ɏ", "Ƶ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"🅰", "🅱", "🅲", "🅳", "🅴", "🅵", "🅶", "🅷", "🅸", "🅹", "🅺", "🅻", "🅼", "🅽", "🅾", "🅿", "🆀", "🆁", "🆂", "🆃", "🆄", "🆅", "🆆", "🆇", "🆈", "🆉", "🅰", "🅱", "🅲", "🅳", "🅴", "🅵", "🅶", "🅷", "🅸", "🅹", "🅺", "🅻", "🅼", "🅽", "🅾", "🅿", "🆀", "🆁", "🆂", "🆃", "🆄", "🆅", "🆆", "🆇", "🆈", "🆉", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"₳", "฿", "₵", "Đ", "Ɇ", "₣", "₲", "Ⱨ", "ł", "J", "₭", "Ⱡ", "₥", "₦", "Ø", "₱", "Q", "Ɽ", "₴", "₮", "Ʉ", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "₩", "Ӿ", "Ɏ", "Ⱬ", "₳", "฿", "₵", "Đ", "Ɇ", "₣", "₲", "Ⱨ", "ł", "J", "₭", "Ⱡ", "₥", "₦", "Ø", "₱", "Q", "Ɽ", "₴", "₮", "Ʉ", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "₩", "Ӿ", "Ɏ", "Ⱬ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"【A】", "【B】", "【C】", "【D】", "【E】", "【F】", "【G】", "【H】", "【I】", "【J】", "【K】", "【L】", "【M】", "【N】", "【O】", "【P】", "【Q】", "【R】", "【S】", "【T】", "【U】", "【V】", "【W】", "【X】", "【Y】", "【Z】", "【a】", "【b】", "【c】", "【d】", "【e】", "【f】", "【g】", "【h】", "【i】", "【j】", "【k】", "【l】", "【m】", "【n】", "【o】", "【p】", "【q】", "【r】", "【s】", "【t】", "【u】", "【v】", "【w】", "【x】", "【y】", "【z】", "【0】", "【1】", "【2】", "【3】", "【4】", "【5】", "【6】", "【7】", "【8】", "【9】"}));
        fancy_txt_list.add(new Font(new String[]{"『A』", "『B』", "『C』", "『D』", "『E』", "『F』", "『G』", "『H』", "『I』", "『J』", "『K』", "『L』", "『M』", "『N』", "『O』", "『P』", "『Q』", "『R』", "『S』", "『T』", "『U』", "『V』", "『W』", "『X』", "『Y』", "『Z』", "『a』", "『b』", "『c』", "『d』", "『e』", "『f』", "『g』", "『h』", "『i』", "『j』", "『k』", "『l』", "『m』", "『n』", "『o』", "『p』", "『q』", "『r』", "『s』", "『t』", "『u』", "『v』", "『w』", "『x』", "『y』", "『z』", "『0』", "『1』", "『2』", "『3』", "『4』", "『5』", "『6』", "『7』", "『8』", "『9』"}));
        fancy_txt_list.add(new Font(new String[]{"A҉", "B҉", "C҉", "D҉", "E҉", "F҉", "G҉", "H҉", "I҉", "J҉", "K҉", "L҉", "M҉", "N҉", "O҉", "P҉", "Q҉", "R҉", "S҉", "T҉", "U҉", "V҉", "W҉", "X҉", "Y҉", "Z҉", "a҉", "b҉", "c҉", "d҉", "e҉", "f҉", "g҉", "h҉", "i҉", "j҉", "k҉", "l҉", "m҉", "n҉", "o҉", "p҉", "q҉", "r҉", "s҉", "t҉", "u҉", "v҉", "w҉", "x҉", "y҉", "z҉", "0҉", "1҉", "2҉", "3҉", "4҉", "5҉", "6҉", "7҉", "8҉", "9҉"}));

        fancy_txt_list.add(new Font(new String[]{"Aͦ", "Bͦ", "Cͦ", "Dͦ", "Eͦ", "Fͦ", "Gͦ", "Hͦ", "Iͦ", "Jͦ", "Kͦ", "Lͦ", "Mͦ", "Nͦ", "Oͦ", "Pͦ", "Qͦ", "Rͦ", "Sͦ", "Tͦ", "Uͦ", "Vͦ", "Wͦ", "Xͦ", "Yͦ", "Zͦ", "aͦ", "bͦ", "cͦ", "dͦ", "eͦ", "fͦ", "gͦ", "hͦ", "iͦ", "jͦ", "kͦ", "lͦ", "mͦ", "nͦ", "oͦ", "pͦ", "qͦ", "rͦ", "sͦ", "tͦ", "uͦ", "vͦ", "wͦ", "xͦ", "yͦ", "zͦ", "0ͦ", "1ͦ", "2ͦ", "3ͦ", "4ͦ", "5ͦ", "6ͦ", "7ͦ", "8ͦ", "9ͦ"}));
        fancy_txt_list.add(new Font(new String[]{"A͡", "B͡", "C͡", "D͡", "E͡", "F͡", "G͡", "H͡", "I͡", "J͡", "K͡", "L͡", "M͡", "N͡", "O͡", "P͡", "Q͡", "R͡", "S͡", "T͡", "U͡", "V͡", "W͡", "X͡", "Y͡", "Z͡", "A͡", "B͡", "C͡", "D͡", "E͡", "F͡", "G͡", "H͡", "I͡", "J͡", "K͡", "L͡", "M͡", "N͡", "O͡", "P͡", "Q͡", "R͡", "S͡", "T͡", "U͡", "V͡", "W͡", "X͡", "Y͡", "Z͡", "0͡", "1͡", "2͡", "3͡", "4͡", "5͡", "6͡", "7͡", "8͡", "9͡"}));
        fancy_txt_list.add(new Font(new String[]{"A⃕", "B⃕", "C⃕", "D⃕", "E⃕", "F⃕", "G⃕", "H⃕", "I⃕", "J⃕", "K⃕", "L⃕", "M⃕", "N⃕", "O⃕", "P⃕", "Q⃕", "R⃕", "S⃕", "T⃕", "U⃕", "V⃕", "W⃕", "X⃕", "Y⃕", "Z⃕", "A⃕", "B⃕", "C⃕", "D⃕", "E⃕", "F⃕", "G⃕", "H⃕", "I⃕", "J⃕", "K⃕", "L⃕", "M⃕", "N⃕", "O⃕", "P⃕", "Q⃕", "R⃕", "S⃕", "T⃕", "U⃕", "V⃕", "W⃕", "X⃕", "Y⃕", "Z⃕", "0⃕", "1⃕", "2⃕", "3⃕", "4⃕", "5⃕", "6⃕", "7⃕", "8⃕", "9⃕"}));
        fancy_txt_list.add(new Font(new String[]{"A͛", "B͛", "C͛", "D͛", "E͛", "F͛", "G͛", "H͛", "I͛", "J͛", "K͛", "L͛", "M͛", "N͛", "O͛", "P͛", "Q͛", "R͛", "S͛", "T͛", "U͛", "V͛", "W͛", "X͛", "Y͛", "Z͛", "A͛", "B͛", "C͛", "D͛", "E͛", "F͛", "G͛", "H͛", "I͛", "J͛", "K͛", "L͛", "M͛", "N͛", "O͛", "P͛", "Q͛", "R͛", "S͛", "T͛", "U͛", "V͛", "W͛", "X͛", "Y͛", "Z͛", "0͛", "1͛", "2͛", "3͛", "4͛", "5͛", "6͛", "7͛", "8͛", "9͛"}));
        fancy_txt_list.add(new Font(new String[]{"A͌", "B͌", "C͌", "D͌", "E͌", "F͌", "G͌", "H͌", "I͌", "J͌", "K͌", "L͌", "M͌", "N͌", "O͌", "P͌", "Q͌", "R͌", "S͌", "T͌", "U͌", "V͌", "W͌", "X͌", "Y͌", "Z͌", "A͌", "B͌", "C͌", "D͌", "E͌", "F͌", "G͌", "H͌", "I͌", "J͌", "K͌", "L͌", "M͌", "N͌", "O͌", "P͌", "Q͌", "R͌", "S͌", "T͌", "U͌", "V͌", "W͌", "X͌", "Y͌", "Z͌", "0͌", "1͌", "2͌", "3͌", "4͌", "5͌", "6͌", "7͌", "8͌", "9͌"}));
        fancy_txt_list.add(new Font(new String[]{"ᴬ", "ᴮ", "ᶜ", "ᴰ", "ᴱ", "ᶠ", "ᴳ", "ᴴ", "ᴵ", "ᴶ", "ᴷ", "ᴸ", "ᴹ", "ᴺ", "ᴼ", "ᴾ", "ᵟ", "ᴿ", "ˢ", "ᵀ", "ᵁ", "ᵛ", "ᵂ", "ˣ", "ᵞ", "ᶻ", "ᴬ", "ᴮ", "ᶜ", "ᴰ", "ᴱ", "ᶠ", "ᴳ", "ᴴ", "ᴵ", "ᴶ", "ᴷ", "ᴸ", "ᴹ", "ᴺ", "ᴼ", "ᴾ", "ᵟ", "ᴿ", "ˢ", "ᵀ", "ᵁ", "ᵛ", "ᵂ", "ˣ", "ᵞ", "ᶻ", "⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹"}));

        fancy_txt_list.add(new Font(new String[]{"α", "в", "c", "d", "є", "f", "g", "h", "í", "j", "k", "l", "m", "n", "σ", "p", "q", "r", "ѕ", "t", "u", "v", "w", "х", "ч", "z", "α", "в", "c", "d", "є", "f", "g", "h", "í", "j", "k", "l", "m", "n", "σ", "p", "q", "r", "ѕ", "t", "u", "v", "w", "х", "ч", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ѧ", "ɞ", "ċ", "Ԁ", "є", "ғ", "ɢ", "һ", "ı", "j", "ҡ", "ʟ", "ṃ", "ṅ", "ȏ", "ƿ", "զ", "я", "ṡ", "ṭ", "ȗ", "ṿ", "ẇ", "×", "ʏ", "ẓ", "ѧ", "ɞ", "ċ", "Ԁ", "є", "ғ", "ɢ", "һ", "ı", "j", "ҡ", "ʟ", "ṃ", "ṅ", "ȏ", "ƿ", "զ", "я", "ṡ", "ṭ", "ȗ", "ṿ", "ẇ", "×", "ʏ", "ẓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ꭺ", "b", "Ꮯ", "Ꭰ", "Ꭼ", "f", "Ꮆ", "h", "Ꭵ", "j", "Ꮶ", "Ꮮ", "m", "Ꮑ", "Ꮎ", "Ꮲ", "q", "Ꮢ", "s", "Ҭ", "u", "Ꮙ", "Ꮃ", "x", "Ꮍ", "Ꮓ", "Ꭺ", "b", "Ꮯ", "Ꭰ", "Ꭼ", "f", "Ꮆ", "h", "Ꭵ", "j", "Ꮶ", "Ꮮ", "m", "Ꮑ", "Ꮎ", "Ꮲ", "q", "Ꮢ", "s", "Ҭ", "u", "Ꮙ", "Ꮃ", "x", "Ꮍ", "Ꮓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ɑ", "ҍ", "ϲ", "ժ", "ҽ", "ƒ", "ց", "հ", "í", "յ", "Ƙ", "Ӏ", "ʍ", "ղ", "օ", "Թ", "զ", "ɾ", "Տ", "Ե", "մ", "ѵ", "ա", "×", "վ", "Հ", "ɑ", "ҍ", "ϲ", "ժ", "ҽ", "ƒ", "ց", "հ", "í", "յ", "Ƙ", "Ӏ", "ʍ", "ղ", "օ", "Թ", "զ", "ɾ", "Տ", "Ե", "մ", "ѵ", "ա", "×", "վ", "Հ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ą", "ც", "ƈ", "ɖ", "ɛ", "ʄ", "ɠ", "ɧ", "ı", "ʝ", "ƙ", "Ɩ", "ɱ", "ŋ", "ơ", "℘", "զ", "ཞ", "ʂ", "ɬ", "ų", "۷", "ῳ", "ҳ", "ყ", "ʑ", "ą", "ც", "ƈ", "ɖ", "ɛ", "ʄ", "ɠ", "ɧ", "ı", "ʝ", "ƙ", "Ɩ", "ɱ", "ŋ", "ơ", "℘", "զ", "ཞ", "ʂ", "ɬ", "ų", "۷", "ῳ", "ҳ", "ყ", "ʑ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));


        fancy_txt_list.add(new Font(new String[]{"å", "ɞ", "ċ", "Ԁ", "є", "ғ", "ɢ", "һ", "ı", "j", "ҡ", "Ŀ", "ṃ", "ṅ", "ọ", "ƿ", "q", "ŗ", "ṡ", "ṭ", "ȗ", "ṿ", "ẇ", "×", "ʏ", "ẓ", "å", "ɞ", "ċ", "Ԁ", "є", "ғ", "ɢ", "һ", "ı", "j", "ҡ", "Ŀ", "ṃ", "ṅ", "ọ", "ƿ", "q", "ŗ", "ṡ", "ṭ", "ȗ", "ṿ", "ẇ", "×", "ʏ", "ẓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A͟͟", "B͟͟", "C͟͟", "D͟͟", "E͟͟", "F͟͟", "G͟͟", "H͟͟", "I͟͟", "J͟͟", "K͟͟", "L͟͟", "M͟͟", "N͟͟", "O͟͟", "P͟͟", "Q͟͟", "R͟͟", "S͟͟", "T͟͟", "U͟͟", "V͟͟", "W͟͟", "X͟͟", "Y͟͟", "Z͟͟", "A͟͟", "B͟͟", "C͟͟", "D͟͟", "E͟͟", "F͟͟", "G͟͟", "H͟͟", "I͟͟", "J͟͟", "K͟͟", "L͟͟", "M͟͟", "N͟͟", "O͟͟", "P͟͟", "Q͟͟", "R͟͟", "S͟͟", "T͟͟", "U͟͟", "V͟͟", "W͟͟", "X͟͟", "Y͟͟", "Z͟͟", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ḁͦ", "B̥ͦ", "C̥ͦ", "D̥ͦ", "E̥ͦ", "F̥ͦ", "G̥ͦ", "H̥ͦ", "I̥ͦ", "J̥ͦ", "K̥ͦ", "L̥ͦ", "M̥ͦ", "N̥ͦ", "O̥ͦ", "P̥ͦ", "Q̥ͦ", "R̥ͦ", "S̥ͦ", "T̥ͦ", "U̥ͦ", "V̥ͦ", "W̥ͦ", "X̥ͦ", "Y̥ͦ", "Z̥ͦ", "Ḁͦ", "B̥ͦ", "C̥ͦ", "D̥ͦ", "E̥ͦ", "F̥ͦ", "G̥ͦ", "H̥ͦ", "I̥ͦ", "J̥ͦ", "K̥ͦ", "L̥ͦ", "M̥ͦ", "N̥ͦ", "O̥ͦ", "P̥ͦ", "Q̥ͦ", "R̥ͦ", "S̥ͦ", "T̥ͦ", "U̥ͦ", "V̥ͦ", "W̥ͦ", "X̥ͦ", "Y̥ͦ", "Z̥ͦ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A̬̤̯", "B̬̤̯", "C̬̤̯", "D̬̤̯", "E̬̤̯", "F̬̤̯", "G̬̤̯", "H̬̤̯", "I̬̤̯", "J̬̤̯", "K̬̤̯", "L̬̤̯", "M̬̤̯", "N̬̤̯", "O̬̤̯", "P̬̤̯", "Q̬̤̯", "R̬̤̯", "S̬̤̯", "T̬̤̯", "U̬̤̯", "V̬̤̯", "W̬̤̯", "X̬̤̯", "Y̬̤̯", "Z̬̤̯", "A̬̤̯", "B̬̤̯", "C̬̤̯", "D̬̤̯", "E̬̤̯", "F̬̤̯", "G̬̤̯", "H̬̤̯", "I̬̤̯", "J̬̤̯", "K̬̤̯", "L̬̤̯", "M̬̤̯", "N̬̤̯", "O̬̤̯", "P̬̤̯", "Q̬̤̯", "R̬̤̯", "S̬̤̯", "T̬̤̯", "U̬̤̯", "V̬̤̯", "W̬̤̯", "X̬̤̯", "Y̬̤̯", "Z̬̤̯", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ᗛ", "ᗷ", "Č", "Đ", "ℨ", "F", "Ꮆ", "ℌ", "Ĭ", "ℑ", "Ƙ", "Ĺ", "Ṁ", "Ŋ", "Ɵ", "Ƥ", "Q", "Ʀ", "Ṩ", "Ṫ", "Ự", "Ʋ", "ϖ", "Ẍ", "Ƴ", "Ƶ", "ᗛ", "ᗷ", "Č", "Đ", "ℨ", "F", "Ꮆ", "ℌ", "Ĭ", "ℑ", "Ƙ", "Ĺ", "Ṁ", "Ŋ", "Ɵ", "Ƥ", "Q", "Ʀ", "Ṩ", "Ṫ", "Ự", "Ʋ", "ϖ", "Ẍ", "Ƴ", "Ƶ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ค", "๒", "ς", "๔", "є", "Ŧ", "g", "♄", "ί", "j", "ƙ", "l", "๓", "ภ", "๏", "Թ", "ợ", "г", "ร", "t", "ย", "v", "ฬ", "x", "y", "z", "ค", "๒", "ς", "๔", "є", "Ŧ", "g", "♄", "ί", "j", "ƙ", "l", "๓", "ภ", "๏", "Թ", "ợ", "г", "ร", "t", "ย", "v", "ฬ", "x", "y", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ᴀ", "ʙ", "ᴄ", "ᴅ", "ᴇ", "ғ", "ɢ", "ʜ", "ɪ", "ᴊ", "ᴋ", "ʟ", "ᴍ", "ɴ", "ᴏ", "ᴘ", "ǫ", "ʀ", "s", "ᴛ", "ᴜ", "ᴠ", "ᴡ", "x", "ʏ", "ᴢ", "ᴀ", "ʙ", "ᴄ", "ᴅ", "ᴇ", "ғ", "ɢ", "ʜ", "ɪ", "ᴊ", "ᴋ", "ʟ", "ᴍ", "ɴ", "ᴏ", "ᴘ", "ǫ", "ʀ", "s", "ᴛ", "ᴜ", "ᴠ", "ᴡ", "x", "ʏ", "ᴢ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ɑ", "ɓ", "ɕ", "Ƌ", "ɛ", "ʄ", "ɠ", "ɦ", "ɨ", "ϳ", "ƙ", "ƚ", "ɱ", "ɲ", "ɵ", "ϼ", "ɋ", "ɾ", "ʂ", "ʈ", "ự", "ʋ", "ϣ", "ӝ", "џ", "ʑ", "ɑ", "ɓ", "ɕ", "Ƌ", "ɛ", "ʄ", "ɠ", "ɦ", "ɨ", "ϳ", "ƙ", "ƚ", "ɱ", "ɲ", "ɵ", "ϼ", "ɋ", "ɾ", "ʂ", "ʈ", "ự", "ʋ", "ϣ", "ӝ", "џ", "ʑ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ɑ", "ɓ", "ƈ", "ɗ", "ꍟ", "ʄ", "ɠ", "ɧ", "ꀤ", "ꀭ", "ƙ", "ɭ", "ɱ", "ɳ", "ꂦ", "ƥ", "ǫ", "ɽ", "ʂ", "ʈ", "ʋ", "ᐯ", "ɯ", "ꊼ", "ɣ", "ʐ", "ɑ", "ɓ", "ƈ", "ɗ", "ꍟ", "ʄ", "ɠ", "ɧ", "ꀤ", "ꀭ", "ƙ", "ɭ", "ɱ", "ɳ", "ꂦ", "ƥ", "ǫ", "ɽ", "ʂ", "ʈ", "ʋ", "ᐯ", "ɯ", "ꊼ", "ɣ", "ʐ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "Ꮖ", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "Ꮖ", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"∀", "B", "Ɔ", "p", "Ǝ", "Ⅎ", "פ", "H", "I", "ſ", "ʞ", "˥", ExifInterface.LONGITUDE_WEST, "N", "O", "Ԁ", "b", "ɹ", ExifInterface.LATITUDE_SOUTH, "ʇ", "∩", "Λ", "M", "χ", "⅄", "Z", "ɐ", "q", "ɔ", "p", "ǝ", "ɟ", "ƃ", "ɥ", "ı", "ɾ", "ʞ", "ʃ", "ɯ", "u", "o", "d", "b", "ɹ", "s", "ʇ", "n", "ʌ", "ʍ", "x", "ʎ", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, "Ɛ", "4", "5", "9", "7", "8", "6"}));

        fancy_txt_list.add(new Font(new String[]{"λ", "B", "₡", "Ð", ExifInterface.LONGITUDE_EAST, "₣", "G", "Ҥ", "ł", "J", "ƙ", "Ł", "M", "₦", "0", "P", "Q", "Ʀ", "$", "₸", "U", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "₩", "X", "¥", "Z", "λ", "B", "₡", "Ð", ExifInterface.LONGITUDE_EAST, "₣", "G", "Ҥ", "ł", "J", "ƙ", "Ł", "M", "₦", "Ø", "P", "Q", "Ʀ", "$", "₸", "U", ExifInterface.GPS_MEASUREMENT_INTERRUPTED, "₩", "X", "¥", "Z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "𐀀", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "𐀀", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A͠", "B͠", "C͠", "D͠", "E͠", "F͠", "G͠", "H͠", "I͠", "J͠", "K͠", "L͠", "M͠", "N͠", "O͠", "P͠", "Q͠", "R͠", "S͠", "T͠", "U͠", "V͠", "W͠", "X͠", "Y͠", "Z͠", "a͠", "b͠", "c͠", "d͠", "e͠", "f͠", "g͠", "h͠", "i͠", "j͠", "k͠", "l͠", "m͠", "n͠", "o͠", "p͠", "q͠", "r͠", "s͠", "t͠", "u͠", "v͠", "w͠", "x͠", "y͠", "z͠", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A͓̽", "B͓̽", "C͓̽", "D͓̽", "E͓̽", "F͓̽", "G͓̽", "H͓̽", "I͓̽", "J͓̽", "K͓̽", "L͓̽", "M͓̽", "N͓̽", "O͓̽", "P͓̽", "Q͓̽", "R͓̽", "S͓̽", "T͓̽", "U͓̽", "V͓̽", "W͓̽", "X͓̽", "Y͓̽", "Z͓̽", "a͓̽", "b͓̽", "c͓̽", "d͓̽", "e͓̽", "f͓̽", "g͓̽", "h͓̽", "i͓̽", "j͓̽", "k͓̽", "l͓̽", "m͓̽", "n͓̽", "o͓̽", "p͓̽", "q͓̽", "r͓̽", "s͓̽", "t͓̽", "u͓̽", "v͓̽", "w͓̽", "x͓̽", "y͓̽", "z͓̽", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A͎", "B͎", "C͎", "D͎", "E͎", "F͎", "G͎", "H͎", "I͎", "J͎", "K͎", "L͎", "M͎", "N͎", "O͎", "P͎", "Q͎", "R͎", "S͎", "T͎", "U͎", "V͎", "W͎", "X͎", "Y͎", "Z͎", "a͎", "b͎", "c͎", "d͎", "e͎", "f͎", "g͎", "h͎", "i͎", "j͎", "k͎", "l͎", "m͎", "n͎", "o͎", "p͎", "q͎", "r͎", "s͎", "t͎", "u͎", "v͎", "w͎", "x͎", "y͎", "z͎", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A⃘", "B⃘", "C⃘", "D⃘", "E⃘", "F⃘", "G⃘", "H⃘", "I⃘", "J⃘", "K⃘", "L⃘", "M⃘", "N⃘", "O⃘", "P⃘", "Q⃘", "R⃘", "S⃘", "T⃘", "U⃘", "V⃘", "W⃘", "X⃘", "Y⃘", "Z⃘", "a⃘", "b⃘", "c⃘", "d⃘", "e⃘", "f⃘", "g⃘", "h⃘", "i⃘", "j⃘", "k⃘", "l⃘", "m⃘", "n⃘", "o⃘", "p⃘", "q⃘", "r⃘", "s⃘", "t⃘", "u⃘", "v⃘", "w⃘", "x⃘", "y⃘", "z⃘", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ѧ", "♭", "¢", "∂", "℮", "ḟ", "ℊ", "ℌ", "ʝ", "ї", "к", "ℓ", "м", "η", "◎", "℘", "ⓠ", "ґ", "﹩", "†", "ʊ", "ṽ", "ẘ", "ϰ", "¥", "ẕ", "Ѧ", "♭", "¢", "∂", "℮", "ḟ", "ℊ", "ℌ", "ї", "ʝ", "к", "ℓ", "м", "η", "◎", "℘", "ⓠ", "ґ", "﹩", "†", "ʊ", "ṽ", "ẘ", "ϰ", "¥", "ẕ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"α", "ɓ", "ɕ", "δ", "ε", "ƒ", "ɡ", "հ", "ί", "յ", "Ƙ", "ʆ", "ʍ", "η", "σ", "Թ", "զ", "ɾ", "န", "ϯ", "մ", "ѵ", "ϖ", "X", "ψ", "Հ", "α", "ɓ", "ɕ", "δ", "ε", "ƒ", "ɡ", "հ", "ί", "յ", "Ƙ", "ʆ", "ʍ", "η", "σ", "Թ", "զ", "ɾ", "န", "ϯ", "մ", "ѵ", "ϖ", "X", "ψ", "Հ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ศ", "๖", "໒", "อ", "ཛ", "f", "g", "ཏ", "ར", "j", "K", "ʆ", "ฅ", "ས", "๑", "♇", "q", "ཞ", "ຮ", "₮", "ມ", "v", "ཡ", "×", "ƴ", "ƶ", "ศ", "๖", "໒", "อ", "ཛ", "f", "g", "ཏ", "ར", "j", "K", "ʆ", "ฅ", "ས", "๑", "♇", "q", "ཞ", "ຮ", "₮", "ມ", "v", "ཡ", "×", "ƴ", "ƶ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A̸͟͞", "B̸͟͞", "C̸͟͞", "D̸͟͞", "E̸͟͞", "F̸͟͞", "G̸͟͞", "H̸͟͞", "I̸͟͞", "J̸͟͞", "K̸͟͞", "L̸͟͞", "M̸͟͞", "N̸͟͞", "O̸͟͞", "P̸͟͞", "Q̸͟͞", "R̸͟͞", "S̸͟͞", "T̸͟͞", "U̸͟͞", "V̸͟͞", "W̸͟͞", "X̸͟͞", "Y̸͟͞", "Z̸͟͞", "a̸͟͞", "b̸͟͞", "c̸͟͞", "d̸͟͞", "e̸͟͞", "f̸͟͞", "g̸͟͞", "h̸͟͞", "i̸͟͞", "j̸͟͞", "k̸͟͞", "l̸͟͞", "m̸͟͞", "n̸͟͞", "o̸͟͞", "p̸͟͞", "q̸͟͞", "r̸͟͞", "s̸͟͞", "t̸͟͞", "u̸͟͞", "v̸͟͞", "w̸͟͞", "x̸͟͞", "y̸͟͞", "z̸͟͞", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ѧ", "ɞ", "ċ", "Ԁ", "є", "ғ", "ɢ", "һ", "ı", "j", "ҡ", "ʟ", "ṃ", "ṅ", "ȏ", "ƿ", "զ", "я", "ṡ", "ṭ", "ȗ", "ṿ", "ẇ", "×", "ʏ", "ẓ", "ѧ", "ɞ", "ċ", "Ԁ", "є", "ғ", "ɢ", "һ", "ı", "j", "ҡ", "ʟ", "ṃ", "ṅ", "ȏ", "ƿ", "զ", "я", "ṡ", "ṭ", "ȗ", "ṿ", "ẇ", "×", "ʏ", "ẓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ﾑ", "乃", "c", "d", "乇", "ｷ", "g", "ん", "ﾉ", "ﾌ", "ズ", "ﾚ", "ʍ", "刀", "O", "ｱ", "q", "尺", "丂", "ｲ", "u", "√", "w", "ﾒ", "ﾘ", "乙", "ﾑ", "乃", "c", "d", "乇", "ｷ", "g", "ん", "ﾉ", "ﾌ", "ズ", "ﾚ", "ʍ", "刀", "O", "ｱ", "q", "尺", "丂", "ｲ", "u", "√", "w", "ﾒ", "ﾘ", "乙", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"@", "♭", "☾", "∂", "☰", "∱", "g", "♄", "ί", "j", "ƙ", "ᒪ", "ɱ", "n", "☯", "Թ", "q", "☈", "$", "☨", "☋", "✔", "ա", "x", "¥", "z", "@", "♭", "☾", "∂", "☰", "∱", "g", "♄", "ί", "j", "ƙ", "ᒪ", "ɱ", "n", "☯", "Թ", "q", "☈", "$", "☨", "☋", "✔", "ա", "x", "¥", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));

        fancy_txt_list.add(new Font(new String[]{"a̾", "b̾", "c̾", "d̾", "e̾", "f̾", "g̾", "h̾", "i̾", "j̾", "k̾", "l̾", "m̾", "n̾", "o̾", "p̾", "q̾", "r̾", "s̾", "t̾", "u̾", "v̾", "w̾", "x̾", "y̾", "z̾", "a̾", "b̾", "c̾", "d̾", "e̾", "f̾", "g̾", "h̾", "i̾", "j̾", "k̾", "l̾", "m̾", "n̾", "o̾", "p̾", "q̾", "r̾", "s̾", "t̾", "u̾", "v̾", "w̾", "x̾", "y̾", "z̾", "0̾", "1̾", "2̾", "3̾", "4̾", "5̾", "6̾", "7̾", "8̾", "9̾"}));
        fancy_txt_list.add(new Font(new String[]{"Ḁ", "B̥", "C̥", "D̥", "E̥", "F̥", "G̥", "H̥", "I̥", "J̥", "K̥", "L̥", "M̥", "N̥", "O̥", "P̥", "Q̥", "R̥", "S̥", "T̥", "U̥", "V̥", "W̥", "X̥", "Y̥", "Z̥", "ḁ", "b̥", "c̥", "d̥", "e̥", "f̥", "g̥", "h̥", "i̥", "j̥", "k̥", "l̥", "m̥", "n̥", "o̥", "p̥", "q̥", "r̥", "s̥", "t̥", "u̥", "v̥", "w̥", "x̥", "y̥", "z̥", "0̥", "1̥", "2̥", "3̥", "4̥", "5̥", "6̥", "7̥", "8̥", "9̥"}));
        fancy_txt_list.add(new Font(new String[]{"A̽", "B̽", "C̽", "D̽", "E̽", "F̽", "G̽", "H̽", "I̽", "J̽", "K̽", "L̽", "M̽", "N̽", "O̽", "P̽", "Q̽", "R̽", "S̽", "T̽", "U̽", "V̽", "W̽", "X̽", "Y̽", "Z̽", "a̽", "b̽", "c̽", "d̽", "e̽", "f̽", "g̽", "h̽", "i̽", "j̽", "k̽", "l̽", "m̽", "n̽", "o̽", "p̽", "q̽", "r̽", "s̽", "t̽", "u̽", "v̽", "w̽", "x̽", "y̽", "z̽", "0̽", "1̽", "2̽", "3̽", "4̽", "5̽", "6̽", "7̽", "8̽", "9̽"}));
        fancy_txt_list.add(new Font(new String[]{"A̳", "B̳", "C̳", "D̳", "E̳", "F̳", "G̳", "H̳", "I̳", "J̳", "K̳", "L̳", "M̳", "N̳", "O̳", "P̳", "Q̳", "R̳", "S̳", "T̳", "U̳", "V̳", "W̳", "X̳", "Y̳", "Z̳", "A̳", "B̳", "C̳", "D̳", "E̳", "F̳", "G̳", "H̳", "I̳", "J̳", "K̳", "L̳", "M̳", "N̳", "O̳", "P̳", "Q̳", "R̳", "S̳", "T̳", "U̳", "V̳", "W̳", "X̳", "Y̳", "Z̳", "0̳", "1̳", "2̳", "3̳", "4̳", "5̳", "6̳", "7̳", "8̳", "9̳"}));
        fancy_txt_list.add(new Font(new String[]{"Δ", "β", "C", "D", "Σ", "Ғ", "G", "H", "I", "J", "Ҝ", "L", "M", "Π", "Ω", "P", "Q", "R", ExifInterface.LATITUDE_SOUTH, "T", "U", "∇", "Ш", "X", "Ψ", "Z", "Δ", "β", "C", "D", "Σ", "Ғ", "G", "H", "I", "J", "Ҝ", "L", "M", "Π", "Ω", "P", "Q", "R", ExifInterface.LATITUDE_SOUTH, "T", "U", "∇", "Ш", "X", "Ψ", "Z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A⃣", "B⃣", "C⃣", "D⃣", "E⃣", "F⃣", "G⃣", "H⃣", "I⃣", "J⃣", "K⃣", "L⃣", "M⃣", "N⃣", "O⃣", "P⃣", "Q⃣", "R⃣", "S⃣", "T⃣", "U⃣", "V⃣", "W⃣", "X⃣", "Y⃣", "Z⃣", "A⃣", "B⃣", "C⃣", "D⃣", "E⃣", "F⃣", "G⃣", "H⃣", "I⃣", "J⃣", "K⃣", "L⃣", "M⃣", "N⃣", "O⃣", "P⃣", "Q⃣", "R⃣", "S⃣", "T⃣", "U⃣", "V⃣", "W⃣", "X⃣", "Y⃣", "Z⃣", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "⊺", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "⊺", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A͜͡", "B͜͡", "C͜͡", "D͜͡", "E͜͡", "F͜͡", "G͜͡", "H͜͡", "I͜͡", "J͜͡", "K͜͡", "L͜͡", "M͜͡", "N͜͡", "O͜͡", "P͜͡", "Q͜͡", "R͜͡", "S͜͡", "T͜͡", "U͜͡", "V͜͡", "W͜͡", "X͜͡", "Y͜͡", "Z͜͡", "A͜͡", "B͜͡", "C͜͡", "D͜͡", "E͜͡", "F͜͡", "G͜͡", "H͜͡", "I͜͡", "J͜͡", "K͜͡", "L͜͡", "M͜͡", "N͜͡", "O͜͡", "P͜͡", "Q͜͡", "R͜͡", "S͜͡", "T͜͡", "U͜͡", "V͜͡", "W͜͡", "X͜͡", "Y͜͡", "Z͜͡", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));


        fancy_txt_list.add(new Font(new String[]{"ᗩ", "ᕊ", "ᙅ", "ᖙ", "ᙓ", "ℱ", "ᘐ", "ᖺ", "ᓮ", "ᒎ", "Ḱ", "ᒪ", "ᙢ", "ᘉ", "ට", "ᖰ", "Ⴓ", "ᖇ", "ᔕ", "Ʈ", "ᕰ", "Ꮙ", "w", "ჯ", "૪", "ᔓ", "ᗩ", "ᕊ", "ᙅ", "ᖙ", "ᙓ", "ℱ", "ᘐ", "ᖺ", "ᓮ", "ᒎ", "Ḱ", "ᒪ", "ᙢ", "ᘉ", "ට", "ᖰ", "Ⴓ", "ᖇ", "ᔕ", "Ʈ", "ᕰ", "Ꮙ", "w", "ჯ", "૪", "ᔓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ꭿ", "Ᏸ", "Ꮳ", "Ꮄ", "Ꮛ", "Ꮀ", "Ꮆ", "Ꮒ", "i", "Ꮰ", "Ꮶ", "l", "m", "Ꮑ", "Ꮻ", "Ꮅ", "Ꮔ", "ᖇ", "Ꭶ", "Ꮏ", "Ꮜ", "Ꮙ", "Ꮿ", "ﾒ", "Ꭹ", "Ꮓ", "Ꭿ", "Ᏸ", "Ꮳ", "Ꮄ", "Ꮛ", "Ꮀ", "Ꮆ", "Ꮒ", "i", "Ꮰ", "Ꮶ", "l", "m", "Ꮑ", "Ꮻ", "Ꮅ", "Ꮔ", "ᖇ", "Ꭶ", "Ꮏ", "Ꮜ", "Ꮙ", "Ꮿ", "ﾒ", "Ꭹ", "Ꮓ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ᾰ", "♭", "ḉ", "ᖱ", "ḙ", "ḟ", "❡", "ℏ", "!", "♩", "к", "ℓ", "Պ", "ℵ", "✺", "℘", "ǭ", "Ի", "ṧ", "т", "ṳ", "ṽ", "ω", "✘", "⑂", "ℨ", "ᾰ", "♭", "ḉ", "ᖱ", "ḙ", "ḟ", "❡", "ℏ", "!", "♩", "к", "ℓ", "Պ", "ℵ", "✺", "℘", "ǭ", "Ի", "ṧ", "т", "ṳ", "ṽ", "ω", "✘", "⑂", "ℨ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"∀", "♭", "ḉ", "∂", "ε", "ḟ", "ℊ", "н", "ḯ", "ʝ", "ḱ", "ʟ", "ღ", "η", "ø", "℘", "ⓠ", "я", "﹩", "⊥", "ʊ", "ṽ", "ẘ", "✖", "¥", "ℨ", "∀", "♭", "ḉ", "∂", "ε", "ḟ", "ℊ", "н", "ḯ", "ʝ", "ḱ", "ʟ", "ღ", "η", "ø", "℘", "ⓠ", "я", "﹩", "⊥", "ʊ", "ṽ", "ẘ", "✖", "¥", "ℨ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A͚", "B͚", "C͚", "D͚", "E͚", "F͚", "G͚", "H͚", "I͚", "J͚", "K͚", "L͚", "M͚", "N͚", "O͚", "P͚", "Q͚", "R͚", "S͚", "T͚", "U͚", "V͚", "W͚", "X͚", "Y͚", "Z͚", "A͚", "B͚", "C͚", "D͚", "E͚", "F͚", "G͚", "H͚", "I͚", "J͚", "K͚", "L͚", "M͚", "N͚", "O͚", "P͚", "Q͚", "R͚", "S͚", "T͚", "U͚", "V͚", "W͚", "X͚", "Y͚", "Z͚", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"α", "ɓ", "ɕ", "δ", "ε", "ƒ", "ɡ", "հ", "ί", "յ", "Ƙ", "ʆ", "ʍ", "η", "σ", "Թ", "զ", "ɾ", "⑀", "ϯ", "մ", "ѵ", "ϖ", "x", "ψ", "Հ", "α", "ɓ", "ɕ", "δ", "ε", "ƒ", "ɡ", "հ", "ί", "յ", "Ƙ", "ʆ", "ʍ", "η", "σ", "Թ", "զ", "ɾ", "⑀", "ϯ", "մ", "ѵ", "ϖ", "x", "ψ", "Հ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ศ", "๖", "໒", "อ", "ཛ", "f", "g", "ཏ", "ར", "j", "K", "ʆ", "ฅ", "ས", "๑", "♇", "q", "ཞ", "ຮ", "₮", "ມ", "v", "ཡ", "×", "ƴ", "ƶ", "ศ", "๖", "໒", "อ", "ཛ", "f", "g", "ཏ", "ར", "j", "K", "ʆ", "ฅ", "ས", "๑", "♇", "q", "ཞ", "ຮ", "₮", "ມ", "v", "ཡ", "×", "ƴ", "ƶ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A̤̮", "B̤̮", "C̤̮", "D̤̮", "E̤̮", "F̤̮", "G̤̮", "H̤̮", "I̤̮", "J̤̮", "K̤̮", "L̤̮", "M̤̮", "N̤̮", "O̤̮", "P̤̮", "Q̤̮", "R̤̮", "S̤̮", "T̤̮", "Ṳ̮", "V̤̮", "W̤̮", "X̤̮", "Y̤̮", "Z̤̮", "A̤̮", "B̤̮", "C̤̮", "D̤̮", "E̤̮", "F̤̮", "G̤̮", "H̤̮", "I̤̮", "J̤̮", "K̤̮", "L̤̮", "M̤̮", "N̤̮", "O̤̮", "P̤̮", "Q̤̮", "R̤̮", "S̤̮", "T̤̮", "Ṳ̮", "V̤̮", "W̤̮", "X̤̮", "Y̤̮", "Z̤̮", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ꮨ", "Ᏸ", "Ꮸ", "Ꭰ", "Ꮛ", "F", "Ꮆ", "H", "I", "Ꮰ", "K", "L", "M", "Ꮑ", "Ꭷ", "Ꭾ", "Q", "R", "Ꭶ", "T", "U", "Ꮴ", "Ꮚ", "X", "Ꮍ", "Z", "Ꮨ", "Ᏸ", "Ꮸ", "Ꭰ", "Ꮛ", "F", "Ꮆ", "H", "I", "Ꮰ", "K", "L", "M", "Ꮑ", "Ꭷ", "Ꭾ", "Q", "R", "Ꭶ", "T", "U", "Ꮴ", "Ꮚ", "X", "Ꮍ", "Z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));

        fancy_txt_list.add(new Font(new String[]{"A̠", "B̠", "C̠", "D̠", "E̠", "F̠", "G̠", "H̠", "I̠", "J̠", "K̠", "L̠", "M̠", "N̠", "O̠", "P̠", "Q̠", "R̠", "S̠", "T̠", "U̠", "V̠", "W̠", "X̠", "Y̠", "Z̠", "a̠", "b̠", "c̠", "d̠", "e̠", "f̠", "g̠", "h̠", "i̠", "j̠", "k̠", "l̠", "m̠", "n̠", "o̠", "p̠", "q̠", "r̠", "s̠", "t̠", "u̠", "v̠", "w̠", "x̠", "y̠", "z̠", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ả", "B̉", "C̉", "D̉", "Ẻ", "F̉", "G̉", "H̉", "Ỉ", "J̉", "K̉", "L̉", "M̉", "N̉", "Ỏ", "P̉", "Q̉", "R̉", "S̉", "T̉", "Ủ", "V̉", "W̉", "X̉", "Ỷ", "Z̉", "ả", "b̉", "c̉", "d̉", "ẻ", "f̉", "g̉", "h̉", "ỉ", "j̉", "k̉", "l̉", "m̉", "n̉", "ỏ", "p̉", "q̉", "r̉", "s̉", "t̉", "ủ", "v̉", "w̉", "x̉", "ỷ", "z̉", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A̺͆", "B̺͆", "C̺͆", "D̺͆", "E̺͆", "F̺͆", "G̺͆", "H̺͆", "I̺͆", "J̺͆", "K̺͆", "L̺͆", "M̺͆", "N̺͆", "O̺͆", "P̺͆", "Q̺͆", "R̺͆", "S̺͆", "T̺͆", "U̺͆", "V̺͆", "W̺͆", "X̺͆", "Y̺͆", "Z̺͆", "a̺͆", "b̺͆", "c̺͆", "d̺͆", "e̺͆", "f̺͆", "g̺͆", "h̺͆", "i̺͆", "j̺͆", "k̺͆", "l̺͆", "m̺͆", "n̺͆", "o̺͆", "p̺͆", "q̺͆", "r̺͆", "s̺͆", "t̺͆", "u̺͆", "v̺͆", "w̺͆", "x̺͆", "y̺͆", "z̺͆", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A͒", "B͒", "C͒", "D͒", "E͒", "F͒", "G͒", "H͒", "I͒", "J͒", "K͒", "L͒", "M͒", "N͒", "O͒", "P͒", "Q͒", "R͒", "S͒", "T͒", "U͒", "V͒", "W͒", "X͒", "Y͒", "Z͒", "a͒", "b͒", "c͒", "d͒", "e͒", "f͒", "g͒", "h͒", "i͒", "j͒", "k͒", "l͒", "m͒", "n͒", "o͒", "p͒", "q͒", "r͒", "s͒", "t͒", "u͒", "v͒", "w͒", "x͒", "y͒", "z͒", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"A༙", "B༙", "C༙", "D༙", "E༙", "F༙", "G༙", "H༙", "I༙", "J༙", "K༙", "L༙", "M༙", "N༙", "O༙", "P༙", "Q༙", "R༙", "S༙", "T༙", "U༙", "V༙", "W༙", "X༙", "Y༙", "Z༙", "a༙", "b༙", "c༙", "d༙", "e༙", "f༙", "g༙", "h༙", "i༙", "j༙", "k༙", "l༙", "m༙", "n༙", "o༙", "p༙", "q༙", "r༙", "s༙", "t༙", "u༙", "v༙", "w༙", "x༙", "y༙", "z༙", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Aྂ", "Bྂ", "Cྂ", "Dྂ", "Eྂ", "Fྂ", "Gྂ", "Hྂ", "Iྂ", "Jྂ", "Kྂ", "Lྂ", "Mྂ", "Nྂ", "Oྂ", "Pྂ", "Qྂ", "Rྂ", "Sྂ", "Tྂ", "Uྂ", "Vྂ", "Wྂ", "Xྂ", "Yྂ", "Zྂ", "aྂ", "bྂ", "cྂ", "dྂ", "eྂ", "fྂ", "gྂ", "hྂ", "iྂ", "jྂ", "kྂ", "lྂ", "mྂ", "nྂ", "oྂ", "pྂ", "qྂ", "rྂ", "sྂ", "tྂ", "uྂ", "vྂ", "wྂ", "xྂ", "yྂ", "zྂ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"@", "♭", "☾", "∂", "☰", "∱", "g", "♄", "ί", "j", "ƙ", "ᒪ", "ɱ", "n", "☯", "Թ", "q", "☈", "$", "☨", "☋", "✔", "ա", "x", "¥", "z", "@", "♭", "☾", "∂", "☰", "∱", "g", "♄", "ί", "j", "ƙ", "ᒪ", "ɱ", "n", "☯", "Թ", "q", "☈", "$", "☨", "☋", "✔", "ա", "x", "¥", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));


        fancy_txt_list.add(new Font(new String[]{"ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "T", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "ǟ", "ɮ", "ƈ", "ɖ", "ɛ", "ʄ", "ɢ", "ɦ", "ɨ", "ʝ", "Ꮶ", "ʟ", "ʍ", "ռ", "օ", "ք", "զ", "ʀ", "ֆ", "T", "ʊ", "ʋ", "ա", "x", "ʏ", "ʐ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"α", "Ϧ", "ͼ", "δ", "ϵ", "f", "ϭ", "h", "ῖ", "j", "k", "l", "ϻ", "ͷ", "ϴ", "ϼ", "ϑ", "r", "ϩ", "ϯ", "ῠ", "ν", "ϣ", "x", "ϒ", "ϟ", "α", "Ϧ", "ͼ", "δ", "ϵ", "f", "ϭ", "h", "ῖ", "j", "k", "l", "ϻ", "ͷ", "ϴ", "ϼ", "ϑ", "r", "ϩ", "ϯ", "ῠ", "ν", "ϣ", "x", "ϒ", "ϟ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"Ꭿ", "ℬ", "ℂ", "ⅅ", "ℰ", "ℱ", "Ꮆ", "ℋ", "ℐ", "Ꭻ", "Ꮶ", "ℒ", "ℳ", "ℕ", "Ꮎ", "ℙ", "ℚ", "ℛ", "Ѕ", "T", "U", "Ꮙ", "Ꮗ", "X", "Ꮍ", "ℤ", "Ꭿ", "ℬ", "ℂ", "ⅅ", "ℰ", "ℱ", "Ꮆ", "ℋ", "ℐ", "Ꭻ", "Ꮶ", "ℒ", "ℳ", "ℕ", "Ꮎ", "ℙ", "ℚ", "ℛ", "Ѕ", "T", "U", "Ꮙ", "Ꮗ", "X", "Ꮍ", "ℤ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{"ค", "๒", "ς", "๔", "є", "Ŧ", "ﻮ", "ђ", "เ", "ן", "к", "ɭ", "๓", "ภ", "๏", "ק", "ợ", "г", "ร", "Շ", "ย", "ש", "ฬ", "א", "ץ", "չ", "ค", "๒", "ς", "๔", "є", "Ŧ", "ﻮ", "ђ", "เ", "ן", "к", "ɭ", "๓", "ภ", "๏", "ק", "ợ", "г", "ร", "Շ", "ย", "ש", "ฬ", "א", "ץ", "չ", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));
        fancy_txt_list.add(new Font(new String[]{ExifInterface.GPS_MEASUREMENT_IN_PROGRESS, "d", "ↄ", "b", "ɘ", "ꟻ", "g", "H", "i", "j", "k", "l", "m", "ᴎ", "o", "q", "p", "ᴙ", "ꙅ", "T", "U", "v", "w", "x", "Y", "z", ExifInterface.GPS_MEASUREMENT_IN_PROGRESS, "d", "ↄ", "b", "ɘ", "ꟻ", "g", "H", "i", "j", "k", "l", "m", "ᴎ", "o", "q", "p", "ᴙ", "ꙅ", "T", "U", "v", "w", "x", "Y", "z", "0", "1", ExifInterface.GPS_MEASUREMENT_2D, ExifInterface.GPS_MEASUREMENT_3D, "4", "5", "6", "7", "8", "9"}));

    }

    public static String convert(Font font, String str) {

        Object[] texts = font.getTexts();

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < str.length(); i++) {

            char charAt = str.charAt(i);
            int indexOf = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".indexOf(charAt);
            sb.append(indexOf != -1 ? texts[indexOf] : Character.valueOf(charAt));

        }
        return sb.toString();
    }

    @Override
    protected void onPause() {
        super.onPause();
        fancy_main_et.clearFocus();
    }

    public class Fancy_Main_Adapter extends RecyclerView.Adapter<Fancy_Main_Adapter.Fancy_Data> {

        Context context;
        ArrayList<Font> arrayList;
        String string;

        public Fancy_Main_Adapter(VS_Fancy_Text_Open_Activity textFancyFMActivity, ArrayList<Font> arrayList, String string) {
            this.context = textFancyFMActivity;
            this.arrayList = arrayList;
            this.string = string;
        }

        @Override
        public Fancy_Data onCreateViewHolder(ViewGroup parent, int viewType) {
            return new Fancy_Data(LayoutInflater.from(context).inflate(R.layout.item_text_fancy, parent, false));
        }

        @Override
        public void onBindViewHolder(Fancy_Data holder, int position) {

            String str = VS_Fancy_Text_Open_Activity.convert(arrayList.get(position), string);

            holder.item_text_set.setText(str);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    InterAdCall.getHelpIndicatorExplicit().callintermethod(VS_Fancy_Text_Open_Activity.this, true, msg -> {
                        Intent intent = new Intent(context, VS_Fancy_Text_Show_Activity.class);
                        intent.putExtra("converted_txt", str);
                        intent.putExtra("entered_txt", string);
                        context.startActivity(intent);
                    });



                }
            });
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        public void set_first_string(String trim) {

            string = trim;

            notifyItemRangeChanged(0, getItemCount());
        }

        class Fancy_Data extends RecyclerView.ViewHolder {

            TextView item_text_set;

            public Fancy_Data(View itemView) {
                super(itemView);
                item_text_set = itemView.findViewById(R.id.item_text_set);
            }
        }
    }
}