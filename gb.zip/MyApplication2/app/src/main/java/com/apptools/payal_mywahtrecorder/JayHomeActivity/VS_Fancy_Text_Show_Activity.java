package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

public class VS_Fancy_Text_Show_Activity extends AppCompatActivity {

    TextView preview_txt;

    TextView user_txt;

    ImageView preview_copy_img,preview_share_img;

    ImageView fancy_preview_back_img;
    private Context activity;

    @Override
    protected void onResume() {
        super.onResume();
    }

    private long mLastClickTime = 0L;
    private static final long CLICK_TIME_INTERVAL = 700;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vs_fancy_text_show);

        activity = this;

        fancy_preview_back_img = findViewById(R.id.fancy_preview_back_img);

        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        String converted_txt = getIntent().getStringExtra("converted_txt");
        String entered_txt = getIntent().getStringExtra("entered_txt");

        preview_txt = findViewById(R.id.preview_txt);
        preview_copy_img = findViewById(R.id.preview_copy_img);
        preview_share_img = findViewById(R.id.preview_share_img);
        user_txt = findViewById(R.id.user_txt);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        user_txt.setText(entered_txt);
        preview_txt.setText(converted_txt);

        user_txt.setMovementMethod(new ScrollingMovementMethod());
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        preview_copy_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip_copy = ClipData.newPlainText("fffff", preview_txt.getText().toString());
                clipboardManager.setPrimaryClip(clip_copy);

                Toast.makeText(VS_Fancy_Text_Show_Activity.this, JemsProviderKt.getMyString(activity,R.string.copied) , Toast.LENGTH_SHORT).show();

            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));
        preview_share_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    long now = System.currentTimeMillis();
                    if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                        return;
                    }
                    mLastClickTime = now;

                    Intent share_Intent = new Intent(Intent.ACTION_SEND);
                    share_Intent.setType("text/plain");
                    share_Intent.putExtra(Intent.EXTRA_TEXT, converted_txt);
                    startActivity(Intent.createChooser(share_Intent, "choose single"));
                } catch(Exception e) {

                }
            }
        });

        fancy_preview_back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();

            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }
}