package com.apptools.payal_mywahtrecorder.JAydata;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;

public class RecordData implements Comparable<RecordData> {
    public long id = -1;
    public String packageName;
    public String path;
    public long recordTime;

    public static RecordData create(Cursor cursor) {
        RecordData recordData = new RecordData();
        recordData.id = cursor.getLong(cursor.getColumnIndex("id"));
        recordData.packageName = cursor.getString(cursor.getColumnIndex("packageName"));
        recordData.path = cursor.getString(cursor.getColumnIndex("path"));
        recordData.recordTime = cursor.getLong(cursor.getColumnIndex("recordTime"));

        return recordData;
    }

    public int compareTo(RecordData recordData) {
        return (int) (recordData.recordTime - this.recordTime);
    }

    public static RecordData create(Intent intent) {
        RecordData recordData = new RecordData();
        recordData.id = intent.getLongExtra("id", -1);
        recordData.packageName = intent.getStringExtra("packageName");
        recordData.path = intent.getStringExtra("path");
        recordData.recordTime = intent.getLongExtra("recordTime", 0);
        return recordData;
    }

    public void setIntentExtra(Intent intent) {
        intent.putExtra("id", this.id);
        intent.putExtra("packageName", this.packageName);
        intent.putExtra("path", this.path);
        intent.putExtra("recordTime", this.recordTime);
    }

    public ContentValues getValues() {
        ContentValues contentValues = new ContentValues();
        contentValues.put("packageName", this.packageName);
        contentValues.put("path", this.path);
        contentValues.put("recordTime", Long.valueOf(this.recordTime));
        return contentValues;
    }

    public void update(RecordData recordData) {
        this.packageName = recordData.packageName;
        this.recordTime = recordData.recordTime;
        this.path = recordData.path;
        this.id = recordData.id;
    }
}
