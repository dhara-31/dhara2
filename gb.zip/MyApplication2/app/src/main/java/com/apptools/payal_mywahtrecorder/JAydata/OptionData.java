package com.apptools.payal_mywahtrecorder.JAydata;

public class OptionData {
    public String desc;
    public int iconId;
    public int option;
    public boolean selectable;
    public String title;
    public int type;

    public OptionData(int type, int option, String title, String desc, boolean selectable, int iconId) {
        this.type = type;
        this.option = option;
        this.title = title;
        this.desc = desc;
        this.selectable = selectable;
        this.iconId = iconId;
    }
}
