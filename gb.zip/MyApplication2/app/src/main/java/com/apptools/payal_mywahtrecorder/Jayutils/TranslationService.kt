package com.apptools.payal_mywahtrecorder.Jayutils

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class TranslateModel(var text: String, var key: String, var value: String)

val arrayListOfTranslateModel: ArrayList<TranslateModel> = ArrayList()

object TranslationService {
    fun translateText(
        textToTranslate: String?, targetLanguage: String, callback: (String) -> Unit
    ) {
        val size = arrayListOfTranslateModel.size
        try {
            textToTranslate?.apply {
                val selected: TranslateModel? = arrayListOfTranslateModel.find { (it.key == targetLanguage&& it.text == textToTranslate) }
             
                if (selected != null) {
                    callback(selected.value)
                    return
                }
                
            }
            callback("loading...")
            
            val sourceLanguage = "en"
            val googleTranslateUrl =
                "https://translate.google.com/m?hl=$targetLanguage&sl=$sourceLanguage&tl=$targetLanguage&ie=UTF-8&prev=_m&q=" + URLEncoder.encode(
                    textToTranslate, "UTF-8"
                )
            val url = URL(googleTranslateUrl)
            val connection = url.openConnection() as HttpURLConnection
            
           connection.requestMethod = "GET"
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val response = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                reader.close()
                
                val value = extractTranslation(response.toString())
                arrayListOfTranslateModel.add(
                    TranslateModel(
                        textToTranslate!!, targetLanguage, value
                    )
                )
                callback(value)
            } else {

                arrayListOfTranslateModel.add(
                    TranslateModel(
                        textToTranslate!!, targetLanguage, textToTranslate
                    )
                )
                callback(textToTranslate)
            }
        } catch (e: IOException) {
            e.printStackTrace()
            arrayListOfTranslateModel.add(
                TranslateModel(
                    textToTranslate!!, targetLanguage, textToTranslate
                )
            )
            callback(textToTranslate)
        }
        if (size != arrayListOfTranslateModel.size) {
            arrayListOfTranslateModel.sortBy {
                it.key
            }
        }
    }
    
    private fun extractTranslation(htmlResponse: String): String {
        val first = "class=\"result-container\">"
        val start = htmlResponse.indexOf(first) + first.length
        val temp = htmlResponse.substring(start)
        val tempStart = temp.indexOf("</div>")
        val result = temp.substring(0, tempStart)
        return if (result.contains("div>")) {
            ""
        } else {
            result
        }
    }
}