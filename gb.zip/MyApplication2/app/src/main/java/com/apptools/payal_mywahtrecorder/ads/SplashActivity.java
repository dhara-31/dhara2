package com.apptools.payal_mywahtrecorder.ads;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.apptools.payal_mywahtrecorder.JayTokandata.Activity.ExtraActivity;
import com.apptools.payal_mywahtrecorder.Jaylanguage.LanguageActivity;
import com.apptools.payal_mywahtrecorder.R;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {


    boolean overtimegtDve = false;

    public Dialog dialogtDg;
    //   public static Boolean apgtDopenD = true;

    public static Boolean fg = false;
    public static Integer gffg = 0;
    public static Boolean fgdg = false;

    public static Handler f;
    public static Runnable rth;
    CountDownTimer tf;
    int timerScreen = 7000;
    public DApplication dfg = DApplication.getInstance();
    boolean tg = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppOpenclass.fividdecgtmag = true;

        setContentView(R.layout.splash);

        fgdg = false;
        gffg = 0;

        fg = false;
        DApplication.a = false;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        AppOpenclass.Splasviddecgtmty = SplashActivity.this;

        if (isNetworkAvailable()) {
            try {
                if (dialogtDg != null && dialogtDg.isShowing()) {
                    dialogtDg.dismiss();
                }
            } catch (Exception ignored) {
            }

            getAiwthNewData();
            startgtDve();
        } else {

            if (AppOpenclass.f == null) {
                InternetDialogUpdate();
            }
        }
    }
    public void getAiwthNewData() {

        try {
            InterAdCall.getHelpIndicatorExplicit();

            RequestQueue queue = Volley.newRequestQueue(SplashActivity.this);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, "https://ard-infotech-default-rtdb.firebaseio.com/GB_WAPP_001.json", null, new com.android.volley.Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    JsonParser parser = new JsonParser();
                    JsonElement mJson = parser.parse(response.toString());
                    Gson gson = new Gson();
                    AppDetail object = gson.fromJson(mJson, AppDetail.class);
                   /* // dfg.setAppDetail(object);
                    Log.e("TAG", "caaaa: " + object);

                    //  object.setAdstatus("2");
                    object.setAdmobnative("sss");
                    object.setFbnative("");
                    object.setFbnativebanner("ddd");*/
                    DApplication.getMeVcallApplication().setMyModelHelper(object);

                    InterAdCall.getHelpIndicatorExplicit().loadviddecgtm(SplashActivity.this);
                    if (dfg.getMeVcallApplication().getAppDetails() != null && dfg.getAppDetails().getAdstatus().equalsIgnoreCase("2")) {
                        StartMaigtDeen();
                    } else if (dfg.getAppDetails() != null && dfg.getAppDetails().getAdstatus().equals("1")) {


                        InterAdCall.myInterDetector = DApplication.wholeInterCountdown();
                        InterAdCall.qcounter = DApplication.newcountdon();

                        InterAdCall.getHelpIndicatorExplicit().loadMainIntersd(SplashActivity.this);
                        if (dfg.getAppDetails() != null && dfg.getAppDetails().getAppopenAdmob() != null && !TextUtils.isEmpty(dfg.getAppDetails().getAppopenAdmob())) {

                            AppOpenclass.gf = dfg.getAppDetails().getAppopenAdmob();

                            dfg.dg();
                            dfg.b = "SplashActivity";

                            AppOpenclass.Splasviddecgtmty = SplashActivity.this;

                            DApplication.appOviddecgtmger.fividdecgtmag = true;

                            if (AppOpenclass.f == null) {
                                DApplication.appOviddecgtmger.getOpeviddecgtms();
                            }

                        } else {
                            StartMaigtDeen();
                        }
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    StartMaigtDeen();
                    Log.e("TAG", "errr: " + error.getLocalizedMessage());
                }
            });

            queue.add(jsonObjectRequest);

        } catch (Exception e) {
        }
    }


    public void startgtDve() {

        overtimegtDve = false;
        rth = new Runnable() {
            @Override
            public void run() {

                overtimegtDve = true;
                DApplication.a = true;

                if (isNetworkAvailable()) {
                    try {
                        if (dialogtDg != null && dialogtDg.isShowing()) {
                            dialogtDg.dismiss();
                        }
                    } catch (Exception e) {
                    }

                    if (tg) {


                        if (fgdg == false) {

                            fg = true;

                            DApplication.a = true;
                            DApplication.appOviddecgtmger.fividdecgtmag = false;

                            try {
                                if (f != null) {
                                    f.removeCallbacks(rth);
                                }
                            } catch (Exception e) {

                            }


                            if (DApplication.numberDetector() >= 3) {

                                startActivity(new Intent(SplashActivity.this, ExtraActivity.class));
                                finish();
                            } else if (DApplication.numberDetector() >= 2) {

                                startActivity(new Intent(SplashActivity.this, LanguageActivity.class));
                                finish();
                            } else if (DApplication.numberDetector() >= 1) {
                                startActivity(new Intent(SplashActivity.this, StartScreenActivity.class));
                                finish();
                            } else {
                                startActivity(new Intent(SplashActivity.this, HOmeActvitiy.class));
                                finish();
                            }

                        }

                    }
                } else {
                    DApplication.a = true;
                    try {
                        if (dialogtDg != null && dialogtDg.isShowing()) {
                            dialogtDg.dismiss();
                        }
                    } catch (Exception e) {
                    }
                    InternetDialogUpdate();
                }
            }
        };

        try {
            if (f != null) {
                f.removeCallbacks(rth);
            }
        } catch (Exception e) {

        }


        try {
            if (tf != null) {
                tf.cancel();
            }
        } catch (Exception e) {

        }

        f = new Handler();

        f.postDelayed(rth, timerScreen);

        tf = new CountDownTimer(timerScreen, 100) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
            }

        }.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        tg = false;
    }

    private void StartMaigtDeen() {

        DApplication.appOviddecgtmger.fividdecgtmag = false;


        if (DApplication.numberDetector() >= 3) {

            startActivity(new Intent(SplashActivity.this, ExtraActivity.class));
            finish();
        } else if (DApplication.numberDetector() >= 2) {

            startActivity(new Intent(SplashActivity.this, LanguageActivity.class));
            finish();
        } else if (DApplication.numberDetector() >= 1) {
            startActivity(new Intent(SplashActivity.this, StartScreenActivity.class));
            finish();
        } else {
            startActivity(new Intent(SplashActivity.this, HOmeActvitiy.class));
            finish();
        }


    }


    @Override
    protected void onResume() {
        tg = true;
        super.onResume();

    }


    public void InternetDialogUpdate() {
        dialogtDg = new Dialog(this);
        dialogtDg.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialogtDg.requestWindowFeature(1);
        dialogtDg.setContentView(R.layout.dialog);
        dialogtDg.setCancelable(false);
        TextView txt_yes = (TextView) dialogtDg.findViewById(R.id.exit);


        try {
            tf.cancel();
            f.removeCallbacks(rth);
        } catch (Exception e) {

        }

        txt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                dialogtDg.dismiss();

            }
        });
        if (!isFinishing()) {
            dialogtDg.show();
        }
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            boolean isAvailable = false;
            if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                isAvailable = true;
            }
            return isAvailable;
        } catch (Exception e) {
            return false;
        }

    }


    @Override
    protected void onDestroy() {
        try {
            if (f != null) {
                f.removeCallbacks(rth);
            }
        } catch (Exception e) {

        }
        try {
            if (tf != null) {
                tf.cancel();
            }
        } catch (Exception e) {
        }
        super.onDestroy();
    }


    @Override
    public void onBackPressed() {
    }
}
