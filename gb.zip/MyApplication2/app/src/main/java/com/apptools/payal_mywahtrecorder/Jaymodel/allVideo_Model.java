package com.apptools.payal_mywahtrecorder.Jaymodel;

import android.net.Uri;

public class allVideo_Model {

    String videoTitle;
    long duration;
    Uri videoUri;

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public allVideo_Model(String videoTitle, Uri videoUri) {
        this.videoTitle = videoTitle;
        this.videoUri = videoUri;
    }

    public allVideo_Model() {
    }

    public String getVideoTitle() {
        return videoTitle;
    }

    public void setVideoTitle(String videoTitle) {
        this.videoTitle = videoTitle;
    }

    public Uri getVideoUri() {
        return videoUri;
    }

    public void setVideoUri(Uri videoUri) {
        this.videoUri = videoUri;
    }
}
