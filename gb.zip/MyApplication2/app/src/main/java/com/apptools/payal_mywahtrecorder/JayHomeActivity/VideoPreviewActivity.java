package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jaycommon.MusicPlayer;
import com.apptools.payal_mywahtrecorder.JAydata.MusicData;

import java.io.File;

public class VideoPreviewActivity extends AppCompatActivity {
    public MusicData[] audioList;
    public MusicPlayer audioPlayer;
    public boolean firstPreper = true;

    public ImageView imgPlayTag;
    public ImageView imgProgress;
    private ImageView imgReturn;
    public boolean isPausing = false;
    public boolean isUIShowing = false;
    private FrameLayout layVideo;
    public double playPercent = 0.0d;
    public Handler progressHandler = new Handler();
    public int progressLeft;
    public Runnable updateVideoProgress = new Runnable() {


        public void run() {
            int currentPosition = videoPlayer.getCurrentPosition();
            if (!videoPlayer.isPlaying() || currentPosition < videoEnd) {
                double d = (double) currentPosition;
                double d2 = (double) videoBegin;
                Double.isNaN(d);
                Double.isNaN(d2);
                Double.isNaN(d);
                Double.isNaN(d2);
                double d3 = d - d2;
                double d4 = (double) videoEnd;
                double d5 = (double) videoBegin;
                Double.isNaN(d4);
                Double.isNaN(d5);
                Double.isNaN(d4);
                Double.isNaN(d5);
                double d6 = d3 / (d4 - d5);
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) imgPlayTag.getLayoutParams();
                double width = (double) imgProgress.getWidth();
                Double.isNaN(width);
                Double.isNaN(width);
                layoutParams.leftMargin = (int) (width * d6);
                imgPlayTag.setLayoutParams(layoutParams);
                progressHandler.postDelayed(updateVideoProgress, 17);
                playPercent = d6;
                return;
            }
            stopPlay();
        }
    };
    public int videoBegin;
    public int videoDuration;
    public int videoEnd;
    private String videoPath;
    public VideoView videoPlayer;

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_video_preview);

        this.videoPlayer = (VideoView) findViewById(R.id.avp_video);
        this.imgReturn = (ImageView) findViewById(R.id.avp_img_return);
        this.imgPlayTag = (ImageView) findViewById(R.id.avp_img_play_tag);
        this.imgProgress = (ImageView) findViewById(R.id.avp_img_prog_bg);
        this.layVideo = (FrameLayout) findViewById(R.id.avp_lay_video);
        this.audioPlayer = new MusicPlayer();
        Intent intent = getIntent();
        this.videoPath = intent.getStringExtra("videoPath");
        this.videoBegin = intent.getIntExtra("videoBegin", 0);
        this.videoEnd = intent.getIntExtra("videoEnd", 0);
        Parcelable[] parcelableArrayExtra = intent.getParcelableArrayExtra("audioList");
        if (parcelableArrayExtra != null && parcelableArrayExtra.length > 0) {
            this.audioList = new MusicData[parcelableArrayExtra.length];
            for (int i = 0; i < parcelableArrayExtra.length; i++) {
                this.audioList[i] = (MusicData) parcelableArrayExtra[i];
            }
            this.audioPlayer.setMusicList(this.audioList);
        }
        this.videoPlayer.setVideoPath(this.videoPath);


        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoPlayer);
        videoPlayer.setMediaController(mediaController);

        videoPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int wahat, int extra) {
                try {
                    File filed = new File(videoPath);
                    if (filed.exists()) {
                        filed.delete();
                    }
                } catch (Exception e) {

                }
                return false;
            }
        });

        this.videoPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {


            public void onPrepared(MediaPlayer mediaPlayer) {
                videoDuration = mediaPlayer.getDuration();
                if (videoEnd == 0) {
                    VideoPreviewActivity videoPreviewActivity = VideoPreviewActivity.this;
                    videoPreviewActivity.videoEnd = videoPreviewActivity.videoDuration;
                }
                if (audioList != null && audioList.length > 0) {
                    mediaPlayer.setVolume(0.0f, 0.0f);
                    if (firstPreper) {
                        audioPlayer.play();
                        firstPreper = false;
                    }
                }
                progressHandler.postDelayed(updateVideoProgress, 17);
            }
        });
        this.videoPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {


            public void onCompletion(MediaPlayer mediaPlayer) {
                stopPlay();
            }
        });
        this.layVideo.setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {
                VideoPreviewActivity videoPreviewActivity = VideoPreviewActivity.this;
                videoPreviewActivity.setUIVisible(!videoPreviewActivity.isUIShowing);
            }
        });
        this.imgReturn.setOnClickListener(new View.OnClickListener() {


            public void onClick(View view) {
                onBackPressed();
            }
        });
        this.imgProgress.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {


            @SuppressLint("WrongConstant")
            public boolean onPreDraw() {
                imgProgress.getViewTreeObserver().removeOnPreDrawListener(this);
                VideoPreviewActivity videoPreviewActivity = VideoPreviewActivity.this;
                videoPreviewActivity.progressLeft = videoPreviewActivity.imgProgress.getLeft();
                imgProgress.setVisibility(4);
                return false;
            }
        });


        this.imgPlayTag.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                int action = motionEvent.getAction();
                if (action != 0) {
                    if (action != 1) {
                        if (action == 2) {
                            int rawX = ((int) motionEvent.getRawX()) - progressLeft;
                            if (rawX < 0) {
                                rawX = 0;
                            } else if (rawX > imgProgress.getWidth()) {
                                rawX = imgProgress.getWidth();
                            }
                            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) imgPlayTag.getLayoutParams();
                            layoutParams.leftMargin = rawX;
                            imgPlayTag.setLayoutParams(layoutParams);
                            double d = (double) (videoEnd - videoBegin);
                            double d2 = (double) rawX;
                            double width = (double) imgProgress.getWidth();
                            Double.isNaN(d2);
                            Double.isNaN(width);
                            Double.isNaN(d2);
                            Double.isNaN(width);
                            Double.isNaN(d);
                            Double.isNaN(d);
                            double d3 = d * (d2 / width);
                            VideoView videoView = videoPlayer;
                            double d4 = (double) videoBegin;
                            Double.isNaN(d4);
                            Double.isNaN(d4);
                            videoView.seekTo((int) (d4 + d3));
                            audioPlayer.seekTo((int) d3);
                        } else if (action != 3) {
                        }
                    }
                    if (!isPausing) {
                        resumePlay();
                    }
                } else if (!isPausing) {
                    pausePlay();
                }
                return true;
            }
        });
        int i2 = this.videoBegin;
        if (i2 > 0) {
            this.videoPlayer.seekTo(i2);
        }
        this.videoPlayer.start();
        this.isPausing = false;
    }

    @Override
    public void onStop() {
        super.onStop();
        if (!this.isPausing) {
            pausePlay();

            this.isPausing = true;
        }
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    public void setUIVisible(boolean z) {
        int i;
        if (z) {
            i = View.VISIBLE;
        } else {
            i = View.INVISIBLE;
        }

        this.imgProgress.setVisibility(i);

        this.imgPlayTag.setVisibility(i);
        this.isUIShowing = z;
    }


    public void pausePlay() {
        if (this.videoPlayer.isPlaying()) {
            this.videoPlayer.pause();
        }
        if (this.audioPlayer.isPlaying()) {
            this.audioPlayer.pause();
        }
    }

    public void resumePlay() {
        if (!this.videoPlayer.isPlaying()) {
            this.videoPlayer.start();
        }
        this.audioPlayer.resume();
    }

    public void stopPlay() {
        if (this.videoPlayer.isPlaying()) {
            this.videoPlayer.suspend();
        }
        if (this.audioPlayer.isPlaying()) {
            this.audioPlayer.stop();
        }
        onBackPressed();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.videoPlayer.suspend();
        this.audioPlayer.release();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }
}
