package com.apptools.payal_mywahtrecorder.JayHomeadapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JAydata.AppInfo;
import com.apptools.payal_mywahtrecorder.JAydata.AppInfoType;
import com.apptools.payal_mywahtrecorder.Jayutils.CatchUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

import java.util.List;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.AppHolder> {
    private List<AppInfo> appList;
    public int tag;


    public class AppHolder extends RecyclerView.ViewHolder {
        private ImageView icon;
        public AppInfo info;
        public long lastClickTime = 0;
        private TextView text;

        public AppHolder(View view) {
            super(view);
            this.icon = (ImageView) view.findViewById(R.id.appIcon);
            this.text = (TextView) view.findViewById(R.id.appName);
            view.setOnClickListener(new View.OnClickListener() {


                public void onClick(View view) {
                    long currentTimeMillis = System.currentTimeMillis();
                    if (currentTimeMillis - AppHolder.this.lastClickTime >= 3000) {
                        AppHolder.this.lastClickTime = currentTimeMillis;
                        Intent intent = new Intent(Message.SELECTE_APP);
                        intent.putExtra("packageName", AppHolder.this.info.pkg);
                        intent.putExtra("type", AppHolder.this.info.type.toString());
                        intent.putExtra("tag", AppListAdapter.this.tag);
                        DApplication.getBm().sendBroadcast(intent);
                    }
                }
            });
        }

        public void setData(AppInfo appInfo) {
            this.lastClickTime = 0;
            this.info = appInfo;
            if (appInfo.type == AppInfoType.NORMAL) {
                this.text.setText(appInfo.name);
                this.icon.setImageDrawable(CatchUtils.getInstance().getAppIcon(appInfo.pkg));
            } else if (appInfo.type == AppInfoType.DESKTOP) {
                this.icon.setImageResource(R.drawable.start_recording_button);
                this.text.setText("");
            } else if (appInfo.type == AppInfoType.SELECT) {
              /*  this.icon.setImageResource(R.drawable.ic_add_app);
                this.text.setText(R.string.label_select_app);*/
            }
        }
    }

    public AppListAdapter(int i) {
        this.tag = i;
    }

    public void setAppList(List<AppInfo> list) {
        this.appList = list;
    }

    public void addApp(AppInfo appInfo) {
        for (int size = this.appList.size() - 1; size >= 0; size--) {
            if (this.appList.get(size).type == AppInfoType.NORMAL) {
                int i = size + 1;
                this.appList.add(i, appInfo);
                notifyItemInserted(i);
                return;
            }
        }
        this.appList.add(0, appInfo);
        notifyItemInserted(0);
    }

    public void removeApp(AppInfo appInfo) {
        int indexOf = this.appList.indexOf(appInfo);
        if (indexOf != -1) {
            this.appList.remove(indexOf);
            notifyItemRemoved(indexOf);
            return;
        }

    }

    public void addDesktopItem() {
        AppInfo appInfo = new AppInfo();
        appInfo.type = AppInfoType.DESKTOP;
        this.appList.add(appInfo);
    }

    public void addSelectItem() {
        AppInfo appInfo = new AppInfo();
        appInfo.type = AppInfoType.SELECT;
        this.appList.add(appInfo);
    }

    @Override
    public AppHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new AppHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.app_itemtools, viewGroup, false));
    }

    public void onBindViewHolder(AppHolder appHolder, int i) {
        appHolder.setData(this.appList.get(i));
    }

    @Override
    public int getItemCount() {
        return 1;
    }
}
