package com.apptools.payal_mywahtrecorder.Jayservice;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JAydata.PerferencedName;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class ChangeModeService extends IntentService {
    private NotificationManager manager;

    public ChangeModeService() {
        super("ChangeModeService");
    }

    @SuppressLint("WrongConstant")
    private NotificationManager getManager() {
        if (this.manager == null) {
            this.manager = (NotificationManager) getSystemService("notification");
        }
        return this.manager;
    }

    @SuppressLint("WrongConstant")
    public void onHandleIntent(Intent intent) {
        if (intent != null) {
            @SuppressLint("WrongConstant") NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
            if (Build.VERSION.SDK_INT >= 26) {
                getManager().createNotificationChannel(new NotificationChannel("default", "default", 3));
            }
            int intExtra = intent.getIntExtra("mode", 0);
            DApplication.sP.edit().putInt(PerferencedName.RECORD_MODE, intExtra).apply();
            RemoteViews remoteViews = DApplication.notificationMenu;
            RemoteViews remoteViews2 = DApplication.notificationMenuSmall;
            if (remoteViews != null) {
                if (intExtra == 0 || intExtra == 1) {
                    remoteViews.setImageViewResource(R.id.inm_img_normal, R.drawable.ic_notice_normal_active);
                    remoteViews.setImageViewResource(R.id.inm_img_speak, R.drawable.ic_notice_speak);

                    remoteViews2.setImageViewResource(R.id.inms_img_normal, R.drawable.ic_notice_normal_active);
                    remoteViews2.setImageViewResource(R.id.inms_img_speak, R.drawable.ic_notice_speak);

                } else if (intExtra == 2) {
                    remoteViews.setImageViewResource(R.id.inm_img_normal, R.drawable.ic_notice_normal);
                    remoteViews.setImageViewResource(R.id.inm_img_speak, R.drawable.ic_notice_speak_active);

                    remoteViews2.setImageViewResource(R.id.inms_img_normal, R.drawable.ic_notice_normal);
                    remoteViews2.setImageViewResource(R.id.inms_img_speak, R.drawable.ic_notice_speak_active);

                } else if (intExtra == 3) {
                    remoteViews.setImageViewResource(R.id.inm_img_normal, R.drawable.ic_notice_normal);
                    remoteViews.setImageViewResource(R.id.inm_img_speak, R.drawable.ic_notice_speak);

                    remoteViews2.setImageViewResource(R.id.inms_img_normal, R.drawable.ic_notice_normal);
                    remoteViews2.setImageViewResource(R.id.inms_img_speak, R.drawable.ic_notice_speak);

                } else {
                    return;
                }
            }
            notificationManager.notify(1, DApplication.notification);
        }
    }
}
