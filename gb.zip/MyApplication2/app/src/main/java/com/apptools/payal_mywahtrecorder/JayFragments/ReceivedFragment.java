package com.apptools.payal_mywahtrecorder.JayFragments;


import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.file_set_int;
import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.selectedPos;
import static com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_CleanerHomeMediaActivity.size_path_log;
import static com.apptools.payal_mywahtrecorder.JayFragments.SentFragment.list_sent;
import static com.apptools.payal_mywahtrecorder.JayFragments.SentFragment.size_sent_set;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterRecevi.list_select_doc;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterRecevi.list_select_file;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_doc_sent;
import static com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterSent.list_select_file_sent;

import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayHomeadapter.MyAdapterRecevi;
import com.apptools.payal_mywahtrecorder.JAydata.Savers;
import com.apptools.payal_mywahtrecorder.Jayutils.FileCleanerUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;

import java.io.File;
import java.util.ArrayList;


public class ReceivedFragment extends Fragment {

    TextView text_select_item_nub, text_set__no_data;
    RecyclerView recyclre_receiv;
    ImageView imd_delete_recevi;
    MyAdapterRecevi myAdapterRecevi;
    public static ArrayList<Savers> list_recevi = new ArrayList<>();

    PreferenceUtil preferenceUtil;
    private String name;
    private boolean select_all = false;
    private Dialog alert_select;
    private Dialog dialog;
    ImageView img_rece_all_select_an, img_rece_all_select;
    RelativeLayout realti_select;
    public static long size_rece_set = 0;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_received, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        preferenceUtil = new PreferenceUtil(requireActivity());
        name = preferenceUtil.getString(PreferenceUtil.SET_NIIK_TITAL, "");

        text_select_item_nub = view.findViewById(R.id.text_select_item_nub);

        recyclre_receiv = view.findViewById(R.id.recyclre_receiv);
        text_set__no_data = view.findViewById(R.id.text_set__no_data);
        imd_delete_recevi = view.findViewById(R.id.imd_delete_recevi);
        img_rece_all_select_an = view.findViewById(R.id.img_rece_all_select_an);
        img_rece_all_select = view.findViewById(R.id.img_rece_all_select);
        realti_select = view.findViewById(R.id.realti_select);

        img_rece_all_select_an.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                img_rece_all_select.setVisibility(View.VISIBLE);
                img_rece_all_select_an.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= 30) {

                    if (!select_all) {

                        list_select_doc.clear();
                        for (Savers saver : list_recevi) {
                            list_select_doc.add(saver.getDocumentFile());
                        }
                        select_all = true;
                    }

                    onclickset(list_select_doc.size());
                } else {

                    if (!select_all) {
                        list_select_file.clear();
                        for (Savers saver : list_recevi) {
                            list_select_file.add(saver.getFile());
                        }
                        select_all = true;

                    }

                    onclickset(list_select_file.size());
                }

                if (myAdapterRecevi != null) {
                    myAdapterRecevi.updatelist(list_recevi);
                    myAdapterRecevi.updata11Doc(list_select_doc);
                    myAdapterRecevi.update11dow(list_select_file);
                    myAdapterRecevi.notifyDataSetChanged();
                }
            }
        });
        img_rece_all_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img_rece_all_select.setVisibility(View.GONE);
                img_rece_all_select_an.setVisibility(View.VISIBLE);
                if (Build.VERSION.SDK_INT >= 30) {

                    if (select_all) {
                        select_all = false;
                        list_select_doc.clear();
                    }

                    onclickset(list_select_doc.size());
                } else {

                    if (select_all) {
                        select_all = false;
                        list_select_file.clear();
                    }

                    onclickset(list_select_file.size());
                }

                if (myAdapterRecevi != null) {
                    myAdapterRecevi.updatelist(list_recevi);
                    myAdapterRecevi.updata11Doc(list_select_doc);
                    myAdapterRecevi.update11dow(list_select_file);
                    myAdapterRecevi.notifyDataSetChanged();
                }
            }
        });


        imd_delete_recevi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (list_select_doc.size() != 0 || list_select_file.size() != 0) {
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(requireActivity());
                    final View customLayout = LayoutInflater.from(requireActivity()).inflate(R.layout.delete_dilog, null, false);
                    alertDialog.setView(customLayout);


                    ImageView Cancel_status_dilog = customLayout.findViewById(R.id.Cancel_status_dilog);
                    ImageView ok_status_dilog = customLayout.findViewById(R.id.ok_status_dilog);
                    Cancel_status_dilog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alert_select.dismiss();

                        }
                    });
                    ok_status_dilog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            long size = 0;
                            alert_select.dismiss();
                            diloagshowmoth();
                            if (Build.VERSION.SDK_INT >= 30) {
                                for (DocumentFile d : list_select_doc) {
                                    size += d.length();
                                    new DELETE_DOC_11_RECE().execute(d.getUri());

                                }

                                file_set_int[selectedPos] = file_set_int[selectedPos] - list_select_doc.size();
                                deldete11uyp();
                                list_select_doc.clear();
                                onclickset(list_select_doc.size());


                            } else {

                                for (File f : list_select_file) {
                                    size += f.length();
                                    checkdatafile(f);
                                }
                                file_set_int[selectedPos] = file_set_int[selectedPos] - list_select_file.size();
                                list_select_file.clear();
                                onclickset(list_select_file.size());

                            }


                        }
                    });
                    alert_select = alertDialog.create();
                    alert_select.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    alert_select.show();
                }


            }
        });


        text_select_item_nub.setText("Selected " + name + " (" + 0 + ")");
        if (name.equals("Images") || name.equals("Gifs") || name.equals("Stickers")) {
            recyclre_receiv.setLayoutManager(new GridLayoutManager(requireActivity(), 3));
        } else {
            recyclre_receiv.setLayoutManager(new GridLayoutManager(requireActivity(), 1));
        }

        recyclre_receiv.setHasFixedSize(true);
        myAdapterRecevi = new MyAdapterRecevi(requireActivity(), list_recevi, name, this::onclickset);
        recyclre_receiv.setAdapter(myAdapterRecevi);
        String path = preferenceUtil.getString(PreferenceUtil.SET_SELECT_ITME, "");

        if (Build.VERSION.SDK_INT >= 30) {

            new Datelist11up().execute(path);

        } else {

            new Datalist10dowRec().execute(new File(path));
        }


    }

    private void deldete11uyp() {

        for (int i = 0; i < list_select_doc.size(); i++) {
            for (int j = 0; j < list_recevi.size(); j++) {


                if (list_select_doc.get(i).toString().contains(list_recevi.get(j).getDocumentFile().toString())) {
                    list_recevi.remove(j);
                    break;
                }

            }
        }


        if (myAdapterRecevi != null) {
            if (list_recevi.size() == 0) {
                realti_select.setVisibility(View.GONE);
                text_select_item_nub.setVisibility(View.GONE);
                recyclre_receiv.setVisibility(View.GONE);
                text_set__no_data.setVisibility(View.VISIBLE);
                imd_delete_recevi.setVisibility(View.GONE);
            } else {
                realti_select.setVisibility(View.VISIBLE);
                text_select_item_nub.setVisibility(View.VISIBLE);
                recyclre_receiv.setVisibility(View.VISIBLE);
                text_set__no_data.setVisibility(View.GONE);
                imd_delete_recevi.setVisibility(View.VISIBLE);
            }
            myAdapterRecevi.updatelist(list_recevi);
        }
    }

    private void checkdatafile(File f) {

        ArrayList<Savers> temp = new ArrayList<>();
        size_path_log[selectedPos] = size_path_log[selectedPos] - f.length();
        for (Savers saver : list_recevi) {
            if (!saver.getFile().toString().equals(f.toString())) {
                temp.add(saver);
            }
        }
        f.delete();
        list_recevi = temp;
        if (myAdapterRecevi != null) {
            if (list_recevi.size() == 0) {
                realti_select.setVisibility(View.GONE);
                text_select_item_nub.setVisibility(View.GONE);
                recyclre_receiv.setVisibility(View.GONE);
                text_set__no_data.setVisibility(View.VISIBLE);
                imd_delete_recevi.setVisibility(View.GONE);
            } else {
                realti_select.setVisibility(View.VISIBLE);
                text_select_item_nub.setVisibility(View.VISIBLE);
                recyclre_receiv.setVisibility(View.VISIBLE);
                text_set__no_data.setVisibility(View.GONE);
                imd_delete_recevi.setVisibility(View.VISIBLE);
            }

            myAdapterRecevi.updatelist(list_recevi);
        }
    }


    private void onclickset(int i) {

        if (dialog != null) {
            if (dialog.isShowing()) {

                dialog.dismiss();
            }
        }

        if (i == 0) {

            img_rece_all_select.setVisibility(View.GONE);
            img_rece_all_select_an.setVisibility(View.VISIBLE);
            imd_delete_recevi.setImageResource(R.drawable.delete_an);

        } else if (list_recevi.size() == i) {
            img_rece_all_select.setVisibility(View.VISIBLE);
            img_rece_all_select_an.setVisibility(View.GONE);
            imd_delete_recevi.setImageResource(R.drawable.delete_se);
            select_all = true;
        } else if (i >= 1) {
            img_rece_all_select.setVisibility(View.GONE);
            img_rece_all_select_an.setVisibility(View.VISIBLE);
            imd_delete_recevi.setImageResource(R.drawable.delete_se);

            select_all = false;
        }


        text_select_item_nub.setText("Selected " + name + " (" + i + ")");
    }


    class Datalist10dowRec extends AsyncTask<File, Void, ArrayList<Savers>> {

        @Override
        protected ArrayList<Savers> doInBackground(File... files) {
            if (files[0].canExecute()) {

                File[] statusFiles;
                statusFiles = files[0].listFiles();
                list_recevi.clear();

                for (File file : statusFiles) {
                    Savers saver = new Savers(file, file.getName(), file.getAbsolutePath(), file.length());
                    if (!file.getName().equals("Sent") && !file.getName().equals("Private")) {

                        if (file.isDirectory()) {

                            File[] files_list;
                            files_list = file.listFiles();
                            for (File file1 : files_list) {
                                Savers saver2 = new Savers(file1, file1.getName(), file1.getAbsolutePath(), file1.length());
                                if (saver2.getFile().exists() && saver2.getFile().length() > 0) {
                                    list_recevi.add(saver2);
                                    size_rece_set += file1.length();

                                }
                            }

                        } else {
                            if (saver.getFile().exists() && saver.getFile().length() > 0) {
                                list_recevi.add(saver);
                                size_rece_set += file.length();
                            }
                        }
                    }

                }

            }
            return list_recevi;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<Savers> savers) {
            super.onPostExecute(savers);
            file_set_int[selectedPos] = savers.size() + list_sent.size();
            list_recevi = savers;
            size_path_log[selectedPos] = size_rece_set + size_sent_set;
            myAdapterRecevi.updatelist(list_recevi);
            if (myAdapterRecevi.getItemCount() == 0) {
                realti_select.setVisibility(View.GONE);
                text_select_item_nub.setVisibility(View.GONE);
                recyclre_receiv.setVisibility(View.GONE);
                text_set__no_data.setVisibility(View.VISIBLE);
                imd_delete_recevi.setVisibility(View.GONE);
                imd_delete_recevi.setVisibility(View.GONE);
            } else {
                realti_select.setVisibility(View.VISIBLE);
                text_select_item_nub.setVisibility(View.VISIBLE);
                recyclre_receiv.setVisibility(View.VISIBLE);
                text_set__no_data.setVisibility(View.GONE);
                imd_delete_recevi.setVisibility(View.VISIBLE);
                imd_delete_recevi.setVisibility(View.VISIBLE);
            }
        }
    }

    class Datelist11up extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            try {


                String val = preferenceUtil.getString(PreferenceUtil.KeyUseThisFolder, "");


                String path_data = preferenceUtil.getString(PreferenceUtil.SET_SELECT_ITME, "");

                DocumentFile document = DocumentFile.fromSingleUri(requireActivity(), Uri.parse(path_data));
                DocumentFile documentFileget = null;
                String data = preferenceUtil.getString(PreferenceUtil.SELECT_WHAZ, null);

                if (data.equals("waz_w4b")) {
                    if (document.getName().equals("Backups")) {
                        documentFileget = DocumentFile.fromTreeUri(requireActivity(), Uri.parse(val)).findFile("com.whatsapp.w4b").findFile("WhatsApp Business").findFile(document.getName());

                    } else {
                        documentFileget = DocumentFile.fromTreeUri(requireActivity(), Uri.parse(val)).findFile("com.whatsapp.w4b").findFile("WhatsApp Business").findFile("Media").findFile(document.getName());
                    }
                } else if (data.equals("whaz_nor")) {
                    if (document.getName().equals("Backups")) {
                        documentFileget = DocumentFile.fromTreeUri(requireActivity(), Uri.parse(val)).findFile("com.whatsapp").findFile("WhatsApp").findFile(document.getName());
                    } else {
                        documentFileget = DocumentFile.fromTreeUri(requireActivity(), Uri.parse(val)).findFile("com.whatsapp").findFile("WhatsApp").findFile("Media").findFile(document.getName());
                    }
                }

                if (documentFileget.exists()) {
                    if (documentFileget.isDirectory()) {

                        for (DocumentFile f : documentFileget.listFiles()) {


                            if (!f.getUri().toString().contains(".nomedia")) {
                                if (!f.getUri().toString().endsWith("Sent") && !f.getUri().toString().endsWith("Private")) {
                                    if (DocumentFile.isDocumentUri(requireActivity(), f.getUri())) {

                                        if (f.isDirectory()) {
                                            for (DocumentFile f2 : f.listFiles()) {
                                                if (!f2.getUri().toString().contains(".nomedia")) {
                                                    File filePath = FileCleanerUtils.getFile(requireActivity(), f2.getUri());
                                                    Savers saver = new Savers(filePath, filePath.getName(), filePath.getAbsolutePath(), f2.getUri(), f2.length(), f2);
                                                    list_recevi.add(saver);
                                                    size_rece_set += f2.length();

                                                }
                                            }
                                        } else {
                                            File filePath = FileCleanerUtils.getFile(requireActivity(), f.getUri());
                                            Savers saver = new Savers(filePath, filePath.getName(), filePath.getAbsolutePath(), f.getUri(), f.length(), f);
                                            list_recevi.add(saver);
                                            size_rece_set += f.length();

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            } catch (Exception e) {
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            diloagshowmoth();
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);


            file_set_int[selectedPos] = list_recevi.size() + list_sent.size();
            size_path_log[selectedPos] = size_rece_set + size_sent_set;


            myAdapterRecevi.updatelist(list_recevi);
            if (myAdapterRecevi.getItemCount() == 0) {
                realti_select.setVisibility(View.GONE);
                text_select_item_nub.setVisibility(View.GONE);
                recyclre_receiv.setVisibility(View.GONE);
                text_set__no_data.setVisibility(View.VISIBLE);
                imd_delete_recevi.setVisibility(View.GONE);
            } else {
                realti_select.setVisibility(View.VISIBLE);
                text_select_item_nub.setVisibility(View.VISIBLE);
                recyclre_receiv.setVisibility(View.VISIBLE);
                text_set__no_data.setVisibility(View.GONE);
                imd_delete_recevi.setVisibility(View.VISIBLE);
            }
            dialog.dismiss();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        select_all = false;
        if (Build.VERSION.SDK_INT >= 30) {
            onclickset(list_select_doc_sent.size());
        } else {
            onclickset(list_select_file_sent.size());
        }
        if (myAdapterRecevi != null) {
            if (list_recevi.size() == 0) {
                realti_select.setVisibility(View.GONE);
                text_select_item_nub.setVisibility(View.GONE);
                recyclre_receiv.setVisibility(View.GONE);
                text_set__no_data.setVisibility(View.VISIBLE);
                imd_delete_recevi.setVisibility(View.GONE);
            } else {
                realti_select.setVisibility(View.VISIBLE);
                text_select_item_nub.setVisibility(View.VISIBLE);
                recyclre_receiv.setVisibility(View.VISIBLE);
                text_set__no_data.setVisibility(View.GONE);
                imd_delete_recevi.setVisibility(View.VISIBLE);
            }
            myAdapterRecevi.updatelist(list_recevi);

        }
    }


    private void diloagshowmoth() {

        dialog = new Dialog(requireActivity());
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View v = LayoutInflater.from(requireActivity()).inflate(R.layout.dialog_loader, null);
        dialog.setContentView(v);
        dialog.show();
    }

    class DELETE_DOC_11_RECE extends AsyncTask<Uri, Void, Boolean> {


        @Override
        protected Boolean doInBackground(Uri... uris) {

            if (uris != null && uris.length > 0) {
                Uri documentUri = uris[0];
                DocumentFile documentFile = DocumentFile.fromSingleUri(requireContext(), documentUri);




                size_path_log[selectedPos] = size_path_log[selectedPos] - documentFile.length();
                if (documentFile.exists()) {
                   try {
                        return documentFile.delete();
                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                }
            }

            return false;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onPostExecute(Boolean savers) {
            super.onPostExecute(savers);


        }


    }


}