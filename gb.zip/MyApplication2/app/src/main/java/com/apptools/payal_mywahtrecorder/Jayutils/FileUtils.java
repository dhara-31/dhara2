package com.apptools.payal_mywahtrecorder.Jayutils;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.os.Environment;
import android.os.StatFs;

import java.io.File;

public final class FileUtils {

    public static String getSaveDirectory(Context context) {
        if (!Environment.getExternalStorageState().equals("mounted")) {
            return null;
        }
        String str = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/" + context.getPackageName() + "/Video Call Recorder for Wahtzup/";
        File file = new File(str);
        if (!file.exists()) {
            file.mkdirs();
        }
        if (file.exists() || file.mkdirs()) {
            return str;
        }
        return null;
    }

    public static String getSave11Directory(Context context) {

        String str = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/" + context.getPackageName() + "/Video Call Recorder for Wahtzup/";
        File file = new File(str);
        if (file.exists() || file.mkdirs()) {
            return str;
        }
        return null;
    }

    public static String getFileName(String str) {
        String substring = str.substring(str.lastIndexOf("/") + 1);
        return substring.indexOf(".") != -1 ? substring.substring(0, substring.indexOf(".")) : substring;
    }

    public static String getVidoeDuration(MediaMetadataRetriever mediaMetadataRetriever) {
        int videoDurationMs = getVideoDurationMs(mediaMetadataRetriever) / 1000;
        int i = (videoDurationMs % 3600) / 60;
        int i2 = videoDurationMs % 60;
        int i3 = videoDurationMs / 3600;
        if (i3 > 0) {
            return String.format("%02d:%02d:%02d", Integer.valueOf(i3), Integer.valueOf(i), Integer.valueOf(i2));
        }
        return String.format("%02d:%02d", Integer.valueOf(i), Integer.valueOf(i2));
    }

    public static int getVideoDurationMs(MediaMetadataRetriever mediaMetadataRetriever) {
        try {
            return Integer.parseInt(mediaMetadataRetriever.extractMetadata(9));
        } catch (Exception e) {

        }
        return 0;
    }

    public static long getFileSize(String str) {
        return new File(str).length();
    }

    public static String convertByteToMB(long j) {
        StringBuilder sb = new StringBuilder();
        double d = (double) j;
        Double.isNaN(d);
        Double.isNaN(d);
        sb.append((int) Math.ceil((d / 1024.0d) / 1024.0d));
        sb.append("m");
        return sb.toString();
    }

    public static long getFreeSpaceInMB() {
        StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
        return ((statFs.getAvailableBlocksLong() * statFs.getBlockSizeLong()) / 1024) / 1024;
    }

}
