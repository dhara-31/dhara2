package com.apptools.payal_mywahtrecorder.JAydata;

import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import java.io.File;

public class Savers {

    private File file;
    private String title;
    private String path;
    private Uri uri;
    private long size;
    private DocumentFile documentFile;

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public Savers(File file, String title, String path, long size) {
        this.file = file;
        this.title = title;
        this.path = path;
        this.size = size;
    }

    public Savers(File file, String title, String path, Uri uri, long size, DocumentFile documentFile) {
        this.file = file;
        this.title = title;
        this.path = path;
        this.uri = uri;
        this.size = size;
        this.documentFile = documentFile;
    }

    public Savers(String title, Uri uri) {
        this.title = title;
        this.uri = uri;
    }

    public DocumentFile getDocumentFile() {
        return documentFile;
    }

    public void setDocumentFile(DocumentFile documentFile) {
        this.documentFile = documentFile;
    }

    public Savers() {

    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }
}
