package com.apptools.payal_mywahtrecorder.Jaylanguage

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isInvisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_ExitActivity
import com.apptools.payal_mywahtrecorder.R
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout
import com.apptools.payal_mywahtrecorder.ads.InterAdCall
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger
import com.apptools.payal_mywahtrecorder.ads.SmallNative
import com.apptools.payal_mywahtrecorder.ads.StartScreenActivity


class LanguageActivity : AppCompatActivity() {

    private lateinit var selectedModel: LanguageMainModel
    val rvLanguage: RecyclerView by lazy { findViewById(R.id.rv_language_main) }
    val btnDone: View by lazy { findViewById(R.id.btnDone) }
    lateinit var adapter: LanguageMainAdapter

    var issettingfrom = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language)
        issettingfrom = intent.getBooleanExtra("IS_FROM_SETTING", false)


        findViewById<View>(R.id.backPress).apply {
            isInvisible = intent.getBooleanExtra("IS_FROM_SETTING", false).not()
            setOnClickListener {
                finish()
            }
        }
        SmallNative.getNonLayoutBottom().smallnative(
            this, findViewById(R.id.relFasBanner),
            findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout)
        );
        rvLanguage.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)

        adapter = LanguageMainAdapter(this, setLanguageDefault()) { languageMainModel ->
            adapter.setSelectLanguage(languageMainModel)
            selectedModel = languageMainModel

        }
        BannerAdLayout.getFirstCallActime(
            this,
            findViewById(R.id.cardFbanner),
            findViewById(R.id.bannerAdfbcontainer),
            false
        );
        rvLanguage.adapter = adapter
        MixerIconMerger.showIconsHere(
            this,
            findViewById(R.id.relQicon1),
            findViewById(R.id.frameQicon1)
        );
        MixerIconMerger.showIconsHere(
            this,
            findViewById(R.id.relQicon2),
            findViewById(R.id.frameQicon2)
        );
        btnDone.setOnClickListener {
            SystemUtil.setPreLanguage(this@LanguageActivity, selectedModel.isoLanguage)


            InterAdCall.getHelpIndicatorExplicit().callintermethod(
                this@LanguageActivity, true
            ) { msg: String? ->

                startActivity(
                    Intent(
                        this,
                        StartScreenActivity::class.java
                    )
                )
            }

        }
    }


    override fun onBackPressed() {
        startActivity(Intent(this@LanguageActivity, JayHome_ExitActivity::class.java))

    }

    private fun setLanguageDefault(): ArrayList<LanguageMainModel> {
        val arrayList: ArrayList<LanguageMainModel> = ArrayList<LanguageMainModel>()
        val preLanguage: String = SystemUtil.getPreLanguage(this)
        arrayList.add(LanguageMainModel("English", "en", false, R.drawable.ic_language_english))
        arrayList.add(LanguageMainModel("Korean", "ko", false, R.drawable.ic_language_korean))
        arrayList.add(LanguageMainModel("Japanese", "ja", false, R.drawable.ic_language_japanese))
        arrayList.add(LanguageMainModel("French", "fr", false, R.drawable.ic_language_french))
        arrayList.add(LanguageMainModel("Hindi", "hi", false, R.drawable.ic_language_hindi))
        arrayList.add(
            LanguageMainModel(
                "Portuguese",
                "pt",
                false,
                R.drawable.ic_language_portuguese
            )
        )
        arrayList.add(LanguageMainModel("Spanish", "es", false, R.drawable.ic_language_spanish))
        arrayList.add(
            LanguageMainModel(
                "Indonesian",
                "in",
                false,
                R.drawable.ic_language_indonesian
            )
        )
        arrayList.add(LanguageMainModel("Malay", "ms", false, R.drawable.ic_language_malaysia))
        arrayList.add(
            LanguageMainModel(
                "Philippines",
                "fil",
                false,
                R.drawable.ic_language_philipinese
            )
        )
        arrayList.add(LanguageMainModel("German", "de", false, R.drawable.ic_language_german))

        arrayList.sortBy {
            it.languageName
        }

        for (i in arrayList.indices) {
            if (preLanguage == arrayList[i].isoLanguage) {
                arrayList[i].isCheck = true
                selectedModel = arrayList[i]
            }
        }
        return arrayList
    }

}