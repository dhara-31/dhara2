package com.apptools.payal_mywahtrecorder.JayTokandata;

import android.app.Activity;

import com.apptools.payal_mywahtrecorder.R;

public class Glob {
    public static String Edit_Folder_name = "Video Call Recorder for Wahtzup";


    public static String[] quotesCategoryList = new String[]{"Best ", "Cool ", "Cute ", "Love ", "Clever ", "Funny ", "Fitness ", "Life ", "Art ", "Sad "};


    public static String[] quotesCategoryList1Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_1_best);
    }
    public static String[] quotesCategoryList2Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_2_cool);
    }
    public static String[] quotesCategoryList3Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_3_cute);
    }
    public static String[] quotesCategoryList4Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_4_love);
    }
    public static String[] quotesCategoryList5Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_5_clever);
    }
    public static String[] quotesCategoryList6Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_6_funny);
    }
    public static String[] quotesCategoryList7Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_7_fitness);
    }
    public static String[] quotesCategoryList8Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_8_life);
    }
    public static String[] quotesCategoryList9Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_9_art);
    }
    public static String[] quotesCategoryList10Main(Activity context) {
        return context.getResources().getStringArray(R.array.quote_list_category_10_sad);
    }
}
