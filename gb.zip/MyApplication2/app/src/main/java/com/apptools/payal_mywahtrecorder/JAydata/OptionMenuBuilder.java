package com.apptools.payal_mywahtrecorder.JAydata;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class OptionMenuBuilder {
    private static final int[][] BIT_RATE_CONFIG;
    private static final int[][] COUNTDOWN_CONFIG = {new int[]{R.string.countdown_0, 0}, new int[]{R.string.countdown_1, 1}, new int[]{R.string.countdown_3, 3}, new int[]{R.string.countdown_5, 5}, new int[]{R.string.countdown_8, 8}};
    private static final int[][] FPS_CONFIG = {new int[]{R.string.fps_60, 60}, new int[]{R.string.fps_45, 45}, new int[]{R.string.fps_30, 30}, new int[]{R.string.fps_24, 24}, new int[]{R.string.fps_15, 15}};
    private static final int[][] RESOLUTION_CONFIG;
    private static int mb = 1048576;

    static {
        int i = mb;
        BIT_RATE_CONFIG = new int[][]{new int[]{R.string.bitrate_auto, 0}, new int[]{R.string.bitrate_12, i * 12}, new int[]{R.string.bitrate_10, i * 10}, new int[]{R.string.bitrate_8, i * 8}, new int[]{R.string.bitrate_5, i * 5}, new int[]{R.string.bitrate_3_5, (i * 3) + (i / 2)}, new int[]{R.string.bitrate_3, i * 3}, new int[]{R.string.bitrate_2_5, (i * 2) + (i / 2)}, new int[]{R.string.bitrate_2, i * 2}, new int[]{R.string.bitrate_1_5, (i * 1) + (i / 2)}};
        RESOLUTION_CONFIG = new int[][]{new int[]{R.string.resulution_1080p, 1920, 1080, i * 5}, new int[]{R.string.resulution_720p, 1280, 720, i * 3}, new int[]{R.string.resulution_540p, 960, 540, i * 2}, new int[]{R.string.resulution_480p, 800, 480, (i * 1) + (i / 2)}, new int[]{R.string.resulution_360p, 640, 360, i * 1}, new int[]{R.string.resulution_240p, 426, 240, i / 2}};
    }


    public static AlertDialog.Builder getBuilder(Context context, int i, DialogInterface.OnClickListener onClickListener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        if (i == 6) {
            builder.setTitle(R.string.label_countdown);
            builder.setItems(createMenuFromConfig(context, COUNTDOWN_CONFIG), onClickListener);
        } else if (i == 0) {
            builder.setTitle(R.string.label_resolution);
            builder.setItems(createMenuFromConfig(context, RESOLUTION_CONFIG), onClickListener);
        } else if (i == 1) {
            builder.setTitle(R.string.label_fps);
            builder.setItems(createMenuFromConfig(context, FPS_CONFIG), onClickListener);
        } else if (i != 2) {
            return null;
        } else {
            builder.setTitle(R.string.label_bitrate);
            builder.setItems(createMenuFromConfig(context, BIT_RATE_CONFIG), onClickListener);
        }
        builder.setNegativeButton(R.string.label_cacel, (DialogInterface.OnClickListener) null);
        return builder;
    }

    public static int[] getOption(int i) {
        if (i == 6) {
            return COUNTDOWN_CONFIG[DApplication.sP.getInt("option" + i, 2)];
        } else if (i == 0) {
            return RESOLUTION_CONFIG[DApplication.sP.getInt("option" + i, 1)];
        } else if (i == 1) {
            return FPS_CONFIG[DApplication.sP.getInt("option" + i, 2)];
        } else if (i != 2) {
            return null;
        } else {
            return BIT_RATE_CONFIG[DApplication.sP.getInt("option" + i, 0)];
        }
    }

    public static void setOption(int i, int i2) {
        SharedPreferences.Editor edit = DApplication.sP.edit();
        edit.putInt("option" + i, i2).apply();
    }

    private static String[] createMenuFromConfig(Context context, int[][] iArr) {
        String[] strArr = new String[iArr.length];
        for (int i = 0; i < iArr.length; i++) {
            strArr[i] = context.getString(iArr[i][0]);
        }
        return strArr;
    }
}
