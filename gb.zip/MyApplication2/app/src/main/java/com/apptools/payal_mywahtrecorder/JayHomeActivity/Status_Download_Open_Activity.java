package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.apptools.payal_mywahtrecorder.JayFragments.Download_w4b_Fragment;
import com.apptools.payal_mywahtrecorder.JayFragments.Download_wa_Fragment;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jayutils.PreferenceUtil;

public class Status_Download_Open_Activity extends AppCompatActivity {

    TextView tab_wa_txt, tab_w4b_txt;

    ViewPager download_viewPager;

    public static Download_wa_Fragment download_wa_fragment;

    public static Download_w4b_Fragment download_w4b_fragment;

    DownloadViewPagerAdapter doaloadViewPagerAdapter;

    int selected_value;

    ImageView download_back_img;

    PreferenceUtil preferenceUtil;


    public int check_wa_w4b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_download_open);

        tab_wa_txt = findViewById(R.id.tab_wa_txt);
        tab_w4b_txt = findViewById(R.id.tab_w4b_txt);

        download_viewPager = findViewById(R.id.download_viewPager);
        download_back_img = findViewById(R.id.download_back_img);

        Intent intent = getIntent();
        selected_value = intent.getIntExtra("selected_option", 1);


        preferenceUtil=new PreferenceUtil(Status_Download_Open_Activity.this);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        check_wa_w4b = preferenceUtil.getInt("add_value_off", 1);

        download_viewPager.setAdapter(doaloadViewPagerAdapter = new DownloadViewPagerAdapter(getSupportFragmentManager()));
        download_viewPager.setOffscreenPageLimit(2);
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));

        if (check_wa_w4b == 1) {

            download_viewPager.setCurrentItem(0);

            tab_wa_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));
            tab_w4b_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));

        } else if (check_wa_w4b == 2) {

            download_viewPager.setCurrentItem(1);


            tab_wa_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));
            tab_w4b_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));
        }

        download_viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                if (position == 0) {

                    tab_wa_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));
                    tab_w4b_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));


                } else if (position == 1) {

                    tab_wa_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));
                    tab_w4b_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));

                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        tab_wa_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                download_viewPager.setCurrentItem(0);

                tab_wa_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));
                tab_w4b_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));

            }
        });


        tab_w4b_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                download_viewPager.setCurrentItem(1);

                tab_wa_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_normal_bg));
                tab_w4b_txt.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_green_bg));

            }
        });

        download_back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();

            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    private class DownloadViewPagerAdapter extends FragmentPagerAdapter {

        public DownloadViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int pos) {
            switch (pos) {

                case 0:
                    download_wa_fragment = Download_wa_Fragment.newInstance(selected_value);
                    return download_wa_fragment;
                case 1:
                    download_w4b_fragment = Download_w4b_Fragment.newInstance(selected_value);
                    return download_w4b_fragment;

                default:
                    return Download_w4b_Fragment.newInstance(2);
            }
        }

        @Override
        public int getCount() {
            return 2;
        }
    }


}