package com.apptools.payal_mywahtrecorder.JaynewSplitter;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.daasuu.mp4compose.composer.Mp4Composer;
import com.apptools.payal_mywahtrecorder.LoadingVideos;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;

public class SelectSplitter extends AppCompatActivity {

    String fileName;
    String VideoPath;
    String DestPath;
    long duration;
    Mp4Composer mp4Composer;

    int totalSplitPart = 0;
    int videoNumber = 0;
    float videoPart = 0;
    long ST;
    long ET;

    VideoView videoView;
    ImageView vv_Action_Pause, vv_Action_Play, iv_back_Splitting;
    ImageView iv_10SecVideo, iv_20SecVideo, iv_30SecVideo;
    MediaController mediaControls;
    LinearLayout splitbtn;
    TextView tvduration;
    long selectedSec;
    CardView cardView;
    LoadingVideos loadingVideos;
    private Context activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_splitter);

        activity = this;

        iv_back_Splitting = findViewById(R.id.video_show_back_img);
        videoView = findViewById(R.id.vv_Spliter);
        vv_Action_Pause = findViewById(R.id.vv_Action_Pause);
        vv_Action_Play = findViewById(R.id.vv_Action_Play);
        iv_10SecVideo = findViewById(R.id.iv_10SecVideo);
        iv_20SecVideo = findViewById(R.id.iv_20SecVideo);
        iv_30SecVideo = findViewById(R.id.iv_30SecVideo);
        splitbtn = findViewById(R.id.splitbtn);
        tvduration = findViewById(R.id.tvduration);
        cardView = findViewById(R.id.CardView);

        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        loadingVideos = new LoadingVideos(SelectSplitter.this);
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        Intent intent = getIntent();
        VideoPath = intent.getStringExtra("VideoUrl");
        duration = intent.getLongExtra("duration", 0);
        fileName = intent.getStringExtra("fileName");

        videoView.setVideoPath(VideoPath);
        videoView.requestFocus();

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {

                if (mediaPlayer.getVideoHeight() > mediaPlayer.getVideoWidth()) {
                    cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    videoView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

                } else {
                    cardView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    videoView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                }
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int result = am.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    videoView.start();
                }
                vv_Action_Play.setVisibility(View.GONE);
                vv_Action_Pause.setVisibility(View.VISIBLE);
            }
        });

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                videoView.start();
            }
        });

        vv_Action_Play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int result = am.requestAudioFocus(focusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    videoView.start();
                }
                vv_Action_Play.setVisibility(View.GONE);
                vv_Action_Pause.setVisibility(View.VISIBLE);
            }
        });

        vv_Action_Pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                videoView.pause();
                vv_Action_Play.setVisibility(View.VISIBLE);
                vv_Action_Pause.setVisibility(View.GONE);
            }
        });

        Glide.with(this).load(VideoPath).into(iv_10SecVideo);
        Glide.with(this).load(VideoPath).into(iv_20SecVideo);
        Glide.with(this).load(VideoPath).into(iv_30SecVideo);

        File file = new File(getExternalFilesDir("").toString() + "/GBWahatzAps/video/");
        if (!file.exists()) {
            file.mkdirs();
        }

        iv_back_Splitting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        iv_10SecVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (duration > 10000) {

                    InterAdCall.getHelpIndicatorExplicit().callintermethod(SelectSplitter.this, true, msg -> {
                        Intent intent1 = new Intent(SelectSplitter.this, B_VSplitter.class);
                        intent1.putExtra("fileName", fileName);
                        intent1.putExtra("increase", 10000);
                        intent1.putExtra("VideoUrl", VideoPath);
                        intent1.putExtra("duration", duration);

                        startActivity(intent1);
                    });


                } else {
                    Toast.makeText(SelectSplitter.this, JemsProviderKt.getMyString(activity, R.string.video_is_below_10sec), Toast.LENGTH_SHORT).show();
                }
            }
        });

        iv_20SecVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (duration > 20000) {

                    InterAdCall.getHelpIndicatorExplicit().callintermethod(SelectSplitter.this, true, msg -> {
                        Intent intent1 = new Intent(SelectSplitter.this, B_VSplitter.class);
                        intent1.putExtra("fileName", fileName);
                        intent1.putExtra("increase", 20000);
                        intent1.putExtra("VideoUrl", VideoPath);
                        intent1.putExtra("duration", duration);


                        startActivity(intent1);
                    });



                } else {
                    Toast.makeText(SelectSplitter.this, JemsProviderKt.getMyString(activity, R.string.video_is_below_20sec), Toast.LENGTH_SHORT).show();

                }

            }
        });

        iv_30SecVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (duration > 30000) {

                    InterAdCall.getHelpIndicatorExplicit().callintermethod(SelectSplitter.this, true, msg -> {
                        Intent intent1 = new Intent(SelectSplitter.this, B_VSplitter.class);
                        intent1.putExtra("fileName", fileName);
                        intent1.putExtra("increase", 30000);
                        intent1.putExtra("VideoUrl", VideoPath);
                        intent1.putExtra("duration", duration);


                        startActivity(intent1);
                    });



                } else {
                    Toast.makeText(SelectSplitter.this, JemsProviderKt.getMyString(activity, R.string.video_is_below_30sec), Toast.LENGTH_SHORT).show();

                }
            }
        });

    }

    private AudioManager.OnAudioFocusChangeListener focusChangeListener = new AudioManager.OnAudioFocusChangeListener() {
        public void onAudioFocusChange(int focusChange) {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            switch (focusChange) {
                case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK):
                    videoView.pause();
                    vv_Action_Pause.setVisibility(View.GONE);
                    vv_Action_Play.setVisibility(View.VISIBLE);
                    break;
                case (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT):
                    videoView.pause();
                    vv_Action_Pause.setVisibility(View.GONE);
                    vv_Action_Play.setVisibility(View.VISIBLE);
                    break;
                case (AudioManager.AUDIOFOCUS_LOSS):
                    videoView.pause();
                    vv_Action_Pause.setVisibility(View.GONE);
                    vv_Action_Play.setVisibility(View.VISIBLE);
                    break;
                case (AudioManager.AUDIOFOCUS_GAIN):
                    break;
                default:
                    break;
            }
        }
    };


    @Override
    public void onBackPressed() {
        finish();
    }


}