package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.JayHomeadapter.AppListAdapter;
import com.apptools.payal_mywahtrecorder.JAydata.AppData;
import com.apptools.payal_mywahtrecorder.JAydata.AppInfo;
import com.apptools.payal_mywahtrecorder.JAydata.AppInfoType;
import com.apptools.payal_mywahtrecorder.JAydata.PerferencedName;
import com.apptools.payal_mywahtrecorder.Jayservice.ChangeModeService;
import com.apptools.payal_mywahtrecorder.Jayutils.AppUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.DatabaseUtils;
import com.apptools.payal_mywahtrecorder.Jayutils.Message;
import com.apptools.payal_mywahtrecorder.ads.DApplication;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.BasePermissionActivity;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.PermissionClass;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JayHome_Recorder_activity extends BasePermissionActivity {

    public Map<String, AppInfo> addedAppMap;
    public RecyclerView appList;
    public AppListAdapter appListAdapter;
    public ImageView btnOption;
    public ImageView btnVideo;

    public BroadcastReceiver receiver;
    public AppInfoType recordType;
    public DisplayMetrics screenMetrics;
    public Map<String, AppInfo> unAddedAppMap;

    public JayHome_Recorder_activity homeActivity;
    private MediaProjection mediaProjection;
    private MediaProjectionManager projectionManager;
    LinearLayout layProgress;

    View permissionLayoutForCallRecord;
    View mainLayoutForCallRecord;
    TextView permissionDescForCallRecord;
    TextView permissionButtonForCallRecord;
    boolean oneTime ;

    @Override
    public void onResumePermission() {

    }

    @Override
    public void onCreatePermission(@Nullable Bundle savedInstanceState) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_recorder_activitytools);
        homeActivity = this;

        ArrayList<String> permission = new ArrayList<>();
        permission.add(Manifest.permission.RECORD_AUDIO);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission.add(Manifest.permission.READ_MEDIA_VIDEO);
            permission.add(Manifest.permission.READ_MEDIA_IMAGES);
        } else {
            permission.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            permission.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        setPermissions(permission);


        mainLayoutForCallRecord = findViewById(R.id.mainLayoutForCallRecord);
        permissionLayoutForCallRecord = findViewById(R.id.permissionLayoutForCallRecord);
        permissionDescForCallRecord = findViewById(R.id.permissionDescForCallRecord);
        permissionButtonForCallRecord = findViewById(R.id.permissionButtonForCallRecord);
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));

        this.btnOption = (ImageView) findViewById(R.id.am_img_option);
        layProgress = findViewById(R.id.layProgress);
        this.btnOption.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_Recorder_activity.this, true, msg -> {
                    startActivity(new Intent(homeActivity, JayHome_OptionActivity.class));
                });

            }
        });


        ImageView iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.btnVideo = (ImageView) findViewById(R.id.am_img_videos);

        btnVideo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_Recorder_activity.this, true, msg -> {
                    startActivity(new Intent(homeActivity, JayHome_VideoListActivity.class).putExtra("openFirst", true));
                    finish();
                });



            }
        });


        this.appList = (RecyclerView) findViewById(R.id.am_app_list);
        this.appList.setLayoutManager(new GridLayoutManager(this, 1));
        this.appListAdapter = new AppListAdapter(1);

        permissionButtonForCallRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PermissionClass permissionHelper = getPermissionHelper();
                if (permissionHelper != null) {
                    permissionHelper.askPermission(homeActivity, true);
                }
            }
        });

    }

    @Override
    public void forceToOpenSetting(boolean need) {
        if (need) {
            permissionButtonForCallRecord.setText("Open Setting");
        } else {
            permissionButtonForCallRecord.setText("Permission Grant");
        }
    }

    boolean called = false;

    @Override
    public void permissionAllowCallBack(boolean permissionAllowed) {

        btnOption.setVisibility(View.GONE);
        mainLayoutForCallRecord.setVisibility(View.GONE);
        permissionLayoutForCallRecord.setVisibility(View.VISIBLE);

        if (permissionAllowed) {
            if (Settings.canDrawOverlays(homeActivity)) {
                btnOption.setVisibility(View.VISIBLE);
                mainLayoutForCallRecord.setVisibility(View.VISIBLE);
                permissionLayoutForCallRecord.setVisibility(View.GONE);
            } else {
                permissionDescForCallRecord.setText("Recording Screen, We need some basic permission for display over other apps on your phone. Click on Open Settings and turn on the switch to allow permission.");
                permissionButtonForCallRecord.setText("Open Setting");
                if (oneTime) {
                    startActivity(new Intent(homeActivity, JayHome_GuideDrawOverActivity.class).putExtra("key_screen_rec", true));
                    oneTime = false;
                }
            }

            if (called) {
                return;
            }
            called = true;
            if (Settings.canDrawOverlays(homeActivity)) {
                new asyncInitRecorder().execute();
            }
            permissionButtonForCallRecord.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (Settings.canDrawOverlays(homeActivity)) {
                        new asyncInitRecorder().execute();
                    } else {
                        startActivity(new Intent(homeActivity, JayHome_GuideDrawOverActivity.class).putExtra("key_screen_rec", true));
                    }

                }
            });


        } else {
            oneTime = true;
        }
    }

    public class asyncInitRecorder extends AsyncTask<Void, String, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            DApplication.checkRecordService();
            layProgress.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {


            initAppList();


            noticeCanOverlay();
            initReceiver();
            initScreen();

            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);

            appList.setAdapter(appListAdapter);
            layProgress.setVisibility(View.GONE);
        }
    }


    private void initScreen() {
        try {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getRealMetrics(displayMetrics);
            this.screenMetrics = displayMetrics;
            DApplication.screenWidth = displayMetrics.widthPixels;
            DApplication.screenHeight = displayMetrics.heightPixels;
            DApplication.screenDpi = displayMetrics.densityDpi;
        } catch (Exception e) {

        }

    }

    private void initReceiver() {
        this.receiver = new BroadcastReceiver() {

            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (action.equals(Message.SELECTE_APP)) {
                    String stringExtra = intent.getStringExtra("type");
                    String stringExtra2 = intent.getStringExtra("packageName");
                    if (stringExtra.equals(AppInfoType.NORMAL.toString())) {
                        int intExtra = intent.getIntExtra("tag", 0);
                        if (intExtra == 1) {
                            DApplication.currRecord.packageName = stringExtra2;
                            homeActivity.checkToRecord(AppInfoType.NORMAL);
                        } else if (intExtra == 2) {
                            AppInfo appInfo = homeActivity.addedAppMap.get(stringExtra2);
                            if (appInfo != null) {
                                homeActivity.appListAdapter.removeApp(appInfo);
                                homeActivity.addedAppMap.remove(stringExtra2);
                                homeActivity.unAddedAppMap.put(stringExtra2, appInfo);
                                return;
                            }
                            AppInfo appInfo2 = homeActivity.unAddedAppMap.get(stringExtra2);
                            homeActivity.appListAdapter.addApp(appInfo2);
                            homeActivity.addedAppMap.put(stringExtra2, appInfo2);
                            homeActivity.unAddedAppMap.remove(stringExtra2);
                        }
                    } else if (stringExtra.equals(AppInfoType.DESKTOP.toString())) {
                        DApplication.currRecord.packageName = null;
                        homeActivity.checkToRecord(AppInfoType.DESKTOP);
                    } else if (stringExtra.equals(AppInfoType.SELECT.toString())) {

                    }
                } else if (action.equals(Message.ADD_VIDEO)) {
                } else if (action.equals(Message.DELETE_VIDEO)) {
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Message.SELECTE_APP);
        intentFilter.addAction(Message.ADD_VIDEO);
        intentFilter.addAction(Message.DELETE_VIDEO);
        intentFilter.addAction(Message.RENAME_VIDEO);
        DApplication.getBm().registerReceiver(this.receiver, intentFilter);
    }

    private void recordDesktop() {

        DApplication.currRecord.packageName = null;
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        startActivity(intent);
    }


    private void checkToRecord(AppInfoType appInfoType) {

        if (DApplication.sP.getInt(PerferencedName.RECORD_MODE, 0) == 0) {
            this.recordType = appInfoType;

            homeActivity.updateMode(1);

            readyToRecord(homeActivity.recordType);


            return;
        }
        readyToRecord(appInfoType);
    }

    private void readyToRecord(AppInfoType appInfoType) {
        recordDesktop();

        DApplication.getBm().sendBroadcast(new Intent(Message.SHOW_RECORD_BUTTON));
    }

    private void initAppList() {
        List<AppInfo> installedAppList = AppUtils.getInstalledAppList();
        List<AppData> appsList = DatabaseUtils.getInstance().getAppsList();
        ArrayList<AppInfo> arrayList = new ArrayList<>();
        int size = installedAppList.size();
        HashMap<String, AppInfo> hashMap = new HashMap<>();
        for (int i = 0; i < size; i++) {
            AppInfo appInfo = installedAppList.get(i);
            hashMap.put(appInfo.pkg, appInfo);
        }
        int size2 = appsList.size();
        this.addedAppMap = new HashMap<>();
        for (int i2 = 0; i2 < size2; i2++) {
            AppInfo appInfo2 = hashMap.get(appsList.get(i2).packageName);
            if (appInfo2 != null) {
                arrayList.add(appInfo2);
                this.addedAppMap.put(appInfo2.pkg, appInfo2);
                hashMap.remove(appInfo2.pkg);
            }
        }
        this.unAddedAppMap = hashMap;
        this.appListAdapter.setAppList(arrayList);
        this.appListAdapter.addDesktopItem();
        this.appListAdapter.addSelectItem();


    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        DApplication.getBm().unregisterReceiver(this.receiver);

    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);


        if (i == 101) {
            if (i2 == -1) {

                this.mediaProjection = this.projectionManager.getMediaProjection(i2, intent);

                DApplication.screenProjection = this.mediaProjection;
                DApplication.getBm().sendBroadcast(new Intent(Message.GET_SCREEN_PROJECTION));
            }

        }

    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 102) {
            for (int i2 : iArr) {
                if (i2 != 0) {
                    alertToExit(R.string.tips_no_permision);
                    return;
                }
            }
            noticeCanOverlay();
        }
    }

    private void noticeCanOverlay() {

        try {
            DApplication.getOverlayPermision = true;
            DApplication.getBm().sendBroadcast(new Intent(Message.GET_OVER_LAY_PROMISSION));
        } catch (Exception e) {

        }

    }

    private void updateMode(int i) {
        Intent intent = new Intent(this, ChangeModeService.class);
        intent.putExtra("mode", i);
        startService(intent);
    }

    private void alertToExit(int i) {
        new AlertDialog.Builder(this).setTitle(R.string.app_name).setIcon(R.mipmap.ic_launcher).setMessage(i).setCancelable(false).setOnCancelListener(new DialogInterface.OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
                homeActivity.finish();
            }
        }).setNegativeButton(R.string.tips_confirm, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                homeActivity.finish();
            }
        }).create().show();
    }


}
