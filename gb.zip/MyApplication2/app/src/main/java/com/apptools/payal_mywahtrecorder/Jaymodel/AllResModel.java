package com.apptools.payal_mywahtrecorder.Jaymodel;

import com.apptools.payal_mywahtrecorder.ads.AppDetail;

import java.util.ArrayList;

public class AllResModel {
    private ArrayList<DeprecatedModelAd> adsdetail = new ArrayList<>();
    private AppDetail appdetail;

    public ArrayList<DeprecatedModelAd> getAdsdetail() {
        return adsdetail;
    }

    public void setAdsdetail(ArrayList<DeprecatedModelAd> adsdetail) {
        this.adsdetail = adsdetail;
    }

    public AppDetail getAppdetail() {
        return appdetail;
    }

    public void setAppdetail(AppDetail appdetail) {
        this.appdetail = appdetail;
    }

}
