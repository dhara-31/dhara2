package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.SaveSS;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.copyFile;
import static com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants.statusSaverActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.JayStatusSaver.Constants;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.Jayutils.jems.JemsProviderKt;

import java.io.File;

public class VS_Status_Image_Preview_Activity extends AppCompatActivity {

    ImageView preview_img;

    TextView image_preview_txt;

    ImageView status_delete_img, status_share_img, status_download;

    String image_path;

    boolean showDownload ;
    int preview_value;

    ImageView preview_back_img;
    private long mLastClickTime = 0l;
    private static final long CLICK_TIME_INTERVAL = 700;
    private Activity activity;

    @Override
    protected void onResume() {
        super.onResume();


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vs_status_image_preview);

        activity = this;

        Intent intent = getIntent();
        image_path = intent.getStringExtra("image_show");
        preview_value = intent.getIntExtra("preview_value", 2);
        showDownload = intent.getBooleanExtra("show_download", true);

        preview_img = findViewById(R.id.preview_img);
        image_preview_txt = findViewById(R.id.image_preview_txt);
        status_delete_img = findViewById(R.id.status_delete_img);
        status_share_img = findViewById(R.id.status_share_img);
        status_download = findViewById(R.id.status_download);

        preview_back_img = findViewById(R.id.preview_back_img);
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        checkDownload();
        status_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (image_path.contains("%2F")) {
                    SaveSS(image_path, Constants.getFileNameFromUri(activity, Uri.parse(image_path)), activity, (statusSaverActivity.isStatusAppPresent) ? statusSaverActivity.APP_DIR_WA : statusSaverActivity.APP_DIR_WAB);
                } else {
                    copyFile(new File(image_path), activity, (statusSaverActivity.isStatusAppPresent) ? statusSaverActivity.APP_DIR_WA : statusSaverActivity.APP_DIR_WAB);
                }
                checkDownload();
            }
        });


        Glide.with(VS_Status_Image_Preview_Activity.this).load(image_path).into(preview_img);

        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        status_delete_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                open_dialog_for_delete();

            }
        });

        status_share_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                long now = System.currentTimeMillis();
                if (now - mLastClickTime < CLICK_TIME_INTERVAL) {
                    return;
                }
                mLastClickTime = now;

                Uri picUri = FileProvider.getUriForFile(VS_Status_Image_Preview_Activity.this, getPackageName() + ".provider", new File(image_path));

                Intent intent = new Intent(Intent.ACTION_SEND);

                intent.putExtra(Intent.EXTRA_STREAM, picUri);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
                intent.setType("image/*");
                startActivity(Intent.createChooser(intent, "Share Via"));

            }
        });


        preview_back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();

            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    private void checkDownload() {
        status_download.setVisibility(View.GONE);
        status_share_img.setVisibility(View.GONE);
        status_delete_img.setVisibility(View.GONE);
        Constants.scanBothAppFile(this, image_path, new Constants.CallBackOfListFiles() {
            @Override
            public void checkFile(String selectedFilePath) {
                if (selectedFilePath.isEmpty()) {
                    status_download.setVisibility(View.VISIBLE);
                    status_share_img.setVisibility(View.GONE);
                    status_delete_img.setVisibility(View.GONE);
                } else {
                    status_download.setVisibility(View.GONE);
                    status_share_img.setVisibility(View.VISIBLE);
                    if (showDownload){
                        status_delete_img.setVisibility(View.VISIBLE);
                    }
                    image_path = selectedFilePath;
                }
            }
        });

    }

    private void open_dialog_for_delete() {

        final AlertDialog.Builder alert = new AlertDialog.Builder(VS_Status_Image_Preview_Activity.this);

        View mView = LayoutInflater.from(VS_Status_Image_Preview_Activity.this).inflate(R.layout.status_item_delete_dialog_layout, null);

        TextView delete_dialog_cancel_txt = (TextView) mView.findViewById(R.id.delete_dialog_cancel_txt);
        TextView delete_dialog_okay_txt = (TextView) mView.findViewById(R.id.delete_dialog_okay_txt);

        alert.setView(mView);
        final AlertDialog alertDialog = alert.create();
        alertDialog.setCanceledOnTouchOutside(false);

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        delete_dialog_cancel_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                alertDialog.dismiss();

            }
        });

        delete_dialog_okay_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                File file = new File(image_path);
                file.delete();

                MediaScannerConnection.scanFile(VS_Status_Image_Preview_Activity.this, new String[]{file.toString()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });

                finish();

                Toast.makeText(VS_Status_Image_Preview_Activity.this, JemsProviderKt.getMyString(getApplicationContext(), R.string.successfully_deleted), Toast.LENGTH_SHORT).show();


                alertDialog.dismiss();

            }
        });


        alertDialog.show();

    }
}