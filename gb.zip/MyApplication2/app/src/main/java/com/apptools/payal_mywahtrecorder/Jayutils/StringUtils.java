package com.apptools.payal_mywahtrecorder.Jayutils;

public class StringUtils {
    public static boolean equals(String str, String str2) {
        if (str == str2) {
            return true;
        }
        if (str == null || str2 == null) {
            return false;
        }
        return str.equals(str2);
    }
}
