package com.apptools.payal_mywahtrecorder.ads;

import android.app.Activity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.Jaymodel.MixerBannerModel;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;

import java.util.ArrayList;

public class BannerAdLayout {
    private static int detectorParse = 0;
    private static int[] actionList1 = new int[]{R.drawable.gamesmall1, R.drawable.gamesmall2, R.drawable.gamesmall3, R.drawable.gamesmall4, R.drawable.gamesmall5, R.drawable.gamesmall6,
            R.drawable.gamesmall7, R.drawable.gamesmall8};

    public static void fillMeAlone(Activity activity, RelativeLayout layoutHome, FrameLayout anotherLayout) {
        try {

            AppDetail adIdDetail = DApplication.getInstance().getAppDetails();
            if (adIdDetail != null && adIdDetail.getAdmobbanner() != null && !TextUtils.isEmpty(adIdDetail.getAdmobbanner()) && adIdDetail.getAdstatus().equalsIgnoreCase("1")) {
                com.google.android.gms.ads.AdView AdVieviddecgtmner = new com.google.android.gms.ads.AdView(activity);
                AdVieviddecgtmner.setAdSize(getAviddecgtmze(activity));
                AdVieviddecgtmner.setAdUnitId(adIdDetail.getAdmobbanner());
                AdRequest adRequest = new AdRequest.Builder().build();
                AdVieviddecgtmner.loadAd(adRequest);

                AdVieviddecgtmner.setAdListener(new com.google.android.gms.ads.AdListener() {
                    @Override
                    public void onAdLoaded() {
                        anotherLayout.addView(AdVieviddecgtmner);
                        super.onAdLoaded();
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        try {
                            fillMeAlone1(activity, layoutHome, anotherLayout);
                        } catch (Exception e) {

                        }
                    }
                });

            } else {
                try {

                    fillMeAlone1(activity, layoutHome, anotherLayout);
                } catch (Exception e) {

                }
            }
        } catch (Exception e) {

        }


    }

    private static com.google.android.gms.ads.AdSize getAviddecgtmze(Activity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth);
    }

    public static void fillMeAlone1(Activity activity, RelativeLayout layoutHome, FrameLayout anotherLayout) {
        try {
            if (DApplication.checkNetworkAvailable(activity)) {
                anotherLayout.setVisibility(View.VISIBLE);
                layoutHome.setVisibility(View.VISIBLE);
                final float scale = activity.getResources().getDisplayMetrics().density;
                int dp62 = (int) (62 * scale);
                int dp5 = (int) (5 * scale);
                int dp7 = (int) (7 * scale);
                int dp8 = (int) (8 * scale);

                View viewMe = activity.getLayoutInflater().inflate(R.layout.layout_qureka_small, null, true);
                FrameLayout.LayoutParams paramsFrameLayout = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp62);
                anotherLayout.addView(viewMe, paramsFrameLayout);

                RelativeLayout.LayoutParams paramsParentLayoutNew = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, dp62);
                paramsParentLayoutNew.setMargins(dp7, dp8, dp7, dp5);
                layoutHome.setLayoutParams(paramsParentLayoutNew);

                ArrayList<MixerBannerModel> mixerBannerModelArrayList = new ArrayList<>();
                try {
                    if (DApplication.getSizeWay() == 1) {
                        for (int resourceId : openlitAction) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 1);
                            mixerBannerModelArrayList.add(model);
                        }
                    } else if (DApplication.getSizeWay() == 2) {
                        for (int resourceId : actionList1) {
                            MixerBannerModel model = new MixerBannerModel(resourceId, 2);
                            mixerBannerModelArrayList.add(model);
                        }
                    } else {
                        mixerBannerModelArrayList = new ArrayList<>(actionList1.length + openlitAction.length);

                        int sizeSmall = Math.min(actionList1.length, openlitAction.length);

                        int heroCallInt = 0;
                        for (int i = 0; i < sizeSmall; i++) {
                            MixerBannerModel modelgame = new MixerBannerModel(actionList1[i], 2);
                            mixerBannerModelArrayList.add(heroCallInt++, modelgame);

                            MixerBannerModel modelqur = new MixerBannerModel(openlitAction[i], 1);
                            mixerBannerModelArrayList.add(heroCallInt++, modelqur);
                        }
                        if (actionList1.length > openlitAction.length) {
                            int newlength = actionList1.length - sizeSmall;
                            for (int i = 0; i < newlength; i++) {
                                MixerBannerModel mdelgame = new MixerBannerModel(actionList1[sizeSmall + i], 2);
                                mixerBannerModelArrayList.add(heroCallInt++, mdelgame);
                            }
                        } else {
                            int newlenght = openlitAction.length - sizeSmall;
                            for (int i = 0; i < newlenght; i++) {
                                MixerBannerModel modelqur = new MixerBannerModel(openlitAction[sizeSmall + i], 1);
                                mixerBannerModelArrayList.add(heroCallInt++, modelqur);
                            }
                        }
                    }
                } catch (Exception e) {
                    for (int resourceId : actionList1) {
                        MixerBannerModel mixerBannerModel = new MixerBannerModel(resourceId, 2);
                        mixerBannerModelArrayList.add(mixerBannerModel);
                    }
                }

                String actionToPerform = "";
                try {
                    if (DApplication.getSizeWay() == 1 && !DApplication.getTwoUrk()) {
                        actionToPerform = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                    } else if (DApplication.getSizeWay() == 2 && !DApplication.fourNativeUrl()) {
                        actionToPerform = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                    } else {
                        if (mixerBannerModelArrayList.get(detectorParse).getQurOrGame() == 1 && !DApplication.getTwoUrk()) {
                            actionToPerform = DApplication.getMeVcallApplication().getAppDetails().getAdmob3banner();
                        } else if (!DApplication.fourNativeUrl()) {
                            actionToPerform = DApplication.getMeVcallApplication().getAppDetails().getAdmob3native();
                        }
                    }
                } catch (Exception e) {

                }

                if (actionToPerform != null && !TextUtils.isEmpty(actionToPerform)) {
                    ImageView imgNewBannerQka = viewMe.findViewById(R.id.imgNewBannerQka);
                    try {
                        imgNewBannerQka.setImageResource(mixerBannerModelArrayList.get(detectorParse).getBannername());
                    } catch (Exception e) {
                        imgNewBannerQka.setImageResource(actionList1[0]);
                    }
                    detectorParse++;
                    try {
                        if (detectorParse >= mixerBannerModelArrayList.size()) {
                            detectorParse = 0;
                        }
                    } catch (Exception e) {
                        detectorParse = 0;
                    }

                    String finalLastURlToG = actionToPerform;
                    imgNewBannerQka.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            DApplication.tabToIntent(activity, finalLastURlToG);
                        }
                    });
                } else {
                    anotherLayout.setVisibility(View.INVISIBLE);
                    layoutHome.setVisibility(View.GONE);
                }

            } else {
                anotherLayout.setVisibility(View.INVISIBLE);
                layoutHome.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }

    }


    public static void getFirstCallActime(Activity activity, RelativeLayout layoutHome, FrameLayout layoutNative, boolean callToAct) {

        try {
            if (!InterAdCall.checkConnection(activity)) {
                layoutHome.setVisibility(View.GONE);
                return;
            }
            AppDetail myModelHelper = DApplication.getMeVcallApplication().getAppDetails();

            if (myModelHelper != null && myModelHelper.getAdstatus() != null && !TextUtils.isEmpty(myModelHelper.getAdstatus()) && myModelHelper.getAdstatus().equalsIgnoreCase("1")) {

                if (callToAct || DApplication.onePageHowMuchShown()) {
                    LayoutInflater layoutInflater = LayoutInflater.from(activity);
                    LinearLayout linearLayoutLoading = (LinearLayout) layoutInflater.inflate(R.layout.item_loader_banner, layoutNative, false);
                    layoutNative.addView(linearLayoutLoading);
                    layoutHome.setVisibility(View.VISIBLE);
                    try {
                        if (myModelHelper.getFbbanner() != null && !TextUtils.isEmpty(myModelHelper.getFbbanner())) {
                            AdView adView = new AdView(activity, myModelHelper.getFbbanner(), AdSize.BANNER_HEIGHT_50);
                            layoutNative.addView(adView);
                            adView.loadAd(adView.buildLoadAdConfig().withAdListener(new AdListener() {
                                @Override
                                public void onError(Ad ad, AdError adError) {
                                    linearLayoutLoading.setVisibility(View.GONE);
                                    fillMeAlone(activity, layoutHome, layoutNative);
                                }

                                @Override
                                public void onAdLoaded(Ad ad) {
                                    layoutNative.setVisibility(View.VISIBLE);
                                    layoutHome.setVisibility(View.VISIBLE);
                                    linearLayoutLoading.setVisibility(View.GONE);
                                }

                                @Override
                                public void onAdClicked(Ad ad) {

                                }

                                @Override
                                public void onLoggingImpression(Ad ad) {

                                }
                            }).build());
                        } else {
                            linearLayoutLoading.setVisibility(View.GONE);
                            fillMeAlone(activity, layoutHome, layoutNative);
                        }
                    } catch (Exception e) {

                    }
                } else {
                    fillMeAlone(activity, layoutHome, layoutNative);
                }


            } else {
                layoutNative.setVisibility(View.INVISIBLE);
                layoutHome.setVisibility(View.GONE);
            }
        } catch (Exception e) {

        }
    }


    private static int[] openlitAction = new int[]{R.drawable.qurekasmall1, R.drawable.qurekasmall2, R.drawable.qurekasmall3, R.drawable.qurekasmall4, R.drawable.qurekasmall5};


}
