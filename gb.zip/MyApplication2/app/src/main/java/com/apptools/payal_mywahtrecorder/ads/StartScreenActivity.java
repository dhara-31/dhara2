package com.apptools.payal_mywahtrecorder.ads;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.JayHomeActivity.JayHome_ExitActivity;

import com.apptools.payal_mywahtrecorder.R;


import java.util.ArrayList;

public class StartScreenActivity extends AppCompatActivity {
    static SharedPreferences.Editor editor;
    public static ArrayList<String> mResults = new ArrayList<>();

    private String gm;
    int i = 0;
    private SharedPreferences sp;

    AlertDialog alertDialog;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_start_screen);



        mResults.clear();

        setStoreToken(getResources().getString(R.string.app_name));
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        findViewById(R.id.privacy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    if (DApplication.getMeVcallApplication().getAppDetails() != null) {
                        if (DApplication.getMeVcallApplication().getAppDetails().getPrivacy() != null && !DApplication.getMeVcallApplication().getAppDetails().getPrivacy().trim().isEmpty()) {
                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(DApplication.getMeVcallApplication().getAppDetails().getPrivacy()));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.setPackage("com.android.chrome");
                            try {
                                startActivity(i);
                            } catch (ActivityNotFoundException e) {
                                i.setPackage(null);
                                startActivity(i);
                            }
                        } else {
                            Toast.makeText(StartScreenActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(StartScreenActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(StartScreenActivity.this, "Unable to open", Toast.LENGTH_SHORT).show();
                }

            }
        });
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        findViewById(R.id.start2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(StartScreenActivity.this, true, msg -> {
                    startActivity(new Intent(StartScreenActivity.this, HOmeActvitiy.class));
                });


            }
        });

        findViewById(R.id.buttonClickShareApp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - currMillis < totalTime) {
                    return;
                }
                currMillis = now;

                try {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", "Hey check out our app and share with your friends : https://play.google.com/store/apps/details?id=" + getPackageName());
                    intent.setType("text/plain");
                    startActivity(intent);
                } catch (Exception e) {

                }
            }
        });

        findViewById(R.id.buttonClickRateUs).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - currMillis < totalTime) {
                    return;
                }
                currMillis = now;

                try {
                    String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                } catch (ActivityNotFoundException e) {

                } catch (Exception e) {

                }
            }
        });

    }
    private long currMillis = 0;
    private static final long totalTime = 1300;

    private void setStoreToken(String str) {
        this.sp = getSharedPreferences(getPackageName(), 0);
        this.gm = this.sp.getString("gm", "");
        if (this.i == 0 && this.gm.equals("")) {
            SharedPreferences.Editor edit = this.sp.edit();
            edit.putString("gm", "0");
            edit.commit();
            this.gm = this.sp.getString("gm", "");
        }
        if (isOnline()) {
            try {
                if (this.gm.equals("0")) {

                    editor = this.sp.edit();
                    editor.putString("gm", "1");
                    editor.commit();
                }
            } catch (Exception unused) {
            }
        }
    }


    public boolean isOnline() {
        @SuppressLint("WrongConstant") NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }


    @Override
    public void onBackPressed() {

        startActivity(new Intent(StartScreenActivity.this, JayHome_ExitActivity.class));

    }


}
