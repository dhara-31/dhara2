package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.ads.HOmeActvitiy;
import com.bumptech.glide.Glide;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;

public class ResultActivity extends AppCompatActivity {
    private ImageView imgComplete;

    String path;

    static ResultActivity resultActivity = null;

    public static ResultActivity getInstance() {
        return resultActivity;
    }



    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_result);

        resultActivity = this;


        int intExtra = getIntent().getIntExtra("title", 0);
        if (intExtra != 0) {

        }
        path = getIntent().getStringExtra("path");
        this.imgComplete = (ImageView) findViewById(R.id.ar_img_complete);
        if (path != null) {
            Glide.with(this).load(path).into(imgComplete);
        }


        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), true);

        imgComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(ResultActivity.this, true, msg -> {
                    Intent intent2 = new Intent(ResultActivity.this, VideoPreviewActivity.class);
                    intent2.putExtra("videoPath", path);
                    startActivity(intent2);
                    finish();
                });

            }
        });
        findViewById(R.id.done_btn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
              startActivitiesInSequence();
            }
        });


    }

    private void startActivitiesInSequence() {

        Intent mainIntent = new Intent(this, HOmeActvitiy.class);
        Intent thirdActivityIntent = new Intent(this, JayHome_VideoListActivity.class).putExtra("openFirst", true);

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);

        stackBuilder.addNextIntent(mainIntent);
        stackBuilder.addNextIntent(thirdActivityIntent);

        PendingIntent pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);

        try {
            pendingIntent.send();
        } catch (PendingIntent.CanceledException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();


    }

}
