package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.apptools.payal_mywahtrecorder.HelperResize;
import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;

public class VS_Peview_Of_Video_Open_Activity extends AppCompatActivity {


    String preview_video_path;

    ImageView playPauseBtn, preview_back_img;
    VideoView videoView;

    @Override
    protected void onResume() {
        super.onResume();
        try {
            videoView.seekTo(duration);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vs_peview_of_video_opentools);

        videoView = findViewById(R.id.videoView);
        playPauseBtn = findViewById(R.id.v_p_play_img);

        preview_back_img = findViewById(R.id.preview_back_img);

        Intent intent = getIntent();
        preview_video_path = intent.getStringExtra("video_file_path");


        videoView.setVideoPath(preview_video_path);
        videoView.start();
        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        try {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            retriever.setDataSource(preview_video_path);

            int width = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int height = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));

            if (width > height) {
                HelperResize.getheightandwidth(this);
                HelperResize.setSize(findViewById(R.id.videoView), 920, 1100, true);
            } else {
                HelperResize.getheightandwidth(this);
                HelperResize.setHeight(this, findViewById(R.id.videoView), 1100);
            }
            retriever.release();
        } catch (Exception e) {

        }
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        videoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (videoView.isPlaying()) {


                    videoView.pause();
                    playPauseBtn.setVisibility(View.VISIBLE);
                    playPauseBtn.setImageResource(R.drawable.video_play_img_111);

                } else {

                    videoView.start();
                    playPauseBtn.setVisibility(View.GONE);

                }


            }
        });
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {

                videoView.setVideoPath(preview_video_path);
                videoView.start();

            }
        });

        preview_back_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        InterAdCall.callForAniimation(this);
    }

    int duration = 100;

    @Override
    protected void onPause() {
        super.onPause();

        try {
            playPauseBtn.setVisibility(View.VISIBLE);
            duration = videoView.getCurrentPosition();
            if (videoView.isPlaying()) {
                videoView.pause();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}