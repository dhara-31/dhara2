package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.content.BroadcastReceiver;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.JayHomeadapter.OptionListAdapter;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class JayHome_OptionActivity extends AppCompatActivity {
    private RecyclerView optionList;
    private BroadcastReceiver receiver;


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_optiontools);

        this.optionList = (RecyclerView) findViewById(R.id.ao_option_list);
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));
        this.optionList.setLayoutManager(new LinearLayoutManager(this));
        this.optionList.setAdapter(new OptionListAdapter(this));
        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        DApplication.getBm().unregisterReceiver(this.receiver);

    }

    @Override
    public void onBackPressed() {
        finish();
        InterAdCall.callForAniimation(this);
    }
}
