package com.apptools.payal_mywahtrecorder.Jaymodel;

public class MixerBannerModel {
    int bannername;
    int qurOrGame;

    public MixerBannerModel(int bannername, int qurOrGame) {
        this.bannername = bannername;
        this.qurOrGame = qurOrGame;
    }

    public MixerBannerModel() {
    }

    public int getBannername() {
        return bannername;
    }

    public int getQurOrGame() {
        return qurOrGame;
    }
}
