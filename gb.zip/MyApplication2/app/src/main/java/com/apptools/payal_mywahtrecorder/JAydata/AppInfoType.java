package com.apptools.payal_mywahtrecorder.JAydata;

public enum AppInfoType {
    NORMAL,
    DESKTOP,
    SELECT
}
