package com.apptools.payal_mywahtrecorder.Jaymodel;

public interface my_Item_Interface {

    void itemList(int position);
}
