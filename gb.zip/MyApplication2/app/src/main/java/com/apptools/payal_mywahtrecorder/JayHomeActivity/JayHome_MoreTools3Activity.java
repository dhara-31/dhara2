package com.apptools.payal_mywahtrecorder.JayHomeActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;


import com.apptools.payal_mywahtrecorder.R;
import com.apptools.payal_mywahtrecorder.ads.SmallNative;
import com.apptools.payal_mywahtrecorder.JaynewSplitter.PickVideo;
import com.apptools.payal_mywahtrecorder.ads.BannerAdLayout;
import com.apptools.payal_mywahtrecorder.ads.InterAdCall;
import com.apptools.payal_mywahtrecorder.ads.BigNativeAd;
import com.apptools.payal_mywahtrecorder.ads.MixerIconMerger;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class JayHome_MoreTools3Activity extends AppCompatActivity {

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_tools3);


        findViewById(R.id.itemClick_splitter).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_MoreTools3Activity.this, true, msg -> {
                    startActivity(new Intent(JayHome_MoreTools3Activity.this, PickVideo.class));
                });

            }
        });

        findViewById(R.id.itemClick_Cleaner).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_MoreTools3Activity.this, true, msg -> {
                    startActivity(new Intent(JayHome_MoreTools3Activity.this, JayHome_CleanerHomeMediaActivity.class));
                });

            }
        });

        findViewById(R.id.itemClick_CallRecorder).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InterAdCall.getHelpIndicatorExplicit().callintermethod(JayHome_MoreTools3Activity.this, true, msg -> {
                    startActivity(new Intent(JayHome_MoreTools3Activity.this, Quotes_sub_Activity.class).putExtra("categoryItemClick_key",4));
                });
            }
        });
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon4), findViewById(R.id.frameQicon4));

        BannerAdLayout.getFirstCallActime(this, findViewById(R.id.cardFbanner), findViewById(R.id.bannerAdfbcontainer), false);

        if (DApplication.getNativeButtonSizeWidthAndHeight() == 1 && !DApplication.compileTopsideLayout()) {
            BigNativeAd.bignative(this, findViewById(R.id.relFasNative), findViewById(R.id.frameFasLarge));
        } else {
            SmallNative.getNonLayoutBottom().smallnative(this, findViewById(R.id.relFasBanner),
                    findViewById(R.id.framefbattach), findViewById(R.id.nativelayfbsLayout));
        }


        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon1), findViewById(R.id.frameQicon1));
        MixerIconMerger.showIconsHere(this, findViewById(R.id.relQicon2), findViewById(R.id.frameQicon2));


    }

    @Override
    public void onBackPressed() {
        finish();
        InterAdCall.callForAniimation(this);
    }
}