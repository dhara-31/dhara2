package com.apptools.payal_mywahtrecorder.Jayutils;

import android.content.Context;
import android.content.SharedPreferences;

import com.apptools.payal_mywahtrecorder.R;


public class PreferenceUtil {


    public static final String SELECT_WHAZ = "select_wa_&_w4b";

    public static final String KeyUseThisFolder = "778899";
    public static final String SET_NIIK_TITAL = "nik_name";
    public static final String SET_SELECT_ITME = "set_select_item_path";
    public static final String SET_SELECT_TITAL = "set_select_tital";
    public static String PERMISS_W4bZ_TF = "w4bz_pri_tr_fl";
    private final SharedPreferences SP;
    public Context context;


    public PreferenceUtil(Context mContext) {
        context = mContext;
        SP = mContext.getSharedPreferences(mContext.getResources().getString(R.string.app_name), Context.MODE_MULTI_PROCESS);
    }

    public Context getContext() {
        return this.context;
    }

    public SharedPreferences.Editor getEditor() {
        return SP.edit();
    }

    public void putString(String key, String value) {
        getEditor().putString(key, value).commit();
    }

    public String getString(String key, String defValue) {
        return SP.getString(key, defValue);
    }

    public void putInt(String key, int value) {
        getEditor().putInt(key, value).commit();
    }

    public int getInt(String key, int defValue) {
        return SP.getInt(key, defValue);
    }
    public void putLong(String key, long value) {
        getEditor().putLong(key, value).commit();
    }

    public long getLong(String key) {
        return SP.getLong(key, 0l);
    }

    public void putBoolean(String key, boolean value) {
        getEditor().putBoolean(key, value).commit();
    }

    public boolean getBoolean(String key, boolean defValue) {
        return SP.getBoolean(key, defValue);
    }

    public void remove(String key) {
        getEditor().remove(key).commit();
    }

    public void clearPreferences() {
        getEditor().clear().commit();
    }
}
