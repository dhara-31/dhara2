package com.apptools.payal_mywahtrecorder.Jayutils;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.apptools.payal_mywahtrecorder.JAydata.AppInfo;
import com.apptools.payal_mywahtrecorder.JAydata.AppInfoType;
import com.apptools.payal_mywahtrecorder.ads.DApplication;

public class AppUtils {
    private static List<AppInfo> infoList;
    private static Map<String, AppInfo> infoMap;
    private static Map<String, Boolean> whiteMap;


    public static List<AppInfo> getInstalledAppList() {
        List<AppInfo> list = infoList;
        if (list != null) {
            return list;
        }
        initWhiteMap();
        PackageManager packageManager = DApplication.getContext().getPackageManager();
        String packageName = DApplication.getContext().getPackageName();
        List<PackageInfo> installedPackages = packageManager.getInstalledPackages(0);
        ArrayList arrayList = new ArrayList();
        infoMap = new HashMap();
        for (PackageInfo packageInfo : installedPackages) {
            AppInfo appInfo = new AppInfo();
            appInfo.pkgInfo = packageInfo;
            boolean z = true;
            if ((packageInfo.applicationInfo.flags & 1) == 0) {
                z = false;
            }
            appInfo.isSystem = z;
            appInfo.pkg = packageInfo.packageName;
            appInfo.name = packageManager.getApplicationLabel(packageInfo.applicationInfo).toString();
            appInfo.type = AppInfoType.NORMAL;
            if (whiteMap.containsKey(appInfo.pkg) || (!appInfo.isSystem && !packageName.equals(appInfo.pkg))) {
                arrayList.add(appInfo);
                infoMap.put(appInfo.pkg, appInfo);
            }
        }
        infoList = arrayList;
        return arrayList;
    }

    public static String getAppName(String str) {
        AppInfo appInfo = infoMap.get(str);
        return appInfo != null ? appInfo.name : str;
    }

    public static AppInfo getAppInfo(String str) {
        return infoMap.get(str);
    }

    private static void initWhiteMap() {
        if (whiteMap == null) {
            whiteMap = new HashMap();
            whiteMap.put("com.google.android.youtube", true);
        }
    }
}
